$ErrorActionPreference = "Continue"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$TunnelHttp = "__TUNNEL_HTTP__"
$TunnelWs   = "__TUNNEL_WS__/tunnel"
$SkipSetup  = __SKIP_SETUP__
$InstallMtr = __INSTALL_MTR__

if (-not $SkipSetup) {
    Clear-Host
    Write-Host "==================================================================" -ForegroundColor Cyan
    Write-Host "  ARENA AI v6.0 - YEREL GPU SES + HARITA + FIRTINA + ORMAN KART   " -ForegroundColor Cyan
    Write-Host "==================================================================" -ForegroundColor Cyan
    Write-Host ""

    $prevProg = $ProgressPreference
    $ProgressPreference = 'SilentlyContinue'

    $ModUrl = "$TunnelHttp/mod.jar"
    $TempJar = Join-Path $env:TEMP "arena-ai-bridge-v6.jar"
    Invoke-WebRequest -Uri $ModUrl -OutFile $TempJar -UseBasicParsing -TimeoutSec 180

    $FabricApiUrl = "https://cdn.modrinth.com/data/P7dR8mSH/versions/BPX6fK06/fabric-api-0.97.3%2B1.20.4.jar"
    $MtrModUrl    = "https://cdn.modrinth.com/data/XKPAmI6u/versions/Xurz5xWy/MTR-fabric-4.0.5%2B1.20.4.jar"

    # Gercek oyun klasorunu bul (.minecraft\game varsa DOGRUDAN orayi kullan, yanlislikla ust .minecraft'a yazma!)
    $CandidateRoots = @()
    if (Test-Path "$env:APPDATA\.minecraft\game") {
        $CandidateRoots += "$env:APPDATA\.minecraft\game"
    } elseif (Test-Path "$env:APPDATA\.tlauncher\legacy\Minecraft\game") {
        $CandidateRoots += "$env:APPDATA\.tlauncher\legacy\Minecraft\game"
    } elseif (Test-Path "$env:APPDATA\.tl\game") {
        $CandidateRoots += "$env:APPDATA\.tl\game"
    } elseif (Test-Path "$env:APPDATA\.minecraft") {
        $CandidateRoots += "$env:APPDATA\.minecraft"
    }

    $LegacyTtsDir = "$env:APPDATA\.minecraft\arena-tts"

    foreach ($Root in $CandidateRoots) {
        if (Test-Path $Root) {
            Write-Host "[*] Oyun dizini algilandi: $Root" -ForegroundColor Green
            $ModsDir = Join-Path $Root "mods"
            if (!(Test-Path $ModsDir)) {
                New-Item -ItemType Directory -Path $ModsDir -Force | Out-Null
            }

            # 0. Yerel DirectML GPU & RAM EMA Lightning Türkçe Ses Motoru (39 MB - tek sefer indirilir!)
            $TtsDir = Join-Path $Root "arena-tts"
            $ModelsDir = Join-Path $TtsDir "models"
            New-Item -ItemType Directory -Path $ModelsDir -Force | Out-Null

            # Eger ust .minecraft\arena-tts icinde daha onceden indirilmis dosyalar varsa 0.1 saniyede tasi/kopyala!
            if (($Root -ne "$env:APPDATA\.minecraft") -and (Test-Path $LegacyTtsDir)) {
                if ((Test-Path "$LegacyTtsDir\arena-onnx-directml.jar") -and !(Test-Path "$TtsDir\arena-onnx-directml.jar")) {
                    Copy-Item -Path "$LegacyTtsDir\arena-onnx-directml.jar" -Destination "$TtsDir\arena-onnx-directml.jar" -Force -ErrorAction SilentlyContinue
                }
                if (Test-Path "$LegacyTtsDir\models") {
                    Get-ChildItem -Path "$LegacyTtsDir\models" -File -ErrorAction SilentlyContinue | ForEach-Object {
                        $dst = Join-Path $ModelsDir $_.Name
                        if (!(Test-Path $dst)) {
                            Copy-Item -Path $_.FullName -Destination $dst -Force -ErrorAction SilentlyContinue
                        }
                    }
                }
            }

            $OrtJarDest = Join-Path $TtsDir "arena-onnx-directml.jar"
            Write-Host "[*] DirectML GPU & RAM EMA Lightning ses motoru kontrol ediliyor: $TtsDir" -ForegroundColor Cyan
            if (!(Test-Path $OrtJarDest) -or ((Get-Item $OrtJarDest).Length -lt 5000000)) {
                Invoke-WebRequest -Uri "$TunnelHttp/ema-asset/arena-onnx-directml.jar" -OutFile $OrtJarDest -UseBasicParsing -TimeoutSec 90
            }
            foreach ($ModelFile in @("meta.json", "text.onnx", "sound.onnx", "decoder.onnx")) {
                $MDest = Join-Path $ModelsDir $ModelFile
                if (!(Test-Path $MDest) -or ((Get-Item $MDest).Length -lt 100)) {
                    Write-Host "    -> Model indiriliyor (GPU/RAM icin): $ModelFile ..." -ForegroundColor DarkCyan
                    Invoke-WebRequest -Uri "$TunnelHttp/ema-asset/$ModelFile" -OutFile $MDest -UseBasicParsing -TimeoutSec 120
                }
            }
            Write-Host "[+] EMA Lightning DirectML GPU + RAM Turkce model hazir!" -ForegroundColor Green

            # 1. ArenaAI Bridge v6.0 guncelle (Minecraft aciksa kapanana kadar bekler ve aninda yazar!)
            $RemoteShaNow = ""
            try { $RemoteShaNow = (Invoke-WebRequest -Uri "$TunnelHttp/mod.sha" -UseBasicParsing -TimeoutSec 10).Content.Trim().ToLower() } catch {}
            $DestJar = Join-Path $ModsDir "arena-ai-bridge-1.0.0.jar"
            $WarnedLock = $false
            while ($true) {
                try {
                    Copy-Item -Path $TempJar -Destination $DestJar -Force -ErrorAction Stop
                    if ($RemoteShaNow) { Set-Content -Path "$DestJar.sha" -Value $RemoteShaNow -NoNewline -ErrorAction SilentlyContinue }
                    Write-Host "[+] ArenaAI Bridge v6.0.0 DOGRUDAN kuruldu: $DestJar" -ForegroundColor Green
                    break
                } catch {
                    if (-not $WarnedLock) {
                        Write-Host "[!] Minecraft su an acik (mod dosyasi kilitli)." -ForegroundColor Yellow
                        Write-Host "    -> Lutfen Minecraft'i KAPAT (bu pencereyi kapatma, kapattigin saniye v6.0 otomatik yuklenecek)..." -ForegroundColor Yellow
                        $WarnedLock = $true
                    }
                    Start-Sleep -Seconds 1
                }
            }

            # 2. Eger /mtr uzerinden cagrildiysa Fabric API + MTR 4.0.5 (1.20.4) otomatik kur!
            if ($InstallMtr) {
                $ExistingFabricApi = Get-ChildItem -Path $ModsDir -Filter "fabric-api*.jar" -ErrorAction SilentlyContinue
                if (-not $ExistingFabricApi) {
                    $FabDest = Join-Path $ModsDir "fabric-api-0.97.3+1.20.4.jar"
                    Write-Host "[*] Fabric API 0.97.3+1.20.4 indiriliyor (MTR icin zorunlu)..." -ForegroundColor Cyan
                    try {
                        Invoke-WebRequest -Uri $FabricApiUrl -OutFile $FabDest -UseBasicParsing -TimeoutSec 60
                        Write-Host "[+] Fabric API kuruldu: $FabDest" -ForegroundColor Green
                    } catch {
                        Write-Host "[!] Fabric API indirilemedi: $($_.Exception.Message)" -ForegroundColor Red
                    }
                } else {
                    Write-Host "[OK] Fabric API zaten kurulu: $($ExistingFabricApi[0].Name)" -ForegroundColor Green
                }

                $ExistingMtr = Get-ChildItem -Path $ModsDir -Filter "*MTR*1.20.4*.jar" -ErrorAction SilentlyContinue
                if (-not $ExistingMtr) {
                    $MtrDest = Join-Path $ModsDir "MTR-fabric-4.0.5+1.20.4.jar"
                    Write-Host "[*] Minecraft Transit Railway (MTR 4.0.5 - 81 MB) Modrinth'ten indiriliyor, lutfen bekle..." -ForegroundColor Cyan
                    try {
                        $prevProg = $ProgressPreference
                        $ProgressPreference = 'SilentlyContinue'
                        Invoke-WebRequest -Uri $MtrModUrl -OutFile $MtrDest -UseBasicParsing -TimeoutSec 300
                        $ProgressPreference = $prevProg
                        Write-Host "[+] MTR 4.0.5+1.20.4 basariyla kuruldu: $MtrDest" -ForegroundColor Green
                    } catch {
                        Write-Host "[!] MTR indirilemedi: $($_.Exception.Message)" -ForegroundColor Red
                    }
                } else {
                    Write-Host "[OK] MTR zaten kurulu: $($ExistingMtr[0].Name)" -ForegroundColor Green
                }
            }
        }
    }

    Write-Host ""
    Write-Host "[*] HAZIR! TLegacy'den 'Fabric 1.20.4' ile dunyana gir, canli baglanti basliyor..." -ForegroundColor Yellow
    Write-Host ""
}

$PrimaryGameRoot = if (Test-Path "$env:APPDATA\.minecraft\game") {
    "$env:APPDATA\.minecraft\game"
} elseif (Test-Path "$env:APPDATA\.tlauncher\legacy\Minecraft\game") {
    "$env:APPDATA\.tlauncher\legacy\Minecraft\game"
} elseif (Test-Path "$env:APPDATA\.tl\game") {
    "$env:APPDATA\.tl\game"
} else {
    "$env:APPDATA\.minecraft"
}
$PrimaryDestJar = Join-Path (Join-Path $PrimaryGameRoot "mods") "arena-ai-bridge-1.0.0.jar"

$CSharpSource = @"
#pragma warning disable SYSLIB0014
using System;
using System.Collections.Concurrent;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Net.WebSockets;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

public class ArenaBridgeV6
{
    private ClientWebSocket ws;
    private readonly SemaphoreSlim sendLock = new SemaphoreSlim(1, 1);
    private readonly ConcurrentDictionary<string, TcpClient> tcpConns = new ConcurrentDictionary<string, TcpClient>();
    private volatile int detectedUdpLanPort = -1;
    private volatile bool running = true;

    public void Start(string wsUrl, string httpBase, string destJarPath)
    {
        Thread udpThread = new Thread(ListenLanMulticast);
        udpThread.IsBackground = true;
        udpThread.Start();

        Thread modWatchThread = new Thread(() => AutoSyncModLoop(httpBase, destJarPath));
        modWatchThread.IsBackground = true;
        modWatchThread.Start();

        while (running)
        {
            try
            {
                RunSessionAsync(wsUrl).GetAwaiter().GetResult();
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("[~] Baglanti yenileniyor: " + ex.Message);
                Console.ResetColor();
            }
            CleanupTcp();
            Thread.Sleep(2000);
        }
    }

    private void ListenLanMulticast()
    {
        while (running)
        {
            UdpClient udp = null;
            try
            {
                udp = new UdpClient();
                udp.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
                udp.Client.Bind(new IPEndPoint(IPAddress.Any, 4445));
                udp.JoinMulticastGroup(IPAddress.Parse("224.0.2.60"));
                IPEndPoint ep = new IPEndPoint(IPAddress.Any, 0);
                while (running)
                {
                    byte[] data = udp.Receive(ref ep);
                    string msg = Encoding.UTF8.GetString(data);
                    Match m = Regex.Match(msg, @"\[AD\](\d+)\[/AD\]");
                    if (m.Success)
                    {
                        int p;
                        if (int.TryParse(m.Groups[1].Value, out p))
                        {
                            detectedUdpLanPort = p;
                        }
                    }
                }
            }
            catch
            {
                Thread.Sleep(3000);
            }
            finally
            {
                if (udp != null) { try { udp.Close(); } catch {} }
            }
        }
    }

    private async Task RunSessionAsync(string wsUrl)
    {
        using (ws = new ClientWebSocket())
        {
            ws.Options.KeepAliveInterval = TimeSpan.FromSeconds(15);
            await ws.ConnectAsync(new Uri(wsUrl), CancellationToken.None);

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("[OK] ArenaAI v3.0 Bulut Sunucusuna baglandi! Minecraft dunyasi bekleniyor...");
            Console.ResetColor();

            CancellationTokenSource cts = new CancellationTokenSource();
            Task hbTask = HeartbeatLoopAsync(cts.Token);

            try
            {
                await ReceiveLoopAsync(cts.Token);
            }
            finally
            {
                cts.Cancel();
                try { await hbTask; } catch {}
            }
        }
    }

    private async Task HeartbeatLoopAsync(CancellationToken ct)
    {
        int lastPrintedPort = -1;
        while (!ct.IsCancellationRequested && ws.State == WebSocketState.Open)
        {
            try
            {
                int statusCode;
                byte[] modBytes = RawLocalHttp("GET", "/status", null, 1800, out statusCode);
                if (statusCode == 200 && modBytes != null && modBytes.Length > 0)
                {
                    string jsonStr = Encoding.UTF8.GetString(modBytes);
                    int lanPort = ExtractInt(jsonStr, "lanPort", -1);
                    bool inWorld = jsonStr.IndexOf("\"inWorld\":true", StringComparison.OrdinalIgnoreCase) >= 0;
                    bool mtr = jsonStr.IndexOf("\"mtrLoaded\":true", StringComparison.OrdinalIgnoreCase) >= 0;
                    if (!inWorld) lanPort = -1;
                    if (lanPort > 0 && lanPort != lastPrintedPort)
                    {
                        lastPrintedPort = lanPort;
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.WriteLine("[OK] Minecraft Dunyasi & ArenaAI v3 Modu algilandi! (LAN: " + lanPort + (mtr ? " | MTR Aktif!" : "") + ")");
                        Console.ResetColor();
                    }
                    string b64 = Convert.ToBase64String(modBytes);
                    await SendRawJsonAsync("{\"type\":\"state\",\"modActive\":true,\"inWorld\":" + (inWorld ? "true" : "false") + ",\"lanPort\":" + lanPort + ",\"b64\":\"" + b64 + "\"}");
                }
                else
                {
                    int uPort = detectedUdpLanPort;
                    bool alive = uPort > 0 && CheckTcpAlive(uPort);
                    if (!alive) uPort = -1;
                    if (uPort > 0 && uPort != lastPrintedPort)
                    {
                        lastPrintedPort = uPort;
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.WriteLine("[OK] Vanilla LAN Dunyasi algilandi! (Port: " + uPort + ")");
                        Console.ResetColor();
                    }
                    await SendRawJsonAsync("{\"type\":\"state\",\"modActive\":false,\"inWorld\":" + (alive ? "true" : "false") + ",\"lanPort\":" + uPort + ",\"b64\":\"\"}");
                }
            }
            catch {}
            await Task.Delay(1500, ct);
        }
    }

    private bool CheckTcpAlive(int port)
    {
        try
        {
            using (TcpClient c = new TcpClient())
            {
                Task t = c.ConnectAsync("127.0.0.1", port);
                return t.Wait(250) && c.Connected;
            }
        }
        catch { return false; }
    }

    private async Task ReceiveLoopAsync(CancellationToken ct)
    {
        byte[] buf = new byte[65536];
        while (!ct.IsCancellationRequested && ws.State == WebSocketState.Open)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                WebSocketReceiveResult res;
                do
                {
                    res = await ws.ReceiveAsync(new ArraySegment<byte>(buf), ct);
                    if (res.MessageType == WebSocketMessageType.Close) return;
                    ms.Write(buf, 0, res.Count);
                } while (!res.EndOfMessage);

                string msg = Encoding.UTF8.GetString(ms.ToArray());
                HandleMessage(msg);
            }
        }
    }

    private void HandleMessage(string msg)
    {
        string type = ExtractStr(msg, "type");
        if (type == "tcp_open")
        {
            string connId = ExtractStr(msg, "connId");
            int port = ExtractInt(msg, "port", -1);
            Task.Run(() => OpenLocalTcpAsync(connId, port));
        }
        else if (type == "tcp_data")
        {
            string connId = ExtractStr(msg, "connId");
            string b64 = ExtractStr(msg, "b64");
            TcpClient tc;
            if (tcpConns.TryGetValue(connId, out tc))
            {
                try
                {
                    byte[] raw = Convert.FromBase64String(b64);
                    NetworkStream ns = tc.GetStream();
                    ns.Write(raw, 0, raw.Length);
                    ns.Flush();
                }
                catch
                {
                    CloseTcp(connId);
                }
            }
        }
        else if (type == "tcp_close")
        {
            string connId = ExtractStr(msg, "connId");
            CloseTcp(connId);
        }
        else if (type == "rpc")
        {
            Task.Run(() => HandleRpcAsync(msg));
        }
        else if (type == "log")
        {
            string b64 = ExtractStr(msg, "b64");
            if (!string.IsNullOrEmpty(b64))
            {
                string text = Encoding.UTF8.GetString(Convert.FromBase64String(b64));
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine(text);
                Console.ResetColor();
            }
        }
    }

    private async Task OpenLocalTcpAsync(string connId, int port)
    {
        TcpClient tc = new TcpClient();
        try
        {
            tc.NoDelay = true;
            await tc.ConnectAsync("127.0.0.1", port);
            tcpConns[connId] = tc;
            NetworkStream ns = tc.GetStream();
            byte[] buf = new byte[32768];
            while (tc.Connected && ws != null && ws.State == WebSocketState.Open)
            {
                int n = await ns.ReadAsync(buf, 0, buf.Length);
                if (n <= 0) break;
                string b64 = Convert.ToBase64String(buf, 0, n);
                await SendRawJsonAsync("{\"type\":\"tcp_data\",\"connId\":\"" + connId + "\",\"b64\":\"" + b64 + "\"}");
            }
        }
        catch {}
        finally
        {
            CloseTcp(connId);
            try { await SendRawJsonAsync("{\"type\":\"tcp_close\",\"connId\":\"" + connId + "\"}"); } catch {}
        }
    }

    private void CloseTcp(string connId)
    {
        TcpClient tc;
        if (tcpConns.TryRemove(connId, out tc))
        {
            try { tc.Close(); } catch {}
        }
    }

    private void CleanupTcp()
    {
        foreach (string k in tcpConns.Keys)
        {
            CloseTcp(k);
        }
    }

    private async Task HandleRpcAsync(string msg)
    {
        string reqId = ExtractStr(msg, "reqId");
        string action = ExtractStr(msg, "action");
        try
        {
            if (action == "mod_http")
            {
                string method = ExtractStr(msg, "method");
                string path = ExtractStr(msg, "path");
                string b64Body = ExtractStr(msg, "b64");
                byte[] bodyBytes = string.IsNullOrEmpty(b64Body) ? null : Convert.FromBase64String(b64Body);
                int status;
                byte[] resp = RawLocalHttp(method, path, bodyBytes, 25000, out status);
                string outB64 = resp != null ? Convert.ToBase64String(resp) : "";
                await SendRawJsonAsync("{\"type\":\"rpc_res\",\"reqId\":\"" + reqId + "\",\"status\":" + status + ",\"b64\":\"" + outB64 + "\"}");
            }
            else
            {
                await SendRawJsonAsync("{\"type\":\"rpc_res\",\"reqId\":\"" + reqId + "\",\"status\":501,\"b64\":\"\"}");
            }
        }
        catch (Exception ex)
        {
            string errB64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(ex.Message));
            await SendRawJsonAsync("{\"type\":\"rpc_res\",\"reqId\":\"" + reqId + "\",\"status\":500,\"b64\":\"" + errB64 + "\"}");
        }
    }

    private byte[] RawLocalHttp(string method, string path, byte[] body, int timeoutMs, out int statusCode)
    {
        statusCode = 0;
        try
        {
            using (TcpClient tc = new TcpClient())
            {
                tc.ReceiveTimeout = timeoutMs;
                tc.SendTimeout = timeoutMs;
                Task ct = tc.ConnectAsync("127.0.0.1", 25580);
                if (!ct.Wait(Math.Min(timeoutMs, 1500)) || !tc.Connected) return null;

                NetworkStream ns = tc.GetStream();
                int len = body != null ? body.Length : 0;
                string reqHead = method + " " + path + " HTTP/1.1\r\n" +
                                 "Host: 127.0.0.1:25580\r\n" +
                                 "Content-Type: application/json; charset=utf-8\r\n" +
                                 "Content-Length: " + len + "\r\n" +
                                 "Connection: close\r\n\r\n";
                byte[] headBytes = Encoding.ASCII.GetBytes(reqHead);
                ns.Write(headBytes, 0, headBytes.Length);
                if (len > 0) ns.Write(body, 0, len);
                ns.Flush();

                using (MemoryStream ms = new MemoryStream())
                {
                    byte[] buf = new byte[16384];
                    int r;
                    while ((r = ns.Read(buf, 0, buf.Length)) > 0)
                    {
                        ms.Write(buf, 0, r);
                    }
                    byte[] all = ms.ToArray();
                    int sep = FindHeaderEnd(all);
                    if (sep < 0) return null;
                    string headStr = Encoding.ASCII.GetString(all, 0, sep);
                    string[] firstLine = headStr.Split('\r', '\n')[0].Split(' ');
                    if (firstLine.Length >= 2) int.TryParse(firstLine[1], out statusCode);
                    int bodyLen = all.Length - (sep + 4);
                    byte[] respBody = new byte[bodyLen];
                    if (bodyLen > 0) Buffer.BlockCopy(all, sep + 4, respBody, 0, bodyLen);
                    return respBody;
                }
            }
        }
        catch { return null; }
    }

    private static int FindHeaderEnd(byte[] b)
    {
        for (int i = 0; i <= b.Length - 4; i++)
        {
            if (b[i] == 13 && b[i + 1] == 10 && b[i + 2] == 13 && b[i + 3] == 10) return i;
        }
        return -1;
    }

    private async Task SendRawJsonAsync(string json)
    {
        if (ws == null || ws.State != WebSocketState.Open) return;
        byte[] data = Encoding.UTF8.GetBytes(json);
        await sendLock.WaitAsync();
        try
        {
            if (ws.State == WebSocketState.Open)
            {
                await ws.SendAsync(new ArraySegment<byte>(data), WebSocketMessageType.Text, true, CancellationToken.None);
            }
        }
        finally
        {
            sendLock.Release();
        }
    }

    private static string ExtractStr(string json, string key)
    {
        Match m = Regex.Match(json, "\"" + Regex.Escape(key) + "\"\\s*:\\s*\"([^\"]*)\"");
        return m.Success ? m.Groups[1].Value : "";
    }

    private static int ExtractInt(string json, string key, int defVal)
    {
        Match m = Regex.Match(json, "\"" + Regex.Escape(key) + "\"\\s*:\\s*(-?\\d+)");
        int v;
        return (m.Success && int.TryParse(m.Groups[1].Value, out v)) ? v : defVal;
    }

    private void AutoSyncModLoop(string httpBase, string destJarPath)
    {
        string lastWarnedSha = "";
        while (running)
        {
            try
            {
                if (!string.IsNullOrEmpty(httpBase) && !string.IsNullOrEmpty(destJarPath))
                {
                    string remoteSha = "";
                    using (WebClient wc = new WebClient())
                    {
                        remoteSha = wc.DownloadString(httpBase + "/mod.sha").Trim().ToLowerInvariant();
                    }
                    if (remoteSha.Length >= 16)
                    {
                        string shaFile = destJarPath + ".sha";
                        string localSha = (File.Exists(destJarPath) && File.Exists(shaFile))
                            ? File.ReadAllText(shaFile).Trim().ToLowerInvariant()
                            : "";
                        if (localSha != remoteSha)
                        {
                            string tmp = Path.Combine(Path.GetTempPath(), "arena-auto-mod.jar");
                            using (WebClient wc = new WebClient())
                            {
                                wc.DownloadFile(httpBase + "/mod.jar", tmp);
                            }
                            try
                            {
                                string dir = Path.GetDirectoryName(destJarPath);
                                if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
                                File.Copy(tmp, destJarPath, true);
                                File.WriteAllText(shaFile, remoteSha);
                                Console.ForegroundColor = ConsoleColor.Green;
                                Console.WriteLine("[OTO-GUNCELLEME] Yeni mod surumu otomatik olarak " + destJarPath + " konumuna kuruldu!");
                                Console.ResetColor();
                            }
                            catch
                            {
                                if (lastWarnedSha != remoteSha)
                                {
                                    lastWarnedSha = remoteSha;
                                    Console.ForegroundColor = ConsoleColor.Cyan;
                                    Console.WriteLine("[OTO-GUNCELLEME] Yeni mod hazir; Minecraft kapandigi saniye otomatik olarak .minecraft\\game\\mods icine yazilacak.");
                                    Console.ResetColor();
                                }
                            }
                        }
                    }
                }
            }
            catch {}
            Thread.Sleep(5000);
        }
    }
}
"@

if (-not ("ArenaBridgeV6" -as [type])) {
    if ($PSVersionTable.PSVersion.Major -ge 7) {
        try {
            Add-Type -TypeDefinition $CSharpSource -Language CSharp -IgnoreWarnings -ErrorAction Stop
        } catch {
            $WinPS = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
            if (Test-Path $WinPS) {
                $NextEndpoint = if ($InstallMtr) { "mtr5" } else { "win5" }
                & $WinPS -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; irm '$TunnelHttp/$NextEndpoint' | iex"
                return
            }
            throw
        }
    } else {
        Add-Type -TypeDefinition $CSharpSource -Language CSharp
    }
}

$Bridge = New-Object ArenaBridgeV6
$Bridge.Start($TunnelWs, $TunnelHttp, $PrimaryDestJar)

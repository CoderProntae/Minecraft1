const BASE = 'http://127.0.0.1:8080';
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

async function act(body) {
  for (let i = 0; i < 4; i++) {
    const r = await fetch(BASE + '/api/act', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...body, force: true })
    });
    const d = await r.json();
    if (d && d.ok !== false) return d;
    await sleep(250);
  }
  return { ok: false };
}

async function cmd(c) {
  return act({ action: 'command', command: c });
}

// Measured rim profiles from WorldContextAnalyzer heightGridStep4:
// z:    52, 56, 60, 64, 68, 72, 76, 80, 84
const Z_PTS   = [52, 56, 60, 64, 68, 72, 76, 80, 84];
const WEST_Y  = [63, 65, 67, 68, 69, 70, 71, 71, 70]; // x = -26
const EAST_Y  = [63, 63, 66, 66, 67, 68, 69, 69, 70]; // x = -12

function interpProfile(arr, z) {
  if (z <= Z_PTS[0]) return arr[0];
  if (z >= Z_PTS[Z_PTS.length - 1]) return arr[arr.length - 1];
  for (let i = 0; i < Z_PTS.length - 1; i++) {
    if (z >= Z_PTS[i] && z <= Z_PTS[i + 1]) {
      const t = (z - Z_PTS[i]) / (Z_PTS[i + 1] - Z_PTS[i]);
      return arr[i] + t * (arr[i + 1] - arr[i]);
    }
  }
  return 63;
}

async function sendBatches(ops, batchSize = 240) {
  for (let i = 0; i < ops.length; i += batchSize) {
    const slice = ops.slice(i, i + batchSize);
    await act({ action: 'build', ops: slice, recordUndo: false, strictPhysics: false, cleanFloating: false });
    await sleep(60);
  }
}

async function main() {
  await act({ action: 'stop' });
  // Keep ArenaAI safely high in open air!
  await cmd('tp ArenaAI -18 76 50');
  await sleep(250);

  // ==================== PART 1: SMOOTH BILINEAR HILLSIDE RESTORATION (z=54..83, x=-25..-13) ====================
  const hillOps = [];
  for (let z = 54; z <= 83; z++) {
    const wy = interpProfile(WEST_Y, z);
    const ey = interpProfile(EAST_Y, z);
    // Smooth S-curve fade near north toe (z=54..58) and south crest (z=80..83)
    const southBlend = z >= 79 ? (z - 79) / 5.0 : 0.0;

    for (let x = -25; x <= -13; x++) {
      const tx = (x - (-26)) / ((-12) - (-26)); // 0 at west (-26), 1 at east (-12)
      let h = wy * (1 - tx) + ey * tx;
      // Subtle natural organic crown (+0.55 in center of hill) so it never looks flat/boxy
      const crown = Math.sin(tx * Math.PI) * 0.55 * Math.min(1.0, (z - 53) / 10.0);
      if (southBlend > 0) {
        h = h * (1 - southBlend) + 70.3 * southBlend;
      } else {
        h += crown;
      }
      const topY = Math.max(63, Math.min(71, Math.round(h)));

      // Fill dirt from y=63 up to topY-1, then grass_block/moss_block at topY
      for (let y = 63; y < topY; y++) {
        hillOps.push({ x, y, z, block: 'minecraft:dirt' });
      }
      const hash = Math.abs((x * 73856093) ^ (z * 19349663)) % 17;
      const surfBlock = (hash === 0 || hash === 5) ? 'minecraft:moss_block' : 'minecraft:grass_block';
      hillOps.push({ x, y: topY, z, block: surfBlock });

      // Scatter natural woodland ferns & short grass on top
      if (topY >= 64 && hash === 2) {
        hillOps.push({ x, y: topY + 1, z, block: 'minecraft:fern' });
      } else if (topY >= 64 && (hash === 7 || hash === 11)) {
        hillOps.push({ x, y: topY + 1, z, block: 'minecraft:short_grass' });
      }
    }
  }

  // Plant 2 natural spruce trees on the restored hillside so it blends 100% into Kuzey Orman!
  function addSmallSpruce(tx, baseY, tz) {
    for (let dy = 0; dy < 6; dy++) {
      hillOps.push({ x: tx, y: baseY + dy, z: tz, block: 'minecraft:spruce_log[axis=y]' });
    }
    const layers = [
      { dy: 2, r: 2 }, { dy: 3, r: 1 }, { dy: 4, r: 2 }, { dy: 5, r: 1 }, { dy: 6, r: 0 }
    ];
    for (const { dy, r } of layers) {
      for (let dx = -r; dx <= r; dx++) {
        for (let dz = -r; dz <= r; dz++) {
          if (dx === 0 && dz === 0 && dy < 6) continue;
          if (r === 2 && Math.abs(dx) === 2 && Math.abs(dz) === 2) continue;
          hillOps.push({
            x: tx + dx,
            y: baseY + dy,
            z: tz + dz,
            block: 'minecraft:spruce_leaves[distance=1,persistent=true,waterlogged=false]'
          });
        }
      }
    }
  }
  addSmallSpruce(-22, 69, 69);
  addSmallSpruce(-16, 69, 76);

  console.log('Applying smooth hillside ops:', hillOps.length);
  await sendBatches(hillOps, 260);

  // ==================== PART 2: BRIDGE <-> STATION ENTRANCE TIMBER & STONE FOOTPATH ====================
  // Watchtower sits at x=-35..-30, z=20..25; Station Lodge sits at x=-29..-25, z=20..29 (front doorway at z=18..19).
  // Wooden river bridge lands at x=-35..-31, z=26..28 (y=62..63).
  await cmd('tp ArenaAI -26 70 20');
  await sleep(250);

  const pathOps = [];
  const pathCells = [];

  // A) Bridge East Landing Deck (x=-34..-30, z=26..29 -> smooth y=63 spruce boardwalk deck over shoreline y=62)
  for (let x = -34; x <= -30; x++) {
    for (let z = 26; z <= 29; z++) {
      pathCells.push({ x, y: 63, z, mat: (z === 27 || z === 28) ? 'minecraft:spruce_planks' : 'minecraft:mossy_stone_bricks' });
    }
  }
  // Half-slab step down to meet bridge deck if bridge is at y=62.5/63 at x=-35
  for (let z = 26; z <= 28; z++) {
    pathCells.push({ x: -35, y: 63, z, mat: 'minecraft:spruce_slab[type=bottom,waterlogged=false]' });
  }

  // B) South-Gable Curve (x=-31..-23, z=30..31 at y=63)
  for (let x = -31; x <= -23; x++) {
    for (let z = 30; z <= 31; z++) {
      pathCells.push({ x, y: 63, z, mat: (z === 30) ? 'minecraft:spruce_planks' : 'minecraft:mossy_cobblestone' });
    }
  }

  // C) East Lodge Promenade (x=-24..-23, z=18..30 at y=63) leading straight to Front Porch!
  for (let z = 18; z <= 30; z++) {
    pathCells.push({ x: -24, y: 63, z, mat: 'minecraft:spruce_planks' });
    pathCells.push({ x: -23, y: 63, z, mat: 'minecraft:mossy_cobblestone' });
  }

  // D) Expanded Front Entrance Plaza & North Riverfront Walk past Watchtower (x=-34..-23, z=17..19 at y=63)
  for (let x = -34; x <= -23; x++) {
    for (let z = 17; z <= 19; z++) {
      if (x >= -29 && x <= -25 && z >= 18) continue; // Keep existing lodge porch & hanging lanterns intact
      pathCells.push({ x, y: 63, z, mat: (z === 18) ? 'minecraft:spruce_planks' : 'minecraft:mossy_stone_bricks' });
    }
  }

  for (const c of pathCells) {
    // Solid foundation at y=62 in case of river edge water/mud
    pathOps.push({ x: c.x, y: 62, z: c.z, block: 'minecraft:mossy_cobblestone' });
    pathOps.push({ x: c.x, y: c.y, z: c.z, block: c.mat });
    // Clear any tall grass/reeds on the walkway (never touching lodge or watchtower!)
    pathOps.push({ x: c.x, y: c.y + 1, z: c.z, block: 'minecraft:air' });
    pathOps.push({ x: c.x, y: c.y + 2, z: c.z, block: 'minecraft:air' });
  }

  // Warm Timber Guide Lamp Posts along the footpath
  for (const [lx, lz] of [[-33, 29], [-23, 31], [-22, 24], [-23, 17], [-32, 17]]) {
    pathOps.push({ x: lx, y: 63, z: lz, block: 'minecraft:mossy_stone_bricks' });
    pathOps.push({ x: lx, y: 64, z: lz, block: 'minecraft:spruce_fence[east=false,north=false,south=false,waterlogged=false,west=false]' });
    pathOps.push({ x: lx, y: 65, z: lz, block: 'minecraft:lantern[hanging=false,waterlogged=false]' });
  }

  console.log('Applying bridge-to-entrance footpath ops:', pathOps.length);
  await sendBatches(pathOps, 240);

  await act({ action: 'follow', target: 'ilkan', distance: 4 });
  console.log('HEAL_NORTH_SURFACE_DONE');
}

main().catch(e => { console.error(e); process.exit(1); });

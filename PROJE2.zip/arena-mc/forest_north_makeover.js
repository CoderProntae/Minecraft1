const BASE = 'http://127.0.0.1:8080';
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

async function act(body) {
  for (let i = 0; i < 5; i++) {
    const r = await fetch(BASE + '/api/act', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...body, force: true })
    });
    const d = await r.json();
    if (d && d.ok !== false) return d;
    await sleep(300);
  }
  return { ok: false };
}

async function cmd(c) {
  await act({ action: 'command', command: c });
}

async function main() {
  await act({ action: 'stop' });

  // 1. Seal the tiny sky gap at z=83..86 above tunnel ceiling!
  await cmd('fill -21 53 82 -15 62 86 minecraft:stone_bricks');
  await cmd('fill -21 63 82 -15 63 86 minecraft:grass_block');

  // 2. Transform Platform Hall Walls, Ceiling & Floor from Hospital-White Quartz to Warm Nordic Forest Timber & Mossy Stone!
  // East track wall (x=-15, z=20..44) & West wall segments (x=-28)
  await cmd('fill -15 49 20 -15 53 44 minecraft:mossy_stone_bricks');
  await cmd('fill -15 51 20 -15 51 44 minecraft:green_concrete');
  await cmd('fill -28 49 26 -28 53 34 minecraft:mossy_stone_bricks');
  await cmd('fill -28 51 26 -28 51 34 minecraft:green_concrete');
  // North & South end headwalls (z=19 and z=45) in mossy stone + timber
  await cmd('fill -28 49 19 -20 54 19 minecraft:mossy_stone_bricks');
  await cmd('fill -28 49 45 -20 54 45 minecraft:mossy_stone_bricks');

  // Vaulted Warm Spruce Timber Ceiling (y=55)
  await cmd('fill -27 55 20 -16 55 44 minecraft:spruce_planks');

  // Natural Forest Slate + Spruce Boardwalk Platform Floor (y=48, x=-27..-22, z=20..44)
  await cmd('fill -27 48 20 -22 48 44 minecraft:polished_andesite');
  await cmd('fill -26 48 20 -26 48 44 minecraft:spruce_planks');
  await cmd('fill -23 48 20 -23 48 44 minecraft:spruce_planks');

  // Mezzanine Forest Timber & Stone Restyle (y=56..62)
  await cmd('fill -28 56 21 -22 56 39 minecraft:spruce_planks');
  await cmd('fill -28 62 21 -22 62 39 minecraft:spruce_planks');
  await cmd('fill -29 57 20 -29 61 40 minecraft:mossy_stone_bricks');
  await cmd('fill -21 57 20 -21 61 40 minecraft:mossy_stone_bricks');
  // Re-open Flight 1 & Flight 2 stair openings cleanly
  await cmd('fill -28 57 21 -26 66 28 minecraft:air');
  await cmd('fill -24 49 25 -22 57 33 minecraft:air');

  // Surface Forest Timber Lodge Entrance Pavilion (x=-29..-25, z=20..29, y=63..69)
  await cmd('fill -29 63 18 -25 63 21 minecraft:mossy_stone_bricks');
  await cmd('fill -29 67 20 -25 67 29 minecraft:spruce_planks');
  await cmd('fill -28 67 20 -26 67 20 minecraft:green_concrete');
  await cmd('fill -29 68 20 -25 68 29 minecraft:spruce_slab[type=bottom]');

  const ops = [];

  // Surface Lodge Cedar Corner Trunks & Woodland Greenery
  for (const [cx, cz] of [[-29, 20], [-25, 20], [-29, 29], [-25, 29], [-29, 25], [-25, 25]]) {
    for (let y = 64; y <= 67; y++) {
      ops.push({ x: cx, y, z: cz, block: 'minecraft:stripped_spruce_log[axis=y]' });
    }
  }
  ops.push({ x: -30, y: 64, z: 20, block: 'minecraft:flowering_azalea' });
  ops.push({ x: -24, y: 64, z: 20, block: 'minecraft:flowering_azalea' });
  ops.push({ x: -28, y: 66, z: 19, block: 'minecraft:lantern[hanging=true]' });
  ops.push({ x: -26, y: 66, z: 19, block: 'minecraft:lantern[hanging=true]' });

  // Warm Spruce Timber Staircases (Flight 1 & Flight 2 with diagonal upside-down spruce ribbon soffit!)
  for (let i = 0; i < 7; i++) {
    const sz = 21 + i, sy = 63 - i;
    for (let x = -28; x <= -26; x++) {
      ops.push({ x, y: sy - 1, z: sz, block: 'minecraft:spruce_planks' });
      ops.push({ x, y: sy, z: sz, block: 'minecraft:spruce_stairs[facing=north,half=bottom,shape=straight,waterlogged=false]' });
      for (let ay = sy + 1; ay <= sy + 4; ay++) ops.push({ x, y: ay, z: sz, block: 'minecraft:air' });
    }
  }
  for (let i = 0; i < 8; i++) {
    const sz = 33 - i, sy = 56 - i;
    for (let x = -24; x <= -22; x++) {
      if (sy - 1 >= 49) {
        ops.push({ x, y: sy - 1, z: sz, block: 'minecraft:spruce_stairs[facing=north,half=top,shape=straight,waterlogged=false]' });
      }
      ops.push({ x, y: sy, z: sz, block: 'minecraft:spruce_stairs[facing=south,half=bottom,shape=straight,waterlogged=false]' });
      for (let ay = sy + 1; ay <= sy + 4; ay++) ops.push({ x, y: ay, z: sz, block: 'minecraft:air' });
    }
    if (sy + 1 <= 55) {
      ops.push({ x: -25, y: sy, z: sz, block: 'minecraft:spruce_fence[east=false,north=false,south=false,waterlogged=false,west=false]' });
    }
  }

  // Cedar Wall Pillars + Heavy Cedar Ceiling Rafters + Lush Hanging Foliage & Glow Berries!
  for (const rz of [20, 24, 28, 32, 36, 40, 44]) {
    for (let y = 49; y <= 54; y++) {
      ops.push({ x: -15, y, z: rz, block: 'minecraft:stripped_spruce_log[axis=y]' });
    }
  }
  for (const rz of [22, 28, 34, 40, 44]) {
    for (let x = -27; x <= -16; x++) {
      if (x >= -25 && x <= -22 && rz >= 25 && rz <= 33) continue;
      if (x === -21 || x === -18) continue;
      ops.push({ x, y: 54, z: rz, block: 'minecraft:stripped_spruce_log[axis=x]' });
    }
  }
  // Lush forest canopy leaves & softly glowing berries tucked into ceiling corners (x=-27 & x=-16)
  for (let z = 21; z <= 43; z += 2) {
    ops.push({ x: -16, y: 54, z, block: (z % 4 === 1) ? 'minecraft:flowering_azalea_leaves[distance=1,persistent=true]' : 'minecraft:azalea_leaves[distance=1,persistent=true]' });
    if (z % 6 === 3) {
      ops.push({ x: -16, y: 53, z, block: 'minecraft:cave_vines[age=22,berries=true]' });
    }
    if (z >= 26 && z <= 33) {
      ops.push({ x: -27, y: 54, z, block: 'minecraft:flowering_azalea_leaves[distance=1,persistent=true]' });
      if (z === 29) ops.push({ x: -27, y: 53, z, block: 'minecraft:cave_vines[age=22,berries=true]' });
    }
  }

  // Cedar Trunk Columns on Platform (preserving Map Board at z=36 & News Board at z=42!)
  for (const cz of [22, 36, 42]) {
    ops.push({ x: -25, y: 49, z: cz, block: 'minecraft:mossy_stone_bricks' });
    for (let y = 50; y <= 54; y++) {
      ops.push({ x: -25, y, z: cz, block: 'minecraft:stripped_spruce_log[axis=y]' });
    }
  }
  ops.push({ x: -24, y: 50, z: 36, block: 'arena_ai_bridge:world_map_board[facing=east,map_mode=0]' });
  ops.push({ x: -24, y: 50, z: 42, block: 'arena_ai_bridge:transit_news_board[facing=east]' });

  // Warm Cedar Benches on Platform
  for (let z = 22; z <= 24; z++) {
    ops.push({ x: -26, y: 49, z, block: 'minecraft:spruce_stairs[facing=west,half=bottom,shape=straight,waterlogged=false]' });
  }
  for (let z = 39; z <= 40; z++) {
    ops.push({ x: -23, y: 49, z, block: 'minecraft:spruce_stairs[facing=west,half=bottom,shape=straight,waterlogged=false]' });
  }

  // Ensure pure-white primary ceiling LEDs stay unbroken along platform & track
  for (let z = 21; z <= 43; z += 3) {
    if (z === 27 || z === 36) continue; // Reserved for hanging PIDS poles!
    ops.push({ x: -21, y: 54, z, block: 'arena_ai_bridge:tunnel_emergency_light[ceiling=true,emergency=false,facing=north]' });
    ops.push({ x: -18, y: 54, z, block: 'arena_ai_bridge:tunnel_emergency_light[ceiling=true,emergency=false,facing=north]' });
  }

  await act({ action: 'build', ops, recordUndo: false, strictPhysics: false, cleanFloating: false });

  // 3. Hang REAL MTR Digital PIDS Arrival Screens (with solid pids_pole mounts at y=54 -> pids_1 at y=53!)
  //    PLUS Crisp White-Text Station Name Wall Signs & Mezzanine PIDS!
  await cmd('tp ArenaAI -21 49 32');
  await sleep(250);
  const placeRes = await act({
    action: 'place_real',
    recordUndo: false,
    steps: [
      // North-end Platform PIDS (hangs from y=55 ceiling via pole at y=54, screen at y=53 facing along platform!)
      { x: -21, y: 54, z: 27, item: 'mtr:pids_pole', against: 'up', look: 'south', replace: true },
      { x: -21, y: 53, z: 27, item: 'mtr:pids_1', against: 'up', look: 'south', replace: true },
      // South-end Platform PIDS (screen at y=53 facing along platform!)
      { x: -21, y: 54, z: 36, item: 'mtr:pids_pole', against: 'up', look: 'north', replace: true },
      { x: -21, y: 53, z: 36, item: 'mtr:pids_1', against: 'up', look: 'north', replace: true },
      // Mezzanine Turnstile PIDS (hangs from y=62 ceiling -> pole at y=61 -> pids_1 at y=60!)
      { x: -26, y: 61, z: 35, item: 'mtr:pids_pole', against: 'up', look: 'north', replace: true },
      { x: -26, y: 60, z: 35, item: 'mtr:pids_1', against: 'up', look: 'north', replace: true },
      // Crisp White-Letter MTR Station Name Wall Signs on Emerald Green Forest Band!
      { x: -16, y: 51, z: 22, item: 'mtr:station_name_wall', against: 'east', look: 'east', replace: true },
      { x: -16, y: 51, z: 26, item: 'mtr:station_name_wall', against: 'east', look: 'east', replace: true },
      { x: -16, y: 51, z: 30, item: 'mtr:station_name_wall', against: 'east', look: 'east', replace: true },
      { x: -16, y: 51, z: 34, item: 'mtr:station_name_wall', against: 'east', look: 'east', replace: true },
      { x: -16, y: 51, z: 38, item: 'mtr:station_name_wall', against: 'east', look: 'east', replace: true },
      { x: -16, y: 51, z: 42, item: 'mtr:station_name_wall', against: 'east', look: 'east', replace: true }
    ]
  });
  console.log('PIDS & Signs place_real:', JSON.stringify(placeRes.results || placeRes.ok));

  // 4. Activate y=48 M1 Orman Metro route & generate schedules so PIDS shows live train arrival countdowns!
  const setupRes = await fetch(BASE + '/api/mtr-control', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      op: 'setup_line',
      trainId: 'r_train_mini_cab_3',
      northStationName: 'Kuzey Orman',
      southStationName: 'Güney Orman',
      dwellMillis: 20000,
      frequencyPerHour: 20
    })
  }).then(r => r.json()).catch(e => ({ ok: false, error: e.message }));
  console.log('MTR setup_line:', JSON.stringify(setupRes));

  await act({ action: 'follow', target: 'ilkan', distance: 3 });
  console.log('FOREST_NORTH_MAKEOVER_DONE');
}

main().catch(e => { console.error(e); process.exit(1); });

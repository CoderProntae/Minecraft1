// Stage 1: Kuzey Orman Merkez Garı + Tren Deposu (v4.0 Real Player Right-Click Build)
const BASE = 'http://127.0.0.1:8080';

async function postAct(body) {
  const r = await fetch(BASE + '/api/act', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  return r.json();
}

async function runBatch(steps, label) {
  // Send in crisp 250-step player batches so each batch executes fast and cleanly
  let totalPlaced = 0;
  let allFailed = [];
  for (let i = 0; i < steps.length; i += 250) {
    const chunk = steps.slice(i, i + 250);
    const res = await postAct({ action: 'place_real', steps: chunk });
    totalPlaced += (res.placedCount || 0);
    if (res.failed && res.failed.length) allFailed.push(...res.failed);
  }
  console.log(`[${label}] Placed: ${totalPlaced}/${steps.length}, Failed: ${allFailed.length}`);
  if (allFailed.length) console.log('Sample failures:', allFailed.slice(0, 5));
}

async function main() {
  const steps = [];
  const push = (x, y, z, item, opts = {}) => steps.push({ x, y, z, item, ...opts });

  // 1. Solid Grounded Foundation & Track Ballast (y=62..63) from z=-11 (Depot) to z=50 (Tunnel approach)
  // First clear replaceable tall grass/ferns above deck if any by replacing foundation cleanly
  for (let z = -11; z <= 50; z++) {
    for (let x = -20; x <= -16; x++) {
      push(x, 62, z, 'minecraft:cobblestone', { replace: true, look: 'south' });
      const topMat = (x >= -19 && x <= -17) ? 'minecraft:andesite' : 'minecraft:stone_bricks';
      push(x, 63, z, topMat, { replace: true, look: 'south' });
    }
  }

  // Station Platform & Concourse Foundation (x=-23..-20, z=20..44, y=62..64)
  for (let z = 20; z <= 44; z++) {
    for (let x = -23; x <= -20; x++) {
      push(x, 62, z, 'minecraft:stone_bricks', { replace: true, look: 'west' });
      push(x, 63, z, 'minecraft:stone_bricks', { replace: true, look: 'west' });
      if (x === -20) {
        // VERIFIED VIA ArenaAI OWN EYE: look="west" places yellow safety stripe facing East track (x=-18)!
        push(x, 64, z, 'mtr:platform', { replace: true, look: 'west', against: 'down' });
      } else {
        const floorMat = (x === -23) ? 'minecraft:polished_andesite' : 'minecraft:smooth_stone';
        push(x, 64, z, floorMat, { replace: true, look: 'west', against: 'down' });
      }
    }
  }

  // Bridge-to-Station Entrance Path & Wide Stairs (x=-29..-24, z=21..24) connecting arched bridge landing!
  for (let z = 21; z <= 24; z++) {
    for (let x = -29; x <= -25; x++) {
      push(x, 62, z, 'minecraft:cobblestone', { replace: true, look: 'east' });
      push(x, 63, z, (x + z) % 2 === 0 ? 'minecraft:stone_bricks' : 'minecraft:gravel', { replace: true, look: 'east' });
    }
    // Step up onto y=64 concourse at x=-24 (player looks EAST going up into station -> stairs face east!)
    push(-24, 62, z, 'minecraft:stone_bricks', { replace: true, look: 'east' });
    push(-24, 63, z, 'minecraft:stone_bricks', { replace: true, look: 'east' });
    push(-24, 64, z, 'minecraft:stone_brick_stairs', { replace: true, look: 'east', half: 'bottom', against: 'down' });
  }

  // 2. Station Columns, Back Railings & Timber Canopy Roof (z=20..44)
  const pillarZs = [20, 26, 32, 38, 44];
  for (let z = 20; z <= 44; z++) {
    const isPillar = pillarZs.includes(z);
    const isEntrance = (z >= 21 && z <= 24);
    if (isPillar) {
      // West column at x=-23 and East canopy column at x=-16
      for (let y = 65; y <= 68; y++) {
        push(-23, y, z, y === 65 ? 'minecraft:chiseled_stone_bricks' : 'minecraft:spruce_log', { replace: true, look: 'south', against: 'down' });
      }
      for (let y = 64; y <= 68; y++) {
        push(-16, y, z, y <= 65 ? 'minecraft:stone_bricks' : 'minecraft:spruce_log', { replace: true, look: 'south', against: 'down' });
      }
    } else if (!isEntrance) {
      // Low railing along west edge (x=-23, y=65) & east track guard fence (x=-16, y=64)
      push(-23, 65, z, 'minecraft:spruce_fence', { look: 'south', against: 'down' });
      push(-16, 64, z, 'minecraft:stone_brick_wall', { look: 'south', against: 'down' });
    }
  }

  // Roof Crossbeams (y=69) at pillarZs & Longitudinal Purlins + Slabs (y=69..70)
  for (const z of pillarZs) {
    // Build inward from both columns (-23 and -16) so every block clicks against a neighbor!
    push(-23, 69, z, 'minecraft:dark_oak_planks', { against: 'down', look: 'east' });
    push(-22, 69, z, 'minecraft:dark_oak_planks', { against: 'west', look: 'east' });
    push(-21, 69, z, 'minecraft:dark_oak_planks', { against: 'west', look: 'east' });
    push(-20, 69, z, 'minecraft:dark_oak_planks', { against: 'west', look: 'east' });
    push(-16, 69, z, 'minecraft:dark_oak_planks', { against: 'down', look: 'west' });
    push(-17, 69, z, 'minecraft:dark_oak_planks', { against: 'east', look: 'west' });
    push(-18, 69, z, 'minecraft:dark_oak_planks', { against: 'east', look: 'west' });
    push(-19, 69, z, 'minecraft:dark_oak_planks', { against: 'east', look: 'west' });
  }

  // Roof Canopy Deck (z=20..44, x=-23..-16 at y=70: pitched spruce slabs + central skylight glass!)
  for (let z = 20; z <= 44; z++) {
    // Ridge first over columns/beams, progressing z=20 -> 44 so every slab clicks against z-1 or y-1!
    for (const x of [-23, -16, -22, -17, -21, -18, -20, -19]) {
      if (x === -23 || x === -16) {
        push(x, 69, z, 'minecraft:dark_oak_slab', { half: 'top', look: 'south' });
      } else if (x === -19 || x === -20) {
        push(x, 70, z, pillarZs.includes(z) ? 'minecraft:dark_oak_planks' : 'minecraft:tinted_glass', { look: 'south' });
      } else {
        push(x, 70, z, 'minecraft:spruce_slab', { half: 'bottom', look: 'south' });
      }
    }
  }

  // 3. Northern Train Depot Shed (z=-11..+12, x=-20..-16) for MTR Siding
  const depotPillars = [-10, -4, 2, 8, 12];
  for (let z = -10; z <= 12; z++) {
    const isP = depotPillars.includes(z);
    for (const x of [-20, -16]) {
      if (isP) {
        for (let y = 64; y <= 67; y++) {
          push(x, y, z, y === 64 ? 'minecraft:stone_bricks' : 'minecraft:spruce_log', { against: 'down', look: 'south' });
        }
      } else {
        push(x, 64, z, 'minecraft:stone_bricks', { against: 'down', look: 'south' });
        push(x, 65, z, 'minecraft:spruce_fence', { against: 'down', look: 'south' });
      }
    }
  }
  // North Buffer Stop Wall at z=-11
  for (let x = -20; x <= -16; x++) {
    push(x, 64, -11, 'minecraft:chiseled_stone_bricks', { against: 'down', look: 'south' });
    if (x === -18) push(x, 65, -11, 'minecraft:redstone_lamp', { against: 'down', look: 'south' });
  }
  for (const z of depotPillars) {
    push(-20, 68, z, 'minecraft:dark_oak_planks', { against: 'down', look: 'east' });
    push(-19, 68, z, 'minecraft:dark_oak_planks', { against: 'west', look: 'east' });
    push(-16, 68, z, 'minecraft:dark_oak_planks', { against: 'down', look: 'west' });
    push(-17, 68, z, 'minecraft:dark_oak_planks', { against: 'east', look: 'west' });
    push(-18, 68, z, 'minecraft:dark_oak_planks', { against: 'east', look: 'west' });
    push(-18, 67, z, 'minecraft:lantern', { against: 'up', look: 'south' });
  }
  for (let z = -10; z <= 12; z++) {
    for (let x = -20; x <= -16; x++) {
      push(x, 69, z, 'minecraft:spruce_slab', { half: 'bottom', look: 'south' });
    }
  }

  // 4. Real MTR 4.0.5 Station Furniture & Hanging PIDS + Lanterns (under solid y=69 crossbeams!)
  // Hang lanterns & 2-block PIDS underneath solid y=69 beams (ZERO floating!)
  for (const z of [20, 32, 44]) {
    push(-21, 68, z, 'minecraft:lantern', { against: 'up', look: 'south' });
    push(-18, 68, z, 'minecraft:lantern', { against: 'up', look: 'south' });
  }
  for (const z of [26, 38]) {
    // Support rod from y=69 beam down to y=68, then hang PIDS at y=67!
    push(-20, 68, z, 'mtr:pids_pole', { against: 'up', look: 'south' });
    push(-20, 67, z, 'mtr:pids_1', { against: 'up', look: 'east' });
    push(-22, 68, z, 'minecraft:lantern', { against: 'up', look: 'south' });
  }

  // Ticket Machines (verified: screen faces OPPOSITE of look -> look="north" at z=20 faces south, look="west" at x=-23 faces east!)
  push(-22, 65, 20, 'mtr:ticket_machine', { against: 'down', look: 'north' });
  push(-22, 65, 26, 'mtr:ticket_machine', { against: 'down', look: 'south' });

  // Ticket Barriers across the entrance (x=-23, z=21..24: passengers walk EAST into station!)
  push(-23, 65, 21, 'mtr:ticket_barrier_entrance_1', { against: 'down', look: 'east' });
  push(-23, 65, 22, 'mtr:ticket_barrier_entrance_1', { against: 'down', look: 'east' });
  push(-23, 65, 23, 'mtr:ticket_barrier_exit_1', { against: 'down', look: 'west' });
  push(-23, 65, 24, 'mtr:ticket_barrier_exit_1', { against: 'down', look: 'west' });

  // Tall Standing Station Name Signs & Passenger Benches on Platform
  push(-21, 65, 29, 'mtr:station_name_tall_standing', { against: 'down', look: 'west' });
  push(-21, 65, 35, 'mtr:station_name_tall_standing', { against: 'down', look: 'west' });
  push(-22, 65, 31, 'minecraft:spruce_stairs', { against: 'down', half: 'bottom', look: 'west' });
  push(-22, 65, 32, 'minecraft:spruce_stairs', { against: 'down', half: 'bottom', look: 'west' });
  push(-22, 65, 33, 'minecraft:spruce_stairs', { against: 'down', half: 'bottom', look: 'west' });

  // 5. MTR Rail Nodes along x=-18, y=64:
  // z=-10 -> z=12 (22m Siding), z=12 -> z=20 (8m Switch/Approach), z=20 -> z=44 (24m Platform)
  for (const rz of [-10, 12, 20, 44]) {
    push(-18, 64, rz, 'mtr:rail', { against: 'down', look: 'south', replace: true });
  }

  await runBatch(steps, 'Kuzey Orman Merkez Gari + Depo');

  // 6. Connect MTR Rail Nodes via real item interactions!
  const connectPair = async (z1, z2, item) => {
    const r1 = await postAct({ action: 'interact', x: -18, y: 64, z: z1, side: 'up', item });
    const r2 = await postAct({ action: 'interact', x: -18, y: 64, z: z2, side: 'up', item });
    console.log(`Connected z=${z1}->${z2} (${item}):`, r1.result, r2.result);
  };

  // Turnback at north end of depot (-10 -> 12 siding), approach (12 -> 20), platform (20 -> 44)
  await connectPair(-10, 12, 'mtr:rail_connector_siding');
  await connectPair(12, 20, 'mtr:rail_connector_80');
  await connectPair(20, 44, 'mtr:rail_connector_platform');
}

main().catch(console.error);

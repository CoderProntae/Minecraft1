// Modern Architectural Underground Metro Station Builder — Güney Orman (M1, y=48)
// Builds in small zero-lag batches (<= 450 blocks) while polling live chat so we never miss ilkan!
const BASE = 'http://127.0.0.1:8080';
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

let baselineChatTime = 0;

async function getState() {
  const r = await fetch(BASE + '/api/state');
  return await r.json();
}

async function checkInterruptChat() {
  const st = await getState();
  const chats = (st.recentChat || []).filter(c => c.username === 'ilkan' && !c.text.startsWith('Teleported ') && c.time > baselineChatTime);
  if (chats.length > 0) {
    console.log('CHAT_INTERRUPT:', JSON.stringify(chats));
    process.exit(0);
  }
}

async function act(body) {
  for (let i = 0; i < 6; i++) {
    const r = await fetch(BASE + '/api/act', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...body, force: true })
    });
    const d = await r.json();
    if (d && d.ok !== false) return d;
    await sleep(600);
  }
  return { ok: false };
}

async function sendBuildBatched(ops, label) {
  const BATCH = 420;
  for (let i = 0; i < ops.length; i += BATCH) {
    await checkInterruptChat();
    const slice = ops.slice(i, i + BATCH);
    await act({ action: 'build', ops: slice, recordUndo: false, strictPhysics: false, cleanFloating: false });
    await sleep(90);
  }
  console.log(`[OK] ${label} (${ops.length} blocks)`);
}

async function connectRail(z1, y1, z2, y2, item) {
  const r1 = await act({ action: 'interact', x: -18, y: y1, z: z1, side: 'up', item });
  const r2 = await act({ action: 'interact', x: -18, y: y2, z: z2, side: 'up', item });
  console.log(`  [RAIL ${item}] (${z1},y${y1})->(${z2},y${y2}):`, r1.result, r2.result);
}

async function main() {
  const initSt = await getState();
  const ilkanChats = (initSt.recentChat || []).filter(c => c.username === 'ilkan');
  baselineChatTime = ilkanChats.length ? ilkanChats[ilkanChats.length - 1].time : Date.now();

  // Keep South chunks loaded via ArenaAI at safe vantage point
  await act({ action: 'stop' });
  await act({ action: 'command', command: 'tp ArenaAI -24 68 1564' });
  await sleep(350);

  // 1. Break old upper MTR rail nodes (y=73) & disconnect old ramp at (-18, 48, 1524)
  await connectRail(1524, 48, 1568, 73, 'mtr:rail_remover');
  await sendBuildBatched([
    { x: -18, y: 73, z: 1568, block: 'minecraft:air' },
    { x: -18, y: 73, z: 1592, block: 'minecraft:air' },
    { x: -18, y: 73, z: 1608, block: 'minecraft:air' }
  ], 'Removed old elevated y=73 rail nodes');

  // 2. Clear old elevated ramp & upper station structure (z=1525..1609, x=-26..-14, y=67..84) + seal natural y=66 forest surface!
  const surfaceOps = [];
  for (let z = 1525; z <= 1609; z++) {
    for (let x = -25; x <= -14; x++) {
      // Clear artificial raised viaduct above y=66
      for (let y = 67; y <= 83; y++) {
        surfaceOps.push({ x, y, z, block: 'minecraft:air' });
      }
      // Natural forest lawn / stone cap at y=65..66 over the old open cut (z=1525..1609)
      if (z >= 1525 && z <= 1608) {
        surfaceOps.push({ x, y: 65, z, block: 'minecraft:dirt' });
        surfaceOps.push({ x, y: 66, z, block: 'minecraft:grass_block' });
      }
    }
    // Fill old ramp trench (y=54..64, x=-22..-14) with solid stone so tunnel roof is 100% underground!
    for (let y = 54; y <= 64; y++) {
      for (let x = -22; x <= -14; x++) {
        surfaceOps.push({ x, y, z, block: 'minecraft:stone' });
      }
    }
  }
  await sendBuildBatched(surfaceOps, 'Restored natural y=66 forest ground & buried old ramp');

  // 3. Extend flat y=48 tunnel approach (z=1524..1565) & tail turnback tunnel (z=1595..1611)
  const tunOps = [];
  for (const [zStart, zEnd] of [[1525, 1564], [1596, 1611]]) {
    for (let z = zStart; z <= zEnd; z++) {
      const isRib = (z % 8 === 0);
      const isLed = (z % 4 === 0);
      for (let y = 47; y <= 53; y++) {
        for (let x = -21; x <= -15; x++) {
          if (y === 47) {
            tunOps.push({ x, y, z, block: (x >= -19 && x <= -17) ? 'minecraft:andesite' : 'minecraft:polished_deepslate' });
          } else if (y === 53 || x === -21 || x === -15) {
            tunOps.push({ x, y, z, block: isRib ? 'minecraft:polished_deepslate' : 'minecraft:stone_bricks' });
          } else if (y === 52 && (x === -20 || x === -16)) {
            tunOps.push({ x, y, z, block: isRib ? 'minecraft:polished_deepslate' : 'minecraft:stone_brick_slab[type=top]' });
          } else if (isLed && y === 52 && x === -18) {
            tunOps.push({ x, y, z, block: 'arena_ai_bridge:tunnel_emergency_light[ceiling=true,emergency=false,facing=north]' });
          } else if (isRib && y === 50 && x === -20) {
            tunOps.push({ x, y, z, block: 'arena_ai_bridge:tunnel_emergency_light[ceiling=false,emergency=false,facing=east]' });
          } else if (isRib && y === 50 && x === -16) {
            tunOps.push({ x, y, z, block: 'arena_ai_bridge:tunnel_emergency_light[ceiling=false,emergency=false,facing=west]' });
          } else {
            tunOps.push({ x, y, z, block: 'minecraft:air' });
          }
        }
      }
    }
    // End wall of turnback tunnel at z=1612
    if (zEnd === 1611) {
      for (let y = 47; y <= 53; y++) {
        for (let x = -21; x <= -15; x++) {
          tunOps.push({ x, y, z: 1612, block: 'minecraft:polished_deepslate' });
        }
      }
    }
  }
  await sendBuildBatched(tunOps, 'Built flat y=48 approach & tail tunnels with pure white LEDs');

  // 4. Grand Vaulted Underground Platform Hall (z=1565..1595, x=-28..-15, y=47..55)
  const hallOps = [];
  for (let z = 1565; z <= 1595; z++) {
    const isEndWall = (z === 1565 || z === 1595);
    const isFrame = (z % 6 === 0);
    for (let y = 47; y <= 55; y++) {
      for (let x = -28; x <= -15; x++) {
        // Outer structural shell
        if (x === -28 || x === -15 || y === 47 || y === 55 || isEndWall) {
          // Keep tunnel portal openings at z=1565 & z=1595 (x=-20..-16, y=48..52)
          if (isEndWall && x >= -20 && x <= -16 && y >= 48 && y <= 52) {
            hallOps.push({ x, y, z, block: 'minecraft:air' });
            continue;
          }
          // Keep Stair Flight 2 ceiling opening at y=55 (x=-26..-24, z=1571..1580)
          if (y === 55 && x >= -26 && x <= -24 && z >= 1571 && z <= 1580) {
            hallOps.push({ x, y, z, block: 'minecraft:air' });
            continue;
          }
          if (y === 47) {
            hallOps.push({ x, y, z, block: (x >= -19 && x <= -16) ? 'minecraft:andesite' : 'minecraft:polished_deepslate' });
          } else if (y === 55) {
            // Coffered modern white quartz + dark titanium ceiling
            hallOps.push({ x, y, z, block: isFrame ? 'minecraft:polished_deepslate' : 'minecraft:smooth_quartz' });
          } else if (y === 51 && (x === -28 || x === -15)) {
            // Iconic M1 Red Metro line band along both station walls!
            hallOps.push({ x, y, z, block: 'minecraft:red_concrete' });
          } else if (y >= 49 && y <= 53 && !isFrame && !isEndWall) {
            hallOps.push({ x, y, z, block: 'minecraft:smooth_quartz' });
          } else {
            hallOps.push({ x, y, z, block: 'minecraft:polished_deepslate' });
          }
          continue;
        }

        // Platform level y=48 (passengers walk at y=49; track bed x=-19..-16 stays open at y=48!)
        if (y === 48) {
          if (x >= -19 && x <= -16) {
            hallOps.push({ x, y, z, block: 'minecraft:air' });
          } else if (x === -20 && z >= 1568 && z <= 1592) {
            hallOps.push({ x, y, z, block: 'mtr:platform[door_type=none,facing=west,side=0]' });
          } else if (x === -20) {
            hallOps.push({ x, y, z, block: 'minecraft:polished_deepslate' });
          } else if (x === -21 && z >= 1568 && z <= 1592) {
            // Yellow safety tactile strip
            hallOps.push({ x, y, z, block: 'minecraft:yellow_concrete' });
          } else {
            hallOps.push({ x, y, z, block: 'minecraft:smooth_quartz' });
          }
          continue;
        }

        // Interior air & ceiling LEDs (y=49..54)
        if (y === 54 && (z % 3 === 1) && (x === -22 || x === -18 || (x === -26 && (z < 1570 || z > 1581)))) {
          hallOps.push({ x, y, z, block: 'arena_ai_bridge:tunnel_emergency_light[ceiling=true,emergency=false,facing=north]' });
        } else {
          hallOps.push({ x, y, z, block: 'minecraft:air' });
        }
      }
    }
  }

  // Architectural quartz columns + Map & News boards + Glass safety rail around stair well
  for (const cz of [1569, 1583, 1591]) {
    for (let y = 49; y <= 54; y++) {
      hallOps.push({ x: -24, y, z: cz, block: (y === 49 || y === 54) ? 'minecraft:chiseled_quartz_block' : 'minecraft:quartz_pillar[axis=y]' });
    }
  }
  // Digital World Map Board & Transit News Board on columns facing passengers!
  hallOps.push({ x: -23, y: 50, z: 1583, block: 'arena_ai_bridge:world_map_board[facing=east,map_mode=0]' });
  hallOps.push({ x: -23, y: 50, z: 1591, block: 'arena_ai_bridge:transit_news_board[facing=east]' });
  await sendBuildBatched(hallOps, 'Built Vaulted White-Quartz Underground Platform Hall');

  // 5. Mezzanine Ticket & Turnstile Hall (y=56..62, x=-31..-22, z=1567..1586) + Double Staircase + Surface [M1] Glass Pavilion!
  const mezOps = [];
  // Waterproof casing for entire Mezzanine + Stair Shafts (x=-31..-22, y=56..66, z=1566..1586)
  for (let z = 1566; z <= 1586; z++) {
    for (let y = 56; y <= 66; y++) {
      for (let x = -31; x <= -22; x++) {
        const isWall = (x === -31 || x === -22 || z === 1566 || z === 1586);
        if (isWall) {
          mezOps.push({ x, y, z, block: (y === 60 && !isWall) ? 'minecraft:red_concrete' : 'minecraft:polished_deepslate' });
        } else if (y === 56) {
          // Mezzanine floor y=56 (walk at y=57), EXCEPT Flight 2 stair cutout (x=-26..-24, z=1571..1579)!
          if (x >= -26 && x <= -24 && z >= 1571 && z <= 1579) {
            mezOps.push({ x, y, z, block: 'minecraft:air' });
          } else {
            mezOps.push({ x, y, z, block: 'minecraft:smooth_quartz' });
          }
        } else if (y === 66) {
          // Roof at surface plaza y=66, EXCEPT Flight 1 entrance opening (x=-30..-28, z=1567..1576)!
          if (x >= -30 && x <= -28 && z >= 1567 && z <= 1576) {
            mezOps.push({ x, y, z, block: 'minecraft:air' });
          } else {
            mezOps.push({ x, y, z, block: 'minecraft:polished_andesite' });
          }
        } else if (y >= 62 && y <= 65 && !(x >= -30 && x <= -28 && z >= 1567 && z <= 1578)) {
          // Solid ceiling above Mezzanine (y=62) up to surface (y=65) outside Flight 1 shaft
          mezOps.push({ x, y, z, block: (y === 62) ? 'minecraft:smooth_quartz' : 'minecraft:stone' });
        } else {
          mezOps.push({ x, y, z, block: 'minecraft:air' });
        }
      }
    }
  }

  // Flight 1 Stairs: Surface Plaza (z=1567, y=66) -> Mezzanine Floor (z=1576, y=57) along x=-30..-28 (going South)
  for (let i = 0; i < 10; i++) {
    const sz = 1567 + i;
    const sy = 66 - i;
    for (let x = -30; x <= -28; x++) {
      for (let fy = 56; fy < sy; fy++) {
        mezOps.push({ x, y: fy, z: sz, block: 'minecraft:polished_deepslate' });
      }
      mezOps.push({ x, y: sy, z: sz, block: 'minecraft:smooth_quartz_stairs[facing=north,half=bottom,shape=straight,waterlogged=false]' });
      for (let ay = sy + 1; ay <= Math.min(66, sy + 5); ay++) {
        mezOps.push({ x, y: ay, z: sz, block: 'minecraft:air' });
      }
    }
    // Glass balustrade along x=-27 beside Flight 1
    if (sy + 1 <= 65) mezOps.push({ x: -27, y: sy + 1, z: sz, block: 'minecraft:tinted_glass' });
  }

  // Mezzanine Turnstile Gate Line at x=-27 (z=1580..1585, walking floor y=57) separating Unpaid (x=-30..-28) from Paid (x=-26..-23)
  for (let z = 1577; z <= 1585; z++) {
    if (z >= 1580 && z <= 1581) {
      mezOps.push({ x: -27, y: 57, z, block: 'mtr:ticket_barrier_entrance_1[facing=east,open=closed]' });
    } else if (z >= 1582 && z <= 1583) {
      mezOps.push({ x: -27, y: 57, z, block: 'mtr:ticket_barrier_exit_1[facing=west,open=closed]' });
    } else {
      mezOps.push({ x: -27, y: 57, z, block: 'minecraft:glass_pane[east=false,north=true,south=true,waterlogged=false,west=false]' });
      mezOps.push({ x: -27, y: 58, z, block: 'minecraft:glass_pane[east=false,north=true,south=true,waterlogged=false,west=false]' });
    }
  }
  // Mezzanine Ceiling White LEDs (y=61)
  for (const lz of [1578, 1581, 1584]) {
    mezOps.push({ x: -29, y: 61, z: lz, block: 'arena_ai_bridge:tunnel_emergency_light[ceiling=true,emergency=false,facing=north]' });
    mezOps.push({ x: -24, y: 61, z: lz, block: 'arena_ai_bridge:tunnel_emergency_light[ceiling=true,emergency=false,facing=north]' });
  }

  // Flight 2 Stairs: Paid Mezzanine (z=1579, y=56) -> Underground Platform Floor (z=1572, y=49) along x=-26..-24 (going North!)
  for (let i = 0; i < 8; i++) {
    const sz = 1579 - i;
    const sy = 56 - i; // 56, 55, 54, 53, 52, 51, 50, 49 (steps down cleanly onto y=48 floor!)
    for (let x = -26; x <= -24; x++) {
      for (let fy = 49; fy < sy; fy++) {
        mezOps.push({ x, y: fy, z: sz, block: 'minecraft:smooth_quartz' });
      }
      mezOps.push({ x, y: sy, z: sz, block: 'minecraft:smooth_quartz_stairs[facing=south,half=bottom,shape=straight,waterlogged=false]' });
      for (let ay = sy + 1; ay <= sy + 5; ay++) {
        mezOps.push({ x, y: ay, z: sz, block: 'minecraft:air' });
      }
    }
  }

  // 6. Sleek Modern Surface [M1] Glass & Dark-Titanium Entrance Pavilion (x=-31..-26, z=1565..1577, y=67..71)
  // Open front entrance on the North side (z=1565..1566, x=-30..-28)!
  for (let z = 1565; z <= 1577; z++) {
    for (let x = -31; x <= -26; x++) {
      // Clear trees/foliage right around entrance plaza
      for (let y = 67; y <= 74; y++) {
        mezOps.push({ x, y, z, block: 'minecraft:air' });
      }
      const isEdgeX = (x === -31 || x === -26);
      const isBackZ = (z === 1577);
      const isFrontPortal = (z === 1565);

      if (z === 1565 || z === 1566) {
        if (x >= -30 && x <= -28) {
          mezOps.push({ x, y: 66, z, block: 'minecraft:smooth_quartz' });
        }
      }
      if (z >= 1566 && z <= 1577) {
        // Modern cantilevered flat roof at y=71 with M1 Red accent band at y=70!
        mezOps.push({ x, y: 71, z, block: 'minecraft:polished_deepslate_slab[type=bottom,waterlogged=false]' });
        if (isEdgeX || isBackZ || z === 1566) {
          mezOps.push({ x, y: 70, z, block: (z === 1566 && x >= -30 && x <= -28) ? 'minecraft:red_concrete' : 'minecraft:polished_deepslate' });
        } else if (z % 3 === 0 && x === -29) {
          mezOps.push({ x, y: 70, z, block: 'arena_ai_bridge:tunnel_emergency_light[ceiling=true,emergency=false,facing=north]' });
        }
        // Glass curtain walls on sides & back (open entrance at z=1566, x=-30..-28!)
        if (isEdgeX || isBackZ) {
          for (let y = 67; y <= 69; y++) {
            const isCorner = (isEdgeX && (z === 1566 || isBackZ));
            mezOps.push({ x, y, z, block: isCorner ? 'minecraft:polished_deepslate' : 'minecraft:glass' });
          }
        }
      }
    }
  }
  await sendBuildBatched(mezOps, 'Built Mezzanine Turnstile Hall, Double Staircase & Surface [M1] Glass Pavilion');

  // 7. Place MTR rail nodes at y=48 + Ticket Machines & PIDS boards via place_real, then connect MTR rails!
  await act({ action: 'command', command: 'tp ArenaAI -18 49 1568' });
  await sleep(300);

  await act({
    action: 'place_real',
    recordUndo: false,
    steps: [
      { x: -18, y: 48, z: 1546, item: 'mtr:rail', against: 'down', look: 'south', replace: true },
      { x: -18, y: 48, z: 1568, item: 'mtr:rail', against: 'down', look: 'south', replace: true },
      { x: -18, y: 48, z: 1592, item: 'mtr:rail', against: 'down', look: 'south', replace: true },
      { x: -18, y: 48, z: 1610, item: 'mtr:rail', against: 'down', look: 'south', replace: true },
      { x: -30, y: 57, z: 1579, item: 'mtr:ticket_machine', against: 'down', look: 'west', replace: true },
      { x: -21, y: 53, z: 1574, item: 'mtr:pids_1', against: 'up', look: 'east', replace: true },
      { x: -21, y: 53, z: 1586, item: 'mtr:pids_1', against: 'up', look: 'east', replace: true }
    ]
  });
  await sleep(250);

  await connectRail(1524, 48, 1546, 48, 'mtr:rail_connector_80');
  await connectRail(1546, 48, 1568, 48, 'mtr:rail_connector_80');
  await connectRail(1568, 48, 1592, 48, 'mtr:rail_connector_platform');
  await connectRail(1592, 48, 1610, 48, 'mtr:rail_connector_turn_back');

  console.log('SOUTH_UNDERGROUND_COMPLETE');
}

main().catch(e => { console.error(e); process.exit(1); });

const http = require('http');
const net = require('net');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const express = require('express');
const { WebSocketServer } = require('ws');
const mineflayer = require('mineflayer');
const { pathfinder, Movements, goals } = require('mineflayer-pathfinder');
const collectBlock = require('mineflayer-collectblock').plugin;
const pvp = require('mineflayer-pvp').plugin;
const Vec3 = require('vec3');
const { synthesizeTurkishPA, getEmaEngine } = require('./tts');
getEmaEngine().then(() => console.log('[TTS] EMA Lightning (8.6M ONNX) Türkçe model RAM\'e yüklendi!')).catch((e) => console.error('[TTS] EMA init error:', e));

const PORT = 8080;
const LOCAL_MC_PROXY_PORT = 25566;
const VISION_DIR = path.join(__dirname, 'vision');
fs.mkdirSync(VISION_DIR, { recursive: true });

// Sunucunun beklenmedik paket/fizik hatalarinda kapanmasini onle
process.on('uncaughtException', (err) => {
  console.error('[KORUMA - uncaughtException]:', err && err.stack ? err.stack : err);
});
process.on('unhandledRejection', (reason) => {
  console.error('[KORUMA - unhandledRejection]:', reason);
});

// ==================== GLOBAL STATE ====================
let tunnelUrl = null;
function getTunnelUrl() {
  try {
    const f = path.join(__dirname, 'tunnel_url.txt');
    if (fs.existsSync(f)) {
      const u = fs.readFileSync(f, 'utf8').trim();
      if (u.startsWith('https://')) tunnelUrl = u;
    }
  } catch {}
  return tunnelUrl;
}
let cachedStateMap = null;
let clientWs = null;
let clientState = {
  connected: false,
  connectedAt: null,
  lastHeartbeat: null,
  modActive: false,
  inWorld: false,
  lanPort: -1,
  telemetry: null,
  loadedMods: null
};

let tcpSeq = 1;
let rpcSeq = 1;
const localTcpSockets = new Map();
const pendingRpcs = new Map();

let bot = null;
let botConnecting = false;
let lastBotAttempt = 0;
let botMode = 'idle';
let targetPlayerName = null;
let moddedStateSyncSummary = { blocks: 0, items: 0 };

const buildHistoryStack = [];
const chatHistory = [];
const eventQueue = [];
const eventWaiters = [];
let eventSeq = 1;

function addLog(msg) {
  const line = `[${new Date().toISOString().slice(11, 19)}] ${msg}`;
  console.log(line);
  chatHistory.push({ time: Date.now(), system: true, text: line });
  if (chatHistory.length > 150) chatHistory.shift();
}

function pushEvent(ev) {
  const full = { id: eventSeq++, timestamp: Date.now(), ...ev };
  if (eventWaiters.length > 0) {
    const waiter = eventWaiters.shift();
    clearTimeout(waiter.timer);
    waiter.resolve(full);
  } else {
    eventQueue.push(full);
    if (eventQueue.length > 100) eventQueue.shift();
  }
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ==================== CLOUDFLARE TUNNEL MANAGER ====================
function startCloudflared() {
  const bin = path.join(__dirname, 'bin', 'cloudflared');
  if (!fs.existsSync(bin)) {
    addLog('UYARI: cloudflared bulunamadi: ' + bin);
    return;
  }
  const proc = spawn(bin, ['tunnel', '--no-autoupdate', '--url', `http://127.0.0.1:${PORT}`], {
    stdio: ['ignore', 'pipe', 'pipe']
  });

  const onData = (chunk) => {
    const str = chunk.toString('utf8');
    const m = str.match(/https:\/\/[a-zA-Z0-9-]+\.trycloudflare\.com/);
    if (m && m[0] !== tunnelUrl) {
      tunnelUrl = m[0];
      fs.writeFileSync(path.join(__dirname, 'tunnel_url.txt'), tunnelUrl, 'utf8');
      addLog(`CLOUDFLARE TUNEL HAZIR: ${tunnelUrl}`);
    }
  };
  proc.stdout.on('data', onData);
  proc.stderr.on('data', onData);
  proc.on('exit', (code) => {
    addLog(`cloudflared kapandi (${code}), 3sn icinde yeniden baslatiliyor...`);
    setTimeout(startCloudflared, 3000);
  });
}

// ==================== LOCAL TCP PROXY FOR MINEFLAYER ====================
const tcpProxyServer = net.createServer((socket) => {
  if (!clientWs || clientWs.readyState !== 1 || clientState.lanPort <= 0) {
    socket.destroy();
    return;
  }
  const connId = 'c' + (tcpSeq++);
  socket.setNoDelay(true);
  localTcpSockets.set(connId, socket);

  wsSend({ type: 'tcp_open', connId, port: clientState.lanPort });

  socket.on('data', (chunk) => {
    wsSend({ type: 'tcp_data', connId, b64: chunk.toString('base64') });
  });

  const cleanup = () => {
    if (localTcpSockets.delete(connId)) {
      wsSend({ type: 'tcp_close', connId });
    }
  };
  socket.on('end', cleanup);
  socket.on('close', cleanup);
  socket.on('error', () => {
    cleanup();
    socket.destroy();
  });
});

tcpProxyServer.listen(LOCAL_MC_PROXY_PORT, '127.0.0.1', () => {
  addLog(`Yerel MC TCP Vekili aktif: 127.0.0.1:${LOCAL_MC_PROXY_PORT}`);
});

// ==================== WEBSOCKET RPC HELPERS ====================
function wsSend(obj) {
  if (clientWs && clientWs.readyState === 1) {
    try {
      clientWs.send(JSON.stringify(obj));
      return true;
    } catch {
      return false;
    }
  }
  return false;
}

function sendWinConsoleLog(text) {
  wsSend({ type: 'log', b64: Buffer.from(text, 'utf8').toString('base64') });
}

function callClientRpc(action, params = {}, timeoutMs = 15000) {
  return new Promise((resolve, reject) => {
    if (!clientWs || clientWs.readyState !== 1) {
      return reject(new Error('Windows istemcisi bagli degil'));
    }
    const reqId = 'r' + (rpcSeq++);
    const timer = setTimeout(() => {
      pendingRpcs.delete(reqId);
      reject(new Error(`RPC zaman asimi (${action})`));
    }, timeoutMs);

    pendingRpcs.set(reqId, { resolve, reject, timer });
    wsSend({ type: 'rpc', reqId, action, ...params });
  });
}

async function modHttp(method, urlPath, bodyObj = null, timeoutMs = 15000) {
  const b64 = bodyObj ? Buffer.from(JSON.stringify(bodyObj), 'utf8').toString('base64') : '';
  const res = await callClientRpc('mod_http', { method, path: urlPath, b64 }, timeoutMs);
  const raw = res.b64 ? Buffer.from(res.b64, 'base64') : Buffer.alloc(0);
  return { status: res.status, buffer: raw };
}

async function modJson(method, urlPath, bodyObj = null, timeoutMs = 15000) {
  const { status, buffer } = await modHttp(method, urlPath, bodyObj, timeoutMs);
  const text = buffer.toString('utf8');
  try {
    return { status, data: JSON.parse(text) };
  } catch {
    return { status, data: { ok: false, raw: text } };
  }
}

async function captureVision() {
  if (clientState.modActive) {
    try {
      const { status, buffer } = await modHttp('GET', '/screenshot', null, 8000);
      if (status === 200 && buffer.length > 500) {
        const outPath = path.join(VISION_DIR, 'latest.png');
        fs.writeFileSync(outPath, buffer);
        return { ok: true, source: 'fabric_framebuffer', path: outPath, bytes: buffer.length };
      }
    } catch (e) {
      addLog('Mod screenshot hatasi: ' + e.message);
    }
  }
  return { ok: false, error: 'Goruntu alinamadi' };
}

async function captureBotVision(queryObj = {}) {
  if (clientState.modActive) {
    try {
      const qs = new URLSearchParams(queryObj).toString();
      const urlPath = qs ? `/bot_vision?${qs}` : '/bot_vision';
      const { status, buffer } = await modHttp('GET', urlPath, null, 8000);
      if (status === 200 && buffer.length > 500) {
        const outPath = path.join(VISION_DIR, 'bot_eye.png');
        fs.writeFileSync(outPath, buffer);
        return { ok: true, source: 'arena_ai_own_eye', path: outPath, bytes: buffer.length };
      }
      return { ok: false, status, error: buffer.toString('utf8') || 'Bot kamerasi alinamadi' };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  }
  return { ok: false, error: 'Mod aktif degil' };
}

async function refreshLiveContext() {
  if (clientState.connected && clientState.modActive) {
    try {
      const st = await modJson('GET', '/status', null, 3000);
      if (st.status === 200 && st.data?.ok) {
        clientState.telemetry = st.data;
      }
    } catch {}
  }
  return {
    player: clientState.telemetry?.player || null,
    targetBlock: clientState.telemetry?.targetBlock || null,
    mtrLoaded: !!clientState.telemetry?.mtrLoaded,
    modVersion: clientState.telemetry?.modVersion || null,
    bot: getBotSummary(),
    unreadPlayerChatEvents: eventQueue.filter(e => e.type === 'chat').map(e => ({
      id: e.id,
      username: e.username,
      message: e.message
    }))
  };
}

// ==================== FABRIC MOD & MTR REGISTRY SYNC FOR MINEFLAYER ====================
function applyCachedStateMapSync(instance) {
  if (!cachedStateMap || !instance || !instance.registry) return;
  const moddedBlocks = cachedStateMap.moddedBlocks || [];
  const moddedItems = cachedStateMap.moddedItems || [];
  const reg = instance.registry;
  let stateCount = 0;

  for (const mb of moddedBlocks) {
    const fullShape = mb.solid ? [[0, 0, 0, 1, 1, 1]] : [];
    const blockDef = {
      id: mb.rawBlockId,
      name: mb.id,
      displayName: mb.id,
      hardness: 1.5,
      resistance: 6,
      minStateId: mb.minStateId,
      maxStateId: mb.maxStateId,
      defaultState: mb.minStateId,
      states: null, // CRITICAL: states MUST be null so prismarine-block uses .shapes directly!
      stateShapes: [fullShape],
      drops: [],
      diggable: false,
      transparent: !mb.solid,
      filterLight: mb.solid ? 15 : 0,
      emitLight: 0,
      boundingBox: mb.solid ? 'block' : 'empty',
      material: 'rock',
      shapes: fullShape
    };
    reg.blocks[mb.rawBlockId] = blockDef;
    reg.blocksByName[mb.id] = blockDef;
    for (let sid = mb.minStateId; sid <= mb.maxStateId; sid++) {
      reg.blocksByStateId[sid] = blockDef;
      stateCount++;
    }
  }

  for (const mi of moddedItems) {
    const itemDef = {
      id: mi.rawId,
      name: mi.id,
      displayName: mi.id,
      stackSize: mi.maxCount || 64
    };
    reg.items[mi.rawId] = itemDef;
    reg.itemsByName[mi.id] = itemDef;
  }

  moddedStateSyncSummary = { blocks: moddedBlocks.length, stateIds: stateCount, items: moddedItems.length };
}

async function syncModdedRegistriesToBot(instance) {
  if (!clientState.modActive) return;
  try {
    const [modsRes, mapRes] = await Promise.all([
      modJson('GET', '/mods', null, 6000).catch(() => null),
      modJson('GET', '/state_map', null, 10000).catch(() => null)
    ]);

    if (modsRes?.data?.ok) {
      clientState.loadedMods = modsRes.data;
    }
    if (mapRes?.data?.ok) {
      cachedStateMap = mapRes.data;
    }
    if (instance) {
      applyCachedStateMapSync(instance);
      if (moddedStateSyncSummary.blocks > 0 || moddedStateSyncSummary.items > 0) {
        addLog(`Mod kayitlari Mineflayer'a esitlendi: ${moddedStateSyncSummary.blocks} modlu blok (${moddedStateSyncSummary.stateIds} state), ${moddedStateSyncSummary.items} modlu esya!`);
      }
    }
  } catch (e) {
    addLog('Mod registry esitleme uyarisi: ' + e.message);
  }
}

// ==================== MINEFLAYER BOT ====================
const HOSTILE_MOBS = new Set([
  'zombie', 'zombie_villager', 'husk', 'drowned', 'skeleton', 'stray', 'wither_skeleton',
  'spider', 'cave_spider', 'pillager', 'vindicator', 'evoker', 'ravager', 'witch',
  'slime', 'magma_cube', 'phantom', 'blaze', 'endermite', 'silverfish', 'vex'
]);

async function pickupNearbyDrops(maxRadius = 16, durationMs = 3000) {
  if (!bot || !bot.entity) return 0;
  const endAt = Date.now() + durationMs;
  let visited = 0;
  while (Date.now() < endAt && bot && bot.entity) {
    const drop = bot.nearestEntity(e => e && (e.name === 'item' || e.objectType === 'Item') && e.position.distanceTo(bot.entity.position) <= maxRadius);
    if (!drop) break;
    visited++;
    bot.pathfinder.setGoal(new goals.GoalNear(drop.position.x, drop.position.y, drop.position.z, 0.8));
    await sleep(650);
  }
  return visited;
}

async function equipBestWeapon() {
  if (!bot) return null;
  const order = ['netherite_sword', 'diamond_sword', 'iron_sword', 'stone_sword', 'wooden_sword', 'netherite_axe', 'diamond_axe', 'iron_axe', 'stone_axe'];
  const items = bot.inventory.items();
  for (const name of order) {
    const found = items.find(i => i.name === name);
    if (found) {
      await bot.equip(found, 'hand').catch(() => {});
      return found.name;
    }
  }
  return null;
}

async function equipAllArmor() {
  if (!bot) return [];
  const equipped = [];
  const slots = [
    { dest: 'head', suffix: '_helmet' },
    { dest: 'torso', suffix: '_chestplate' },
    { dest: 'legs', suffix: '_leggings' },
    { dest: 'feet', suffix: '_boots' }
  ];
  for (const s of slots) {
    const item = bot.inventory.items().find(i => i.name.endsWith(s.suffix));
    if (item) {
      await bot.equip(item, s.dest).catch(() => {});
      equipped.push(item.name);
    }
  }
  const shield = bot.inventory.items().find(i => i.name === 'shield');
  if (shield) {
    await bot.equip(shield, 'off-hand').catch(() => {});
    equipped.push('shield');
  }
  return equipped;
}

function createSafeMovements(instance, canDig = false) {
  const mcMove = new Movements(instance);
  mcMove.canDig = canDig;
  mcMove.allow1by1towers = false; // ASLA altina kirik tas kulesi dikmesin!
  mcMove.allowParkour = true;
  mcMove.allowSprinting = true;
  return mcMove;
}

async function ensureBotConnected() {
  if (bot || botConnecting) return;
  if (!clientState.connected || !clientState.inWorld || clientState.lanPort <= 0) return;
  const now = Date.now();
  if (now - lastBotAttempt < 5000) return;
  lastBotAttempt = now;
  botConnecting = true;

  addLog(`ArenaAI dunyaya baglaniyor (LAN Port: ${clientState.lanPort})...`);

  try {
    // Chunk paketleri gelmeden ONCE modlu bloklari hafizaya al!
    if (clientState.modActive && !cachedStateMap) {
      await syncModdedRegistriesToBot(null);
    }

    const instance = mineflayer.createBot({
      host: '127.0.0.1',
      port: LOCAL_MC_PROXY_PORT,
      username: 'ArenaAI',
      version: '1.20.4',
      auth: 'offline',
      checkTimeoutInterval: 60000,
      hideErrors: true
    });

    if (instance._client) {
      instance._client.on('error', (err) => {
        addLog('MC protokol uyarisi: ' + err.message);
      });
    }

    instance.loadPlugin(pathfinder);
    instance.loadPlugin(collectBlock);
    instance.loadPlugin(pvp);

    instance.once('login', () => {
      // SENKRON modlu blok esitleme (ilk chunk okunmadan milisaniyeler once!)
      applyCachedStateMapSync(instance);
      syncModdedRegistriesToBot(instance).catch(() => {});
    });

    instance.once('spawn', async () => {
      bot = instance;
      botConnecting = false;
      botMode = 'idle'; // Sabit ezbere takip dongusu kapali!

      await syncModdedRegistriesToBot(instance);
      bot.pathfinder.setMovements(createSafeMovements(bot, false));

      addLog('ArenaAI dunyaya katildi (v3.0 - sifir ezbere mesaj modu)!');
      sendWinConsoleLog('[OK] ArenaAI v3.0 dunyana katildi!');

      if (clientState.modActive) {
        await modJson('POST', '/command', { command: 'op ArenaAI', silent: true }).catch(() => {});
      }

      const live = await refreshLiveContext();
      const vision = await captureVision().catch(() => ({ ok: false }));

      // Hicbir onceden yazilmis cumle kurma! Sadece gercek olayi AI'a ilet, AI canli gorup kendisi konussun.
      pushEvent({
        type: 'bot_spawned',
        botPos: bot.entity ? bot.entity.position : null,
        liveContext: live,
        loadedMods: clientState.loadedMods,
        moddedSync: moddedStateSyncSummary,
        vision
      });
    });

    let lastInboundChatSig = '';
    let lastInboundChatMs = 0;
    const handleInboundPlayerChat = async (username, message) => {
      if (!bot || !username || username === bot.username || username === 'ArenaAI') return;
      const cleanMsg = String(message || '').trim();
      if (!cleanMsg) return;
      const now = Date.now();
      const sig = `${username}:${cleanMsg}`;
      if (sig === lastInboundChatSig && (now - lastInboundChatMs) < 1500) return;
      lastInboundChatSig = sig;
      lastInboundChatMs = now;

      targetPlayerName = username;
      addLog(`CHAT <${username}>: ${cleanMsg}`);
      chatHistory.push({ time: now, username, text: cleanMsg });
      if (chatHistory.length > 150) chatHistory.shift();
      try {
        fs.appendFileSync(path.join(__dirname, 'mc_chat.log'), `${new Date(now).toISOString()} <${username}> ${cleanMsg}\n`, 'utf8');
      } catch {}

      const live = await refreshLiveContext();
      const vision = await captureVision().catch(() => ({ ok: false }));

      pushEvent({
        type: 'chat',
        username,
        message: cleanMsg,
        botState: getBotSummary(),
        telemetry: clientState.telemetry,
        liveContext: live,
        vision
      });
    };

    instance.on('chat', (username, message) => {
      handleInboundPlayerChat(username, message);
    });

    instance.on('messagestr', (msgStr) => {
      const m = String(msgStr || '').match(/^<([A-Za-z0-9_]{2,24})>\s+(.+)$/);
      if (m) {
        handleInboundPlayerChat(m[1], m[2]);
      }
    });

    instance.on('kicked', (reason) => addLog('ArenaAI sunucudan atildi: ' + JSON.stringify(reason)));
    instance.on('error', (err) => addLog('ArenaAI hata: ' + err.message));
    instance.on('end', () => {
      addLog('ArenaAI baglantisi sonlandi.');
      bot = null;
      botConnecting = false;
    });
  } catch (e) {
    botConnecting = false;
    addLog('Bot baslatma hatasi: ' + e.message);
  }
}

function getPrimaryPlayerName() {
  if (clientState.telemetry?.player?.name) return clientState.telemetry.player.name;
  if (!bot) return targetPlayerName;
  for (const name of Object.keys(bot.players)) {
    if (name !== bot.username) return name;
  }
  return targetPlayerName;
}

function getBotSummary() {
  if (!bot || !bot.entity) return { connected: false };
  return {
    connected: true,
    username: bot.username,
    mode: botMode,
    pos: {
      x: Math.round(bot.entity.position.x * 100) / 100,
      y: Math.round(bot.entity.position.y * 100) / 100,
      z: Math.round(bot.entity.position.z * 100) / 100
    },
    health: bot.health,
    food: bot.food,
    heldItem: bot.heldItem ? { name: bot.heldItem.name, count: bot.heldItem.count } : null,
    inventory: bot.inventory.items().map(i => ({ name: i.name, count: i.count }))
  };
}

// Sadece kullanici acikca "takip et" veya "koru" isterse calisan istege bagli hareket
setInterval(async () => {
  if (!bot || !bot.entity) return;
  const pName = getPrimaryPlayerName();
  const pEnt = pName ? bot.players[pName]?.entity : null;

  if (botMode === 'guard') {
    const mob = bot.nearestEntity(e => {
      if (!e || !e.name) return false;
      if (!HOSTILE_MOBS.has(e.name.toLowerCase())) return false;
      const refPos = pEnt ? pEnt.position : bot.entity.position;
      return e.position.distanceTo(refPos) <= 16;
    });
    if (mob) {
      await equipBestWeapon();
      if (!bot.pvp.target || bot.pvp.target.id !== mob.id) bot.pvp.attack(mob);
      return;
    } else if (bot.pvp.target) {
      bot.pvp.stop();
    }
  }

  if (botMode === 'follow' && pEnt) {
    // Eger oyuncu ucuyorsa (havada > 4 blok yuksekteyse) pesinden kule dikmeye/ziplamaya calisma!
    const dy = pEnt.position.y - bot.entity.position.y;
    const distXZ = Math.hypot(pEnt.position.x - bot.entity.position.x, pEnt.position.z - bot.entity.position.z);
    if (distXZ > 3.8 && Math.abs(dy) <= 4 && !bot.pathfinder.isMoving()) {
      bot.pathfinder.setGoal(new goals.GoalXZ(pEnt.position.x, pEnt.position.z));
    }
  }
}, 800);

// ==================== EXPRESS + REST API ====================
const app = express();
app.use(express.json({ limit: '30mb' }));

app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.sendStatus(200);
  next();
});

app.get(['/win', '/win5', '/mtr', '/mtr5'], (req, res) => {
  const proto = req.headers['x-forwarded-proto'] || 'https';
  const host = req.headers['host'];
  const baseHttp = getTunnelUrl() || `${proto}://${host}`;
  const baseWs = baseHttp.replace(/^http/, 'ws');
  const skipSetup = req.path === '/win5' || req.path === '/mtr5';
  const installMtr = req.path === '/mtr' || req.path === '/mtr5';

  let ps = fs.readFileSync(path.join(__dirname, 'win-bridge.ps1'), 'utf8');
  ps = ps
    .replace(/__TUNNEL_HTTP__/g, baseHttp)
    .replace(/__TUNNEL_WS__/g, baseWs)
    .replace(/__SKIP_SETUP__/g, skipSetup ? '$true' : '$false')
    .replace(/__INSTALL_MTR__/g, installMtr ? '$true' : '$false');
  res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  res.send(ps);
});

app.get('/mod.jar', (req, res) => {
  const jarPath = path.join(__dirname, 'mods', 'arena-ai-bridge-1.0.0.jar');
  res.setHeader('Content-Type', 'application/java-archive');
  res.setHeader('Content-Disposition', 'attachment; filename="arena-ai-bridge-1.0.0.jar"');
  res.sendFile(jarPath);
});

app.get('/mod.sha', (req, res) => {
  try {
    const crypto = require('crypto');
    const jarPath = path.join(__dirname, 'mods', 'arena-ai-bridge-1.0.0.jar');
    const buf = fs.readFileSync(jarPath);
    const sha = crypto.createHash('sha256').update(buf).digest('hex');
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.send(sha);
  } catch (e) {
    res.status(500).send('');
  }
});

app.get('/ema-asset/:name', (req, res) => {
  const allowed = new Set(['arena-onnx-directml.jar', 'meta.json', 'text.onnx', 'sound.onnx', 'decoder.onnx']);
  const fn = path.basename(String(req.params.name || ''));
  if (!allowed.has(fn)) return res.status(404).json({ ok: false, error: 'Not found' });
  const fp = path.join(__dirname, 'ema-models', fn);
  if (!fs.existsSync(fp)) return res.status(404).json({ ok: false, error: 'Missing file' });
  res.setHeader('Content-Type', 'application/octet-stream');
  res.sendFile(fp);
});

app.get('/vision/latest', (req, res) => {
  const png = path.join(VISION_DIR, 'latest.png');
  if (fs.existsSync(png)) return res.sendFile(png);
  res.status(404).json({ ok: false, error: 'Henuz goruntu yok' });
});

app.get('/api/state', async (req, res) => {
  if (req.query.refresh === '1' && clientState.connected && clientState.modActive) {
    await refreshLiveContext();
  }
  res.json({
    ok: true,
    version: '3.0.1',
    tunnelUrl: getTunnelUrl(),
    clientState,
    moddedSync: moddedStateSyncSummary,
    bot: getBotSummary(),
    pendingEvents: eventQueue.length,
    recentChat: chatHistory.slice(-25)
  });
});

app.get('/api/mods', async (req, res) => {
  if (!clientState.modActive) return res.status(503).json({ ok: false, error: 'Mod aktif degil' });
  try {
    const r = await modJson('GET', '/mods', null, 6000);
    clientState.loadedMods = r.data;
    res.json(r.data);
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

app.get('/api/registry', async (req, res) => {
  if (!clientState.modActive) return res.status(503).json({ ok: false, error: 'Mod aktif degil' });
  try {
    const q = new URLSearchParams(req.query).toString();
    const r = await modJson('GET', `/registry?${q}`, null, 8000);
    res.json(r.data);
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

app.all('/api/mtr', async (req, res) => {
  if (!clientState.modActive) return res.status(503).json({ ok: false, error: 'Mod aktif degil' });
  try {
    const q = new URLSearchParams(req.query).toString();
    const body = req.method === 'POST' ? req.body : null;
    const r = await modJson(req.method === 'POST' ? 'POST' : 'GET', `/mtr_proxy?${q}`, body, 8000);
    res.json(r.data);
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

app.get('/api/wait-event', (req, res) => {
  const timeoutSec = Math.min(600, Math.max(1, parseInt(req.query.timeout || '240', 10)));
  if (eventQueue.length > 0) {
    return res.json({ ok: true, event: eventQueue.shift() });
  }
  const waiter = {
    resolve: (ev) => res.json({ ok: true, event: ev }),
    timer: setTimeout(() => {
      const idx = eventWaiters.indexOf(waiter);
      if (idx >= 0) eventWaiters.splice(idx, 1);
      res.json({ ok: true, timeout: true, event: null, bot: getBotSummary(), clientState });
    }, timeoutSec * 1000)
  };
  eventWaiters.push(waiter);
  req.on('close', () => {
    const idx = eventWaiters.indexOf(waiter);
    if (idx >= 0) {
      clearTimeout(waiter.timer);
      eventWaiters.splice(idx, 1);
    }
  });
});

app.get('/api/mtr-state', async (req, res) => {
  if (!clientState.modActive) return res.status(503).json({ ok: false, error: 'Mod aktif degil' });
  try {
    const r = await modJson('GET', '/mtr_state', null, 10000);
    res.json(r.data);
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

app.post('/api/mtr-control', async (req, res) => {
  if (!clientState.modActive) return res.status(503).json({ ok: false, error: 'Mod aktif degil' });
  try {
    const r = await modJson('POST', '/mtr_control', req.body || {}, 15000);
    res.json(r.data);
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

app.all('/api/map', async (req, res) => {
  if (!clientState.modActive) return res.status(503).json({ ok: false, error: 'Mod aktif degil' });
  try {
    const r = await modJson(req.method === 'POST' ? 'POST' : 'GET', '/map_api', req.method === 'POST' ? (req.body || {}) : null, 12000);
    res.json(r.data);
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

app.post('/api/balance', async (req, res) => {
  if (!clientState.modActive) return res.status(503).json({ ok: false, error: 'Mod aktif degil' });
  try {
    const r = await modJson('POST', '/balance', req.body || { amount: 0 }, 8000);
    res.json(r.data);
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

app.post('/api/announce', async (req, res) => {
  if (!clientState.modActive) return res.status(503).json({ ok: false, error: 'Mod aktif degil' });
  try {
    const text = String(req.body?.text || '').trim();
    const voice = req.body?.voice === 'erkek' ? 'erkek' : 'kadin';
    const chime = req.body?.chime || 'station';
    const volume = typeof req.body?.volume === 'number' ? req.body.volume : 0.94;
    const interrupt = !!req.body?.interrupt;
    if (!text) return res.status(400).json({ ok: false, error: 'Metin bos' });

    if (String(clientState.telemetry?.modVersion || '').startsWith('6.')) {
      const lr = await modJson('POST', '/local_tts', { text, chime, interrupt }, 8000).catch(() => null);
      if (lr?.data?.ok && lr.data.localReady) {
        return res.json({ ok: true, localGpu: true, backend: lr.data.backend, chime });
      }
    }

    const wavBuf = await synthesizeTurkishPA(text, voice, chime);
    const r = await modJson('POST', '/play_wav', {
      b64: wavBuf.toString('base64'),
      volume,
      interrupt
    }, 15000);
    // Also show crisp Turkish subtitle on player's actionbar!
    if (req.body?.subtitle !== false) {
      await modJson('POST', '/actionbar', { text: `🔊 [ANONS]: ${text}` }).catch(() => {});
    }
    res.json({ ok: true, voice, chime, wavBytes: wavBuf.length, modResult: r.data });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

// Automatic Real-Time Turkish Metro & Train PA Announcer (active when mod v5.0+ is loaded!)
let cachedMtrTopology = { stationsByHex: new Map(), routesByHex: new Map(), lastFetch: 0 };
let lastRideNextStationHex = null;
let lastStationApproachAnnouncedAt = 0;

async function playAutoTurkishPA(text, voice = 'kadin', chime = 'station') {
  try {
    const wavBuf = await synthesizeTurkishPA(text, voice, chime);
    await modJson('POST', '/play_wav', { b64: wavBuf.toString('base64'), volume: 0.92, interrupt: false }, 12000);
    await modJson('POST', '/actionbar', { text: `🔊 ${text}` }).catch(() => {});
    addLog(`[TR-ANONS (${voice})]: ${text}`);
  } catch (e) {
    addLog('[TR-ANONS Hata]: ' + e.message);
  }
}

app.post('/api/screenshot', async (req, res) => {
  res.json(await captureVision());
});

app.post('/api/bot-vision', async (req, res) => {
  res.json(await captureBotVision(req.body || {}));
});

app.get('/api/templates', async (req, res) => {
  if (!clientState.modActive) return res.status(503).json({ ok: false, error: 'Mod aktif degil' });
  try {
    const q = new URLSearchParams(req.query).toString();
    const r = await modJson('GET', `/templates?${q}`, null, 8000);
    res.json(r.data);
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

app.get('/api/scan', async (req, res) => {
  if (clientState.modActive) {
    try {
      const q = new URLSearchParams(req.query).toString();
      const r = await modJson('GET', `/scan?${q}`, null, 10000);
      return res.json(r.data);
    } catch (e) {
      return res.status(500).json({ ok: false, error: e.message });
    }
  }
  res.status(503).json({ ok: false, error: 'Mod aktif degil' });
});

app.get('/api/scan3d', async (req, res) => {
  if (clientState.modActive) {
    try {
      const q = new URLSearchParams(req.query).toString();
      const r = await modJson('GET', `/scan3d?${q}`, null, 12000);
      return res.json(r.data);
    } catch (e) {
      return res.status(500).json({ ok: false, error: e.message });
    }
  }
  res.status(503).json({ ok: false, error: 'Mod aktif degil' });
});

// ==================== REAL-TIME ATOMIC ACTION ENGINE (NO PRE-SCRIPTED SPEECH) ====================
app.post('/api/act', async (req, res) => {
  const { action } = req.body || {};
  try {
    // GERCEK ZAMANLI KONUSMA KORUMASI: Eger oyuncu o sirada yeni bir sey yazdiysa,
    // onceden hazirlanmis bayat cumleyi gonderme; once oyuncunun yeni mesajini oku!
    if (action === 'chat') {
      const unreadChats = eventQueue.filter(e => e.type === 'chat');
      if (unreadChats.length > 0 && req.body.force !== true) {
        return res.json({
          ok: false,
          abortedBecausePlayerSpoke: true,
          reason: 'Oyuncu yeni bir mesaj yazdi; onceden yazilmis cumle iptal edildi.',
          unreadPlayerMessages: unreadChats.map(e => ({ id: e.id, username: e.username, message: e.message }))
        });
      }
      const text = String(req.body.text || req.body.message || '').trim();
      if (bot && text.length <= 220) {
        bot.chat(text);
      } else if (clientState.modActive) {
        // 256 karakter Netty sinirina takilmadan tam metni mod uzerinden temiz gonder!
        await modJson('POST', '/chat', { text: `<ArenaAI> ${text}` });
      } else if (bot) {
        const words = text.split(' ');
        let line = '';
        for (const w of words) {
          if ((line + ' ' + w).trim().length > 210) {
            bot.chat(line.trim());
            await sleep(250);
            line = w;
          } else {
            line = (line + ' ' + w).trim();
          }
        }
        if (line.trim()) bot.chat(line.trim());
      }
      chatHistory.push({ time: Date.now(), username: 'ArenaAI', text });
      try {
        fs.appendFileSync(path.join(__dirname, 'mc_chat.log'), `${new Date().toISOString()} <ArenaAI> ${text}\n`, 'utf8');
      } catch {}
      return res.json({ ok: true, liveContext: await refreshLiveContext() });
    }

    if (action === 'actionbar') {
      if (clientState.modActive) {
        await modJson('POST', '/actionbar', { text: String(req.body.text || '') });
      }
      return res.json({ ok: true });
    }

    if (action === 'build') {
      const ops = Array.isArray(req.body.ops) ? req.body.ops : [];
      if (ops.length === 0) return res.json({ ok: true, changedBlocks: 0 });
      if (!clientState.modActive) return res.status(503).json({ ok: false, error: 'Mod bagli degil' });

      const payload = {
        ops,
        recordUndo: req.body.recordUndo !== false,
        strictPhysics: req.body.strictPhysics !== false,
        autoConnect: req.body.autoConnect !== false,
        cleanFloating: req.body.cleanFloating !== false
      };
      const r = await modJson('POST', '/build', payload, 25000);
      if (r.data?.changedBlocks > 0) buildHistoryStack.push(1);
      return res.json({
        ...r.data,
        liveContext: await refreshLiveContext()
      });
    }

    if (action === 'clean_floating') {
      if (!clientState.modActive) return res.status(503).json({ ok: false, error: 'Mod bagli degil' });
      const r = await modJson('POST', '/clean_floating', req.body || {}, 25000);
      return res.json({
        ...r.data,
        liveContext: await refreshLiveContext()
      });
    }

    if (action === 'place_real') {
      if (!clientState.modActive) return res.status(503).json({ ok: false, error: 'Mod bagli degil' });
      const r = await modJson('POST', '/place_real', req.body || {}, 25000);
      if (r.data?.placedCount > 0) buildHistoryStack.push(1);
      return res.json({ ...r.data, liveContext: await refreshLiveContext() });
    }

    if (action === 'break_real') {
      if (!clientState.modActive) return res.status(503).json({ ok: false, error: 'Mod bagli degil' });
      const r = await modJson('POST', '/break_real', req.body || {}, 20000);
      if (r.data?.brokenCount > 0) buildHistoryStack.push(1);
      return res.json({ ...r.data, liveContext: await refreshLiveContext() });
    }

    if (action === 'place_nbt') {
      if (!clientState.modActive) return res.status(503).json({ ok: false, error: 'Mod bagli degil' });
      const payload = { ...(req.body || {}) };
      if (payload.file && fs.existsSync(payload.file)) {
        payload.b64 = fs.readFileSync(payload.file).toString('base64');
      }
      const r = await modJson('POST', '/place_nbt', payload, 25000);
      if (r.data?.ok) buildHistoryStack.push(1);
      return res.json({ ...r.data, liveContext: await refreshLiveContext() });
    }

    if (action === 'save_nbt') {
      if (!clientState.modActive) return res.status(503).json({ ok: false, error: 'Mod bagli degil' });
      const r = await modJson('POST', '/save_nbt', req.body || {}, 20000);
      if (r.data?.ok && r.data?.b64 && req.body?.outFile) {
        fs.mkdirSync(path.dirname(req.body.outFile), { recursive: true });
        fs.writeFileSync(req.body.outFile, Buffer.from(r.data.b64, 'base64'));
      }
      return res.json({ ok: r.data?.ok, sizeX: r.data?.sizeX, sizeY: r.data?.sizeY, sizeZ: r.data?.sizeZ, outFile: req.body?.outFile });
    }

    if (action === 'interact') {
      if (!clientState.modActive) return res.status(503).json({ ok: false, error: 'Mod bagli degil' });
      const r = await modJson('POST', '/interact', req.body || {}, 10000);
      return res.json({
        ...r.data,
        liveContext: await refreshLiveContext()
      });
    }

    if (action === 'undo') {
      if (!clientState.modActive) return res.json({ ok: false, error: 'Undo icin Fabric modu gereklidir' });
      const chunks = buildHistoryStack.pop() || 1;
      let totalRestored = 0;
      for (let k = 0; k < chunks; k++) {
        const r = await modJson('POST', '/undo', {});
        if (r.data?.restoredBlocks) totalRestored += r.data.restoredBlocks;
      }
      return res.json({ ok: true, restoredBlocks: totalRestored, liveContext: await refreshLiveContext() });
    }

    if (action === 'command') {
      const cmd = String(req.body.command || '');
      if (clientState.modActive) {
        const r = await modJson('POST', '/command', { command: cmd, silent: req.body.silent !== false });
        return res.json({ ...r.data, liveContext: await refreshLiveContext() });
      } else if (bot) {
        bot.chat(cmd.startsWith('/') ? cmd : '/' + cmd);
        return res.json({ ok: true, fallback: 'bot_chat' });
      }
      return res.status(503).json({ ok: false, error: 'Bagli degil' });
    }

    if (action === 'come') {
      if (!bot) return res.json({ ok: false, error: 'Bot bagli degil' });
      botMode = 'idle';
      bot.pvp.stop();
      const pName = req.body.player || getPrimaryPlayerName();
      const pEnt = pName ? bot.players[pName]?.entity : null;
      if (!pEnt) {
        if (clientState.modActive && pName) {
          await modJson('POST', '/command', { command: `tp ArenaAI ${pName}`, silent: true });
          return res.json({ ok: true, teleported: true, liveContext: await refreshLiveContext() });
        }
        return res.json({ ok: false, error: 'Oyuncu yakinda gorunmuyor' });
      }
      const dist = bot.entity.position.distanceTo(pEnt.position);
      if (dist > 65 && clientState.modActive) {
        await modJson('POST', '/command', { command: `tp ArenaAI ${pName}`, silent: true });
      } else {
        bot.pathfinder.setGoal(new goals.GoalNear(pEnt.position.x, pEnt.position.y, pEnt.position.z, 2));
      }
      return res.json({ ok: true, distance: Math.round(dist * 10) / 10, liveContext: await refreshLiveContext() });
    }

    if (action === 'goto') {
      if (!bot) return res.json({ ok: false, error: 'Bot bagli degil' });
      botMode = 'idle';
      bot.pvp.stop();
      const { x, y, z, range = 1.5, waitArrival = true } = req.body;
      bot.pathfinder.setGoal(new goals.GoalNear(x, y, z, range));
      if (waitArrival) {
        await Promise.race([sleep(4000), new Promise(r => bot.once('goal_reached', r))]);
      }
      return res.json({ ok: true, target: { x, y, z }, liveContext: await refreshLiveContext() });
    }

    if (action === 'look') {
      if (!bot || !bot.entity) return res.json({ ok: false, error: 'Bot bagli degil' });
      if (req.body.player) {
        const pEnt = bot.players[req.body.player]?.entity;
        if (pEnt) await bot.lookAt(pEnt.position.offset(0, 1.62, 0), true);
      } else if (typeof req.body.x === 'number') {
        await bot.lookAt(new Vec3(req.body.x, req.body.y, req.body.z), true);
      }
      return res.json({ ok: true, liveContext: await refreshLiveContext() });
    }

    if (action === 'follow') {
      botMode = 'follow';
      if (bot) bot.pvp.stop();
      return res.json({ ok: true, mode: botMode });
    }

    if (action === 'guard') {
      botMode = 'guard';
      await equipBestWeapon();
      await equipAllArmor();
      return res.json({ ok: true, mode: botMode });
    }

    if (action === 'stop') {
      botMode = 'idle';
      if (bot) {
        bot.pathfinder.setGoal(null);
        bot.pvp.stop();
        bot.clearControlStates();
      }
      return res.json({ ok: true, mode: botMode });
    }

    if (action === 'equip') {
      if (!bot) return res.json({ ok: false, error: 'Bot bagli degil' });
      if (req.body.allArmor) {
        const eq = await equipAllArmor();
        const wp = await equipBestWeapon();
        return res.json({ ok: true, equipped: eq, weapon: wp });
      }
      const rawName = String(req.body.item || '');
      const cleanName = rawName.replace('minecraft:', '');
      const dest = req.body.slot || 'hand';
      const it = bot.inventory.items().find(i => i.name === rawName || i.name === cleanName);
      if (!it) return res.json({ ok: false, error: `Envanterde ${rawName} yok` });
      await bot.equip(it, dest);
      return res.json({ ok: true, equipped: it.name, slot: dest });
    }

    if (action === 'pickup') {
      if (!bot) return res.json({ ok: false, error: 'Bot bagli degil' });
      const collected = await pickupNearbyDrops(20, 4000);
      return res.json({ ok: true, collectedStops: collected, liveContext: await refreshLiveContext() });
    }

    res.status(400).json({ ok: false, error: 'Bilinmeyen action: ' + action });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

// Canli Kontrol Paneli (Web UI v3.0)
app.get('/', (req, res) => {
  const baseHttp = tunnelUrl || `https://${req.headers.host}`;
  const cmdWin = `irm ${baseHttp}/win | iex`;
  const cmdMtr = `irm ${baseHttp}/mtr | iex`;
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.send(`<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>ArenaAI v3.0 — Minecraft 1.20.4 + MTR Köprüsü</title>
<style>
  :root { --bg: #0b0f17; --card: #131b29; --border: #223049; --accent: #38bdf8; --mtr: #a855f7; --ok: #22c55e; --text: #e2e8f0; --muted: #94a3b8; }
  * { box-sizing: border-box; margin: 0; padding: 0; font-family: system-ui, -apple-system, sans-serif; }
  body { background: var(--bg); color: var(--text); padding: 24px; line-height: 1.5; }
  .wrap { max-width: 1120px; margin: 0 auto; display: grid; gap: 18px; }
  .header { background: linear-gradient(135deg, #131b29, #0f172a); border: 1px solid var(--border); border-radius: 16px; padding: 22px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px; }
  .title { font-size: 21px; font-weight: 700; }
  .badge { padding: 6px 12px; border-radius: 999px; font-size: 13px; font-weight: 600; background: #1e293b; border: 1px solid var(--border); }
  .badge.ok { background: rgba(34,197,94,0.15); color: #4ade80; border-color: rgba(34,197,94,0.35); }
  .cmd-box { background: #070a10; border: 1px solid var(--border); border-radius: 12px; padding: 14px; display: flex; gap: 12px; align-items: center; justify-content: space-between; flex-wrap: wrap; margin-top: 8px; }
  code { color: #38bdf8; font-family: ui-monospace, Consolas, monospace; font-size: 14px; word-break: break-all; }
  code.mtr { color: #c084fc; }
  button { background: var(--accent); color: #08101d; border: none; border-radius: 8px; padding: 8px 14px; font-weight: 700; cursor: pointer; }
  button.mtr { background: var(--mtr); color: #fff; }
  .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 18px; }
  .card { background: var(--card); border: 1px solid var(--border); border-radius: 14px; padding: 18px; }
  .card h3 { font-size: 13px; color: var(--muted); text-transform: uppercase; margin-bottom: 10px; }
  .kv { display: flex; justify-content: space-between; padding: 6px 0; border-bottom: 1px solid rgba(255,255,255,0.05); font-size: 14px; }
  .log { height: 220px; overflow-y: auto; background: #070a10; border-radius: 10px; padding: 12px; font-family: monospace; font-size: 12.5px; color: #cbd5e1; }
  img.vision { width: 100%; border-radius: 10px; border: 1px solid var(--border); background: #070a10; min-height: 180px; object-fit: contain; }
</style>
</head>
<body>
<div class="wrap">
  <div class="header">
    <div>
      <div class="title">⚡ ArenaAI v3.0 — 3B Fizik Doğrulamalı & MTR Mod Uyumlu Köprü</div>
      <div style="color:var(--muted);font-size:14px;margin-top:4px;">Sıfır Havada Blok + Sıfır Ezbere Cümle + Minecraft Transit Railway (MTR 4.0.5) Tam Desteği</div>
    </div>
    <div id="connBadge" class="badge">Yükleniyor...</div>
  </div>
  <div class="card">
    <h3>Seçenek 1 — Standart Bağlantı (Modu Kendi Kuranlar İçin ArenaAI v3 Günceller & Bağlar)</h3>
    <div class="cmd-box">
      <code id="psCmd">${cmdWin}</code>
      <button onclick="navigator.clipboard.writeText(document.getElementById('psCmd').innerText)">Kopyala</button>
    </div>
    <h3 style="margin-top:16px;">Seçenek 2 — Otomatik MTR 4.0.5 + Fabric API + ArenaAI v3 Kurulumu & Bağlantı</h3>
    <div class="cmd-box">
      <code id="mtrCmd" class="mtr">${cmdMtr}</code>
      <button class="mtr" onclick="navigator.clipboard.writeText(document.getElementById('mtrCmd').innerText)">Kopyala</button>
    </div>
  </div>
  <div class="grid">
    <div class="card">
      <h3>Canlı Durum</h3>
      <div class="kv"><span>Windows Köprüsü</span><strong id="wConn">-</strong></div>
      <div class="kv"><span>ArenaAI Mod Sürümü</span><strong id="mAct">-</strong></div>
      <div class="kv"><span>MTR Mod Durumu</span><strong id="mtrStat">-</strong></div>
      <div class="kv"><span>ArenaAI Oyuncu</span><strong id="bConn">-</strong></div>
      <div class="kv"><span>Oyuncu Konumu</span><strong id="pPos">-</strong></div>
      <div class="kv"><span>Baktığı Blok</span><strong id="pTarget">-</strong></div>
    </div>
    <div class="card">
      <h3>Canlı Ekran Görüşü</h3>
      <img id="vImg" class="vision" alt="Oyun içi görüntü bekleniyor..." />
    </div>
  </div>
  <div class="card">
    <h3>Oyun İçi Akış</h3>
    <div id="logBox" class="log"></div>
  </div>
</div>
<script>
async function poll() {
  try {
    const r = await fetch('/api/state');
    const d = await r.json();
    document.getElementById('wConn').textContent = d.clientState.connected ? 'Bağlı ✅' : 'Bekleniyor...';
    const ver = d.clientState.telemetry?.modVersion || (d.clientState.modActive ? '1.0' : '-');
    document.getElementById('mAct').textContent = d.clientState.modActive ? ('Aktif (v' + ver + ') ✅') : 'Bekleniyor';
    document.getElementById('mtrStat').textContent = d.clientState.telemetry?.mtrLoaded ? 'MTR Yüklü 🚆✅' : 'Yüklü Değil / Bekleniyor';
    document.getElementById('bConn').textContent = d.bot.connected ? 'Oyunda ✅' : 'Dünya Bekleniyor';
    const p = d.clientState.telemetry?.player;
    document.getElementById('pPos').textContent = p ? (p.name + ' (' + p.blockX + ', ' + p.blockY + ', ' + p.blockZ + ')') : '-';
    const tb = d.clientState.telemetry?.targetBlock;
    document.getElementById('pTarget').textContent = (tb && tb.hit) ? (tb.block + ' @ ' + tb.x + ',' + tb.y + ',' + tb.z) : '-';
    const badge = document.getElementById('connBadge');
    if (d.bot.connected) { badge.textContent = '🟢 OYUNDA AKTİF'; badge.className = 'badge ok'; }
    else if (d.clientState.connected) { badge.textContent = '🟡 WINDOWS BAĞLI - DÜNYA BEKLENİYOR'; badge.className = 'badge'; }
    else { badge.textContent = '⚪ BAĞLANTI BEKLENİYOR'; badge.className = 'badge'; }
    if (d.tunnelUrl) {
      document.getElementById('psCmd').textContent = 'irm ' + d.tunnelUrl + '/win | iex';
      document.getElementById('mtrCmd').textContent = 'irm ' + d.tunnelUrl + '/mtr | iex';
    }
    const lb = document.getElementById('logBox');
    lb.innerHTML = d.recentChat.map(c => c.system ? ('<div>' + c.text + '</div>') : ('<div style="color:#38bdf8"><b>&lt;' + c.username + '&gt;</b> ' + c.text + '</div>')).join('');
    lb.scrollTop = lb.scrollHeight;
    if (d.clientState.inWorld) document.getElementById('vImg').src = '/vision/latest?t=' + Date.now();
  } catch (e) {}
}
setInterval(poll, 2000);
poll();
</script>
</body>
</html>`);
});

// ==================== HTTP + WEBSOCKET SERVER ====================
const httpServer = http.createServer(app);
const wss = new WebSocketServer({ server: httpServer, path: '/tunnel' });

wss.on('connection', (ws) => {
  if (clientWs && clientWs !== ws) {
    try { clientWs.close(); } catch {}
  }
  clientWs = ws;
  clientState.connected = true;
  clientState.connectedAt = Date.now();
  clientState.lastHeartbeat = Date.now();
  addLog('WINDOWS ISTEMCISI TUNEL UZERINDEN BAGLANDI!');
  pushEvent({ type: 'windows_connected' });

  ws.on('message', (raw) => {
    let msg;
    try {
      msg = JSON.parse(raw.toString('utf8'));
    } catch {
      return;
    }

    if (msg.type === 'state') {
      clientState.lastHeartbeat = Date.now();
      if (msg.modActive) {
        clientState.modActive = true;
        clientState.lastModActiveAt = Date.now();
      } else if (!clientState.lastModActiveAt || Date.now() - clientState.lastModActiveAt > 8000) {
        clientState.modActive = false;
      }
      const prevLanPort = clientState.lanPort;
      clientState.inWorld = !!msg.inWorld;
      clientState.lanPort = typeof msg.lanPort === 'number' ? msg.lanPort : -1;
      if (prevLanPort !== clientState.lanPort || !clientState.inWorld) {
        if (bot) {
          addLog(`LAN port degisti (${prevLanPort} -> ${clientState.lanPort}), ArenaAI yeniden baglaniyor...`);
          try { bot.quit(); } catch {}
          try { if (bot._client && bot._client.socket) bot._client.socket.destroy(); } catch {}
          bot = null;
          botConnecting = false;
          lastBotAttempt = 0;
        }
        cachedStateMap = null;
      }
      if (msg.b64) {
        try {
          clientState.telemetry = JSON.parse(Buffer.from(msg.b64, 'base64').toString('utf8'));
        } catch {}
      }
      if (clientState.inWorld && clientState.lanPort > 0) {
        ensureBotConnected();
      }
    } else if (msg.type === 'tcp_data') {
      const sock = localTcpSockets.get(msg.connId);
      if (sock && msg.b64) {
        try {
          sock.write(Buffer.from(msg.b64, 'base64'));
        } catch {
          sock.destroy();
          localTcpSockets.delete(msg.connId);
        }
      }
    } else if (msg.type === 'tcp_close') {
      const sock = localTcpSockets.get(msg.connId);
      if (sock) {
        localTcpSockets.delete(msg.connId);
        sock.destroy();
      }
    } else if (msg.type === 'rpc_res') {
      const p = pendingRpcs.get(msg.reqId);
      if (p) {
        clearTimeout(p.timer);
        pendingRpcs.delete(msg.reqId);
        p.resolve({ status: msg.status, b64: msg.b64 || '' });
      }
    }
  });

  ws.on('close', () => {
    if (clientWs === ws) {
      clientWs = null;
      clientState.connected = false;
      clientState.inWorld = false;
      clientState.lanPort = -1;
      for (const [, s] of localTcpSockets) {
        try { s.destroy(); } catch {}
      }
      localTcpSockets.clear();
      addLog('Windows istemci baglantisi kapandi.');
    }
  });

  ws.on('error', () => {});
});

httpServer.listen(PORT, '0.0.0.0', () => {
  addLog(`ArenaAI Merkez Sunucusu v3.0.1 calisiyor: 0.0.0.0:${PORT}`);
  if (process.env.EXTERNAL_TUNNEL !== '1') {
    startCloudflared();
  } else {
    getTunnelUrl();
  }
});

const BASE = 'http://127.0.0.1:8080';
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

async function act(body) {
  for (let i = 0; i < 4; i++) {
    const r = await fetch(BASE + '/api/act', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...body, force: true })
    });
    const d = await r.json();
    if (d && d.ok !== false) return d;
    await sleep(200);
  }
  return { ok: false };
}

async function scan3d(x1, y1, z1, x2, y2, z2) {
  const r = await fetch(`${BASE}/api/scan3d?x1=${x1}&y1=${y1}&z1=${z1}&x2=${x2}&y2=${y2}&z2=${z2}`);
  return await r.json();
}

async function main() {
  // 1. Clean Kuzey Orman Mezzanine clutter, floating benches, floating enquiry, backwards ticket machine, and station tunnel lights
  await act({ action: 'command', command: 'gamemode spectator ArenaAI' });
  await act({ action: 'command', command: 'tp ArenaAI -21 50 31' });
  await sleep(500);

  const northScan = await scan3d(-33, 47, 19, -15, 62, 45);
  const northOps = [
    // Remove floating benches over staircase
    { x: -22, y: 57, z: 29, block: 'minecraft:air' },
    { x: -22, y: 57, z: 30, block: 'minecraft:air' },
    // Remove floating & backwards enquiry processor + excess mezzanine clutter
    { x: -28, y: 58, z: 33, block: 'minecraft:air' },
    { x: -28, y: 59, z: 33, block: 'minecraft:air' },
    { x: -28, y: 57, z: 31, block: 'minecraft:air' },
    { x: -23, y: 57, z: 36, block: 'minecraft:air' },
    { x: -23, y: 58, z: 39, block: 'minecraft:air' },
    { x: -22, y: 59, z: 24, block: 'minecraft:air' },
    { x: -22, y: 59, z: 32, block: 'minecraft:air' },
    // Fix backwards ticket machine at z=37 to face EAST toward passengers!
    { x: -28, y: 57, z: 37, block: 'mtr:ticket_machine[facing=east,half=lower]' },
    { x: -28, y: 58, z: 37, block: 'mtr:ticket_machine[facing=east,half=upper]' },
  ];
  // Replace every scattered tunnel_emergency_light inside Kuzey Orman station with warm flush pearlescent_froglight
  for (const [x, y, z, pi] of (northScan.voxels || [])) {
    if ((northScan.palette[pi] || '').includes('tunnel_emergency_light')) {
      northOps.push({ x, y, z, block: 'minecraft:pearlescent_froglight[axis=y]' });
    }
  }
  await act({ action: 'build', ops: northOps });
  await sleep(350);

  // 2. Convert the ENTIRE 1.52 km Tunnel (z=46..1564) into ONE CONTINUOUS SEAMLESS CENTER CEILING LED STRIP (-18, 52, z)
  const segments = [
    [46, 220, 130],
    [221, 410, 315],
    [411, 600, 505],
    [601, 790, 695],
    [791, 980, 885],
    [981, 1170, 1075],
    [1171, 1360, 1265],
    [1361, 1564, 1465],
  ];
  for (const [z1, z2, midZ] of segments) {
    await act({ action: 'command', command: `tp ArenaAI -18 49 ${midZ}` });
    await sleep(300);
    await act({
      action: 'command',
      command: `fill -18 52 ${z1} -18 52 ${z2} arena_ai_bridge:tunnel_emergency_light[ceiling=true,emergency=false,facing=north]`
    });
    await sleep(200);
  }

  // 3. Clean Güney Orman Station scattered tunnel_emergency_lights & place verified wall/floor furniture
  await act({ action: 'command', command: 'tp ArenaAI -21 49 1584' });
  await sleep(450);
  const southScan = await scan3d(-32, 47, 1565, -15, 62, 1595);
  const southOps = [];
  for (const [x, y, z, pi] of (southScan.voxels || [])) {
    if ((southScan.palette[pi] || '').includes('tunnel_emergency_light')) {
      southOps.push({ x, y, z, block: 'minecraft:pearlescent_froglight[axis=y]' });
    }
  }
  // Verified solid Smooth Quartz floor (y=48) & solid Smooth Quartz west wall (x=-28)
  southOps.push(
    { x: -27, y: 49, z: 1579, block: 'arena_ai_bridge:vending_machine[facing=east]' },
    { x: -27, y: 49, z: 1581, block: 'arena_ai_bridge:info_kiosk[facing=east]' },
    { x: -27, y: 49, z: 1585, block: 'arena_ai_bridge:metro_bench[facing=east]' },
    { x: -27, y: 49, z: 1586, block: 'arena_ai_bridge:metro_bench[facing=east]' },
    { x: -27, y: 49, z: 1587, block: 'arena_ai_bridge:metro_bench[facing=east]' },
    { x: -27, y: 50, z: 1577, block: 'arena_ai_bridge:safety_cabinet[facing=east]' },
    { x: -27, y: 50, z: 1583, block: 'arena_ai_bridge:ad_lightbox[facing=east,poster_theme=2]' },
    { x: -27, y: 50, z: 1589, block: 'arena_ai_bridge:ad_lightbox[facing=east,poster_theme=0]' }
  );
  await act({ action: 'build', ops: southOps });
  await sleep(350);

  // 4. AUTOMATED POST-HEAL SELF-TEST ACROSS NORTH, TUNNEL, AND SOUTH!
  let issues = [];
  const checkStation = (label, d) => {
    const pal = d.palette || [];
    const map = new Map();
    for (const [x, y, z, pi] of (d.voxels || [])) map.set(`${x},${y},${z}`, pal[pi]);
    for (const [x, y, z, pi] of (d.voxels || [])) {
      const id = pal[pi];
      if (id.includes('tunnel_emergency_light')) {
        issues.push(`${label}: unexpected tunnel_emergency_light in station at (${x},${y},${z})`);
      }
      const base = id.split('[')[0];
      if (base.endsWith('metro_bench') || base.endsWith('vending_machine') || base.endsWith('info_kiosk') || (base.includes('ticket_machine') && id.includes('half=lower'))) {
        const below = map.get(`${x},${y - 1},${z}`) || 'air';
        if (below === 'air' || below.includes('stairs')) {
          issues.push(`${label}: floating floor block ${id} at (${x},${y},${z}) below=${below}`);
        }
      }
      if (base.includes('ticket_machine') && id.includes('facing=west') && (map.get(`${x - 1},${y},${z}`) || 'air') !== 'air') {
        issues.push(`${label}: backwards ticket_machine facing wall at (${x},${y},${z})`);
      }
      if (base.endsWith('ad_lightbox') || base.endsWith('safety_cabinet')) {
        const m = id.match(/facing=(north|south|east|west)/);
        if (m) {
          const f = m[1];
          const bx = x + (f === 'east' ? -1 : f === 'west' ? 1 : 0);
          const bz = z + (f === 'south' ? -1 : f === 'north' ? 1 : 0);
          const back = map.get(`${bx},${y},${bz}`) || 'air';
          if (back === 'air') {
            issues.push(`${label}: unbacked wall block ${id} at (${x},${y},${z}) back=${back}`);
          }
        }
      }
    }
  };

  checkStation('SOUTH', await scan3d(-32, 47, 1565, -15, 62, 1595));
  await act({ action: 'command', command: 'tp ArenaAI -18 49 70' });
  await sleep(350);
  const tun = await scan3d(-19, 51, 60, -17, 53, 75);
  const tunLights = (tun.voxels || []).filter(([x, y, z, pi]) => x === -18 && y === 52 && tun.palette[pi].includes('tunnel_emergency_light'));
  if (tunLights.length !== 16) {
    issues.push(`TUNNEL: expected 16/16 connected LED strip blocks in z=60..75, got ${tunLights.length}`);
  }

  await act({ action: 'command', command: 'tp ArenaAI -21 50 31' });
  await sleep(350);
  checkStation('NORTH', await scan3d(-33, 47, 19, -15, 62, 45));

  // Return ArenaAI cleanly to creative mode on Güney Orman platform
  await act({ action: 'command', command: 'tp ArenaAI -21 49 1584' });
  await act({ action: 'command', command: 'gamemode creative ArenaAI' });

  console.log('SELF-TEST RESULT:', issues.length === 0 ? 'PASSED 100% (0 ISSUES)' : issues);
  if (issues.length > 0) process.exit(1);
}

main().catch(e => { console.error(e); process.exit(1); });

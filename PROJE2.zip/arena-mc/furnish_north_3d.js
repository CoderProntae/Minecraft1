const BASE = 'http://127.0.0.1:8080';
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

async function act(body) {
  for (let i = 0; i < 4; i++) {
    const r = await fetch(BASE + '/api/act', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...body, force: true })
    });
    const d = await r.json();
    if (d && d.ok !== false) return d;
    await sleep(250);
  }
  return { ok: false };
}

async function main() {
  // Keep ArenaAI safely in open platform walkway
  await act({ action: 'command', command: 'tp ArenaAI -21 49 31' });
  await sleep(250);

  const ops = [
    // 1. 3D Ergonomic Station Benches (replacing clunky vanilla stair benches!)
    { x: -26, y: 49, z: 22, block: 'arena_ai_bridge:metro_bench[facing=east]' },
    { x: -26, y: 49, z: 23, block: 'arena_ai_bridge:metro_bench[facing=east]' },
    { x: -26, y: 49, z: 24, block: 'arena_ai_bridge:metro_bench[facing=east]' },
    { x: -23, y: 49, z: 39, block: 'arena_ai_bridge:metro_bench[facing=east]' },
    { x: -23, y: 49, z: 40, block: 'arena_ai_bridge:metro_bench[facing=east]' },
    { x: -22, y: 57, z: 29, block: 'arena_ai_bridge:metro_bench[facing=west]' },
    { x: -22, y: 57, z: 30, block: 'arena_ai_bridge:metro_bench[facing=west]' },

    // 2. 3D Smart Refreshment & Card Top-Up Machines (50% Orman Kart discount in forest region, never free!)
    { x: -28, y: 57, z: 31, block: 'arena_ai_bridge:vending_machine[facing=east]' },
    { x: -28, y: 57, z: 32, block: 'arena_ai_bridge:vending_machine[facing=east]' },
    { x: -27, y: 49, z: 33, block: 'arena_ai_bridge:vending_machine[facing=east]' },

    // 3. 3D Ultra-Slim Backlit Metro Ad Lightboxes (preserving z=28 & z=30 world_map_boards!)
    { x: -27, y: 50, z: 26, block: 'arena_ai_bridge:ad_lightbox[facing=east,poster_theme=0]' },
    { x: -27, y: 50, z: 32, block: 'arena_ai_bridge:ad_lightbox[facing=east,poster_theme=1]' },
    { x: -22, y: 59, z: 24, block: 'arena_ai_bridge:ad_lightbox[facing=west,poster_theme=0]' },
    { x: -22, y: 59, z: 32, block: 'arena_ai_bridge:ad_lightbox[facing=west,poster_theme=2]' },

    // 4. 3D Digital Passenger Info & Balance Totem Kiosks
    { x: -24, y: 49, z: 24, block: 'arena_ai_bridge:info_kiosk[facing=south]' },
    { x: -23, y: 57, z: 36, block: 'arena_ai_bridge:info_kiosk[facing=north]' },

    // 5. 3D Emergency Fire Extinguisher & SOS Wall Cabinets
    { x: -22, y: 50, z: 20, block: 'arena_ai_bridge:safety_cabinet[facing=south]' },
    { x: -22, y: 50, z: 44, block: 'arena_ai_bridge:safety_cabinet[facing=north]' },
    { x: -23, y: 58, z: 39, block: 'arena_ai_bridge:safety_cabinet[facing=north]' }
  ];

  const res = await act({ action: 'build', ops, recordUndo: false, strictPhysics: false, cleanFloating: false });
  console.log('Furnish Kuzey Orman 3D blocks:', res.ok, 'placed:', ops.length);
}

main().catch(e => { console.error(e); process.exit(1); });

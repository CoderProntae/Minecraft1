async function buildMtrCorridor() {
  const act = (body) =>
    fetch('http://127.0.0.1:8080/api/act', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    }).then((r) => r.json());

  // Scan the entire North-South MTR railway corridor: x = -84..-64, z = -34..+130
  const scans = await Promise.all([
    fetch('http://127.0.0.1:8080/api/scan?x=-74&z=-8&r=30&step=1').then((r) => r.json()),
    fetch('http://127.0.0.1:8080/api/scan?x=-74&z=48&r=30&step=1').then((r) => r.json()),
    fetch('http://127.0.0.1:8080/api/scan?x=-74&z=104&r=30&step=1').then((r) => r.json())
  ]);

  const map = new Map();
  for (const s of scans) {
    for (const row of s.grid || []) {
      for (const c of row) map.set(`${c.x},${c.z}`, c);
    }
  }
  const cell = (x, z) => map.get(`${x},${z}`) || { x, y: 64, z, b: 'grass_block' };

  const ops = [];
  const set = (x, y, z, block, onlyAir = false) => ops.push({ op: 'set', x, y, z, block, onlyAir });
  const foundation = (x, y, z, block) => ops.push({ op: 'foundation', x, y, z, block });

  const railX = -76;   // Centerline of MTR railway track
  const deckY = 71;    // Solid viaduct deck at y=71; MTR rail nodes & trains run at y=72!

  // ==================== 1. CONTINUOUS ELEVATED VIADUCT DECK & ARCHED RIVER PIERS (z = -30 .. +125) ====================
  for (let z = -30; z <= 125; z++) {
    // Clear train clearance envelope (x = -78..-74, y = 72..77) so NO branches or walls block the train!
    for (let x = -78; x <= -74; x++) {
      for (let y = deckY + 1; y <= deckY + 6; y++) {
        set(x, y, z, 'minecraft:air');
      }
    }

    // Track Roadbed Deck (x = -78..-74, y = deckY)
    set(-78, deckY, z, 'minecraft:polished_deepslate');
    set(-77, deckY, z, 'minecraft:gravel');
    set(-76, deckY, z, 'minecraft:andesite'); // Solid center sleeper bed for MTR rail!
    set(-75, deckY, z, 'minecraft:gravel');
    set(-74, deckY, z, 'minecraft:polished_deepslate');

    // Under-girder spine at y = deckY - 1
    for (let x = -78; x <= -74; x++) {
      set(x, deckY - 1, z, 'minecraft:stone_bricks');
    }

    const inNorthStation = z >= 2 && z <= 26;
    const inSouthStation = z >= 90 && z <= 114;

    // West Parapet Railing along entire line (and East Parapet where there is no station platform)
    set(-78, deckY + 1, z, z % 6 === 0 ? 'minecraft:chiseled_stone_bricks' : 'minecraft:stone_brick_wall');
    if (z % 12 === 0) set(-78, deckY + 2, z, 'minecraft:lantern');

    if (!inNorthStation && !inSouthStation) {
      set(-74, deckY + 1, z, z % 6 === 0 ? 'minecraft:chiseled_stone_bricks' : 'minecraft:stone_brick_wall');
      if (z % 12 === 0) set(-74, deckY + 2, z, 'minecraft:lantern');
    }

    // Heavy Grounded Stone Viaduct Piers every 10 blocks!
    if (z % 10 === 0) {
      for (const px of [-78, -77, -75, -74]) {
        foundation(px, deckY - 2, z, 'minecraft:stone_bricks');
      }
      // Arch corbels next to pier
      for (const dz of [-1, 1]) {
        if (z + dz >= -30 && z + dz <= 125) {
          set(-78, deckY - 2, z + dz, 'minecraft:stone_brick_stairs[facing=' + (dz < 0 ? 'south' : 'north') + ',half=top]');
          set(-74, deckY - 2, z + dz, 'minecraft:stone_brick_stairs[facing=' + (dz < 0 ? 'south' : 'north') + ',half=top]');
        }
      }
    }
  }

  // Maintenance Siding Shed Roof over z = -28 .. -10
  for (let z = -28; z <= -10; z++) {
    if (z % 6 === -28 % 6 || z === -28 || z === -10) {
      for (let y = deckY + 2; y <= deckY + 5; y++) {
        set(-78, y, z, 'minecraft:deepslate_brick_wall');
        set(-74, y, z, 'minecraft:deepslate_brick_wall');
      }
    }
    for (let x = -79; x <= -73; x++) {
      set(x, deckY + 6, z, Math.abs(x + 76) === 3 ? 'minecraft:deepslate_tile_slab[type=bottom]' : 'minecraft:spruce_planks');
    }
  }

  // ==================== 2. STATION BUILDER HELPER (GENUINE MTR 4.0.5 PLATFORMS, PIDS, TICKET GATES & ROOF!) ====================
  function buildMtrStation(zStart, zEnd, style) {
    const isSouth = style === 'south';
    const wallBlock = isSouth ? 'minecraft:mud_bricks' : 'minecraft:stone_bricks';
    const pillarLog = isSouth ? 'minecraft:stripped_jungle_log[axis=y]' : 'minecraft:stripped_spruce_log[axis=y]';
    const roofPlank = isSouth ? 'minecraft:jungle_planks' : 'minecraft:dark_oak_planks';
    const roofSlab  = isSouth ? 'minecraft:mud_brick_slab[type=bottom]' : 'minecraft:spruce_slab[type=bottom]';
    const fenceMat  = isSouth ? 'minecraft:bamboo_fence' : 'minecraft:spruce_fence';
    const stairMat  = isSouth ? 'minecraft:mud_brick_stairs' : 'minecraft:stone_brick_stairs';

    // Station Platform Deck: x = -74 .. -68 (width 7 blocks!), z = zStart .. zEnd, top surface at y = deckY + 1 (= 72, matching MTR rail node height!)
    // WAIT: In MTR 4, when mtr:rail is placed ON y=71 (so rail block is at y=72), train floor is at y=73 (1 block above rail)!
    // Let's verify: in MTR, platform block top is 1 block ABOVE rail node base (rail node is at y=72, platform block is at y=72, whose solid top is y=73)!
    // YES! Both mtr:rail and mtr:platform sit at y = deckY + 1 (= 72)!
    const platY = deckY + 1; // 72

    for (let z = zStart; z <= zEnd; z++) {
      // Clear headroom across station hall (x = -74..-67, y = platY+1 .. platY+6)
      for (let x = -74; x <= -67; x++) {
        for (let y = platY + 1; y <= platY + 6; y++) {
          set(x, y, z, 'minecraft:air');
        }
      }

      // Solid Support Structure & Grounded Foundations under Station Hall
      for (let x = -74; x <= -68; x++) {
        set(x, deckY, z, wallBlock);
        if ((z - zStart) % 6 === 0 && (x === -73 || x === -68)) {
          foundation(x, deckY - 1, z, wallBlock);
        }
      }

      // MTR Official Platform Edge at x = -74, y = platY (72) facing West toward the track at x = -76!
      // Wait: also check x = -75! Train center is x = -76; in MTR 4 standard gauge, platform edge is 2 blocks from center (x = -74) OR 1 block?
      // Let's check: a 3-block wide train centered on x = -76.0 spans x = -77.5 .. -74.5 -> block -76 is center, block -75 is under train body overhang, block -74 is platform edge? Wait: block -76 center is -75.5!
      // HOLD ON! Check block coordinates carefully!!
      // Block x = -76 spans [-76.0, -75.0], so its center is x = -75.5!
      // A train of width 2.5m centered at -75.5 spans [-76.75, -74.25]!
      // Block x = -75 spans [-75.0, -74.0] (overlaps [-75.0, -74.25] — MTR indented platform or x=-74)!
      // Actually in MTR, rail node block is 1 block wide at x=-76, gap of 1 block at x=-75 (where sleepers extend), and `mtr:platform` is placed at **x = -74** (`facing=west`, looking toward track) OR `x = -75`! Wait: `mtr:platform_indented` overhangs by 0.5 block toward track! Putting `mtr:platform[facing=west,door_type=none,side=0]` at `x = -74` leaves `x = -75` clear for wide trains AND `mtr:platform` has built-in yellow safety line facing West!
      set(-74, platY, z, 'mtr:platform[facing=west,door_type=none,side=0]');

      // Platform Floor Tiles (x = -73 .. -68, y = platY)
      for (let x = -73; x <= -68; x++) {
        set(x, platY, z, (x + z) % 2 === 0 ? 'minecraft:smooth_stone' : 'minecraft:polished_andesite');
      }

      // Back Wall / Columns on East edge (x = -68) — leaving grand Concourse Entrance in the middle (zMid - 2 .. zMid + 2)!
      const zMid = Math.round((zStart + zEnd) / 2);
      const isEntranceGap = Math.abs(z - zMid) <= 2;

      if (!isEntranceGap) {
        if ((z - zStart) % 4 === 0 || z === zStart || z === zEnd) {
          for (let y = platY + 1; y <= platY + 4; y++) set(-68, y, z, pillarLog);
        } else {
          set(-68, platY + 1, z, wallBlock);
          set(-68, platY + 2, z, 'minecraft:glass_pane');
          set(-68, platY + 3, z, fenceMat);
        }
      }

      // North & South End Railings of Platform
      if (z === zStart || z === zEnd) {
        for (let x = -73; x <= -68; x++) {
          set(x, platY + 1, z, fenceMat);
        }
      }

      // Full Station Canopy Roof over Track + Platform (x = -79 .. -67, y = platY + 5 .. +6) — 100% solid ceiling!
      for (let x = -79; x <= -67; x++) {
        if (x === -79 || x === -67) {
          set(x, platY + 5, z, roofSlab);
        } else {
          set(x, platY + 5, z, roofPlank);
          if (x >= -77 && x <= -69) {
            set(x, platY + 6, z, roofSlab);
          }
        }
      }
      // West side roof support columns every 6 blocks at x = -78
      if ((z - zStart) % 6 === 0) {
        for (let y = deckY + 1; y <= platY + 4; y++) {
          set(-78, y, z, pillarLog);
        }
      }
    }

    const zMid = Math.round((zStart + zEnd) / 2);

    // Authentic MTR PIDS (Passenger Information Display Screens) hung from solid roof at platY+5!
    for (const pz of [zStart + 5, zEnd - 5]) {
      set(-72, platY + 4, pz, 'mtr:pids_pole[facing=north]');
      set(-72, platY + 3, pz, 'mtr:pids_1[facing=north]');
      // Solidly chained station lanterns
      set(-70, platY + 4, pz, 'minecraft:chain[axis=y]');
      set(-70, platY + 3, pz, 'minecraft:lantern[hanging=true]');
    }

    // MTR Standing Station Name Totem on Platform!
    set(-71, platY + 1, zMid, 'mtr:station_name_tall_standing[color=0,facing=west,metal=true,third=lower]');
    set(-71, platY + 2, zMid, 'mtr:station_name_tall_standing[color=0,facing=west,metal=true,third=middle]');
    set(-71, platY + 3, zMid, 'mtr:station_name_tall_standing[color=0,facing=west,metal=true,third=upper]');

    // MTR Ticket Concourse & Wide Grand Staircase Descending East (x = -67 .. -60, z = zMid - 2 .. zMid + 2) down to ground!
    // Concourse Landing at x = -67..-65, y = platY, with MTR Ticket Barriers & MTR Ticket Machine!
    for (let x = -67; x <= -65; x++) {
      for (let z = zMid - 3; z <= zMid + 3; z++) {
        foundation(x, platY, z, wallBlock);
        set(x, platY, z, 'minecraft:polished_andesite');
        for (let y = platY + 1; y <= platY + 5; y++) set(x, y, z, 'minecraft:air');
        if (Math.abs(z - zMid) === 3) set(x, platY + 1, z, fenceMat);
      }
    }
    // MTR Ticket Barriers at x = -67 (between concourse & platform!)
    set(-67, platY + 1, zMid - 2, fenceMat);
    set(-67, platY + 1, zMid - 1, 'mtr:ticket_barrier_entrance_1[facing=west,open=open]');
    set(-67, platY + 1, zMid,     'mtr:ticket_barrier_entrance_1[facing=west,open=open]');
    set(-67, platY + 1, zMid + 1, 'mtr:ticket_barrier_exit_1[facing=east,open=open]');
    set(-67, platY + 1, zMid + 2, fenceMat);

    // MTR Ticket Machine at (x = -66, z = zMid - 2)
    set(-66, platY + 1, zMid - 2, 'mtr:ticket_machine[facing=south,half=lower]');
    set(-66, platY + 2, zMid - 2, 'mtr:ticket_machine[facing=south,half=upper]');

    // Grand Grounded Staircase leading East (x = -64, -63, ...) down to natural ground height!
    const targetGround = cell(-59, zMid).y;
    const totalDrop = Math.max(1, platY - targetGround);
    for (let step = 0; step < totalDrop; step++) {
      const sx = -64 + step;
      const sy = platY - step;
      for (let z = zMid - 2; z <= zMid + 2; z++) {
        for (let y = sy + 1; y <= sy + 5; y++) set(sx, y, z, 'minecraft:air');
        foundation(sx, sy - 1, z, wallBlock);
        if (Math.abs(z - zMid) === 2) {
          set(sx, sy, z, wallBlock);
          set(sx, sy + 1, z, fenceMat);
        } else {
          set(sx, sy, z, `${stairMat}[facing=west,half=bottom]`);
        }
      }
    }

    return { platY, zMid };
  }

  const northSt = buildMtrStation(2, 26, 'north');    // 1. Bolge: Kuzey Avrasya Gari
  const southSt = buildMtrStation(90, 114, 'south');  // 2. Bolge: Guney Yagmur Gari

  // Connect South Station stairs (-58, 102) cleanly to Southern Forest North Gate (-85, 115) via paved plaza walk!
  for (let x = -85; x <= -58; x++) {
    for (let z = 111; z <= 113; z++) {
      const g = cell(x, z).y;
      if (!cell(x, z).b.includes('water') && g <= 74) {
        set(x, g, z, (x + z) % 2 === 0 ? 'minecraft:mud_bricks' : 'minecraft:packed_mud');
      }
    }
  }

  console.log('Building MTR Viaduct & Dual Stations ops:', ops.length);
  const buildRes = await act({ action: 'build', ops });
  console.log('MTR ARCHITECTURE RESULT:', JSON.stringify({
    ok: buildRes.ok,
    changedBlocks: buildRes.changedBlocks,
    autoConnected: buildRes.autoConnected,
    cleanedFloating: buildRes.cleanedFloating,
    physicsRejectedCount: (buildRes.physicsRejected || []).length,
    errors: buildRes.errors
  }, null, 2));

  // ==================== 3. PLACE REAL MTR 4.0.5 RAIL NODES & CONNECT 3D SPLINE TRACKS VIA /interact! ====================
  const nodeZs = [-28, -8, 2, 26, 58, 90, 114, 123];
  for (const nz of nodeZs) {
    await act({ action: 'command', command: `tp ArenaAI ${railX + 2} ${deckY + 1} ${nz}` });
    // Right-click top of roadbed (railX, deckY, nz) with mtr:rail to create real MTR Rail Node!
    const rPlace = await act({ action: 'interact', x: railX, y: deckY, z: nz, side: 'up', item: 'mtr:rail' });
    console.log(`Placed MTR Rail Node at z=${nz}:`, rPlace.result);
  }

  // Connect pairs of MTR Rail Nodes at y = deckY + 1 (= 72)!
  const segments = [
    [-28, -8,  'mtr:rail_connector_siding'],    // Depot Siding
    [-8,   2,  'mtr:rail_connector_80'],        // Siding -> North Station
    [2,   26,  'mtr:rail_connector_platform'],  // North Station Platform Track!
    [26,  58,  'mtr:rail_connector_80'],        // River Strait Viaduct North Span
    [58,  90,  'mtr:rail_connector_80'],        // River Strait Viaduct South Span
    [90, 114,  'mtr:rail_connector_platform'],  // South Station Platform Track!
    [114, 123, 'mtr:rail_connector_turn_back']  // South Turnback Tail!
  ];

  for (const [z1, z2, connector] of segments) {
    await act({ action: 'command', command: `tp ArenaAI ${railX + 2} ${deckY + 1} ${z1}` });
    const click1 = await act({ action: 'interact', x: railX, y: deckY + 1, z: z1, side: 'up', item: connector });
    await act({ action: 'command', command: `tp ArenaAI ${railX + 2} ${deckY + 1} ${z2}` });
    const click2 = await act({ action: 'interact', x: railX, y: deckY + 1, z: z2, side: 'up', item: connector });
    console.log(`Connected [${z1} <-> ${z2}] via ${connector}:`, click1.result, '->', click2.result);
  }

  // Station Signs & Give ilkan the MTR Railway Dashboard so he can see the live stations & deploy his favorite train!
  const cmds = [
    `setblock -65 ${northSt.platY + 3} ${northSt.zMid} minecraft:spruce_wall_sign[facing=east]{front_text:{messages:['{"text":"🚆 MTR ISTASYON","bold":true,"color":"aqua"}','{"text":"KUZEY AVRASYA","bold":true,"color":"white"}','{"text":"1. Bolge Gari","color":"green"}','{"text":"Peron 1 - Guney","color":"yellow"}']},is_waxed:1b}`,
    `setblock -65 ${southSt.platY + 3} ${southSt.zMid} minecraft:jungle_wall_sign[facing=east]{front_text:{messages:['{"text":"🚆 MTR ISTASYON","bold":true,"color":"gold"}','{"text":"GUNEY YAGMUR","bold":true,"color":"white"}','{"text":"2. Bolge Gari","color":"green"}','{"text":"Peron 1 - Kuzey","color":"yellow"}']},is_waxed:1b}`,
    `give ilkan mtr:dashboard 1`,
    // Position ArenaAI on South Station platform ready to greet him, and orient ilkan's view if needed!
    `tp ArenaAI -71 ${southSt.platY + 1} ${southSt.zMid}`
  ];
  for (const c of cmds) {
    await act({ action: 'command', command: c });
  }
}

buildMtrCorridor().catch(console.error);

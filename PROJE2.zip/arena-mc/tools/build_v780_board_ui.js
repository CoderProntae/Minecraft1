#!/usr/bin/env node
/**
 * Build v7.8.0 MTR-Authentic PIDS & Station Notice Board Atlas + GUI Texture:
 *  - ZERO sci-fi cyan/blue! Directly modeled after MTR 4.0.5 PIDS (mtr:block/metal + black + #FF9900 orange bar).
 *  1) mod-src/assets/arena_ai_bridge/textures/gui/board_ui_atlas.png (256x256)
 *     - [0,   0, 128, 96] : "roadmap" (MTR PIDS Style: Light anodized silver metal casing + matte black LED matrix + 1px #FF9900 orange header divider)
 *     - [128, 0, 128, 96] : "highway_green" (Karayollari O-7 Highway Green + white reflector rim + silver casing)
 *     - [0,  96, 128, 96] : "highway_blue" / "poster_light" (Classic Metro Station White/Silver Architectural Poster + Charcoal/Red header)
 *     - [128,96, 128, 96] : "warning_amber" (Construction / YAKINDA Notice: Silver casing + hazard header stripe + matte black + amber rule)
 *     - [0..64, 192, 16x16 each] : Crisp pixel-art status icons (0=Green Check, 1=MTR Amber Arrow, 2=Planned Dot, 3=Warning Triangle)
 *     - [0..192, 216, 46x16 each]: Clean industrial MTR route/header badges (0=MTR Orange, 1=Metro Green, 2=Caution Yellow, 3=Transit Red)
 *     - [192, 192, 64, 64]       : MTR neutral warm-silver brushed aluminum 3D casing texture (matches mtr:block/metal)
 *  2) mod-src/assets/arena_ai_bridge/textures/gui/plan_gui.png (256x256)
 *     - [0, 0, 244, 192]   : MTR silver-framed PIDS configuration console (matte black screen + #FF9900 orange bar, zero blue!)
 *     - [0, 198, 51, 16]   : Industrial button normal (#2B2B2B + #5A5A5A bevel)
 *     - [56, 198, 51, 16]  : Industrial button hover (#FF9900 MTR amber)
 *     - [0, 218, 216, 23]  : Row hover highlight (#1F1A12 + #FF9900 1px border)
 */
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const ROOT = path.resolve(__dirname, '..');
const GUI_DIR = path.join(ROOT, 'mod-src/assets/arena_ai_bridge/textures/gui');
fs.mkdirSync(GUI_DIR, { recursive: true });

class Canvas {
  constructor(w, h) {
    this.w = w;
    this.h = h;
    this.buf = Buffer.alloc(w * h * 4, 0);
  }
  idx(x, y) { return (y * this.w + x) * 4; }
  set(x, y, r, g, b, a = 255) {
    x = Math.round(x); y = Math.round(y);
    if (x < 0 || y < 0 || x >= this.w || y >= this.h) return;
    const i = this.idx(x, y);
    if (a >= 255 || this.buf[i + 3] === 0) {
      this.buf[i] = Math.max(0, Math.min(255, Math.round(r)));
      this.buf[i + 1] = Math.max(0, Math.min(255, Math.round(g)));
      this.buf[i + 2] = Math.max(0, Math.min(255, Math.round(b)));
      this.buf[i + 3] = Math.max(0, Math.min(255, Math.round(a)));
    } else {
      const sa = a / 255, da = this.buf[i + 3] / 255;
      const outA = sa + da * (1 - sa);
      this.buf[i]     = Math.round((r * sa + this.buf[i]     * da * (1 - sa)) / outA);
      this.buf[i + 1] = Math.round((g * sa + this.buf[i + 1] * da * (1 - sa)) / outA);
      this.buf[i + 2] = Math.round((b * sa + this.buf[i + 2] * da * (1 - sa)) / outA);
      this.buf[i + 3] = Math.round(outA * 255);
    }
  }
  fillRect(x0, y0, w, h, r, g, b, a = 255) {
    for (let y = y0; y < y0 + h; y++)
      for (let x = x0; x < x0 + w; x++)
        this.set(x, y, r, g, b, a);
  }
  strokeRect(x0, y0, w, h, r, g, b, a = 255) {
    for (let x = x0; x < x0 + w; x++) {
      this.set(x, y0, r, g, b, a);
      this.set(x, y0 + h - 1, r, g, b, a);
    }
    for (let y = y0; y < y0 + h; y++) {
      this.set(x0, y, r, g, b, a);
      this.set(x0 + w - 1, y, r, g, b, a);
    }
  }
  toPNG() {
    const raw = Buffer.alloc(this.h * (1 + this.w * 4));
    for (let y = 0; y < this.h; y++) {
      const rowStart = y * (1 + this.w * 4);
      raw[rowStart] = 0;
      this.buf.copy(raw, rowStart + 1, y * this.w * 4, (y + 1) * this.w * 4);
    }
    const idat = zlib.deflateSync(raw, { level: 9 });
    const crcTable = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
      crcTable[n] = c >>> 0;
    }
    const crc32 = (buf) => {
      let c = 0xffffffff;
      for (let i = 0; i < buf.length; i++) c = crcTable[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
      return (c ^ 0xffffffff) >>> 0;
    };
    const chunk = (type, data) => {
      const len = Buffer.alloc(4); len.writeUInt32BE(data.length, 0);
      const t = Buffer.from(type, 'ascii');
      const body = Buffer.concat([t, data]);
      const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(body), 0);
      return Buffer.concat([len, body, crc]);
    };
    const ihdr = Buffer.alloc(13);
    ihdr.writeUInt32BE(this.w, 0);
    ihdr.writeUInt32BE(this.h, 4);
    ihdr[8] = 8; ihdr[9] = 6; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
    return Buffer.concat([
      Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
      chunk('IHDR', ihdr),
      chunk('IDAT', idat),
      chunk('IEND', Buffer.alloc(0))
    ]);
  }
}

// Helper: Fill MTR brushed neutral silver metal (matches mtr:block/metal.png: ~220-232 neutral grey, zero blue!)
function fillMtrSilverMetal(c, x0, y0, w, h) {
  for (let y = y0; y < y0 + h; y++) {
    // Subtle horizontal brushed grain
    const grain = Math.round(Math.sin(y * 1.9) * 3 + Math.cos(y * 0.7) * 2);
    for (let x = x0; x < x0 + w; x++) {
      const micro = ((x * 13 + y * 7) % 5) - 2;
      const v = 216 + grain + micro;
      c.set(x, y, v, v + 1, v + 1, 255); // strictly neutral silver
    }
  }
  // Clean 3D industrial bevel
  c.fillRect(x0, y0, w, 1, 244, 245, 245, 255);
  c.fillRect(x0, y0, 1, h, 238, 239, 239, 255);
  c.fillRect(x0, y0 + h - 1, w, 1, 148, 150, 152, 255);
  c.fillRect(x0 + w - 1, y0, 1, h, 158, 160, 162, 255);
}

// ==================== 1. BUILD board_ui_atlas.png (256x256) ====================
function buildBoardAtlas() {
  const c = new Canvas(256, 256);

  // A) [0, 0, 128, 96] : MTR PIDS Classic Style ("roadmap" default)
  // Light silver metal casing + recessed matte-black LED dot-matrix + 1px #FF9900 MTR orange divider
  {
    const ox = 0, oy = 0, w = 128, h = 96;
    fillMtrSilverMetal(c, ox, oy, w, h);
    // Dark rubber gasket & recessed bezel at inset 5
    c.strokeRect(ox + 4, oy + 4, w - 8, h - 8, 120, 122, 124, 255);
    c.fillRect(ox + 5, oy + 5, w - 10, h - 10, 10, 10, 10, 255);
    // Subtle authentic LED dot-matrix texture (#0A0A0A / #111111, ZERO blue)
    for (let y = oy + 6; y < oy + h - 6; y++) {
      for (let x = ox + 6; x < ox + w - 6; x++) {
        const dot = (x % 2 === 0 && y % 2 === 0) ? 14 : 9;
        c.set(x, y, dot, dot, dot, 255);
      }
    }
    // MTR PIDS signature warm orange horizontal bar (#FF9900) under header (y = 23)
    c.fillRect(ox + 6, oy + 23, w - 12, 1, 255, 153, 0, 255);
    c.fillRect(ox + 6, oy + 24, w - 12, 1, 90, 52, 0, 255);
    // Subtle neutral dark row dividers at y = 39, 54, 69, 82
    for (const ry of [39, 54, 69, 82]) {
      c.fillRect(ox + 8, oy + ry, w - 16, 1, 24, 24, 24, 255);
    }
  }

  // B) [128, 0, 128, 96] : Karayollari O-7 Highway Green ("highway_green")
  {
    const ox = 128, oy = 0, w = 128, h = 96;
    fillMtrSilverMetal(c, ox, oy, w, h);
    // White retroreflective border + Forest Green (#006837)
    c.fillRect(ox + 4, oy + 4, w - 8, h - 8, 244, 246, 244, 255);
    c.fillRect(ox + 7, oy + 7, w - 14, h - 14, 0, 104, 55, 255);
    for (let y = oy + 7; y < oy + h - 7; y++) {
      for (let x = ox + 7; x < ox + w - 7; x++) {
        if ((x + y) % 4 === 0) c.set(x, y, 0, 114, 61, 255);
      }
    }
    // Darker header & white divider at y = 23
    c.fillRect(ox + 7, oy + 7, w - 14, 16, 0, 84, 44, 255);
    c.fillRect(ox + 7, oy + 23, w - 14, 1, 244, 246, 244, 255);
  }

  // C) [0, 96, 128, 96] : Classic Metro Architectural White/Silver Poster ("highway_blue" / "poster_light")
  // Clean printed station poster: MTR silver frame + off-white matte placard + dark charcoal header + transit red stripe
  {
    const ox = 0, oy = 96, w = 128, h = 96;
    fillMtrSilverMetal(c, ox, oy, w, h);
    c.strokeRect(ox + 4, oy + 4, w - 8, h - 8, 150, 152, 154, 255);
    c.fillRect(ox + 5, oy + 5, w - 10, h - 10, 242, 243, 244, 255);
    // Charcoal header bar + Metro Red rule
    c.fillRect(ox + 5, oy + 5, w - 10, 18, 32, 34, 36, 255);
    c.fillRect(ox + 5, oy + 23, w - 10, 2, 211, 47, 47, 255);
    // Clean light-grey printed row rules
    for (const ry of [39, 54, 69, 82]) {
      c.fillRect(ox + 8, oy + ry, w - 16, 1, 216, 218, 220, 255);
    }
  }

  // D) [128, 96, 128, 96] : Construction / YAKINDA Notice ("warning_amber")
  // MTR silver frame + thin top/bottom yellow-black caution band + matte black LED face + amber divider
  {
    const ox = 128, oy = 96, w = 128, h = 96;
    fillMtrSilverMetal(c, ox, oy, w, h);
    c.fillRect(ox + 4, oy + 4, w - 8, h - 8, 12, 12, 12, 255);
    // Top & bottom 3px caution band inside silver bezel
    for (let x = 4; x < w - 4; x++) {
      for (const y of [4, 5, 6, h - 7, h - 6, h - 5]) {
        const stripe = ((x + y) % 10) < 5;
        c.set(ox + x, oy + y, stripe ? 245 : 22, stripe ? 179 : 22, stripe ? 0 : 22, 255);
      }
    }
    c.fillRect(ox + 6, oy + 23, w - 12, 1, 255, 179, 0, 255);
  }

  // E) [0..64, 192, 16x16 each] : 4 Crisp Pixel-Art Status Icons (so NO broken Unicode glyphs in font!)
  // Icon 0 [0, 192]: Green Completed LED CheckBox
  {
    const ix = 0, iy = 192;
    c.fillRect(ix + 2, iy + 2, 12, 12, 46, 125, 50, 255);
    c.strokeRect(ix + 2, iy + 2, 12, 12, 102, 187, 106, 255);
    // Crisp 2px white checkmark
    const pts = [[4,8],[5,9],[6,10],[7,9],[8,8],[9,7],[10,6],[11,5]];
    for (const [px, py] of pts) {
      c.set(ix + px, iy + py, 255, 255, 255, 255);
      c.set(ix + px, iy + py - 1, 255, 255, 255, 255);
    }
  }
  // Icon 1 [16, 192]: MTR Amber Active Right Arrow
  {
    const ix = 16, iy = 192;
    c.fillRect(ix + 2, iy + 2, 12, 12, 50, 32, 0, 255);
    c.strokeRect(ix + 2, iy + 2, 12, 12, 255, 153, 0, 255);
    c.fillRect(ix + 4, iy + 7, 6, 2, 255, 179, 0, 255);
    for (let d = 0; d < 4; d++) {
      c.set(ix + 8 + d, iy + 5 + d, 255, 193, 7, 255);
      c.set(ix + 8 + d, iy + 10 - d, 255, 193, 7, 255);
      c.set(ix + 7 + d, iy + 5 + d, 255, 193, 7, 255);
      c.set(ix + 7 + d, iy + 10 - d, 255, 193, 7, 255);
    }
  }
  // Icon 2 [32, 192]: Neutral Silver Planned Square
  {
    const ix = 32, iy = 192;
    c.fillRect(ix + 3, iy + 3, 10, 10, 42, 42, 42, 255);
    c.strokeRect(ix + 3, iy + 3, 10, 10, 176, 176, 176, 255);
    c.fillRect(ix + 6, iy + 6, 4, 4, 224, 224, 224, 255);
  }
  // Icon 3 [48, 192]: Warning Caution Amber Diamond/Square
  {
    const ix = 48, iy = 192;
    c.fillRect(ix + 2, iy + 2, 12, 12, 245, 179, 0, 255);
    c.strokeRect(ix + 2, iy + 2, 12, 12, 255, 213, 79, 255);
    c.fillRect(ix + 7, iy + 4, 2, 5, 20, 20, 20, 255);
    c.fillRect(ix + 7, iy + 10, 2, 2, 20, 20, 20, 255);
  }

  // F) [0..192, 216, 46x16 each] : 4 Clean Industrial Rectangular MTR Route/Header Tags
  const tags = [
    [255, 153, 0],   // 0: MTR Orange (#FF9900)
    [0, 121, 58],    // 1: Highway Green
    [245, 179, 0],   // 2: Caution Yellow
    [211, 47, 47]    // 3: Metro Red
  ];
  tags.forEach((rgb, i) => {
    const px = i * 48, py = 216, pw = 46, ph = 16;
    c.fillRect(px, py, pw, ph, rgb[0], rgb[1], rgb[2], 255);
    c.fillRect(px, py, pw, 1, Math.min(255, rgb[0] + 35), Math.min(255, rgb[1] + 35), Math.min(255, rgb[2] + 35), 255);
    c.fillRect(px, py + ph - 1, pw, 1, Math.max(0, rgb[0] - 45), Math.max(0, rgb[1] - 45), Math.max(0, rgb[2] - 45), 255);
  });

  // G) [192, 192, 64, 64] : MTR Neutral Silver Brushed Aluminum 3D Casing Texture
  fillMtrSilverMetal(c, 192, 192, 64, 64);

  const out = path.join(GUI_DIR, 'board_ui_atlas.png');
  fs.writeFileSync(out, c.toPNG());
  console.log('Wrote MTR-style', out);
}

// ==================== 2. BUILD plan_gui.png (256x256) ====================
function buildPlanGui() {
  const c = new Canvas(256, 256);
  const w = 244, h = 192;

  // Outer MTR neutral silver aluminum housing
  fillMtrSilverMetal(c, 0, 0, w, h);

  // Recessed matte-black PIDS console screen
  c.strokeRect(6, 6, w - 12, h - 12, 110, 112, 114, 255);
  c.fillRect(7, 7, w - 14, h - 14, 12, 12, 12, 255);

  // Header bar + MTR 1px #FF9900 orange stripe at y = 30
  c.fillRect(7, 7, w - 14, 23, 18, 18, 18, 255);
  c.fillRect(7, 30, w - 14, 2, 255, 153, 0, 255);

  // 4 Clean Industrial Row Slots [14, 38 + i*26, 216, 22]
  for (let i = 0; i < 4; i++) {
    const ry = 38 + i * 26;
    c.fillRect(14, ry, 216, 22, 20, 20, 20, 255);
    c.strokeRect(14, ry, 216, 22, 46, 46, 46, 255);
  }

  // Bottom Control Dock [14, 146, 216, 34]
  c.fillRect(14, 146, 216, 34, 18, 18, 18, 255);
  c.strokeRect(14, 146, 216, 34, 52, 52, 52, 255);

  // Button Normal [0, 198, 51, 16]: Clean dark industrial button
  c.fillRect(0, 198, 51, 16, 42, 42, 42, 255);
  c.strokeRect(0, 198, 51, 16, 96, 96, 96, 255);
  c.fillRect(1, 199, 49, 1, 72, 72, 72, 255);

  // Button Hover [56, 198, 51, 16]: MTR Orange highlight (#FF9900)
  c.fillRect(56, 198, 51, 16, 255, 153, 0, 255);
  c.strokeRect(56, 198, 51, 16, 255, 204, 102, 255);

  // Row Hover Highlight [0, 218, 216, 22]
  c.fillRect(0, 218, 216, 22, 38, 28, 10, 255);
  c.strokeRect(0, 218, 216, 22, 255, 153, 0, 255);

  const out = path.join(GUI_DIR, 'plan_gui.png');
  fs.writeFileSync(out, c.toPNG());
  console.log('Wrote MTR-style', out);
}

buildBoardAtlas();
buildPlanGui();

const fs = require('fs');

let src = fs.readFileSync('/var/tmp/mcbuild/LivePatchV78F.java', 'utf8');
src = src.replace(/LivePatchV78F/g, 'LivePatchV78I');
src = src.replace(
  '"v7.8.0F-mtr-pids-board-and-gui"',
  '"v7.8.0I-144hz-smooth-6dof-fem-and-live-selftest"'
);

const proImports = `
import ai.arena.bridge.physics.pro.ConstitutiveMaterialDB;
import ai.arena.bridge.physics.pro.FractureAndSolidifier;
import ai.arena.bridge.physics.pro.ProPhysicsRenderer;
import ai.arena.bridge.physics.pro.RigidBody6DoFDynamics;
import ai.arena.bridge.physics.pro.VerletClothAndWeatherSolver;
import ai.arena.bridge.physics.pro.VoxelFrameFEMSolver;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.item.BlockItem;
`;
src = src.replace('import net.minecraft.util.math.RotationAxis;', 'import net.minecraft.util.math.RotationAxis;\n' + proImports);

const proFields = `
    // ==================== MODULAR 6-DoF FEM & 144Hz SMOOTH RIGID-BODY STATE ====================
    private final Set<BlockPos> pendingFEMSeeds = ConcurrentHashMap.newKeySet();
    private final Map<BlockPos, Integer> delayedPlacementChecks = new ConcurrentHashMap<>();
    private final Map<java.util.UUID, Long> lastCheckedPlayerSupportBlock = new ConcurrentHashMap<>();
    private boolean initialSurfaceFEMScanDone = false;
    private volatile double physicsTimeScale = 1.0;
    private volatile double lastServerPhysicsTickMs = 0.0;
`;
src = src.replace('    private Identifier texBoardAtlasId = null;', proFields + '\n    private Identifier texBoardAtlasId = null;');

// Allow TNT chains on surface structures
src = src.replace(
  'if (id.startsWith("mtr:") || id.startsWith("arena_ai_bridge:") || st.isOf(Blocks.BEDROCK) || st.isOf(Blocks.TNT)) {',
  'if (id.startsWith("mtr:") || id.startsWith("arena_ai_bridge:") || st.isOf(Blocks.BEDROCK)) {'
);

// Hook BlockItem placement in UseBlockCallback
const oldPlacement = `            ItemStack held = player.getStackInHand(hand);
            if (held == null || !held.hasNbt() || !held.getNbt().contains("ArenaTape")) {
                return ActionResult.PASS;
            }`;
const newPlacement = `            ItemStack held = player.getStackInHand(hand);
            if (held != null && held.getItem() instanceof BlockItem && !world.isClient) {
                BlockPos placedTarget = hitResult.getBlockPos().offset(hitResult.getSide());
                if (placedTarget.getY() >= 61) {
                    delayedPlacementChecks.put(placedTarget.toImmutable(), 2);
                    lastCheckedPlayerSupportBlock.clear();
                }
            }
            if (held == null || !held.hasNbt() || !held.getNbt().contains("ArenaTape")) {
                return ActionResult.PASS;
            }`;
if (!src.includes(oldPlacement)) { console.error('oldPlacement not found'); process.exit(1); }
src = src.replace(oldPlacement, newPlacement);

const oldEnsureCallbacks = '    private void ensureServerPlacementCallbacks() {';
const newEnsureCallbacks = `    private void installModularBlockBreakHook() {
        // Purge any legacy V78G block-break delegate so zero duplicate callbacks ever run!
        System.getProperties().remove("arena.block_break_delegate");
        System.getProperties().put("arena.pro_break_delegate",
                (PlayerBlockBreakEvents.After) (world, player, pos, state, blockEntity) -> {
                    if (world instanceof ServerWorld sw && pos.getY() >= 61
                            && !FractureAndSolidifier.isProtectedMetroInfrastructure(pos, state)) {
                        lastCheckedPlayerSupportBlock.clear();
                        for (Direction d : Direction.values()) {
                            BlockPos nb = pos.offset(d);
                            BlockState nst = sw.getBlockState(nb);
                            if (!nst.isAir() && nst.getFluidState().isEmpty()
                                    && !FractureAndSolidifier.isNaturalTerrainBlock(nst)
                                    && !FractureAndSolidifier.isProtectedMetroInfrastructure(nb, nst)) {
                                pendingFEMSeeds.add(nb.toImmutable());
                            }
                        }
                    }
                });
        if (!Boolean.getBoolean("arena.pro_break_hook_bound")) {
            System.setProperty("arena.pro_break_hook_bound", "true");
            PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
                Object cb = System.getProperties().get("arena.pro_break_delegate");
                if (cb instanceof PlayerBlockBreakEvents.After after) {
                    after.afterBlockBreak(world, player, pos, state, blockEntity);
                }
            });
        }
    }

    private void ensureServerPlacementCallbacks() {
        installModularBlockBreakHook();`;
if (!src.includes(oldEnsureCallbacks)) { console.error('oldEnsureCallbacks not found'); process.exit(1); }
src = src.replace(oldEnsureCallbacks, newEnsureCallbacks);

// Clean up any legacy entities & load disk blueprints
src = src.replace(
  '        if (!initialRepairDone) {\n            initialRepairDone = true;\n            performFullCleanRepair(world);\n            rebuildBothStationRearSections(world);\n            clearGlassPanePlaceholdersFor3DTapes(world);\n        }',
  `        if (!initialRepairDone) {
            initialRepairDone = true;
            GeoStructuralPhysicsEngine.physicsEnabled = false;
            GeoStructuralPhysicsEngine.RIGID_BODIES.clear();
            GeoStructuralPhysicsEngine.TILTING_STRUCTURES.clear();
            FractureAndSolidifier.ensureLoadedFromDisk();
            rebuildBothStationRearSections(world);
            clearGlassPanePlaceholdersFor3DTapes(world);
        }`
);

src = src.replace(
  '        if (lastAlertCountForRepairDetect > 0 && GeoStructuralPhysicsEngine.ACTIVE_ALERTS.isEmpty()\n                && (!blueprints.isEmpty() || !activeDebrisRubble.isEmpty() || !simulatedFloodWaterBlocks.isEmpty())) {\n            rewindAllBlueprintsAndFloods(world);\n        }',
  `        if (lastAlertCountForRepairDetect > 0 && GeoStructuralPhysicsEngine.ACTIVE_ALERTS.isEmpty()
                && (!FractureAndSolidifier.BLUEPRINTS.isEmpty()
                    || !FractureAndSolidifier.GLOBAL_DEPOSITED_RUBBLE.isEmpty()
                    || !blueprints.isEmpty()
                    || !activeDebrisRubble.isEmpty()
                    || !simulatedFloodWaterBlocks.isEmpty())) {
            FractureAndSolidifier.rewindAllBlueprints(world);
            rewindAllBlueprintsAndFloods(world);
        }`
);

// Replace server tick surface physics calls with timed 160Hz 6-DoF solver
const oldTickCalls = `        interceptExplosionsForBlocksworthCollapse(world);
        tickStagedClusters(world);
        tickRigidBodiesAndSolidifyMound(world);`;
const newTickCalls = `        long physT0 = System.nanoTime();
        VerletClothAndWeatherSolver.tickServerEnvironment(world);
        interceptExplosionsForBlocksworthCollapse(world);
        tickModularFEMIntegrityAndPlacements(world);
        RigidBody6DoFDynamics.tickAll(
                world,
                physicsTimeScale,
                VerletClothAndWeatherSolver.getCurrentSurfaceWindMs(),
                FractureAndSolidifier::solidifyBodyInWorld
        );
        lastServerPhysicsTickMs = Math.round(((System.nanoTime() - physT0) * 1.0e-6) * 1000.0) / 1000.0;`;
if (!src.includes(oldTickCalls)) { console.error('oldTickCalls not found'); process.exit(1); }
src = src.replace(oldTickCalls, newTickCalls);

// Upgrade invoke(...) with full automated live physics self-test & bot surface teleport!
const oldInvoke = `            } else if ("flood_test".equalsIgnoreCase(op) && ow != null) {`;
const newInvoke = `            } else if ("tp_bot".equalsIgnoreCase(op) && ow != null) {
                server.execute(() -> {
                    ServerPlayerEntity ilkan = null;
                    ServerPlayerEntity bot = null;
                    for (ServerPlayerEntity sp : ow.getPlayers()) {
                        if ("ArenaAI".equalsIgnoreCase(sp.getName().getString())) bot = sp;
                        else ilkan = sp;
                    }
                    if (bot != null && ilkan != null) {
                        bot.teleport(ow, ilkan.getX() + 3.5, ilkan.getY() + 0.5, ilkan.getZ() + 2.5, ilkan.getYaw(), 0.0f);
                    }
                });
                res.addProperty("botTeleported", true);
            } else if ("self_test_run".equalsIgnoreCase(op) && ow != null) {
                int tx = payload.has("x") ? payload.get("x").getAsInt() : 8;
                int ty = payload.has("y") ? payload.get("y").getAsInt() : 64;
                int tz = payload.has("z") ? payload.get("z").getAsInt() : 1534;
                String mode = payload.has("mode") ? payload.get("mode").getAsString() : "pier_topple";
                ProPhysicsRenderer.FRAME_TELEMETRY.clear();
                ProPhysicsRenderer.recordTelemetry = true;
                server.execute(() -> {
                    // Ensure solid sand pad at ty - 1
                    for (int dx = -1; dx <= 3; dx++) {
                        for (int dz = -1; dz <= 1; dz++) {
                            BlockPos base = new BlockPos(tx + dx, ty - 1, tz + dz);
                            if (ow.getBlockState(base).isAir()) {
                                ow.setBlockState(base, Blocks.SANDSTONE.getDefaultState(), 2);
                            }
                        }
                    }
                    if ("cantilever_overload".equalsIgnoreCase(mode)) {
                        // Build grounded pier + 5-block stone_bricks cantilever (moment > 130 kN*m -> immediate flexural fracture!)
                        for (int y = 0; y <= 3; y++) {
                            ow.setBlockState(new BlockPos(tx, ty + y, tz), Blocks.STONE_BRICKS.getDefaultState(), 2);
                        }
                        for (int dx = 1; dx <= 5; dx++) {
                            ow.setBlockState(new BlockPos(tx + dx, ty + 3, tz), Blocks.STONE_BRICKS.getDefaultState(), 2);
                        }
                        pendingFEMSeeds.add(new BlockPos(tx + 1, ty + 3, tz));
                    } else if ("single_block_drop".equalsIgnoreCase(mode)) {
                        BlockState sb = Blocks.STONE_BRICKS.getDefaultState();
                        ow.setBlockState(new BlockPos(tx, ty + 3, tz), sb, 2);
                        pendingFEMSeeds.add(new BlockPos(tx, ty + 3, tz));
                    } else {
                        // Build 5-block column + 2-block asymmetrical cap, record in blueprint, then break bottom pier block!
                        FractureAndSolidifier.BlueprintRecord bp = FractureAndSolidifier.getOrCreateBlueprint(new BlockPos(tx, ty, tz));
                        BlockState sb = Blocks.STONE_BRICKS.getDefaultState();
                        bp.originalStates.putIfAbsent(new BlockPos(tx, ty, tz), sb);
                        for (int y = 1; y <= 4; y++) {
                            BlockPos p = new BlockPos(tx, ty + y, tz);
                            ow.setBlockState(p, sb, 2);
                        }
                        ow.setBlockState(new BlockPos(tx + 1, ty + 4, tz), sb, 2);
                        ow.setBlockState(new BlockPos(tx + 2, ty + 4, tz), sb, 2);
                        // Simulate breaking the bottom block (tx, ty, tz)
                        ow.setBlockState(new BlockPos(tx, ty, tz), Blocks.AIR.getDefaultState(), 2);
                        ow.playSound(null, new BlockPos(tx, ty, tz), SoundEvents.BLOCK_STONE_BREAK, SoundCategory.BLOCKS, 1.0f, 0.9f);
                        pendingFEMSeeds.add(new BlockPos(tx, ty + 1, tz));
                    }
                });
                res.addProperty("selfTestStarted", mode);
                res.addProperty("testX", tx);
                res.addProperty("testY", ty);
                res.addProperty("testZ", tz);
            } else if ("self_test_report".equalsIgnoreCase(op)) {
                ProPhysicsRenderer.recordTelemetry = false;
                res.addProperty("clientFps", client != null ? client.getCurrentFps() : -1);
                res.addProperty("activeBodies", RigidBody6DoFDynamics.ACTIVE_BODIES.size());
                res.addProperty("lastFemSolveMs", FractureAndSolidifier.lastFemSolveMs);
                res.addProperty("lastDetachedBlocks", FractureAndSolidifier.lastDetachedBlocks);
                res.addProperty("lastServerPhysicsTickMs", lastServerPhysicsTickMs);
                res.addProperty("blueprintCount", FractureAndSolidifier.BLUEPRINTS.size());
                List<ProPhysicsRenderer.FrameMotionSample> allSamples = new ArrayList<>(ProPhysicsRenderer.FRAME_TELEMETRY);
                long targetId = -1L;
                for (ProPhysicsRenderer.FrameMotionSample s : allSamples) {
                    if (s.bodyId() > targetId) targetId = s.bodyId();
                }
                List<ProPhysicsRenderer.FrameMotionSample> samples = new ArrayList<>();
                for (ProPhysicsRenderer.FrameMotionSample s : allSamples) {
                    if (s.bodyId() == targetId) samples.add(s);
                }
                res.addProperty("trackedBodyId", targetId);
                res.addProperty("recordedFrames", samples.size());
                int upwardSnapFrames = 0;
                double maxFrameDt = 0.0;
                double sumFrameDt = 0.0;
                com.google.gson.JsonArray frameArr = new com.google.gson.JsonArray();
                // Inspect free-fall phase (before first ground bounce where y drops near ground)
                boolean bounced = false;
                for (int i = 0; i < samples.size(); i++) {
                    ProPhysicsRenderer.FrameMotionSample s = samples.get(i);
                    maxFrameDt = Math.max(maxFrameDt, s.frameDtMs());
                    sumFrameDt += s.frameDtMs();
                    if (i >= 2 && !bounced) {
                        // Once near ground (within 1.6m of test base), bounce is genuine collision restitution, not jitter
                        if (s.renderY() < 65.8 && s.deltaY() > 0.002) {
                            bounced = true;
                        } else if (s.deltaY() > 0.0008) {
                            upwardSnapFrames++;
                        }
                    }
                    if (i < 45 || (i % 3) == 0) {
                        JsonObject fo = new JsonObject();
                        fo.addProperty("f", i);
                        fo.addProperty("dtMs", s.frameDtMs());
                        fo.addProperty("fps", s.clientFps());
                        fo.addProperty("y", s.renderY());
                        fo.addProperty("dy", s.deltaY());
                        fo.addProperty("tiltDeg", s.tiltDeg());
                        frameArr.add(fo);
                    }
                }
                res.addProperty("upwardJitterFramesInFreeFall", upwardSnapFrames);
                res.addProperty("maxFrameDtMs", Math.round(maxFrameDt * 100.0) / 100.0);
                res.addProperty("avgFrameDtMs", samples.isEmpty() ? 0.0 : Math.round((sumFrameDt / samples.size()) * 100.0) / 100.0);
                res.add("frames", frameArr);
            } else if ("onar_rewind".equalsIgnoreCase(op) && ow != null) {
                server.execute(() -> FractureAndSolidifier.rewindAllBlueprints(ow));
                res.addProperty("rewound", true);
            } else if ("flood_test".equalsIgnoreCase(op) && ow != null) {`;
if (!src.includes(oldInvoke)) { console.error('oldInvoke not found'); process.exit(1); }
src = src.replace(oldInvoke, newInvoke);

// Replace triggerBlocksworthDemolition .. tickSafeEntityImpacts with clean modular delegation
const startDemIdx = src.indexOf('    public String triggerBlocksworthDemolition(ServerWorld world, BlockPos blastPos, double blastRadius) {');
const endDemIdx   = src.indexOf('    private void tickSafeEntityImpacts(ServerWorld world) {');
if (startDemIdx < 0 || endDemIdx < 0) { console.error('demolition markers missing'); process.exit(1); }

const modularBridgeMethods = `
    private void tickModularFEMIntegrityAndPlacements(ServerWorld world) {
        if (!initialSurfaceFEMScanDone && serverTicks >= 6) {
            for (ServerPlayerEntity sp : world.getPlayers()) {
                if (sp.getY() >= 61.0) {
                    initialSurfaceFEMScanDone = true;
                    BlockPos pc = sp.getBlockPos();
                    BlockPos.Mutable mp = new BlockPos.Mutable();
                    for (int dx = -30; dx <= 30; dx++) {
                        for (int dz = -30; dz <= 30; dz++) {
                            for (int y = 62; y <= 82; y++) {
                                mp.set(pc.getX() + dx, y, pc.getZ() + dz);
                                if (!world.isChunkLoaded(mp.getX() >> 4, mp.getZ() >> 4)) continue;
                                BlockState st = world.getBlockState(mp);
                                if (!st.isAir() && st.getFluidState().isEmpty() && !st.hasBlockEntity()
                                        && !FractureAndSolidifier.isNaturalTerrainBlock(st)
                                        && !FractureAndSolidifier.isNonStructuralAttachment(st)
                                        && !FractureAndSolidifier.isProtectedMetroInfrastructure(mp, st)) {
                                    pendingFEMSeeds.add(mp.toImmutable());
                                }
                            }
                        }
                    }
                }
            }
        }

        if (!delayedPlacementChecks.isEmpty()) {
            Iterator<Map.Entry<BlockPos, Integer>> it = delayedPlacementChecks.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<BlockPos, Integer> e = it.next();
                int rem = e.getValue() - 1;
                if (rem <= 0) {
                    it.remove();
                    pendingFEMSeeds.add(e.getKey());
                } else {
                    e.setValue(rem);
                }
            }
        }

        // Only evaluate live load when a player steps onto a DIFFERENT manufactured block (zero redundant re-solves!)
        if ((serverTicks % 10) == 0) {
            for (ServerPlayerEntity sp : world.getPlayers()) {
                if (sp.getY() >= 62.0 && sp.isOnGround()) {
                    BlockPos under = sp.getBlockPos().down();
                    long key = under.asLong();
                    Long prevKey = lastCheckedPlayerSupportBlock.get(sp.getUuid());
                    if (prevKey == null || prevKey != key) {
                        lastCheckedPlayerSupportBlock.put(sp.getUuid(), key);
                        BlockState ust = world.getBlockState(under);
                        if (!ust.isAir() && !FractureAndSolidifier.isNaturalTerrainBlock(ust)
                                && !FractureAndSolidifier.isProtectedMetroInfrastructure(under, ust)) {
                            pendingFEMSeeds.add(under.toImmutable());
                        }
                    }
                }
            }
        }

        if (pendingFEMSeeds.isEmpty()) return;
        List<BlockPos> seeds = new ArrayList<>(pendingFEMSeeds);
        pendingFEMSeeds.clear();
        Set<BlockPos> visited = new HashSet<>();
        org.joml.Vector3d wind = VerletClothAndWeatherSolver.getCurrentSurfaceWindMs();
        for (BlockPos seed : seeds) {
            if (!visited.contains(seed)) {
                FractureAndSolidifier.evaluateAndCollapseStructure(world, seed, null, 0.0, wind, visited, true);
            }
        }
    }

    public String triggerBlocksworthDemolition(ServerWorld world, BlockPos blastPos, double blastRadius) {
        return FractureAndSolidifier.triggerExplosionWithFEM(
                world,
                blastPos,
                blastRadius,
                VerletClothAndWeatherSolver.getCurrentSurfaceWindMs()
        );
    }

`;

src = src.slice(0, startDemIdx) + modularBridgeMethods + src.slice(endDemIdx);

src = src.replace(
  'rewindAllBlueprintsAndFloods(ow);\n                    performFullCleanRepair(ow);',
  'FractureAndSolidifier.rewindAllBlueprints(ow);\n                    rewindAllBlueprintsAndFloods(ow);\n                    performFullCleanRepair(ow);'
);
src = src.replace(
  'GeoStructuralPhysicsEngine.detachBlockAsLiveRigidBody(world, supportPos, 0.0, -0.6, 0.0);',
  'pendingFEMSeeds.add(supportPos.toImmutable());'
);

const oldRenderAnchor = '        // 2. Render 96m Distant 3D Crimson Tunnel Emergency Strobe on damaged/flooded sectors!';
const newRenderAnchor = `        // 1B. Render 60–240 FPS Zero-Jitter 6-DoF Rigid Clusters & Verlet 3D Cloth Capes
        ProPhysicsRenderer.renderAll(ctx);

        // 2. Render 96m Distant 3D Crimson Tunnel Emergency Strobe on damaged/flooded sectors!`;
if (!src.includes(oldRenderAnchor)) { console.error('oldRenderAnchor not found'); process.exit(1); }
src = src.replace(oldRenderAnchor, newRenderAnchor);

fs.writeFileSync('/var/tmp/mcbuild/LivePatchV78I.java', src, 'utf8');
console.log('Generated /var/tmp/mcbuild/LivePatchV78I.java (' + src.length + ' chars)');

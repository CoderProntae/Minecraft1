const fs = require('fs');

let src = fs.readFileSync('/var/tmp/mcbuild/LivePatchV78F.java', 'utf8');
src = src.replace(/LivePatchV78F/g, 'LivePatchV78J');
src = src.replace(
  '"v7.8.0F-mtr-pids-board-and-gui"',
  '"v7.8.0J-universal-fem-inclined-struts-sagging-persistent-rubble"'
);

const proImports = `
import ai.arena.bridge.physics.pro.ConstitutiveMaterialDB;
import ai.arena.bridge.physics.pro.FractureAndSolidifier;
import ai.arena.bridge.physics.pro.ProPhysicsRenderer;
import ai.arena.bridge.physics.pro.RigidBody6DoFDynamics;
import ai.arena.bridge.physics.pro.VerletClothAndWeatherSolver;
import ai.arena.bridge.physics.pro.VoxelFrameFEMSolver;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Items;
import net.minecraft.server.command.CommandManager;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
`;
src = src.replace('import net.minecraft.util.math.RotationAxis;', 'import net.minecraft.util.math.RotationAxis;\n' + proImports);

const proFields = `
    // ==================== UNIVERSAL 18-NEIGHBOR 6-DoF FEM, SAGGING & PERSISTENT RUBBLE ====================
    private final Set<BlockPos> pendingFEMSeeds = ConcurrentHashMap.newKeySet();
    private final Map<BlockPos, Integer> delayedPlacementChecks = new ConcurrentHashMap<>();
    private final Map<java.util.UUID, Long> lastCheckedPlayerSupportBlock = new ConcurrentHashMap<>();
    private boolean initialSurfaceFEMScanDone = false;
    private boolean dagTemizleCmdRegistered = false;
    private volatile double physicsTimeScale = 1.0;
    private volatile double lastServerPhysicsTickMs = 0.0;
    private volatile int lastBuiltDeckY = 72;
`;
src = src.replace('    private Identifier texBoardAtlasId = null;', proFields + '\n    private Identifier texBoardAtlasId = null;');

// Allow TNT chains on surface structures
src = src.replace(
  'if (id.startsWith("mtr:") || id.startsWith("arena_ai_bridge:") || st.isOf(Blocks.BEDROCK) || st.isOf(Blocks.TNT)) {',
  'if (id.startsWith("mtr:") || id.startsWith("arena_ai_bridge:") || st.isOf(Blocks.BEDROCK)) {'
);

// Hook BlockItem placement in UseBlockCallback (universal across the entire world!)
const oldPlacement = `            ItemStack held = player.getStackInHand(hand);
            if (held == null || !held.hasNbt() || !held.getNbt().contains("ArenaTape")) {
                return ActionResult.PASS;
            }`;
const newPlacement = `            ItemStack held = player.getStackInHand(hand);
            if (held != null && held.getItem() instanceof BlockItem && !world.isClient) {
                BlockPos hitPos = hitResult.getBlockPos();
                BlockPos placedTarget = hitPos.offset(hitResult.getSide());
                if (placedTarget.getY() >= 61) {
                    delayedPlacementChecks.put(placedTarget.toImmutable(), 2);
                    delayedPlacementChecks.put(hitPos.toImmutable(), 2);
                    lastCheckedPlayerSupportBlock.clear();
                }
            }
            if (held == null || !held.hasNbt() || !held.getNbt().contains("ArenaTape")) {
                return ActionResult.PASS;
            }`;
if (!src.includes(oldPlacement)) { console.error('oldPlacement not found'); process.exit(1); }
src = src.replace(oldPlacement, newPlacement);

const oldEnsureCallbacks = '    private void ensureServerPlacementCallbacks() {';
const newEnsureCallbacks = `    private void installModularBlockBreakHook() {
        System.getProperties().remove("arena.block_break_delegate");
        System.getProperties().put("arena.pro_break_delegate",
                (PlayerBlockBreakEvents.After) (world, player, pos, state, blockEntity) -> {
                    if (world instanceof ServerWorld sw && pos.getY() >= 61
                            && !FractureAndSolidifier.isProtectedMetroInfrastructure(pos, state)) {
                        lastCheckedPlayerSupportBlock.clear();
                        pendingFEMSeeds.addAll(FractureAndSolidifier.handleBlockBreakAndCollectSeeds(sw, pos, state));
                    }
                });
        if (!Boolean.getBoolean("arena.pro_break_hook_bound")) {
            System.setProperty("arena.pro_break_hook_bound", "true");
            PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
                Object cb = System.getProperties().get("arena.pro_break_delegate");
                if (cb instanceof PlayerBlockBreakEvents.After after) {
                    after.afterBlockBreak(world, player, pos, state, blockEntity);
                }
            });
        }
    }

    private void ensureDagTemizleCommand(MinecraftServer server) {
        if (dagTemizleCmdRegistered || server == null) return;
        dagTemizleCmdRegistered = true;
        try {
            server.getCommandManager().getDispatcher().register(
                CommandManager.literal("dagtemizle").executes(ctx -> {
                    ServerWorld ow = ctx.getSource().getServer().getOverworld();
                    int restored = FractureAndSolidifier.clearTestRig(ow);
                    ctx.getSource().sendFeedback(
                        () -> Text.literal("§a[ArenaFizik] Test dagi ve dag evi temizlendi (" + restored + " blok eski haline dondu). Tum fizik motoru ozellikleri kalici olarak aktif!"),
                        false
                    );
                    return 1;
                })
            );
            for (ServerPlayerEntity sp : server.getPlayerManager().getPlayerList()) {
                server.getCommandManager().sendCommandTree(sp);
            }
        } catch (Throwable ignored) {}
    }

    private void ensureServerPlacementCallbacks() {
        installModularBlockBreakHook();`;
if (!src.includes(oldEnsureCallbacks)) { console.error('oldEnsureCallbacks not found'); process.exit(1); }
src = src.replace(oldEnsureCallbacks, newEnsureCallbacks);

// Clean up any legacy entities & load disk blueprints
src = src.replace(
  '        if (!initialRepairDone) {\n            initialRepairDone = true;\n            performFullCleanRepair(world);\n            rebuildBothStationRearSections(world);\n            clearGlassPanePlaceholdersFor3DTapes(world);\n        }',
  `        ensureDagTemizleCommand(world.getServer());
        if (!initialRepairDone) {
            initialRepairDone = true;
            GeoStructuralPhysicsEngine.physicsEnabled = false;
            GeoStructuralPhysicsEngine.RIGID_BODIES.clear();
            GeoStructuralPhysicsEngine.TILTING_STRUCTURES.clear();
            FractureAndSolidifier.ensureLoadedFromDisk();
            rebuildBothStationRearSections(world);
            clearGlassPanePlaceholdersFor3DTapes(world);
        }`
);

src = src.replace(
  '        if (lastAlertCountForRepairDetect > 0 && GeoStructuralPhysicsEngine.ACTIVE_ALERTS.isEmpty()\n                && (!blueprints.isEmpty() || !activeDebrisRubble.isEmpty() || !simulatedFloodWaterBlocks.isEmpty())) {\n            rewindAllBlueprintsAndFloods(world);\n        }',
  `        if (lastAlertCountForRepairDetect > 0 && GeoStructuralPhysicsEngine.ACTIVE_ALERTS.isEmpty()
                && (!FractureAndSolidifier.BLUEPRINTS.isEmpty()
                    || !FractureAndSolidifier.GLOBAL_DEPOSITED_RUBBLE.isEmpty()
                    || !FractureAndSolidifier.ELASTIC_PROXIES.isEmpty()
                    || !RigidBody6DoFDynamics.ACTIVE_BODIES.isEmpty()
                    || !blueprints.isEmpty()
                    || !activeDebrisRubble.isEmpty()
                    || !simulatedFloodWaterBlocks.isEmpty())) {
            FractureAndSolidifier.rewindAllBlueprints(world);
            rewindAllBlueprintsAndFloods(world);
        }`
);

const oldTickCalls = `        interceptExplosionsForBlocksworthCollapse(world);
        tickStagedClusters(world);
        tickRigidBodiesAndSolidifyMound(world);`;
const newTickCalls = `        long physT0 = System.nanoTime();
        VerletClothAndWeatherSolver.tickServerEnvironment(world);
        interceptExplosionsForBlocksworthCollapse(world);
        tickModularFEMIntegrityAndPlacements(world);
        RigidBody6DoFDynamics.tickAll(
                world,
                physicsTimeScale,
                VerletClothAndWeatherSolver.getCurrentSurfaceWindMs(),
                FractureAndSolidifier::solidifyBodyInWorld
        );
        lastServerPhysicsTickMs = Math.round(((System.nanoTime() - physT0) * 1.0e-6) * 1000.0) / 1000.0;`;
if (!src.includes(oldTickCalls)) { console.error('oldTickCalls not found'); process.exit(1); }
src = src.replace(oldTickCalls, newTickCalls);

const oldInvoke = `            } else if ("flood_test".equalsIgnoreCase(op) && ow != null) {`;
const newInvoke = `            } else if ("tp_bot".equalsIgnoreCase(op) && ow != null) {
                server.execute(() -> {
                    ServerPlayerEntity ilkan = null;
                    ServerPlayerEntity bot = null;
                    for (ServerPlayerEntity sp : ow.getPlayers()) {
                        if ("ArenaAI".equalsIgnoreCase(sp.getName().getString())) bot = sp;
                        else ilkan = sp;
                    }
                    if (bot != null && ilkan != null) {
                        bot.teleport(ow, ilkan.getX() + 3.5, ilkan.getY() + 0.5, ilkan.getZ() + 2.5, ilkan.getYaw(), 0.0f);
                    }
                });
                res.addProperty("botTeleported", true);
            } else if ("give_test_items".equalsIgnoreCase(op) && ow != null) {
                server.execute(() -> {
                    for (ServerPlayerEntity sp : ow.getPlayers()) {
                        if (!"ArenaAI".equalsIgnoreCase(sp.getName().getString())) {
                            sp.getInventory().insertStack(new ItemStack(Items.NETHERITE_BLOCK, 16));
                            sp.getInventory().insertStack(new ItemStack(Items.GOLD_BLOCK, 16));
                            sp.getInventory().insertStack(new ItemStack(Items.SPRUCE_PLANKS, 32));
                            sp.getInventory().insertStack(new ItemStack(Items.OAK_LOG, 32));
                        }
                    }
                });
                res.addProperty("gaveItems", true);
            } else if ("build_hillside_test".equalsIgnoreCase(op) && ow != null) {
                int bx = payload.has("x") ? payload.get("x") .getAsInt() : 15;
                int bz = payload.has("z") ? payload.get("z") .getAsInt() : 1528;
                server.execute(() -> {
                    buildRemovableHillsideCabinScene(ow, bx, bz);
                });
                res.addProperty("builtHillsideScene", true);
                res.addProperty("baseX", bx);
                res.addProperty("baseZ", bz);
            } else if ("clear_test_rig".equalsIgnoreCase(op) && ow != null) {
                server.execute(() -> FractureAndSolidifier.clearTestRig(ow));
                res.addProperty("clearedTestRig", true);
            } else if ("place_test_block".equalsIgnoreCase(op) && ow != null) {
                int px = payload.get("x").getAsInt();
                int py = payload.get("y").getAsInt();
                int pz = payload.get("z").getAsInt();
                String blockId = payload.has("block") ? payload.get("block").getAsString() : "minecraft:gold_block";
                server.execute(() -> {
                    BlockPos tp = new BlockPos(px, py, pz);
                    Block b = Registries.BLOCK.get(new Identifier(blockId));
                    if (b == Blocks.AIR) {
                        BlockState oldSt = ow.getBlockState(tp);
                        ow.setBlockState(tp, Blocks.AIR.getDefaultState(), 3);
                        pendingFEMSeeds.addAll(FractureAndSolidifier.handleBlockBreakAndCollectSeeds(ow, tp, oldSt));
                    } else {
                        FractureAndSolidifier.TEST_RIG_RESTORE_MAP.putIfAbsent(tp, ow.getBlockState(tp));
                        ow.setBlockState(tp, b.getDefaultState(), 3);
                        pendingFEMSeeds.add(tp);
                        for (Direction d : Direction.values()) pendingFEMSeeds.add(tp.offset(d));
                    }
                });
                res.addProperty("placed", blockId);
            } else if ("self_test_run".equalsIgnoreCase(op) && ow != null) {
                int tx = payload.has("x") ? payload.get("x").getAsInt() : 8;
                int ty = payload.has("y") ? payload.get("y").getAsInt() : 66;
                int tz = payload.has("z") ? payload.get("z").getAsInt() : 1534;
                String mode = payload.has("mode") ? payload.get("mode").getAsString() : "single_block_drop";
                ProPhysicsRenderer.FRAME_TELEMETRY.clear();
                ProPhysicsRenderer.recordTelemetry = true;
                server.execute(() -> {
                    // Guarantee solid floor at ty - 1 and 100% clear open air at ty .. ty + 5!
                    for (int dx = -1; dx <= 5; dx++) {
                        for (int dz = -1; dz <= 1; dz++) {
                            BlockPos floorP = new BlockPos(tx + dx, ty - 1, tz + dz);
                            FractureAndSolidifier.TEST_RIG_RESTORE_MAP.putIfAbsent(floorP, ow.getBlockState(floorP));
                            ow.setBlockState(floorP, Blocks.SANDSTONE.getDefaultState(), 2);
                            for (int dy = 0; dy <= 5; dy++) {
                                BlockPos airP = new BlockPos(tx + dx, ty + dy, tz + dz);
                                FractureAndSolidifier.TEST_RIG_RESTORE_MAP.putIfAbsent(airP, ow.getBlockState(airP));
                                ow.setBlockState(airP, Blocks.AIR.getDefaultState(), 2);
                            }
                        }
                    }
                    if ("single_block_drop".equalsIgnoreCase(mode)) {
                        // Spawn single stone brick 3.0m in clear air -> must free-fall 3.0m smoothly & stay as 3D body!
                        ow.setBlockState(new BlockPos(tx, ty + 3, tz), Blocks.STONE_BRICKS.getDefaultState(), 2);
                        pendingFEMSeeds.add(new BlockPos(tx, ty + 3, tz));
                    } else if ("pier_topple".equalsIgnoreCase(mode)) {
                        BlockState sb = Blocks.STONE_BRICKS.getDefaultState();
                        for (int y = 1; y <= 4; y++) {
                            ow.setBlockState(new BlockPos(tx, ty + y, tz), sb, 2);
                        }
                        ow.setBlockState(new BlockPos(tx + 1, ty + 4, tz), sb, 2);
                        ow.setBlockState(new BlockPos(tx + 2, ty + 4, tz), sb, 2);
                        pendingFEMSeeds.add(new BlockPos(tx, ty + 1, tz));
                    }
                });
                res.addProperty("selfTestStarted", mode);
                res.addProperty("testX", tx);
                res.addProperty("testY", ty);
                res.addProperty("testZ", tz);
            } else if ("self_test_report".equalsIgnoreCase(op)) {
                ProPhysicsRenderer.recordTelemetry = false;
                res.addProperty("clientFps", client != null ? client.getCurrentFps() : -1);
                res.addProperty("activeBodies", RigidBody6DoFDynamics.ACTIVE_BODIES.size());
                int sleepingBodies = 0;
                double sampleRestY = -1.0;
                double sampleTiltDeg = 0.0;
                for (RigidBody6DoFDynamics.RigidCluster6DoF b : RigidBody6DoFDynamics.ACTIVE_BODIES) {
                    if (b.sleeping) sleepingBodies++;
                    sampleRestY = Math.round(b.py * 1000.0) / 1000.0;
                    sampleTiltDeg = Math.round(Math.toDegrees(2.0 * Math.acos(MathHelper.clamp(Math.abs(b.quat.w), 0.0, 1.0))) * 100.0) / 100.0;
                }
                res.addProperty("sleepingPersistent3DBodies", sleepingBodies);
                res.addProperty("lastBodyY", sampleRestY);
                res.addProperty("lastBodyTiltDeg", sampleTiltDeg);
                res.addProperty("elasticSaggingVoxels", FractureAndSolidifier.ELASTIC_PROXIES.size());
                double maxSagDy = 0.0;
                for (FractureAndSolidifier.ElasticSagVoxel sv : FractureAndSolidifier.ELASTIC_PROXIES.values()) {
                    if (Math.abs(sv.targetDy()) > Math.abs(maxSagDy)) maxSagDy = sv.targetDy();
                }
                res.addProperty("maxElasticSagMeters", Math.round(maxSagDy * 1000.0) / 1000.0);
                res.addProperty("lastPeakStressRatio", FractureAndSolidifier.lastPeakStressRatio);
                res.addProperty("lastBuiltDeckY", lastBuiltDeckY);
                res.addProperty("lastFemSolveMs", FractureAndSolidifier.lastFemSolveMs);
                res.addProperty("lastDetachedBlocks", FractureAndSolidifier.lastDetachedBlocks);
                res.addProperty("lastServerPhysicsTickMs", lastServerPhysicsTickMs);
                res.addProperty("rubbleBarriers", FractureAndSolidifier.RUBBLE_BARRIER_OWNER.size());

                List<ProPhysicsRenderer.FrameMotionSample> allSamples = new ArrayList<>(ProPhysicsRenderer.FRAME_TELEMETRY);
                long targetId = -1L;
                for (ProPhysicsRenderer.FrameMotionSample s : allSamples) {
                    if (s.bodyId() > targetId) targetId = s.bodyId();
                }
                List<ProPhysicsRenderer.FrameMotionSample> samples = new ArrayList<>();
                for (ProPhysicsRenderer.FrameMotionSample s : allSamples) {
                    if (s.bodyId() == targetId) samples.add(s);
                }
                res.addProperty("trackedBodyId", targetId);
                res.addProperty("recordedFrames", samples.size());
                int upwardSnapFrames = 0;
                com.google.gson.JsonArray frameArr = new com.google.gson.JsonArray();
                boolean bounced = false;
                for (int i = 0; i < samples.size(); i++) {
                    ProPhysicsRenderer.FrameMotionSample s = samples.get(i);
                    if (i >= 2 && !bounced) {
                        if (s.deltaY() > 0.002 && i > 8) {
                            bounced = true;
                        } else if (s.deltaY() > 0.0008) {
                            upwardSnapFrames++;
                        }
                    }
                    if (i < 35 || (i % 4) == 0) {
                        JsonObject fo = new JsonObject();
                        fo.addProperty("f", i);
                        fo.addProperty("dtMs", s.frameDtMs());
                        fo.addProperty("fps", s.clientFps());
                        fo.addProperty("y", s.renderY());
                        fo.addProperty("dy", s.deltaY());
                        fo.addProperty("tiltDeg", s.tiltDeg());
                        frameArr.add(fo);
                    }
                }
                res.addProperty("upwardJitterFramesInFreeFall", upwardSnapFrames);
                res.add("frames", frameArr);
            } else if ("onar_rewind".equalsIgnoreCase(op) && ow != null) {
                server.execute(() -> FractureAndSolidifier.rewindAllBlueprints(ow));
                res.addProperty("rewound", true);
            } else if ("flood_test".equalsIgnoreCase(op) && ow != null) {`;
if (!src.includes(oldInvoke)) { console.error('oldInvoke not found'); process.exit(1); }
src = src.replace(oldInvoke, newInvoke);

// Replace triggerBlocksworthDemolition .. tickSafeEntityImpacts with clean modular delegation + removable hillside rig builder
const startDemIdx = src.indexOf('    public String triggerBlocksworthDemolition(ServerWorld world, BlockPos blastPos, double blastRadius) {');
const endDemIdx   = src.indexOf('    private void tickSafeEntityImpacts(ServerWorld world) {');
if (startDemIdx < 0 || endDemIdx < 0) { console.error('demolition markers missing'); process.exit(1); }

const modularBridgeMethods = `
    private void setTestRigBlock(ServerWorld world, BlockPos p, BlockState state) {
        FractureAndSolidifier.TEST_RIG_RESTORE_MAP.putIfAbsent(p.toImmutable(), world.getBlockState(p));
        world.setBlockState(p, state, 2);
    }

    /**
     * Builds a 100% removable natural rocky cliffside + mountainside timber house supported by real 45-degree
     * inclined oak-log struts! Uses ONLY ordinary vanilla blocks (ZERO physics hacks — evaluated by the universal FEM engine).
     * Typing /dagtemizle restores every single desert/sand block cleanly!
     */
    private void buildRemovableHillsideCabinScene(ServerWorld world, int valleyX, int centerZ) {
        FractureAndSolidifier.clearTestRig(world);

        int baseY = 64;
        for (int y = 68; y >= 61; y--) {
            BlockState st = world.getBlockState(new BlockPos(valleyX, y, centerZ));
            if (FractureAndSolidifier.isNaturalTerrainBlock(st)) {
                baseY = y + 1;
                break;
            }
        }
        int deckY = baseY + 8;
        this.lastBuiltDeckY = deckY;

        // Clear air volume above valley + 45-deg mountain slope (X = valleyX-3 .. valleyX+15, Z = centerZ-7 .. centerZ+7)
        for (int x = valleyX - 3; x <= valleyX + 15; x++) {
            for (int z = centerZ - 7; z <= centerZ + 7; z++) {
                BlockPos pad = new BlockPos(x, baseY - 1, z);
                if (world.getBlockState(pad).isAir() || !world.getFluidState(pad).isEmpty()) {
                    setTestRigBlock(world, pad, Blocks.SANDSTONE.getDefaultState());
                }
                for (int y = baseY; y <= baseY + 17; y++) {
                    setTestRigBlock(world, new BlockPos(x, y, z), Blocks.AIR.getDefaultState());
                }
            }
        }

        // 1. Sculpt Natural ~45-Degree Rocky Mountain Slope ("Yamaç") rising from X = valleyX+4 up to X = valleyX+14
        for (int dx = 4; dx <= 14; dx++) {
            int x = valleyX + dx;
            for (int dz = -6; dz <= 6; dz++) {
                int z = centerZ + dz;
                double ridgeTaper = Math.max(0.0, 1.0 - (dz * dz) / 46.0);
                int slopeHeight = (int) Math.round((dx - 3) * 1.05 * ridgeTaper);
                // Under the cabin footprint (Z = centerZ-3 .. centerZ+3), keep exact clean 45-degree rock profile
                // so the cabin walls/roof stand free above the rock and rest ONLY on rear piers + 45-deg inclined struts!
                if (Math.abs(dz) <= 3) {
                    if (dx <= 5) slopeHeight = dx - 3;          // dx=4->1, dx=5->2
                    else if (dx == 6) slopeHeight = 4;          // Rock socket at baseY+4 (= deckY-4) for 45-deg struts!
                    else if (dx <= 8) slopeHeight = dx - 2;     // dx=7->5, dx=8->6 (= deckY-2)
                    else if (dx == 9) slopeHeight = 7;          // Rear sill rock ledge at baseY+7 (= deckY-1)
                    else slopeHeight = 8 + (dx - 10);           // Mountain peak rises behind cabin (dx>=10, clear of X=valleyX+8 wall!)
                }
                int topY = baseY + slopeHeight;
                for (int y = baseY; y <= topY; y++) {
                    BlockState rock;
                    if (y == topY && dx >= 10) {
                        rock = Blocks.GRASS_BLOCK.getDefaultState();
                    } else if (((x + y + z) & 3) == 0) {
                        rock = Blocks.ANDESITE.getDefaultState();
                    } else if (((x * 3 + z) & 7) == 0) {
                        rock = Blocks.TUFF.getDefaultState();
                    } else {
                        rock = Blocks.STONE.getDefaultState();
                    }
                    setTestRigBlock(world, new BlockPos(x, y, z), rock);
                }
            }
        }

        // 2. Rear Sill Piers on the upper mountain ledge (X = valleyX + 8, Y = deckY - 1, sitting on rock at deckY - 2 & rock behind at X = valleyX + 9)
        BlockState oakPier = Blocks.OAK_WOOD.getDefaultState();
        for (int z = centerZ - 2; z <= centerZ + 2; z += 2) {
            setTestRigBlock(world, new BlockPos(valleyX + 8, deckY - 1, z), oakPier);
        }

        // 3. THREE Pure 45-Degree Inclined Structural Columns ("Eğik Kolonlar", L = sqrt(2) per diagonal step!)
        // Stepping diagonally up-and-out (-X, +Y) from mountain rock socket (valleyX+6, deckY-3) -> (valleyX+4, deckY-1) -> deck beam (valleyX+3, deckY)
        int[] strutZs = { centerZ - 2, centerZ, centerZ + 2 };
        for (int sz : strutZs) {
            setTestRigBlock(world, new BlockPos(valleyX + 6, deckY - 3, sz), oakPier); // Grounded on rock (valleyX+6, deckY-4) & (valleyX+7, deckY-3)
            setTestRigBlock(world, new BlockPos(valleyX + 5, deckY - 2, sz), oakPier); // 45-deg inclined step 1
            setTestRigBlock(world, new BlockPos(valleyX + 4, deckY - 1, sz), oakPier); // 45-deg inclined step 2 -> meets (valleyX+3, deckY, sz) diagonally!
        }

        // 4. Timber Hillside House Floor & 2m Cantilevered Panoramic Balcony at Y = deckY:
        //    Enclosed cabin: X = valleyX + 4 .. valleyX + 8
        //    Front strut support line: X = valleyX + 3 (supported by 45-degree inclined columns!)
        //    Cantilevered overhanging balcony ("evin ucu"): X = valleyX + 1 .. valleyX + 2 (2.0m overhang!)
        BlockState spruceDeck = Blocks.SPRUCE_PLANKS.getDefaultState();
        BlockState oakBeam    = Blocks.STRIPPED_OAK_WOOD.getDefaultState();
        for (int x = valleyX + 1; x <= valleyX + 8; x++) {
            for (int z = centerZ - 2; z <= centerZ + 2; z++) {
                boolean mainGirder = (z == centerZ - 2 || z == centerZ + 2 || x == valleyX + 3 || x == valleyX + 8);
                setTestRigBlock(world, new BlockPos(x, deckY, z), mainGirder ? oakBeam : spruceDeck);
            }
        }

        // 5. Cozy Light Timber Cabin Superstructure on X = valleyX + 4 .. valleyX + 8 (leaving X = valleyX .. valleyX + 3 open balcony!)
        BlockState wallPlank  = Blocks.SPRUCE_PLANKS.getDefaultState();
        BlockState cornerPost = Blocks.OAK_LOG.getDefaultState();
        BlockState glass      = Blocks.GLASS.getDefaultState();

        for (int y = deckY + 1; y <= deckY + 3; y++) {
            for (int x = valleyX + 4; x <= valleyX + 8; x++) {
                for (int z = centerZ - 2; z <= centerZ + 2; z++) {
                    boolean xEdge = (x == valleyX + 4 || x == valleyX + 8);
                    boolean zEdge = (z == centerZ - 2 || z == centerZ + 2);
                    if (!xEdge && !zEdge) continue;
                    if (x == valleyX + 4 && z == centerZ && y <= deckY + 2) continue; // Open front door to balcony
                    if (x == valleyX + 8 && z == centerZ && y <= deckY + 2) continue; // Rear mountain-crest door
                    if (xEdge && zEdge) {
                        setTestRigBlock(world, new BlockPos(x, y, z), cornerPost);
                    } else if (y == deckY + 2) {
                        setTestRigBlock(world, new BlockPos(x, y, z), glass);
                    } else {
                        setTestRigBlock(world, new BlockPos(x, y, z), wallPlank);
                    }
                }
            }
        }

        // Pitched Cabin Roof (X = valleyX + 4 .. valleyX + 8, clear of the mountain peak at X >= valleyX + 10!)
        for (int x = valleyX + 4; x <= valleyX + 8; x++) {
            for (int z = centerZ - 2; z <= centerZ + 2; z++) {
                setTestRigBlock(world, new BlockPos(x, deckY + 4, z), Blocks.DARK_OAK_PLANKS.getDefaultState());
            }
            for (int z = centerZ - 1; z <= centerZ + 1; z++) {
                setTestRigBlock(world, new BlockPos(x, deckY + 5, z), Blocks.DARK_OAK_PLANKS.getDefaultState());
            }
        }

        // Natural solid rock mountain trail up the south flank (Z = centerZ + 4)
        for (int step = 0; step <= 8; step++) {
            for (int y = baseY; y <= baseY + step; y++) {
                setTestRigBlock(world, new BlockPos(valleyX + 3 + step, y, centerZ + 4), Blocks.STONE.getDefaultState());
            }
        }

        pendingFEMSeeds.add(new BlockPos(valleyX + 2, deckY, centerZ));
    }

    private void tickModularFEMIntegrityAndPlacements(ServerWorld world) {
        if (!initialSurfaceFEMScanDone && serverTicks >= 6) {
            for (ServerPlayerEntity sp : world.getPlayers()) {
                if (sp.getY() >= 61.0) {
                    initialSurfaceFEMScanDone = true;
                    BlockPos pc = sp.getBlockPos();
                    BlockPos.Mutable mp = new BlockPos.Mutable();
                    for (int dx = -30; dx <= 30; dx++) {
                        for (int dz = -30; dz <= 30; dz++) {
                            for (int y = 62; y <= 84; y++) {
                                mp.set(pc.getX() + dx, y, pc.getZ() + dz);
                                if (!world.isChunkLoaded(mp.getX() >> 4, mp.getZ() >> 4)) continue;
                                BlockState st = FractureAndSolidifier.resolveEffectiveState(world, mp);
                                if (FractureAndSolidifier.isStructuralCandidate(mp, st)) {
                                    pendingFEMSeeds.add(mp.toImmutable());
                                }
                            }
                        }
                    }
                }
            }
        }

        if (!delayedPlacementChecks.isEmpty()) {
            Iterator<Map.Entry<BlockPos, Integer>> it = delayedPlacementChecks.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<BlockPos, Integer> e = it.next();
                int rem = e.getValue() - 1;
                if (rem <= 0) {
                    it.remove();
                    BlockPos p = e.getKey();
                    pendingFEMSeeds.add(p);
                    for (Direction d : Direction.values()) {
                        pendingFEMSeeds.add(p.offset(d));
                    }
                } else {
                    e.setValue(rem);
                }
            }
        }

        if ((serverTicks % 10) == 0) {
            for (ServerPlayerEntity sp : world.getPlayers()) {
                if (sp.getY() >= 62.0 && sp.isOnGround()) {
                    BlockPos under = sp.getBlockPos().down();
                    long key = under.asLong();
                    Long prevKey = lastCheckedPlayerSupportBlock.get(sp.getUuid());
                    if (prevKey == null || prevKey != key) {
                        lastCheckedPlayerSupportBlock.put(sp.getUuid(), key);
                        BlockState ust = FractureAndSolidifier.resolveEffectiveState(world, under);
                        if (FractureAndSolidifier.isStructuralCandidate(under, ust)) {
                            pendingFEMSeeds.add(under.toImmutable());
                        }
                    }
                }
            }
        }

        if (pendingFEMSeeds.isEmpty()) return;
        List<BlockPos> seeds = new ArrayList<>(pendingFEMSeeds);
        pendingFEMSeeds.clear();
        Set<BlockPos> visited = new HashSet<>();
        org.joml.Vector3d wind = VerletClothAndWeatherSolver.getCurrentSurfaceWindMs();
        for (BlockPos seed : seeds) {
            if (!visited.contains(seed)) {
                FractureAndSolidifier.evaluateAndCollapseStructure(world, seed, null, 0.0, wind, visited, true);
            }
        }
    }

    public String triggerBlocksworthDemolition(ServerWorld world, BlockPos blastPos, double blastRadius) {
        return FractureAndSolidifier.triggerExplosionWithFEM(
                world,
                blastPos,
                blastRadius,
                VerletClothAndWeatherSolver.getCurrentSurfaceWindMs()
        );
    }

`;

src = src.slice(0, startDemIdx) + modularBridgeMethods + src.slice(endDemIdx);

src = src.replace(
  'rewindAllBlueprintsAndFloods(ow);\n                    performFullCleanRepair(ow);',
  'FractureAndSolidifier.rewindAllBlueprints(ow);\n                    rewindAllBlueprintsAndFloods(ow);\n                    performFullCleanRepair(ow);'
);
src = src.replace(
  'GeoStructuralPhysicsEngine.detachBlockAsLiveRigidBody(world, supportPos, 0.0, -0.6, 0.0);',
  'pendingFEMSeeds.add(supportPos.toImmutable());'
);

const oldRenderAnchor = '        // 2. Render 96m Distant 3D Crimson Tunnel Emergency Strobe on damaged/flooded sectors!';
const newRenderAnchor = `        // 1B. Render 60–240 FPS Zero-Black-Flash 6-DoF Rigid Clusters, Live Sagging Spans & Verlet Capes
        ProPhysicsRenderer.renderAll(ctx);

        // 2. Render 96m Distant 3D Crimson Tunnel Emergency Strobe on damaged/flooded sectors!`;
if (!src.includes(oldRenderAnchor)) { console.error('oldRenderAnchor not found'); process.exit(1); }
src = src.replace(oldRenderAnchor, newRenderAnchor);

fs.writeFileSync('/var/tmp/mcbuild/LivePatchV78J.java', src, 'utf8');
console.log('Generated /var/tmp/mcbuild/LivePatchV78J.java (' + src.length + ' chars)');

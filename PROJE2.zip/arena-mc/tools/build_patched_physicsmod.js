#!/usr/bin/env node
/**
 * Builds Patched Physics Mod Pro v3.0.14 (MC 1.20.4 Fabric + NVIDIA PhysX 5 + ArenaAI API)
 * and bundles it via Fabric Jar-in-Jar inside arena-ai-bridge-1.0.0.jar!
 */
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

function collectJava(dir, out = []) {
  for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, ent.name);
    if (ent.isDirectory()) collectJava(p, out);
    else if (ent.name.endsWith('.java')) out.push(`"${p}"`);
  }
  return out;
}

const work = '/var/tmp/mcbuild/build-pmod-v79';
fs.rmSync(work, { recursive: true, force: true });
fs.mkdirSync(path.join(work, 'pmod-classes'), { recursive: true });
fs.mkdirSync(path.join(work, 'bridge-classes'), { recursive: true });
fs.mkdirSync(path.join(work, 'bridge-jar-root', 'META-INF', 'jars'), { recursive: true });

const fapiJars = fs.readdirSync('/tmp/mcbuild/fapi-named').filter(f => f.endsWith('.jar')).map(f => `/tmp/mcbuild/fapi-named/${f}`);
const libJars = fs.readdirSync('/tmp/mcbuild/libs').filter(f => f.endsWith('.jar')).map(f => `/tmp/mcbuild/libs/${f}`);

// 1. Compile Physics Mod Pro Patch + ArenaPhysicsModBridge (Yarn named)
console.log('[1/4] Compiling Physics Mod Pro patch & ArenaPhysicsModBridge...');
const pmodSources = collectJava('/home/user/arena-mc/physicsmod-patch-src');
const pmodCp = [
  '/tmp/mcbuild/pmod-named-api.jar',
  '/tmp/mcbuild/mc-1.20.4-named.jar',
  ...fapiJars,
  ...libJars
].join(':');

execSync(`/tmp/mcbuild/jdk17/bin/javac -proc:none --release 17 -encoding UTF-8 -cp "${pmodCp}" -d "${work}/pmod-classes" ${pmodSources.join(' ')}`, { stdio: 'inherit' });
execSync(`/tmp/mcbuild/jdk17/bin/jar cf "${work}/pmod-patch-named.jar" -C "${work}/pmod-classes" .`, { stdio: 'inherit' });

// 2. Remap Physics Mod Pro patch classes named -> intermediary
console.log('[2/4] Remapping Physics Mod Pro patch named -> intermediary...');
execSync([
  '/tmp/mcbuild/jdk17/bin/java -Xmx600m -jar /tmp/mcbuild/tiny-remapper.jar',
  `"${work}/pmod-patch-named.jar"`,
  `"${work}/pmod-patch-interm.jar"`,
  '/tmp/mcbuild/yarn.tiny named intermediary',
  '/tmp/mcbuild/pmod-named-api.jar',
  '/tmp/mcbuild/mc-1.20.4-named.jar',
  ...fapiJars,
  ...libJars
].join(' '), { stdio: 'inherit' });

// 3. Assemble /var/tmp/mcbuild/physicsmod-arena-3.0.14.jar (Windows x64 CPU + CUDA GPU PhysX 5 + Turkish lang + Patched classes)
console.log('[3/4] Assembling physicsmod-arena-3.0.14.jar...');
execSync(`python3 -c '
import zipfile, json

orig_jar = "/var/tmp/mcbuild/orig-physics-mod.jar"
patch_jar = "${work}/pmod-patch-interm.jar"
out_jar = "/var/tmp/mcbuild/physicsmod-arena-3.0.14.jar"

with zipfile.ZipFile(patch_jar, "r") as zp:
    patch_entries = {name: zp.read(name) for name in zp.namelist() if not name.endswith("/") and not name.startswith("META-INF/")}

print("Overlaying patched classes:", sorted(patch_entries.keys()))

with zipfile.ZipFile(orig_jar, "r") as zin, \\
     zipfile.ZipFile(out_jar, "w", compression=zipfile.ZIP_DEFLATED) as zout:
    written = set()
    for info in zin.infolist():
        fn = info.filename
        # Skip non-Windows native .so/.dylib binaries to save download bandwidth while keeping 100% of Windows PhysX + CUDA DLLs
        if fn.startswith("de/fabmax/physxjni/linux/") and fn.endswith(".so"):
            continue
        if fn.startswith("de/fabmax/physxjni/macos") and fn.endswith(".dylib"):
            continue
        if fn in patch_entries:
            zout.writestr(fn, patch_entries[fn])
            written.add(fn)
        elif fn == "assets/physicsmod/lang/en_us.json":
            en_bytes = zin.read(fn)
            zout.writestr(info, en_bytes)
            written.add(fn)
            # Also generate Turkish lang fallback based on en_us with key Turkish UI titles!
            try:
                lang = json.loads(en_bytes.decode("utf-8"))
                tr_overrides = {
                    "physicsmod.title": "Physics Mod Pro (ArenaAI Entegre)",
                    "physicsmod.general": "Genel Fizik Ayarları",
                    "physicsmod.blocks": "Blok & Yıkım Fiziği",
                    "physicsmod.mobs": "Canlı (Ragdoll) Fiziği",
                    "physicsmod.ocean": "Okyanus & Dalga Fiziği",
                    "physicsmod.smoke": "Duman Fiziği",
                    "physicsmod.snow": "Kar Fiziği",
                    "physicsmod.cloth": "Kumaş & Pelerin Fiziği",
                    "physicsmod.vines": "Sarmaşık & Kapı Fiziği",
                    "physicsmod.collapse": "Yapısal Çökme (ArenaAI)",
                    "physicsmod.weather": "Rüzgar & Hava Fiziği"
                }
                lang.update(tr_overrides)
                zout.writestr("assets/physicsmod/lang/tr_tr.json", json.dumps(lang, ensure_ascii=False, indent=2).encode("utf-8"))
                written.add("assets/physicsmod/lang/tr_tr.json")
            except Exception:
                pass
        else:
            zout.writestr(info, zin.read(fn))
            written.add(fn)

    for fn, data in patch_entries.items():
        if fn not in written:
            zout.writestr(fn, data)
            written.add(fn)
'`, { stdio: 'inherit' });

// 4. Compile & Remap arena-ai-bridge v7.9.0 and embed META-INF/jars/physicsmod-arena-3.0.14.jar
console.log('[4/4] Compiling & bundling arena-ai-bridge v7.9.0 with nested physicsmod-arena-3.0.14.jar...');
const bridgeSources = collectJava('/home/user/arena-mc/mod-src');
const bridgeCp = [
  '/tmp/mcbuild/mc-1.20.4-named.jar',
  '/tmp/mcbuild/mtr-4.0.5.jar',
  ...fapiJars,
  ...libJars
].join(':');

execSync(`/tmp/mcbuild/jdk17/bin/javac -proc:none --release 17 -encoding UTF-8 -cp "${bridgeCp}" -d "${work}/bridge-classes" ${bridgeSources.join(' ')}`, { stdio: 'inherit' });
execSync(`/tmp/mcbuild/jdk17/bin/jar cf "${work}/bridge-named.jar" -C "${work}/bridge-classes" .`, { stdio: 'inherit' });
execSync([
  '/tmp/mcbuild/jdk17/bin/java -Xmx600m -jar /tmp/mcbuild/tiny-remapper.jar',
  `"${work}/bridge-named.jar"`,
  `"${work}/bridge-remapped.jar"`,
  '/tmp/mcbuild/yarn.tiny named intermediary',
  '/tmp/mcbuild/mc-1.20.4-named.jar',
  '/tmp/mcbuild/mtr-4.0.5.jar',
  ...fapiJars,
  ...libJars
].join(' '), { stdio: 'inherit' });

// Copy existing jar resources, replace fabric.mod.json + ai/ classes, and embed META-INF/jars/physicsmod-arena-3.0.14.jar
const existingJar = fs.realpathSync('/home/user/arena-mc/mods/arena-ai-bridge-1.0.0.jar');
execSync(`cd "${work}/bridge-jar-root" && /tmp/mcbuild/jdk17/bin/jar xf "${existingJar}" && rm -rf ai META-INF/jars && mkdir -p META-INF/jars && /tmp/mcbuild/jdk17/bin/jar xf "${work}/bridge-remapped.jar"`, { stdio: 'inherit' });
fs.copyFileSync('/home/user/arena-mc/mod-src/fabric.mod.json', path.join(work, 'bridge-jar-root', 'fabric.mod.json'));
fs.copyFileSync('/var/tmp/mcbuild/physicsmod-arena-3.0.14.jar', path.join(work, 'bridge-jar-root', 'META-INF', 'jars', 'physicsmod-arena-3.0.14.jar'));

const finalBundledJar = '/var/tmp/mcbuild/arena-ai-bridge-v79-physx-bundled.jar';
// Use -0 (STORE) for outer JAR or fast jar cf so nested 125MB jar isn't double-deflated!
execSync(`/tmp/mcbuild/jdk17/bin/jar c0f "${finalBundledJar}" -C "${work}/bridge-jar-root" .`, { stdio: 'inherit' });

// Symlink /home/user/arena-mc/mods/arena-ai-bridge-1.0.0.jar -> finalBundledJar (keeps /home/user snapshot < 85 MB!)
const modLinkPath = '/home/user/arena-mc/mods/arena-ai-bridge-1.0.0.jar';
fs.rmSync(modLinkPath, { force: true });
fs.symlinkSync(finalBundledJar, modLinkPath);

console.log('SUCCESS! Bundled JAR size:', (fs.statSync(finalBundledJar).size / 1e6).toFixed(2), 'MB');

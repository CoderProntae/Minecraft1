#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const ROOT = '/home/user/arena-mc/mod-src';
const ASSET = path.join(ROOT, 'assets/arena_ai_bridge');
let errors = 0;
const fail = (m) => { console.error('FAIL:', m); errors++; };

// 1. Check all blockstates -> models -> textures
for (const bsFile of fs.readdirSync(path.join(ASSET, 'blockstates'))) {
  if (!bsFile.endsWith('.json')) continue;
  const bs = JSON.parse(fs.readFileSync(path.join(ASSET, 'blockstates', bsFile), 'utf8'));
  const variants = bs.variants || {};
  for (const [k, v] of Object.entries(variants)) {
    const arr = Array.isArray(v) ? v : [v];
    for (const entry of arr) {
      const mRef = entry.model.replace(/^arena_ai_bridge:/, '');
      const mPath = path.join(ASSET, 'models', mRef + '.json');
      if (!fs.existsSync(mPath)) { fail(`Missing model ${mPath} from ${bsFile}[${k}]`); continue; }
      const mj = JSON.parse(fs.readFileSync(mPath, 'utf8'));
      const texMap = mj.textures || {};
      for (const [tk, tv] of Object.entries(texMap)) {
        if (tv.startsWith('arena_ai_bridge:')) {
          const tRel = tv.replace(/^arena_ai_bridge:/, '');
          const tPath = path.join(ASSET, 'textures', tRel + '.png');
          if (!fs.existsSync(tPath)) fail(`Missing texture ${tPath} from ${mRef} (#${tk})`);
        }
      }
      for (const el of (mj.elements || [])) {
        for (const [fk, fv] of Object.entries(el.faces || {})) {
          const ref = (fv.texture || '').replace(/^#/, '');
          if (!texMap[ref]) fail(`Unbound face texture #${ref} in ${mRef} face ${fk}`);
        }
      }
    }
  }
}

// 2. Verify tunnel_emergency_light_*_red binds #led
for (const rf of ['tunnel_emergency_light_ceiling_red.json', 'tunnel_emergency_light_wall_red.json']) {
  const rj = JSON.parse(fs.readFileSync(path.join(ASSET, 'models/block', rf), 'utf8'));
  const faces = rj.elements[1].faces;
  for (const [fk, fv] of Object.entries(faces)) {
    if (fv.texture !== '#led') fail(`${rf} diffuser face ${fk} uses ${fv.texture} instead of #led!`);
  }
}

// 3. Verify sounds & GUI textures
if (!fs.existsSync(path.join(ASSET, 'sounds/tunnel_alarm_beep.ogg'))) fail('Missing tunnel_alarm_beep.ogg');
if (!fs.existsSync(path.join(ASSET, 'textures/gui/vending_gui.png'))) fail('Missing vending_gui.png');
if (!fs.existsSync(path.join(ASSET, 'textures/gui/kiosk_gui.png'))) fail('Missing kiosk_gui.png');

const fmj = JSON.parse(fs.readFileSync(path.join(ROOT, 'fabric.mod.json'), 'utf8'));
if (fmj.version !== '7.8.0') fail(`fabric.mod.json version is ${fmj.version}, expected 7.8.0`);

if (errors > 0) {
  console.error(`Pre-flight verification FAILED with ${errors} error(s)!`);
  process.exit(1);
}
console.log('Pre-flight verification PASSED with 0 errors! All blockstates, 3D models, UVs, #led bindings, GUIs & sounds verified.');

const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const ASSET_ROOT = '/home/user/arena-mc/mod-src/assets/arena_ai_bridge';
const TEX_BLOCK = path.join(ASSET_ROOT, 'textures/block');
const TEX_ITEM  = path.join(ASSET_ROOT, 'textures/item');
const TEX_GUI   = path.join(ASSET_ROOT, 'textures/gui');
const MOD_BLOCK = path.join(ASSET_ROOT, 'models/block');
const MOD_ITEM  = path.join(ASSET_ROOT, 'models/item');
const BS_DIR    = path.join(ASSET_ROOT, 'blockstates');

for (const d of [TEX_BLOCK, TEX_ITEM, TEX_GUI, MOD_BLOCK, MOD_ITEM, BS_DIR]) {
  fs.mkdirSync(d, { recursive: true });
}

// ==================== PNG ENCODER & PIXEL-ART PRIMITIVES ====================
function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c ^= buf[i];
    for (let k = 0; k < 8; k++) c = (c >>> 1) ^ (c & 1 ? 0xedb88320 : 0);
  }
  return (c ^ 0xffffffff) >>> 0;
}
function pngChunk(type, data) {
  const len = Buffer.alloc(4); len.writeUInt32BE(data.length, 0);
  const tb = Buffer.from(type, 'ascii');
  const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(Buffer.concat([tb, data])), 0);
  return Buffer.concat([len, tb, data, crc]);
}
class Canvas {
  constructor(w, h) {
    this.w = w; this.h = h;
    this.data = new Uint8Array(w * h * 4);
  }
  idx(x, y) { return (y * this.w + x) * 4; }
  set(x, y, r, g, b, a = 255) {
    x = Math.floor(x); y = Math.floor(y);
    if (x < 0 || y < 0 || x >= this.w || y >= this.h) return;
    const i = this.idx(x, y);
    this.data[i] = Math.max(0, Math.min(255, Math.round(r)));
    this.data[i+1] = Math.max(0, Math.min(255, Math.round(g)));
    this.data[i+2] = Math.max(0, Math.min(255, Math.round(b)));
    this.data[i+3] = Math.max(0, Math.min(255, Math.round(a)));
  }
  blend(x, y, r, g, b, alpha = 1.0) {
    x = Math.floor(x); y = Math.floor(y);
    if (x < 0 || y < 0 || x >= this.w || y >= this.h) return;
    const i = this.idx(x, y);
    const inv = 1 - alpha;
    this.data[i]   = Math.round(this.data[i]   * inv + r * alpha);
    this.data[i+1] = Math.round(this.data[i+1] * inv + g * alpha);
    this.data[i+2] = Math.round(this.data[i+2] * inv + b * alpha);
    this.data[i+3] = Math.min(255, Math.round(this.data[i+3] * inv + 255 * alpha));
  }
  fill(x0, y0, w, h, fnOrColor) {
    for (let y = y0; y < y0 + h; y++) {
      for (let x = x0; x < x0 + w; x++) {
        const c = typeof fnOrColor === 'function' ? fnOrColor(x, y, x - x0, y - y0) : fnOrColor;
        if (c) this.set(x, y, c[0], c[1], c[2], c[3] ?? 255);
      }
    }
  }
  bevelBox(x0, y0, w, h, base, hi, sh, inset = false) {
    const topC = inset ? sh : hi;
    const botC = inset ? hi : sh;
    this.fill(x0, y0, w, h, base);
    for (let x = x0; x < x0 + w; x++) {
      this.set(x, y0, ...topC);
      this.set(x, y0 + h - 1, ...botC);
    }
    for (let y = y0; y < y0 + h; y++) {
      this.set(x0, y, ...topC);
      this.set(x0 + w - 1, y, ...botC);
    }
  }
  circle(cx, cy, r, col) {
    for (let dy = -Math.ceil(r); dy <= Math.ceil(r); dy++) {
      for (let dx = -Math.ceil(r); dx <= Math.ceil(r); dx++) {
        if (dx*dx + dy*dy <= r*r) this.set(cx + dx, cy + dy, ...col);
      }
    }
  }
  line(x0, y0, x1, y1, col) {
    let dx = Math.abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
    let dy = -Math.abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
    let err = dx + dy;
    while (true) {
      this.set(x0, y0, ...col);
      if (x0 === x1 && y0 === y1) break;
      const e2 = 2 * err;
      if (e2 >= dy) { err += dy; x0 += sx; }
      if (e2 <= dx) { err += dx; y0 += sy; }
    }
  }
  save(filepath) {
    const raw = Buffer.alloc(this.h * (1 + this.w * 4));
    for (let y = 0; y < this.h; y++) {
      raw[y * (1 + this.w * 4)] = 0;
      Buffer.from(this.data.buffer, y * this.w * 4, this.w * 4).copy(raw, y * (1 + this.w * 4) + 1);
    }
    const ihdr = Buffer.alloc(13);
    ihdr.writeUInt32BE(this.w, 0); ihdr.writeUInt32BE(this.h, 4);
    ihdr[8] = 8; ihdr[9] = 6;
    const out = Buffer.concat([
      Buffer.from([137,80,78,71,13,10,26,10]),
      pngChunk('IHDR', ihdr),
      pngChunk('IDAT', zlib.deflateSync(raw, { level: 9 })),
      pngChunk('IEND', Buffer.alloc(0))
    ]);
    fs.writeFileSync(filepath, out);
  }
}

// Deterministic hash & Bayer 4x4 matrix for crisp pixel-art shading/dithering
function hash2(x, y, seed = 1) {
  let n = Math.imul(x * 374761393 + y * 668265263 + seed * 1442695041, 1274126177);
  n = (n ^ (n >>> 13)) >>> 0;
  return (n & 0xffff) / 65535.0;
}
const BAYER4 = [
  [ 0/16,  8/16,  2/16, 10/16],
  [12/16,  4/16, 14/16,  6/16],
  [ 3/16, 11/16,  1/16,  9/16],
  [15/16,  7/16, 13/16,  5/16]
];
function ditherLerp(c1, c2, t, x, y) {
  const b = BAYER4[y & 3][x & 3];
  const pick = t > b ? c2 : c1;
  return pick;
}

// Crisp variable-width pixel font (5px wide for M/W/%, 4px wide for N, 3px wide for standard glyphs)
const FONT_VW = {
  'A': ['010','101','111','101','101'],
  'B': ['110','101','110','101','110'],
  'C': ['011','100','100','100','011'],
  'D': ['110','101','101','101','110'],
  'E': ['111','100','110','100','111'],
  'F': ['111','100','110','100','100'],
  'G': ['0111','1000','1011','1001','0111'],
  'H': ['101','101','111','101','101'],
  'I': ['111','010','010','010','111'],
  'J': ['001','001','001','101','010'],
  'K': ['1001','1010','1100','1010','1001'],
  'L': ['100','100','100','100','111'],
  'M': ['10001','11011','10101','10001','10001'],
  'N': ['1001','1101','1011','1001','1001'],
  'O': ['0110','1001','1001','1001','0110'],
  'P': ['110','101','110','100','100'],
  'R': ['110','101','110','101','101'],
  'S': ['011','100','010','001','110'],
  'T': ['111','010','010','010','010'],
  'U': ['101','101','101','101','111'],
  'V': ['101','101','101','101','010'],
  'W': ['10001','10001','10101','11011','10001'],
  'Y': ['101','101','010','010','010'],
  'Z': ['111','001','010','100','111'],
  '0': ['111','101','101','101','111'],
  '1': ['010','110','010','010','111'],
  '2': ['110','001','010','100','111'],
  '3': ['110','001','010','001','110'],
  '4': ['101','101','111','001','001'],
  '5': ['111','100','110','001','110'],
  '6': ['011','100','110','101','010'],
  '7': ['111','001','010','010','010'],
  '8': ['111','101','111','101','111'],
  '9': ['010','101','011','001','110'],
  '%': ['11001','11010','00100','01011','10011'],
  '/': ['001','001','010','100','100'],
  '-': ['000','000','111','000','000'],
  ':': ['0','1','0','1','0'],
  ' ': ['00','00','00','00','00']
};
function measurePixelText(str) {
  let w = 0;
  for (const ch of str.toUpperCase()) {
    const g = FONT_VW[ch] || FONT_VW[' '];
    w += g[0].length + 1;
  }
  return Math.max(0, w - 1);
}
function drawPixelText(cv, x0, y0, str, col, shadowCol = null) {
  let cx = x0;
  for (const ch of str.toUpperCase()) {
    const g = FONT_VW[ch] || FONT_VW[' '];
    const gw = g[0].length;
    for (let r = 0; r < 5; r++) {
      for (let c = 0; c < gw; c++) {
        if (g[r][c] === '1') {
          if (shadowCol) cv.set(cx + c + 1, y0 + r + 1, ...shadowCol);
          cv.set(cx + c, y0 + r, ...col);
        }
      }
    }
    cx += gw + 1;
  }
}
function drawPixelTextCentered(cv, boxX, boxW, y0, str, col, shadowCol = null) {
  const tw = measurePixelText(str);
  const startX = boxX + Math.max(0, Math.floor((boxW - tw) / 2));
  drawPixelText(cv, startX, y0, str, col, shadowCol);
}

// ==================== 1. ANODIZED GUNMETAL & TITANIUM CASING (64x64) ====================
{
  const cv = new Canvas(64, 64);
  cv.fill(0, 0, 64, 64, (x, y) => {
    const streak = (hash2(Math.floor(x / 4), y, 7) - 0.5) * 8 + (hash2(x, y, 13) - 0.5) * 4;
    const edgeDist = Math.min(x, y, 63 - x, 63 - y);
    const ao = edgeDist === 0 ? -12 : edgeDist === 1 ? 6 : 0;
    const baseR = 40 + streak + ao, baseG = 45 + streak + ao, baseB = 52 + streak + ao;
    return [baseR, baseG, baseB, 255];
  });
  // Subtle recessed service seam & 4 corner hex rivets
  for (const [rx, ry] of [[4,4],[59,4],[4,59],[59,59]]) {
    cv.set(rx, ry, 68, 75, 84);
    cv.set(rx+1, ry, 62, 68, 76);
    cv.set(rx, ry+1, 24, 28, 33);
    cv.set(rx+1, ry+1, 22, 25, 30);
  }
  cv.save(path.join(TEX_BLOCK, 'anodized_gunmetal.png'));
}

// ==================== 2. VENDING MACHINE INTERIOR & SHELVES (64x64) ====================
{
  const cv = new Canvas(64, 64);
  // Top half (0..31): Cool backlit showcase back wall with subtle vertical stainless ribbing
  cv.fill(0, 0, 64, 32, (x, y) => {
    const rib = (x % 4 === 0) ? -5 : (x % 4 === 2) ? 4 : 0;
    const glow = Math.max(0, 18 - y * 0.45);
    return [46 + rib + glow, 56 + rib + glow * 1.2, 68 + rib + glow * 1.4, 255];
  });
  // Bottom half (32..63): Brushed stainless shelf & delivery chute surface
  cv.fill(0, 32, 64, 32, (x, y) => {
    const streak = (hash2(Math.floor(x / 5), y, 21) - 0.5) * 12;
    return [136 + streak, 145 + streak, 156 + streak, 255];
  });
  // Perforated shelf front edge trim at y=60..63
  for (let x = 0; x < 64; x++) {
    cv.set(x, 60, 200, 210, 220);
    cv.set(x, 61, (x % 4 < 2) ? 60 : 150, (x % 4 < 2) ? 68 : 160, (x % 4 < 2) ? 78 : 170);
    cv.set(x, 62, 95, 104, 115);
    cv.set(x, 63, 55, 62, 70);
  }
  cv.save(path.join(TEX_BLOCK, 'vending_interior.png'));
}

// ==================== 3. VENDING MACHINE UPPER FRONT (64x64, 4px = 1 model unit) ====================
// Exact UV sync with vending_machine_upper.json:
// - Canopy header: x=0..16 (px 0..64), y=13.5..15.5 (v_px 2..10)
// - Glass window: x=1.5..10.8 (px 6..43), y=0.2..13.2 (v_px 11..63)
// - Payment column: x=11.0..15.2 (px 44..61), y=0.2..13.2 (v_px 11..63)
{
  const cv = new Canvas(64, 64);
  // Base dark gunmetal frame
  cv.fill(0, 0, 64, 64, (x, y) => {
    const n = (hash2(Math.floor(x/3), y, 31) - 0.5) * 6;
    return [36 + n, 41 + n, 48 + n, 255];
  });
  // Top illuminated marquee sign (px x=4..60, y=2..10)
  cv.bevelBox(4, 2, 56, 8, [14, 42, 54, 255], [22, 30, 38, 255], [75, 92, 108, 255], true);
  cv.fill(5, 3, 54, 6, (x, y) => {
    const cy = 1 - Math.abs(y - 5.5) / 4.0;
    return [18 + cy * 18, 92 + cy * 45, 112 + cy * 50, 255];
  });
  drawPixelTextCentered(cv, 5, 54, 4, 'METRO OTOMAT', [230, 252, 255, 255], [10, 48, 62, 255]);

  // Semi-transparent tempered glass showcase (px x=6..43, y=12..62) -> alpha=92 so 3D items inside shine clearly!
  cv.bevelBox(5, 11, 39, 52, [24, 30, 38, 255], [18, 22, 28, 255], [68, 76, 88, 255], true);
  cv.fill(6, 12, 37, 50, (x, y) => {
    // Crisp diagonal glass specular reflection bands
    const diag = (x + y * 0.75) % 26;
    if (diag < 2.2) return [185, 225, 245, 130];
    if (diag > 4.0 && diag < 5.2) return [150, 200, 225, 105];
    // Inner top LED glow gradient
    const topGlow = Math.max(0, 12 - (y - 12)) * 3;
    return [24 + topGlow, 38 + topGlow * 1.3, 50 + topGlow * 1.5, 82];
  });

  // Right-side payment console panel (px x=45..60, y=12..62)
  cv.bevelBox(45, 12, 15, 50, [52, 58, 68, 255], [76, 84, 96, 255], [26, 30, 36, 255], false);
  // Digital OLED screen (px x=47..58, y=15..25)
  cv.bevelBox(47, 15, 11, 10, [10, 26, 32, 255], [20, 24, 30, 255], [70, 82, 92, 255], true);
  drawPixelText(cv, 49, 18, '4TL', [72, 245, 180, 255]);
  // 3x4 metallic tactile keypad (px x=47..58, y=28..41)
  for (let row = 0; row < 4; row++) {
    for (let col = 0; col < 3; col++) {
      const bx = 47 + col * 4, by = 28 + row * 3;
      cv.set(bx, by, 168, 178, 190);
      cv.set(bx+1, by, 148, 158, 170);
      cv.set(bx+2, by, 110, 120, 132);
      cv.set(bx, by+1, 120, 130, 142);
      cv.set(bx+1, by+1, 96, 105, 116);
      cv.set(bx+2, by+1, 58, 64, 74);
    }
  }
  // Contactless Emerald Smartcard Reader Pad (px x=47..58, y=44..56)
  cv.bevelBox(47, 44, 11, 12, [16, 78, 56, 255], [34, 145, 102, 255], [10, 44, 32, 255], false);
  // Contactless radio wave arcs
  cv.set(51, 50, 150, 255, 200);
  for (const [dx, dy] of [[2,-2],[3,-1],[3,0],[3,1],[2,2],[4,-3],[5,-1],[5,0],[5,1],[4,3]]) {
    cv.set(50 + dx, 50 + dy, 120, 245, 180);
  }
  cv.save(path.join(TEX_BLOCK, 'vending_upper_front.png'));
}

// ==================== 4. VENDING MACHINE LOWER FRONT (64x64) ====================
// Exact UV sync with vending_machine_lower.json:
// - Delivery flap: x=2..11 (px 8..44), y=4.5..10.5 (v_px 22..46)
// - Kickplate louvers: y=0..3 (v_px 52..64)
{
  const cv = new Canvas(64, 64);
  cv.fill(0, 0, 64, 64, (x, y) => {
    const n = (hash2(Math.floor(x/4), y, 41) - 0.5) * 7;
    return [38 + n, 43 + n, 50 + n, 255];
  });
  // Upper stainless accent trim strip (y_px 2..5)
  cv.fill(4, 2, 56, 3, (x, y) => [92 - (y-2)*18, 102 - (y-2)*18, 114 - (y-2)*18, 255]);
  // Delivery Push Flap texture (px x=8..44, y=20..44)
  cv.bevelBox(8, 20, 36, 24, [118, 128, 140, 255], [165, 176, 188, 255], [56, 62, 70, 255], false);
  cv.fill(10, 22, 32, 20, (x, y) => {
    const sheen = Math.sin((x + y * 0.4) * 0.22) * 10 + (hash2(Math.floor(x/5), y, 55) - 0.5) * 6;
    return [122 + sheen, 132 + sheen, 144 + sheen, 255];
  });
  // Recessed dark grip handle bar inside flap
  cv.bevelBox(16, 25, 20, 4, [42, 48, 56, 255], [24, 28, 34, 255], [150, 160, 172, 255], true);
  // Coin return & security cylinder on right (px x=48..57, y=22..34)
  cv.bevelBox(48, 24, 9, 10, [26, 30, 36, 255], [18, 20, 24, 255], [68, 76, 86, 255], true);
  cv.circle(52, 16, 2.2, [160, 170, 182, 255]);
  cv.set(52, 16, 28, 32, 38);

  // Bottom 5 recessed cooling louvers (px x=8..56, y=50..61)
  for (let ly = 50; ly <= 60; ly += 3) {
    for (let x = 8; x < 56; x++) {
      cv.set(x, ly, 18, 21, 26);
      cv.set(x, ly + 1, 58, 65, 74);
    }
  }
  cv.save(path.join(TEX_BLOCK, 'vending_lower_front.png'));
}

// ==================== 5. INFO KIOSK TOUCHSCREEN & PEDESTAL (64x64) ====================
{
  const cv = new Canvas(64, 64);
  // Top crown banner (px y=0..12): Glowing cyan-blue passenger info header with 'i' emblem
  cv.fill(0, 0, 64, 64, (x, y) => {
    const n = (hash2(Math.floor(x/4), y, 61) - 0.5) * 6;
    return [44 + n, 50 + n, 58 + n, 255];
  });
  cv.bevelBox(8, 2, 48, 10, [14, 88, 128, 255], [64, 195, 245, 255], [10, 46, 72, 255], false);
  drawPixelTextCentered(cv, 9, 46, 5, 'YOLCU BILGI', [235, 252, 255, 255], [8, 42, 68, 255]);

  // Touchscreen glass area (px x=8..56, y=16..56 — matches 12x10 angled head)
  cv.bevelBox(8, 16, 48, 40, [14, 22, 34, 255], [96, 108, 122, 255], [24, 28, 34, 255], true);
  cv.fill(10, 18, 44, 36, (x, y) => {
    const grad = (y - 18) * 0.4;
    return [14 + grad * 0.3, 24 + grad * 0.5, 40 + grad * 0.8, 255];
  });
  // Screen top status bar
  cv.fill(10, 18, 44, 6, [20, 64, 96, 255]);
  drawPixelTextCentered(cv, 10, 44, 19, 'M1 ORMAN', [180, 245, 255, 255]);
  // Schematic route graphic on left of screen (emerald forest patch + crimson M1 line + station dots)
  cv.fill(12, 26, 17, 25, (x, y) => ditherLerp([18, 48, 38, 255], [24, 64, 48, 255], 0.45, x, y));
  cv.fill(20, 27, 2, 22, [235, 64, 64, 255]); // M1 crimson trunk line
  cv.circle(21, 29, 2.0, [255, 255, 255, 255]);
  cv.set(21, 29, 235, 64, 64);
  cv.circle(21, 46, 2.0, [255, 255, 255, 255]);
  cv.set(21, 46, 46, 215, 130);
  // Live arrival rows on right of screen
  cv.fill(31, 27, 22, 7, [22, 36, 54, 255]);
  drawPixelTextCentered(cv, 31, 22, 28, 'KUZEY', [220, 235, 250, 255]);
  cv.fill(31, 36, 22, 7, [22, 36, 54, 255]);
  drawPixelTextCentered(cv, 31, 22, 37, 'GUNEY', [220, 235, 250, 255]);
  // Bottom live speed / SCADA OK strip
  cv.fill(31, 45, 22, 6, [18, 82, 58, 255]);
  drawPixelTextCentered(cv, 31, 22, 46, '80KM', [140, 255, 195, 255]);
  cv.save(path.join(TEX_BLOCK, 'kiosk_upper_front.png'));

  // Pedestal brushed silver-slate + cyan LED accent groove
  const ped = new Canvas(64, 64);
  ped.fill(0, 0, 64, 64, (x, y) => {
    const streak = (hash2(x, Math.floor(y / 4), 73) - 0.5) * 9;
    if (x >= 30 && x <= 33) {
      return [38, 195, 235, 255]; // recessed vertical cyan LED accent
    }
    if (x === 29 || x === 34) return [24, 30, 38, 255];
    return [72 + streak, 80 + streak, 90 + streak, 255];
  });
  ped.save(path.join(TEX_BLOCK, 'kiosk_pedestal.png'));
}

// ==================== 6. METRO BENCH OILED WALNUT & CAST IRON (64x64) ====================
{
  const wood = new Canvas(64, 64);
  wood.fill(0, 0, 64, 64, (x, y) => {
    const wave = Math.sin(x * 0.14 + Math.sin(y * 0.35) * 1.4) * 0.5 + 0.5;
    const fine = (hash2(Math.floor(x / 6), y, 91) - 0.5) * 14;
    // Slat edge bevel every 8px vertically
    const sy = y % 8;
    const bev = sy === 0 ? 16 : sy === 7 ? -18 : 0;
    const r = 112 + wave * 24 + fine + bev;
    const g = 72  + wave * 16 + fine * 0.7 + bev * 0.7;
    const b = 42  + wave * 10 + fine * 0.5 + bev * 0.5;
    return [r, g, b, 255];
  });
  wood.save(path.join(TEX_BLOCK, 'bench_walnut.png'));

  const iron = new Canvas(64, 64);
  iron.fill(0, 0, 64, 64, (x, y) => {
    const speck = (hash2(x, y, 107) - 0.5) * 10;
    const edge = (x % 16 === 0 || y % 16 === 0) ? 10 : (x % 16 === 15 || y % 16 === 15) ? -10 : 0;
    return [34 + speck + edge, 37 + speck + edge, 43 + speck + edge, 255];
  });
  iron.save(path.join(TEX_BLOCK, 'bench_cast_iron.png'));
}

// ==================== 7. SAFETY CABINET ATLAS (64x64) ====================
// Quadrants:
// [0..31, 0..31]: Powder-coated crimson steel frame
// [32..63, 0..31]: Semi-transparent emergency door glass with white-red hazard trim & reflection
// [0..31, 32..63]: Extinguisher cylinder (red steel + yellow safety band + pressure gauge)
// [32..63, 32..63]: Inner white-grey reflective backplate + brass valve + black hose
{
  const cv = new Canvas(64, 64);
  // Top-left: Crimson steel casing
  cv.fill(0, 0, 32, 32, (x, y) => {
    const n = (hash2(x, y, 121) - 0.5) * 9;
    const bev = (x === 0 || y === 0) ? 22 : (x === 31 || y === 31) ? -22 : 0;
    return [176 + n + bev, 28 + n * 0.4 + bev * 0.3, 32 + n * 0.4 + bev * 0.3, 255];
  });
  // Top-right: Framed emergency glass door (alpha=85 inside)
  cv.fill(32, 0, 32, 32, (x, y) => {
    const lx = x - 32, ly = y;
    if (lx < 3 || lx >= 29 || ly < 3 || ly >= 29) {
      return [186, 32, 36, 255]; // red door frame
    }
    if (lx === 3 || lx === 28 || ly === 3 || ly === 28) {
      return ((lx + ly) % 4 < 2) ? [245, 245, 248, 220] : [210, 38, 42, 220];
    }
    const streak = ((lx + ly) % 15 < 2) ? 55 : 0;
    return [190 + streak, 225 + streak, 240 + streak, 78];
  });
  // Door chrome latch handle at right-middle of door
  cv.fill(57, 14, 2, 5, [215, 222, 230, 255]);

  // Bottom-left: 3D Fire Extinguisher Cylinder UV (0..16, 32..64) & Brass/Hose (16..32, 32..64)
  cv.fill(0, 32, 16, 32, (x, y) => {
    // Cylindrical horizontal highlight across x=0..15!
    const cyl = Math.sin((x / 15.0) * Math.PI);
    if (y >= 40 && y <= 45) {
      // Instruction label band (yellow/white)
      return [225 * (0.65 + 0.35 * cyl), 195 * (0.65 + 0.35 * cyl), 55, 255];
    }
    return [145 + cyl * 85, 18 + cyl * 22, 22 + cyl * 20, 255];
  });
  // Brass valve (16..23, 32..47) & black braided hose (24..31, 32..63)
  cv.fill(16, 32, 8, 16, (x, y) => {
    const n = (hash2(x, y, 131) - 0.5) * 12;
    return [205 + n, 168 + n, 58 + n, 255];
  });
  cv.circle(20, 39, 2.2, [235, 245, 240, 255]); // pressure gauge dial
  cv.set(20, 39, 35, 195, 75); // green needle
  cv.fill(24, 32, 8, 32, (x, y) => {
    const braid = ((x + y) % 2 === 0) ? 8 : -4;
    return [26 + braid, 28 + braid, 32 + braid, 255];
  });

  // Bottom-right: Inner reflective white-slate cabinet backplate
  cv.fill(32, 32, 32, 32, (x, y) => {
    const n = (hash2(x, y, 141) - 0.5) * 6;
    const ao = Math.min(x - 32, y - 32, 63 - x, 63 - y) < 2 ? -18 : 0;
    return [218 + n + ao, 222 + n + ao, 228 + n + ao, 255];
  });
  cv.save(path.join(TEX_BLOCK, 'safety_cabinet_atlas.png'));
}

// ==================== 8. FOUR HAND-SHADED 64x64 PIXEL-ART POSTERS ====================
function makePosterFrameBase() {
  const cv = new Canvas(64, 64);
  cv.fill(0, 0, 64, 64, (x, y) => {
    const n = (hash2(x, y, 151) - 0.5) * 6;
    return [30 + n, 34 + n, 40 + n, 255];
  });
  return cv;
}
makePosterFrameBase().save(path.join(TEX_BLOCK, 'lightbox_frame.png'));

// Poster 0: M1 Orman Hattı — Layered sunset sky, dithered mountains, pine trees, and M1 train!
{
  const cv = new Canvas(64, 64);
  // Sky gradient (golden dusk to twilight teal) with Bayer dithering
  cv.fill(0, 0, 64, 64, (x, y) => {
    const t = Math.min(1, y / 38.0);
    const top = [22, 52, 82, 255], mid = [58, 118, 132, 255], low = [238, 178, 96, 255];
    return t < 0.55 ? ditherLerp(top, mid, t / 0.55, x, y) : ditherLerp(mid, low, (t - 0.55) / 0.45, x, y);
  });
  // Glowing sun disc
  cv.circle(46, 16, 6.5, [255, 228, 138, 255]);
  cv.circle(46, 16, 4.5, [255, 246, 195, 255]);
  // Distant mountain ridge
  for (let x = 0; x < 64; x++) {
    const mh = Math.round(24 + Math.sin(x * 0.11) * 5 + Math.cos(x * 0.23) * 3);
    for (let y = mh; y < 48; y++) {
      cv.set(x, y, ...(x % 2 === 0 && y < mh + 3 ? [52, 82, 92, 255] : [38, 66, 76, 255]));
    }
  }
  // Shaded pixel pine trees (left & right forest)
  const drawPine = (tx, baseY, h) => {
    cv.fill(tx - 1, baseY - 3, 2, 4, [72, 46, 28, 255]);
    for (let tier = 0; tier < 3; tier++) {
      const ty = baseY - 3 - tier * Math.floor(h * 0.28);
      const tw = Math.max(2, Math.floor((h * 0.45) * (1 - tier * 0.24)));
      const th = Math.floor(h * 0.42);
      for (let dy = 0; dy < th; dy++) {
        const w = Math.max(1, Math.round(tw * (1 - dy / th)));
        for (let dx = -w; dx <= w; dx++) {
          const lit = dx < 0 ? 18 : -10;
          cv.set(tx + dx, ty - dy, 26 + lit, 96 + lit * 1.4, 58 + lit, 255);
        }
      }
    }
  };
  for (const [px, py, ph] of [[8,52,22],[16,50,18],[54,52,23],[47,49,17],[60,54,19]]) drawPine(px, py, ph);

  // Foreground ballast & sleek isometric M1 metro train emerging from forest!
  cv.fill(0, 48, 64, 16, (x, y) => ditherLerp([24, 58, 38, 255], [18, 42, 28, 255], (y - 48) / 16, x, y));
  // Perspective rail bed
  for (let y = 46; y < 64; y++) {
    const halfW = 4 + Math.floor((y - 46) * 0.75);
    for (let x = 32 - halfW; x <= 32 + halfW; x++) {
      const isRail = Math.abs(x - (32 - halfW + 2)) <= 0 || Math.abs(x - (32 + halfW - 2)) <= 0;
      cv.set(x, y, ...(isRail ? [185, 195, 208, 255] : ((y % 2 === 0) ? [68, 72, 78, 255] : [50, 54, 60, 255])));
    }
  }
  // Modern silver-crimson M1 Train cab (x=24..40, y=31..49)
  cv.bevelBox(24, 31, 16, 18, [215, 222, 230, 255], [245, 248, 252, 255], [120, 130, 142, 255], false);
  cv.fill(24, 42, 16, 3, [205, 38, 46, 255]); // M1 crimson livery stripe
  cv.fill(26, 33, 12, 8, [22, 32, 44, 255]);  // dark cab windshield
  cv.line(27, 34, 31, 38, [120, 185, 220, 255]); // windshield glint
  cv.fill(26, 45, 3, 2, [255, 250, 200, 255]); // left LED headlight
  cv.fill(35, 45, 3, 2, [255, 250, 200, 255]); // right LED headlight

  // Top header bar (visible inside frame x=5..59)
  cv.fill(0, 0, 64, 10, [16, 34, 48, 225]);
  drawPixelTextCentered(cv, 5, 54, 3, 'M1 ORMAN HATTI', [235, 250, 255, 255]);
  cv.save(path.join(TEX_BLOCK, 'poster_forest.png'));
}

// Poster 1: Orman Kart Smartcard — Deep emerald dithered backdrop + angled smartcard with gold EMV chip!
{
  const cv = new Canvas(64, 64);
  cv.fill(0, 0, 64, 64, (x, y) => {
    const dist = Math.hypot(x - 32, y - 32) / 42.0;
    return ditherLerp([26, 98, 72, 255], [12, 38, 32, 255], Math.min(1, dist), x, y);
  });
  // Stylized smartcard (x=10..54, y=18..46) with drop shadow
  cv.fill(12, 20, 44, 28, [8, 22, 18, 255]);
  cv.bevelBox(10, 18, 44, 28, [34, 152, 102, 255], [95, 228, 165, 255], [18, 86, 58, 255], false);
  cv.fill(11, 19, 42, 26, (x, y) => {
    const diag = ((x + y) / 68.0);
    return ditherLerp([42, 168, 112, 255], [24, 118, 80, 255], diag, x, y);
  });
  // Gold EMV chip (x=15..22, y=28..34)
  cv.bevelBox(15, 28, 8, 7, [232, 192, 72, 255], [255, 232, 135, 255], [156, 118, 32, 255], false);
  cv.line(15, 31, 22, 31, [168, 128, 38, 255]);
  cv.line(18, 28, 18, 34, [168, 128, 38, 255]);
  // Mini pine silhouette on right of card
  for (let dy = 0; dy < 10; dy++) {
    const w = Math.max(1, Math.round(5 * (1 - dy / 10)));
    for (let dx = -w; dx <= w; dx++) cv.set(44 + dx, 38 - dy, 175, 250, 205);
  }
  drawPixelTextCentered(cv, 11, 42, 21, 'ORMAN KART', [240, 255, 248, 255], [14, 68, 46, 255]);
  drawPixelTextCentered(cv, 0, 64, 52, 'ULASIM %50', [175, 255, 210, 255]);
  cv.save(path.join(TEX_BLOCK, 'poster_card.png'));
}

// Poster 2: Orman Kafe — Warm cozy espresso & pastry pixel illustration!
{
  const cv = new Canvas(64, 64);
  cv.fill(0, 0, 64, 64, (x, y) => {
    const t = y / 64.0;
    return ditherLerp([58, 36, 24, 255], [28, 18, 12, 255], t, x, y);
  });
  // Wooden table counter at y=46..63
  cv.fill(0, 46, 64, 18, (x, y) => {
    const g = (hash2(Math.floor(x/5), y, 171) - 0.5) * 12;
    return [118 + g, 76 + g * 0.7, 44 + g * 0.5, 255];
  });
  cv.fill(0, 46, 64, 2, [156, 108, 68, 255]);
  // Saucer & shaded ceramic coffee cup (x=20..42, y=28..46)
  cv.fill(17, 44, 28, 3, [225, 220, 212, 255]);
  for (let y = 29; y <= 43; y++) {
    const taper = Math.floor((y - 29) * 0.22);
    for (let x = 21 + taper; x <= 41 - taper; x++) {
      const shade = (x - 21) / 20.0;
      const c = shade < 0.65 ? [242, 236, 226, 255] : [192, 184, 172, 255];
      cv.set(x, y, ...c);
    }
  }
  // Cup handle
  for (const [hx, hy] of [[42,32],[44,33],[45,35],[45,37],[44,39],[41,40]]) {
    cv.set(hx, hy, 230, 224, 214); cv.set(hx-1, hy, 200, 192, 182);
  }
  // Rich espresso rim & rising pixel steam wisps
  cv.fill(22, 30, 19, 2, [86, 48, 24, 255]);
  for (let sy = 16; sy < 27; sy++) {
    const sx1 = 27 + Math.round(Math.sin(sy * 0.55) * 1.6);
    const sx2 = 34 + Math.round(Math.cos(sy * 0.55) * 1.6);
    cv.set(sx1, sy, 215, 200, 185);
    cv.set(sx2, sy, 195, 180, 165);
  }
  drawPixelTextCentered(cv, 0, 64, 5, 'ORMAN KAFE', [255, 228, 175, 255], [32, 18, 10, 255]);
  drawPixelTextCentered(cv, 0, 64, 54, 'SICAK KAHVE', [255, 238, 205, 255]);
  cv.save(path.join(TEX_BLOCK, 'poster_cafe.png'));
}

// Poster 3: Line Safety Notice — Crisp UITP yellow/slate transit safety diagram!
{
  const cv = new Canvas(64, 64);
  cv.fill(0, 0, 64, 64, (x, y) => ditherLerp([22, 30, 42, 255], [14, 20, 30, 255], y / 64, x, y));
  // Hazard stripe header & footer
  for (let x = 0; x < 64; x++) {
    for (let y = 0; y < 6; y++) {
      const yellow = ((x + y) % 8) < 4;
      cv.set(x, y, ...(yellow ? [242, 196, 36, 255] : [26, 30, 36, 255]));
      cv.set(x, 58 + y, ...(yellow ? [242, 196, 36, 255] : [26, 30, 36, 255]));
    }
  }
  // Warning triangle emblem in center (y=13..38)
  for (let dy = 0; dy < 24; dy++) {
    const hw = Math.round(dy * 0.62);
    for (let dx = -hw; dx <= hw; dx++) {
      const border = Math.abs(dx) >= hw - 1 || dy >= 22;
      cv.set(32 + dx, 14 + dy, ...(border ? [245, 200, 42, 255] : [42, 36, 18, 255]));
    }
  }
  cv.fill(31, 21, 3, 8, [245, 205, 52, 255]);
  cv.fill(31, 31, 3, 3, [245, 205, 52, 255]);
  drawPixelTextCentered(cv, 0, 64, 44, 'SARI CIZGIYI', [245, 215, 90, 255]);
  drawPixelTextCentered(cv, 0, 64, 51, 'GECMEYINIZ', [235, 242, 250, 255]);
  cv.save(path.join(TEX_BLOCK, 'poster_safety.png'));
}

// ==================== 9. TUNNEL LINEAR LED RAIL ATLAS (64x64) ====================
// x=0..31: Extruded ribbed aluminum ceiling mount channel
// x=32..63: Frosted polycarbonate linear LED lens (#FFFFFF core so LightmapTextureManager drives pure crimson/blackout!)
{
  const cv = new Canvas(64, 64);
  cv.fill(0, 0, 32, 64, (x, y) => {
    const rib = (x === 2 || x === 29) ? 18 : (x === 5 || x === 26) ? -14 : 0;
    const grain = (hash2(x, Math.floor(y / 6), 191) - 0.5) * 6;
    return [62 + rib + grain, 68 + rib + grain, 76 + rib + grain, 255];
  });
  cv.fill(32, 0, 32, 64, (x, y) => {
    const lx = x - 32;
    const center = 1 - Math.abs(lx - 15.5) / 16.0;
    const micro = (hash2(x, y, 199) - 0.5) * 4;
    const v = 228 + center * 27 + micro;
    return [v, v, Math.min(255, v + 3), 255];
  });
  cv.save(path.join(TEX_BLOCK, 'tunnel_led_atlas.png'));
}

// ==================== 10. CUSTOM MINECRAFT PIXEL-ART GUI SHEETS (256x256) ====================
// textures/gui/vending_gui.png (v7.8.0 — 3x3 9-Item Interactive Showcase Grid: 236 x 196):
// - [0, 0, 236, 196]: Beveled MTR dark-titanium container window with 3x3 (9x) product cards & recessed 18x18 slots!
// - [0, 200, 68, 36]: Hovered 3x3 card highlight sprite
// - [70, 200, 68, 36]: Disabled 3x3 card sprite
// - [0, 238, 86, 16] & [88, 238, 86, 16]: Top-up button normal & hover
{
  const gui = new Canvas(256, 256);
  const GW = 236, GH = 196;
  gui.fill(2, 0, GW - 4, GH, [20, 24, 30, 255]);
  gui.fill(0, 2, GW, GH - 4, [20, 24, 30, 255]);
  gui.fill(2, 2, GW - 4, GH - 4, (x, y) => {
    const n = (hash2(Math.floor(x/2), Math.floor(y/2), 211) - 0.5) * 5;
    return [40 + n, 46 + n, 54 + n, 255];
  });
  for (let x = 2; x < GW - 2; x++) {
    gui.set(x, 2, 132, 144, 158); gui.set(x, 3, 92, 102, 116);
    gui.set(x, GH - 4, 24, 28, 34); gui.set(x, GH - 3, 16, 19, 24);
  }
  for (let y = 2; y < GH - 2; y++) {
    gui.set(2, y, 132, 144, 158); gui.set(3, y, 92, 102, 116);
    gui.set(GW - 4, y, 24, 28, 34); gui.set(GW - 3, y, 16, 19, 24);
  }

  // Top header banner well (x=8..228, y=7..27) + cyan accent strip
  gui.bevelBox(8, 7, 220, 20, [14, 32, 44, 255], [18, 22, 28, 255], [84, 102, 118, 255], true);
  gui.fill(10, 25, 216, 1, [38, 192, 228, 255]);

  // Central dark showcase well (x=8..228, y=30..152) holding 3x3 product cards
  gui.bevelBox(8, 30, 220, 122, [24, 29, 36, 255], [16, 20, 26, 255], [76, 88, 102, 255], true);

  // 3x3 Grid of 9 Product Cards (each 68 x 36, at x = 13 + col*71, y = 35 + row*38)
  for (let row = 0; row < 3; row++) {
    for (let col = 0; col < 3; col++) {
      const cx = 13 + col * 71;
      const cy = 35 + row * 38;
      gui.bevelBox(cx, cy, 68, 36, [35, 41, 50, 255], [58, 68, 82, 255], [20, 24, 30, 255], false);
      // Recessed 18x18 item icon well on left of card
      gui.bevelBox(cx + 3, cy + 9, 18, 18, [22, 26, 33, 255], [14, 17, 22, 255], [90, 102, 118, 255], true);
      // Subtle emerald price badge backing at bottom-right of card
      gui.fill(cx + 24, cy + 22, 40, 10, [20, 52, 42, 255]);
    }
  }

  // Bottom OLED status + wallet top-up bar well (x=8..228, y=156..188)
  gui.bevelBox(8, 156, 220, 32, [18, 24, 31, 255], [12, 16, 22, 255], [76, 88, 102, 255], true);

  // Hover card sprite [0, 200, 68, 36]
  gui.bevelBox(0, 200, 68, 36, [28, 72, 62, 255], [88, 228, 174, 255], [16, 44, 36, 255], false);
  gui.bevelBox(3, 209, 18, 18, [18, 34, 30, 255], [12, 22, 20, 255], [110, 215, 170, 255], true);
  gui.fill(24, 222, 40, 10, [28, 112, 82, 255]);

  // Disabled card sprite [70, 200, 68, 36]
  gui.bevelBox(70, 200, 68, 36, [32, 35, 40, 255], [46, 50, 56, 255], [20, 22, 26, 255], false);
  gui.bevelBox(73, 209, 18, 18, [22, 24, 28, 255], [16, 18, 22, 255], [60, 66, 74, 255], true);
  gui.fill(94, 222, 40, 10, [44, 34, 36, 255]);

  // Top-up button normal [0, 238, 86, 16] & hover [88, 238, 86, 16]
  gui.bevelBox(0, 238, 86, 16, [28, 84, 64, 255], [64, 168, 126, 255], [16, 46, 34, 255], false);
  gui.bevelBox(88, 238, 86, 16, [38, 118, 88, 255], [112, 232, 178, 255], [22, 64, 48, 255], false);

  gui.save(path.join(TEX_GUI, 'vending_gui.png'));

  // Info Kiosk GUI Sheet (v7.8.0 — Live Telemetry + Geotech SCADA + Quick Actions: 236 x 186)
  const kg = new Canvas(256, 256);
  const KW = 236, KH = 186;
  kg.fill(2, 0, KW - 4, KH, [18, 24, 32, 255]);
  kg.fill(0, 2, KW, KH - 4, [18, 24, 32, 255]);
  kg.fill(2, 2, KW - 4, KH - 4, (x, y) => {
    const n = (hash2(Math.floor(x/2), Math.floor(y/2), 223) - 0.5) * 5;
    return [38 + n, 45 + n, 54 + n, 255];
  });
  for (let x = 2; x < KW - 2; x++) { kg.set(x, 2, 126, 144, 164); kg.set(x, KH - 3, 18, 22, 28); }
  for (let y = 2; y < KH - 2; y++) { kg.set(2, y, 126, 144, 164); kg.set(KW - 3, y, 18, 22, 28); }
  // Top cyan-accented header well
  kg.bevelBox(8, 7, 220, 22, [14, 44, 68, 255], [10, 24, 38, 255], [76, 134, 172, 255], true);
  kg.fill(10, 27, 216, 1, [56, 205, 245, 255]);
  // Main telemetry screen well (x=8..228, y=32..154)
  kg.bevelBox(8, 32, 220, 122, [15, 22, 32, 255], [10, 14, 22, 255], [68, 84, 102, 255], true);
  // Card 1: Live M1 Train Telemetry & ETA (y=37..73)
  kg.bevelBox(14, 37, 208, 36, [22, 34, 50, 255], [44, 68, 96, 255], [12, 18, 28, 255], false);
  // Card 2: Live Tunnel Geotech FoS & Weather SCADA (y=76..112)
  kg.bevelBox(14, 76, 208, 36, [20, 34, 44, 255], [42, 72, 88, 255], [12, 18, 26, 255], false);
  // Card 3: Orman Kart Balance & Fare Info (y=115..149)
  kg.bevelBox(14, 115, 208, 34, [18, 44, 38, 255], [38, 92, 76, 255], [12, 26, 22, 255], false);
  // Action buttons at y=192: [0, 192, 70, 16] normal, [72, 192, 70, 16] hover, [144, 192, 70, 16] accent emerald
  kg.bevelBox(0, 192, 70, 16, [40, 52, 68, 255], [82, 104, 130, 255], [22, 28, 38, 255], false);
  kg.bevelBox(72, 192, 70, 16, [54, 76, 102, 255], [116, 158, 202, 255], [28, 40, 56, 255], false);
  kg.bevelBox(144, 192, 70, 16, [26, 92, 68, 255], [76, 192, 144, 255], [16, 50, 38, 255], false);
  kg.save(path.join(TEX_GUI, 'kiosk_gui.png'));
}

// ==================== 11. CRISP ORMAN KART ITEM ICON (32x32 TRANSPARENT) ====================
{
  const ic = new Canvas(32, 32);
  // Crisp isometric-tilted transit card on transparent background
  for (let y = 6; y <= 25; y++) {
    for (let x = 3; x <= 28; x++) {
      const border = (x === 3 || x === 28 || y === 6 || y === 25);
      const innerHi = (x === 4 || y === 7);
      if ((x === 3 || x === 28) && (y === 6 || y === 25)) continue; // rounded pixel corners!
      if (border) ic.set(x, y, 14, 52, 36, 255);
      else if (innerHi) ic.set(x, y, 92, 228, 164, 255);
      else {
        const d = (x + y) / 48.0;
        ic.set(x, y, ...ditherLerp([42, 168, 112, 255], [22, 114, 78, 255], d, x, y));
      }
    }
  }
  // Gold chip
  ic.bevelBox(6, 13, 6, 5, [238, 196, 72, 255], [255, 236, 140, 255], [156, 118, 32, 255], false);
  // Pine tree emblem on right
  for (let dy = 0; dy < 8; dy++) {
    const w = Math.max(0, Math.floor((8 - dy) / 2.3));
    for (let dx = -w; dx <= w; dx++) ic.set(22 + dx, 21 - dy, 205, 255, 225, 255);
  }
  ic.save(path.join(TEX_ITEM, 'orman_kart.png'));
}

// ==================== 12. UV-SYNCED MULTI-ELEMENT 3D BLOCKBENCH MODELS ====================
const writeJson = (p, obj) => fs.writeFileSync(p, JSON.stringify(obj, null, 2));

// A) 2-BLOCK VENDING MACHINE (lower + upper)
writeJson(path.join(MOD_BLOCK, 'vending_machine_lower.json'), {
  parent: 'block/block',
  textures: {
    particle: 'arena_ai_bridge:block/anodized_gunmetal',
    body: 'arena_ai_bridge:block/anodized_gunmetal',
    front: 'arena_ai_bridge:block/vending_lower_front',
    interior: 'arena_ai_bridge:block/vending_interior'
  },
  elements: [
    // Recessed heavy lower base & louver kickplate
    {
      from: [1.0, 0.0, 3.5], to: [15.0, 3.0, 15.0],
      faces: {
        down:  { uv: [1, 3.5, 15, 15], texture: '#body' },
        north: { uv: [1, 13, 15, 16], texture: '#front' },
        south: { uv: [1, 13, 15, 16], texture: '#body' },
        west:  { uv: [3.5, 13, 15, 16], texture: '#body' },
        east:  { uv: [3.5, 13, 15, 16], texture: '#body' }
      }
    },
    // Rear & bottom main cabinet below pickup bin
    {
      from: [0.5, 3.0, 6.5], to: [15.5, 16.0, 15.5],
      faces: {
        north: { uv: [0.5, 8, 15.5, 15], texture: '#interior' },
        south: { uv: [0.5, 0, 15.5, 13], texture: '#body' },
        west:  { uv: [6.5, 0, 15.5, 13], texture: '#body' },
        east:  { uv: [0.5, 0, 9.5, 13], texture: '#body' },
        down:  { uv: [0.5, 6.5, 15.5, 15.5], texture: '#body' }
      }
    },
    // Front lower apron below delivery niche (y=3..5)
    {
      from: [0.5, 3.0, 2.5], to: [15.5, 5.0, 6.5],
      faces: {
        north: { uv: [0.5, 11, 15.5, 13], texture: '#front' },
        up:    { uv: [0.5, 9, 15.5, 13], texture: '#interior' },
        west:  { uv: [2.5, 11, 6.5, 13], texture: '#body' },
        east:  { uv: [9.5, 11, 13.5, 13], texture: '#body' },
        down:  { uv: [0.5, 2.5, 15.5, 6.5], texture: '#body' }
      }
    },
    // Right service & coin-return column on screen-RIGHT when facing north (x=0.5..5.0, y=5..16)
    {
      from: [0.5, 5.0, 2.5], to: [5.0, 16.0, 6.5],
      faces: {
        north: { uv: [11.0, 0, 15.5, 11], texture: '#front' },
        west:  { uv: [2.5, 0, 6.5, 11], texture: '#body' },
        east:  { uv: [9.5, 0, 13.5, 11], texture: '#body' }
      }
    },
    // Left cheek framing delivery cavity on screen-LEFT (x=14.0..15.5, y=5..16)
    {
      from: [14.0, 5.0, 2.5], to: [15.5, 16.0, 6.5],
      faces: {
        north: { uv: [0.5, 0, 2.0, 11], texture: '#front' },
        east:  { uv: [2.5, 0, 6.5, 11], texture: '#body' },
        west:  { uv: [2.5, 0, 6.5, 11], texture: '#body' }
      }
    },
    // Upper stainless cross-rail above delivery niche (x=5.0..14.0, y=11.0..16.0)
    {
      from: [5.0, 11.0, 2.5], to: [14.0, 16.0, 6.5],
      faces: {
        north: { uv: [2.0, 0, 11.0, 5], texture: '#front' },
        down:  { uv: [2.0, 2.5, 11.0, 6.5], texture: '#body' },
        up:    { uv: [2.0, 9, 11.0, 13], texture: '#interior' }
      }
    },
    // Angled Stainless Push-Flap Door inside recessed delivery niche (aligned directly under showcase!)
    {
      from: [5.1, 5.2, 3.2], to: [13.9, 11.0, 4.0],
      rotation: { origin: [9.5, 11.0, 3.6], axis: 'x', angle: 22.5 },
      faces: {
        north: { uv: [2.0, 5.0, 11.0, 11.0], texture: '#front' },
        south: { uv: [2.0, 8.0, 11.0, 14.0], texture: '#interior' },
        down:  { uv: [2.0, 10.5, 11.0, 11.0], texture: '#front' }
      }
    }
  ]
});

writeJson(path.join(MOD_BLOCK, 'vending_machine_upper.json'), {
  parent: 'block/block',
  textures: {
    particle: 'arena_ai_bridge:block/anodized_gunmetal',
    body: 'arena_ai_bridge:block/anodized_gunmetal',
    front: 'arena_ai_bridge:block/vending_upper_front',
    interior: 'arena_ai_bridge:block/vending_interior'
  },
  elements: [
    // Insulated rear showcase backwall & side body (z=9.5..15.5)
    {
      from: [0.5, 0.0, 9.5], to: [15.5, 13.5, 15.5],
      faces: {
        north: { uv: [0.5, 0, 15.5, 8], texture: '#interior' },
        south: { uv: [0.5, 2.5, 15.5, 16], texture: '#body' },
        west:  { uv: [9.5, 2.5, 15.5, 16], texture: '#body' },
        east:  { uv: [0.5, 2.5, 6.5, 16], texture: '#body' }
      }
    },
    // Screen-LEFT insulated side wall of showcase (x=14.4..15.5, z=2.5..9.5)
    {
      from: [14.4, 0.0, 2.5], to: [15.5, 13.5, 9.5],
      faces: {
        north: { uv: [0.5, 2.5, 1.6, 16], texture: '#front' },
        west:  { uv: [2.5, 0, 9.5, 8], texture: '#interior' },
        east:  { uv: [2.5, 2.5, 9.5, 16], texture: '#body' }
      }
    },
    // Screen-RIGHT interactive payment column (x=0.5..5.2, z=2.2..9.5)
    {
      from: [0.5, 0.0, 2.2], to: [5.2, 13.5, 9.5],
      faces: {
        north: { uv: [10.8, 2.5, 15.5, 16], texture: '#front' },
        west:  { uv: [6.5, 2.5, 13.8, 16], texture: '#body' },
        east:  { uv: [2.5, 0, 9.5, 8], texture: '#interior' }
      }
    },
    // Protruding 3D Contactless Emerald Card Reader Bezel on screen-RIGHT (x=1.4..4.4, y=1.8..5.0, z=1.7..2.2)
    {
      from: [1.4, 1.8, 1.7], to: [4.4, 5.0, 2.2],
      faces: {
        north: { uv: [11.75, 11.0, 14.5, 14.0], texture: '#front' },
        up:    { uv: [11.75, 11.0, 14.5, 11.5], texture: '#front' },
        down:  { uv: [11.75, 13.5, 14.5, 14.0], texture: '#front' },
        west:  { uv: [11.75, 11.0, 12.25, 14.0], texture: '#front' },
        east:  { uv: [14.0, 11.0, 14.5, 14.0], texture: '#front' }
      }
    },
    // 3 Physical Stainless-Steel Showcase Shelves inside window (x=5.2..14.4, y=0.5, 4.5, 8.5)
    {
      from: [5.2, 0.4, 3.6], to: [14.4, 1.0, 9.5],
      faces: {
        up:    { uv: [1, 9, 10, 15], texture: '#interior' },
        down:  { uv: [1, 9, 10, 15], texture: '#interior' },
        north: { uv: [1, 15, 10, 16], texture: '#interior' }
      }
    },
    {
      from: [5.2, 4.4, 3.6], to: [14.4, 5.0, 9.5],
      faces: {
        up:    { uv: [1, 9, 10, 15], texture: '#interior' },
        down:  { uv: [1, 9, 10, 15], texture: '#interior' },
        north: { uv: [1, 15, 10, 16], texture: '#interior' }
      }
    },
    {
      from: [5.2, 8.4, 3.6], to: [14.4, 9.0, 9.5],
      faces: {
        up:    { uv: [1, 9, 10, 15], texture: '#interior' },
        down:  { uv: [1, 9, 10, 15], texture: '#interior' },
        north: { uv: [1, 15, 10, 16], texture: '#interior' }
      }
    },
    // Recessed Tempered Showcase Glass Pane (x=5.2..14.4, y=0.0..13.5, z=2.7..3.1)
    {
      from: [5.2, 0.0, 2.7], to: [14.4, 13.5, 3.1],
      faces: {
        north: { uv: [1.5, 2.8, 10.75, 15.8], texture: '#front' },
        south: { uv: [10.75, 2.8, 1.5, 15.8], texture: '#front' }
      }
    },
    // Overhanging Illuminated Marquee Canopy (y=13.5..15.8, z=1.6..15.5)
    {
      from: [0.3, 13.5, 1.6], to: [15.7, 15.8, 15.5],
      faces: {
        north: { uv: [0.5, 0.3, 15.5, 2.6], texture: '#front' },
        south: { uv: [0.5, 0, 15.5, 2.5], texture: '#body' },
        west:  { uv: [1.6, 0, 15.5, 2.5], texture: '#body' },
        east:  { uv: [0.5, 0, 14.4, 2.5], texture: '#body' },
        up:    { uv: [0.5, 1.6, 15.5, 15.5], texture: '#body' },
        down:  { uv: [0.5, 1.6, 15.5, 4.0], texture: '#body' }
      }
    }
  ]
});

// Item model uses complete 2-block composite scaled cleanly for inventory/hand!
writeJson(path.join(MOD_ITEM, 'vending_machine.json'), {
  parent: 'arena_ai_bridge:block/vending_machine_upper',
  display: {
    gui: { rotation: [25, 215, 0], translation: [0, -1.5, 0], scale: [0.55, 0.55, 0.55] },
    ground: { translation: [0, 2, 0], scale: [0.35, 0.35, 0.35] },
    thirdperson_righthand: { rotation: [75, 45, 0], translation: [0, 2.5, 0], scale: [0.35, 0.35, 0.35] },
    firstperson_righthand: { rotation: [0, 135, 0], scale: [0.4, 0.4, 0.4] }
  }
});

writeJson(path.join(BS_DIR, 'vending_machine.json'), {
  variants: {
    'facing=north,half=lower': { model: 'arena_ai_bridge:block/vending_machine_lower' },
    'facing=east,half=lower':  { model: 'arena_ai_bridge:block/vending_machine_lower', y: 90 },
    'facing=south,half=lower': { model: 'arena_ai_bridge:block/vending_machine_lower', y: 180 },
    'facing=west,half=lower':  { model: 'arena_ai_bridge:block/vending_machine_lower', y: 270 },
    'facing=north,half=upper': { model: 'arena_ai_bridge:block/vending_machine_upper' },
    'facing=east,half=upper':  { model: 'arena_ai_bridge:block/vending_machine_upper', y: 90 },
    'facing=south,half=upper': { model: 'arena_ai_bridge:block/vending_machine_upper', y: 180 },
    'facing=west,half=upper':  { model: 'arena_ai_bridge:block/vending_machine_upper', y: 270 }
  }
});

// B) 2-BLOCK INFO KIOSK (lower + upper with -22.5° tilted touchscreen console!)
writeJson(path.join(MOD_BLOCK, 'info_kiosk_lower.json'), {
  parent: 'block/block',
  textures: {
    particle: 'arena_ai_bridge:block/kiosk_pedestal',
    ped: 'arena_ai_bridge:block/kiosk_pedestal',
    dark: 'arena_ai_bridge:block/anodized_gunmetal'
  },
  elements: [
    // Anchor baseplate
    {
      from: [2.5, 0.0, 4.0], to: [13.5, 1.5, 13.0],
      faces: {
        up:    { uv: [2.5, 4, 13.5, 13], texture: '#dark' },
        down:  { uv: [2.5, 4, 13.5, 13], texture: '#dark' },
        north: { uv: [2.5, 14.5, 13.5, 16], texture: '#dark' },
        south: { uv: [2.5, 14.5, 13.5, 16], texture: '#dark' },
        west:  { uv: [4, 14.5, 13, 16], texture: '#dark' },
        east:  { uv: [4, 14.5, 13, 16], texture: '#dark' }
      }
    },
    // Central totem column with glowing vertical cyan LED groove (uv x=6..10 centers on x=7.5..8.5!)
    {
      from: [4.2, 1.5, 6.0], to: [11.8, 16.0, 11.0],
      faces: {
        north: { uv: [4.2, 0, 11.8, 14.5], texture: '#ped' },
        south: { uv: [4.2, 0, 11.8, 14.5], texture: '#ped' },
        west:  { uv: [0, 0, 5, 14.5], texture: '#dark' },
        east:  { uv: [0, 0, 5, 14.5], texture: '#dark' }
      }
    },
    // Side dark gunmetal architectural fins
    {
      from: [3.4, 1.5, 6.8], to: [4.2, 16.0, 10.2],
      faces: {
        north: { uv: [1, 0, 2, 14.5], texture: '#dark' },
        south: { uv: [1, 0, 2, 14.5], texture: '#dark' },
        west:  { uv: [6, 0, 9.5, 14.5], texture: '#dark' }
      }
    },
    {
      from: [11.8, 1.5, 6.8], to: [12.6, 16.0, 10.2],
      faces: {
        north: { uv: [14, 0, 15, 14.5], texture: '#dark' },
        south: { uv: [14, 0, 15, 14.5], texture: '#dark' },
        east:  { uv: [6, 0, 9.5, 14.5], texture: '#dark' }
      }
    }
  ]
});

writeJson(path.join(MOD_BLOCK, 'info_kiosk_upper.json'), {
  parent: 'block/block',
  textures: {
    particle: 'arena_ai_bridge:block/kiosk_pedestal',
    ped: 'arena_ai_bridge:block/kiosk_pedestal',
    dark: 'arena_ai_bridge:block/anodized_gunmetal',
    screen: 'arena_ai_bridge:block/kiosk_upper_front'
  },
  elements: [
    // Upper totem spine
    {
      from: [4.2, 0.0, 6.2], to: [11.8, 12.2, 11.0],
      faces: {
        north: { uv: [4.2, 2, 11.8, 14], texture: '#ped' },
        south: { uv: [4.2, 2, 11.8, 14], texture: '#ped' },
        west:  { uv: [1, 2, 6, 14], texture: '#dark' },
        east:  { uv: [1, 2, 6, 14], texture: '#dark' }
      }
    },
    // Top backlit 'YOLCU BILGI' crown header
    {
      from: [3.2, 12.2, 5.2], to: [12.8, 15.0, 11.2],
      faces: {
        north: { uv: [2, 0.5, 14, 3.0], texture: '#screen' },
        south: { uv: [2, 0.5, 14, 3.0], texture: '#screen' },
        west:  { uv: [2, 0, 8, 3], texture: '#dark' },
        east:  { uv: [2, 0, 8, 3], texture: '#dark' },
        up:    { uv: [3, 5, 13, 11], texture: '#dark' },
        down:  { uv: [3, 5, 13, 11], texture: '#dark' }
      }
    },
    // Ergonomic -22.5° Angled Touchscreen Display Head!
    {
      from: [2.0, 1.5, 3.4], to: [14.0, 11.5, 6.6],
      rotation: { origin: [8.0, 6.5, 5.8], axis: 'x', angle: -22.5 },
      faces: {
        north: { uv: [2, 4, 14, 14], texture: '#screen' },
        south: { uv: [2, 2, 14, 12], texture: '#dark' },
        west:  { uv: [1, 2, 4, 12], texture: '#dark' },
        east:  { uv: [12, 2, 15, 12], texture: '#dark' },
        up:    { uv: [2, 1, 14, 4], texture: '#dark' },
        down:  { uv: [2, 12, 14, 15], texture: '#dark' }
      }
    }
  ]
});

writeJson(path.join(MOD_ITEM, 'info_kiosk.json'), {
  parent: 'arena_ai_bridge:block/info_kiosk_upper',
  display: {
    gui: { rotation: [25, 215, 0], translation: [0, -1.5, 0], scale: [0.62, 0.62, 0.62] },
    ground: { translation: [0, 2, 0], scale: [0.38, 0.38, 0.38] },
    thirdperson_righthand: { rotation: [75, 45, 0], translation: [0, 2.5, 0], scale: [0.38, 0.38, 0.38] },
    firstperson_righthand: { rotation: [0, 135, 0], scale: [0.42, 0.42, 0.42] }
  }
});

writeJson(path.join(BS_DIR, 'info_kiosk.json'), {
  variants: {
    'facing=north,half=lower': { model: 'arena_ai_bridge:block/info_kiosk_lower' },
    'facing=east,half=lower':  { model: 'arena_ai_bridge:block/info_kiosk_lower', y: 90 },
    'facing=south,half=lower': { model: 'arena_ai_bridge:block/info_kiosk_lower', y: 180 },
    'facing=west,half=lower':  { model: 'arena_ai_bridge:block/info_kiosk_lower', y: 270 },
    'facing=north,half=upper': { model: 'arena_ai_bridge:block/info_kiosk_upper' },
    'facing=east,half=upper':  { model: 'arena_ai_bridge:block/info_kiosk_upper', y: 90 },
    'facing=south,half=upper': { model: 'arena_ai_bridge:block/info_kiosk_upper', y: 180 },
    'facing=west,half=upper':  { model: 'arena_ai_bridge:block/info_kiosk_upper', y: 270 }
  }
});

// C) CONNECTED ERGONOMIC 3D STATION BENCH (part = single | left | middle | right, -22.5° backrest!)
function makeBenchModel(part) {
  const hasLeftEnd  = (part === 'single' || part === 'left');   // west end (x=0..2) when facing=north
  const hasRightEnd = (part === 'single' || part === 'right');  // east end (x=14..16) when facing=north
  const xMin = hasLeftEnd ? 1.0 : 0.0;
  const xMax = hasRightEnd ? 15.0 : 16.0;
  const els = [];

  // 4 Separate Beveled Walnut Seat Slats with real air gaps!
  for (const [z0, z1, vOff] of [[3.0, 5.2, 0], [5.8, 8.0, 2], [8.6, 10.8, 4], [11.4, 13.4, 6]]) {
    els.push({
      from: [xMin, 6.8, z0], to: [xMax, 8.0, z1],
      faces: {
        up:    { uv: [xMin, vOff, xMax, vOff + 2], texture: '#wood' },
        down:  { uv: [xMin, vOff, xMax, vOff + 2], texture: '#wood' },
        north: { uv: [xMin, vOff, xMax, vOff + 2], texture: '#wood' },
        south: { uv: [xMin, vOff, xMax, vOff + 2], texture: '#wood' },
        west:  { uv: [0, vOff, 2, vOff + 2], texture: '#wood' },
        east:  { uv: [0, vOff, 2, vOff + 2], texture: '#wood' }
      }
    });
  }

  // 3 Angled -22.5° Ergonomic Backrest Slats!
  for (const [y0, y1, vOff] of [[8.8, 11.0, 8], [11.6, 13.8, 10], [14.4, 16.4, 12]]) {
    els.push({
      from: [xMin, y0, 12.6], to: [xMax, y1, 13.8],
      rotation: { origin: [8.0, 8.0, 13.2], axis: 'x', angle: -22.5 },
      faces: {
        north: { uv: [xMin, vOff, xMax, vOff + 2], texture: '#wood' },
        south: { uv: [xMin, vOff, xMax, vOff + 2], texture: '#wood' },
        up:    { uv: [xMin, vOff, xMax, vOff + 1], texture: '#wood' },
        down:  { uv: [xMin, vOff, xMax, vOff + 1], texture: '#wood' },
        west:  { uv: [0, vOff, 1.5, vOff + 2], texture: '#wood' },
        east:  { uv: [0, vOff, 1.5, vOff + 2], texture: '#wood' }
      }
    });
  }

  // Continuous under-seat steel tie-beam (connects seamlessly across multi-block benches!)
  els.push({
    from: [xMin, 5.4, 5.5], to: [xMax, 6.8, 12.5],
    faces: {
      north: { uv: [xMin, 4, xMax, 5.5], texture: '#iron' },
      south: { uv: [xMin, 4, xMax, 5.5], texture: '#iron' },
      down:  { uv: [xMin, 5.5, xMax, 12.5], texture: '#iron' }
    }
  });

  const addCastFrame = (lx0, lx1, withArmrest) => {
    // Front leg, rear leg, floor runner, backrest spine, and optional outer armrest
    els.push(
      { from: [lx0, 0.0, 3.8], to: [lx1, 6.8, 5.4], faces: { north:{uv:[1,8,2.5,15],texture:'#iron'}, south:{uv:[1,8,2.5,15],texture:'#iron'}, west:{uv:[3,8,5,15],texture:'#iron'}, east:{uv:[3,8,5,15],texture:'#iron'}, down:{uv:[1,1,2.5,2.5],texture:'#iron'} } },
      { from: [lx0, 0.0, 11.4], to: [lx1, 6.8, 13.0], faces: { north:{uv:[1,8,2.5,15],texture:'#iron'}, south:{uv:[1,8,2.5,15],texture:'#iron'}, west:{uv:[11,8,13,15],texture:'#iron'}, east:{uv:[11,8,13,15],texture:'#iron'}, down:{uv:[1,1,2.5,2.5],texture:'#iron'} } },
      { from: [lx0, 0.0, 3.4], to: [lx1, 1.0, 13.6], faces: { up:{uv:[1,3,2.5,13],texture:'#iron'}, down:{uv:[1,3,2.5,13],texture:'#iron'}, west:{uv:[3,15,13,16],texture:'#iron'}, east:{uv:[3,15,13,16],texture:'#iron'}, north:{uv:[1,15,2.5,16],texture:'#iron'}, south:{uv:[1,15,2.5,16],texture:'#iron'} } },
      // Angled rear backrest support spine
      {
        from: [lx0, 7.6, 12.9], to: [lx1, 16.0, 14.2],
        rotation: { origin: [8.0, 8.0, 13.2], axis: 'x', angle: -22.5 },
        faces: { north:{uv:[2,0,3.5,8],texture:'#iron'}, south:{uv:[2,0,3.5,8],texture:'#iron'}, west:{uv:[2,0,3.5,8],texture:'#iron'}, east:{uv:[2,0,3.5,8],texture:'#iron'}, up:{uv:[2,0,3.5,1.5],texture:'#iron'} }
      }
    );
    if (withArmrest) {
      els.push(
        { from: [lx0, 8.0, 4.2], to: [lx1, 10.2, 5.4], faces: { north:{uv:[4,4,5.5,6.5],texture:'#iron'}, south:{uv:[4,4,5.5,6.5],texture:'#iron'}, west:{uv:[4,4,5.5,6.5],texture:'#iron'}, east:{uv:[4,4,5.5,6.5],texture:'#iron'} } },
        { from: [lx0 - 0.2, 10.2, 3.6], to: [lx1 + 0.2, 11.1, 13.4], faces: { up:{uv:[0,0,2,10],texture:'#wood'}, down:{uv:[0,0,2,10],texture:'#wood'}, west:{uv:[0,0,10,1],texture:'#wood'}, east:{uv:[0,0,10,1],texture:'#wood'}, north:{uv:[0,0,2,1],texture:'#wood'}, south:{uv:[0,0,2,1],texture:'#wood'} } }
      );
    }
  };

  if (hasLeftEnd)  addCastFrame(1.2, 2.5, true);
  if (hasRightEnd) addCastFrame(13.5, 14.8, true);
  if (!hasLeftEnd && !hasRightEnd) {
    // Slim central structural support rib for middle span
    addCastFrame(7.3, 8.7, false);
  }
  // Continuous longitudinal cast-iron tie-beams under seat & behind backrest so spans never look floating!
  const beamX0 = hasLeftEnd ? 1.5 : 0.0;
  const beamX1 = hasRightEnd ? 14.5 : 16.0;
  els.push(
    { from: [beamX0, 5.2, 5.8], to: [beamX1, 6.1, 7.0], faces: { north:{uv:[0,0,16,1.2],texture:'#iron'}, south:{uv:[0,0,16,1.2],texture:'#iron'}, up:{uv:[0,0,16,1.2],texture:'#iron'}, down:{uv:[0,0,16,1.2],texture:'#iron'} } },
    { from: [beamX0, 10.6, 13.0], to: [beamX1, 11.6, 13.9], faces: { north:{uv:[0,0,16,1.2],texture:'#iron'}, south:{uv:[0,0,16,1.2],texture:'#iron'}, up:{uv:[0,0,16,1.0],texture:'#iron'}, down:{uv:[0,0,16,1.0],texture:'#iron'} } }
  );

  return {
    parent: 'block/block',
    textures: {
      particle: 'arena_ai_bridge:block/bench_walnut',
      wood: 'arena_ai_bridge:block/bench_walnut',
      iron: 'arena_ai_bridge:block/bench_cast_iron'
    },
    elements: els
  };
}

for (const part of ['single', 'left', 'middle', 'right']) {
  writeJson(path.join(MOD_BLOCK, `metro_bench_${part}.json`), makeBenchModel(part));
}
writeJson(path.join(MOD_BLOCK, 'metro_bench.json'), makeBenchModel('single'));
writeJson(path.join(MOD_ITEM, 'metro_bench.json'), {
  parent: 'arena_ai_bridge:block/metro_bench_single',
  display: {
    gui: { rotation: [30, 225, 0], scale: [0.62, 0.62, 0.62] },
    ground: { translation: [0, 2, 0], scale: [0.38, 0.38, 0.38] },
    thirdperson_righthand: { rotation: [75, 45, 0], translation: [0, 2.5, 0], scale: [0.38, 0.38, 0.38] },
    firstperson_righthand: { rotation: [0, 135, 0], scale: [0.42, 0.42, 0.42] }
  }
});

const benchVariants = {};
for (const [f, yRot] of [['north',0],['east',90],['south',180],['west',270]]) {
  for (const part of ['single', 'left', 'middle', 'right']) {
    benchVariants[`facing=${f},part=${part}`] = yRot === 0
      ? { model: `arena_ai_bridge:block/metro_bench_${part}` }
      : { model: `arena_ai_bridge:block/metro_bench_${part}`, y: yRot };
  }
}
writeJson(path.join(BS_DIR, 'metro_bench.json'), { variants: benchVariants });

// D) RECESSED SAFETY CABINET WITH 3D FIRE EXTINGUISHER INSIDE!
writeJson(path.join(MOD_BLOCK, 'safety_cabinet.json'), {
  parent: 'block/block',
  textures: {
    particle: 'arena_ai_bridge:block/safety_cabinet_atlas',
    atlas: 'arena_ai_bridge:block/safety_cabinet_atlas'
  },
  elements: [
    // Cabinet backplate (z=15.0..16.0)
    {
      from: [2.0, 1.0, 15.0], to: [14.0, 15.0, 16.0],
      faces: {
        north: { uv: [8.5, 8.5, 15.5, 15.5], texture: '#atlas' },
        south: { uv: [0.5, 0.5, 7.5, 7.5], texture: '#atlas' }
      }
    },
    // 4 Recessed crimson steel perimeter walls (z=11.5..16.0)
    { from: [2.0, 13.8, 11.5], to: [14.0, 15.0, 15.0], faces: { north:{uv:[0.5,0.5,7.5,1.5],texture:'#atlas'}, up:{uv:[0.5,0.5,7.5,3],texture:'#atlas'}, down:{uv:[0.5,5,7.5,7.5],texture:'#atlas'}, west:{uv:[0.5,0.5,3,1.5],texture:'#atlas'}, east:{uv:[0.5,0.5,3,1.5],texture:'#atlas'} } },
    { from: [2.0, 1.0, 11.5],  to: [14.0, 2.2, 15.0],  faces: { north:{uv:[0.5,6.5,7.5,7.5],texture:'#atlas'}, up:{uv:[8.5,13,15.5,15.5],texture:'#atlas'}, down:{uv:[0.5,0.5,7.5,3],texture:'#atlas'}, west:{uv:[0.5,6.5,3,7.5],texture:'#atlas'}, east:{uv:[0.5,6.5,3,7.5],texture:'#atlas'} } },
    { from: [2.0, 2.2, 11.5],  to: [3.2, 13.8, 15.0],  faces: { north:{uv:[0.5,1,1.5,7],texture:'#atlas'}, west:{uv:[0.5,1,3,7],texture:'#atlas'}, east:{uv:[8.5,9,11,15],texture:'#atlas'} } },
    { from: [12.8, 2.2, 11.5], to: [14.0, 13.8, 15.0], faces: { north:{uv:[6.5,1,7.5,7],texture:'#atlas'}, east:{uv:[0.5,1,3,7],texture:'#atlas'}, west:{uv:[13,9,15.5,15],texture:'#atlas'} } },
    // 3D Fire Extinguisher Red Cylinder inside cabinet (x=5.6..9.0, y=2.2..10.4, z=12.6..14.8)
    {
      from: [5.6, 2.2, 12.6], to: [9.0, 10.4, 14.8],
      faces: {
        north: { uv: [0, 8, 4, 16], texture: '#atlas' },
        west:  { uv: [0, 8, 2, 16], texture: '#atlas' },
        east:  { uv: [2, 8, 4, 16], texture: '#atlas' },
        up:    { uv: [1, 8, 3, 9], texture: '#atlas' }
      }
    },
    // Brass valve head & pressure gauge (y=10.4..12.2)
    {
      from: [6.4, 10.4, 13.0], to: [8.6, 12.2, 14.4],
      faces: {
        north: { uv: [4, 8.5, 6, 11.5], texture: '#atlas' },
        west:  { uv: [4, 8.5, 5.5, 11.5], texture: '#atlas' },
        east:  { uv: [4, 8.5, 5.5, 11.5], texture: '#atlas' },
        up:    { uv: [4, 8.5, 5.5, 10], texture: '#atlas' }
      }
    },
    // Vertical black braided hose (x=9.1..10.1, y=3.2..11.4)
    {
      from: [9.1, 3.2, 13.3], to: [10.1, 11.4, 14.3],
      faces: {
        north: { uv: [6, 8, 8, 16], texture: '#atlas' },
        west:  { uv: [6, 8, 7.5, 16], texture: '#atlas' },
        east:  { uv: [6, 8, 7.5, 16], texture: '#atlas' }
      }
    },
    // Tempered Framed Emergency Glass Door in front (z=11.2..11.5)
    {
      from: [2.2, 1.2, 11.2], to: [13.8, 14.8, 11.5],
      faces: {
        north: { uv: [8, 0, 16, 8], texture: '#atlas' },
        south: { uv: [16, 0, 8, 8], texture: '#atlas' }
      }
    }
  ]
});
writeJson(path.join(MOD_ITEM, 'safety_cabinet.json'), {
  parent: 'arena_ai_bridge:block/safety_cabinet',
  display: { gui: { rotation: [25, 210, 0], translation: [1.5, 0, 0], scale: [0.72, 0.72, 0.72] } }
});

// E) BEVELED BACKLIT AD LIGHTBOX (4 Genuine Pixel-Art Posters!)
const posterNames = ['poster_forest', 'poster_card', 'poster_cafe', 'poster_safety'];
posterNames.forEach((texName, idx) => {
  const mName = idx === 0 ? 'ad_lightbox.json' : `ad_lightbox_${idx}.json`;
  writeJson(path.join(MOD_BLOCK, mName), {
    parent: 'block/block',
    textures: {
      particle: 'arena_ai_bridge:block/lightbox_frame',
      frame: 'arena_ai_bridge:block/lightbox_frame',
      poster: `arena_ai_bridge:block/${texName}`
    },
    elements: [
      // Recessed backlit poster canvas (z=14.8..15.8)
      {
        from: [1.0, 1.5, 14.8], to: [15.0, 14.5, 15.9],
        faces: {
          north: { uv: [0, 0, 16, 16], texture: '#poster' },
          south: { uv: [1, 1.5, 15, 14.5], texture: '#frame' }
        }
      },
      // 4-piece beveled anodized aluminum frame protruding to z=14.2!
      { from: [0.4, 14.2, 14.2], to: [15.6, 15.2, 16.0], faces: { north:{uv:[0.4,0,15.6,1],texture:'#frame'}, up:{uv:[0.4,14,15.6,16],texture:'#frame'}, down:{uv:[0.4,14,15.6,16],texture:'#frame'}, west:{uv:[14,0,16,1],texture:'#frame'}, east:{uv:[14,0,16,1],texture:'#frame'} } },
      { from: [0.4, 0.8, 14.2],  to: [15.6, 1.8, 16.0],  faces: { north:{uv:[0.4,15,15.6,16],texture:'#frame'}, up:{uv:[0.4,14,15.6,16],texture:'#frame'}, down:{uv:[0.4,14,15.6,16],texture:'#frame'}, west:{uv:[14,15,16,16],texture:'#frame'}, east:{uv:[14,15,16,16],texture:'#frame'} } },
      { from: [0.4, 1.8, 14.2],  to: [1.4, 14.2, 16.0],  faces: { north:{uv:[0,1.8,1,14.2],texture:'#frame'}, west:{uv:[14,1.8,16,14.2],texture:'#frame'}, east:{uv:[14,1.8,16,14.2],texture:'#frame'} } },
      { from: [14.6, 1.8, 14.2], to: [15.6, 14.2, 16.0], faces: { north:{uv:[15,1.8,16,14.2],texture:'#frame'}, west:{uv:[14,1.8,16,14.2],texture:'#frame'}, east:{uv:[14,1.8,16,14.2],texture:'#frame'} } }
    ]
  });
});

// F) SEAMLESS LINEAR TUNNEL LED RAIL (0..16 connected end-to-end)
const ceilingLedModel = {
  parent: 'block/block',
  textures: {
    particle: 'arena_ai_bridge:block/tunnel_led_atlas',
    atlas: 'arena_ai_bridge:block/tunnel_led_atlas'
  },
  elements: [
    // Extruded ribbed aluminum ceiling mounting channel (z=0..16 seamless!)
    {
      from: [5.4, 14.8, 0.0], to: [10.6, 16.0, 16.0],
      faces: {
        up:    { uv: [0.5, 0, 7.5, 16], texture: '#atlas' },
        down:  { uv: [0.5, 0, 7.5, 16], texture: '#atlas' },
        west:  { uv: [0, 0, 1.5, 16], rotation: 90, texture: '#atlas' },
        east:  { uv: [6.5, 0, 8.0, 16], rotation: 90, texture: '#atlas' }
      }
    },
    // Frosted polycarbonate continuous LED diffuser lens (z=0..16 seamless!)
    {
      from: [6.2, 14.3, 0.0], to: [9.8, 14.8, 16.0],
      faces: {
        down:  { uv: [8.5, 0, 15.5, 16], texture: '#atlas' },
        west:  { uv: [9, 0, 10, 16], rotation: 90, texture: '#atlas' },
        east:  { uv: [14, 0, 15, 16], rotation: 90, texture: '#atlas' }
      }
    }
  ]
};
const wallLedModel = {
  parent: 'block/block',
  textures: {
    particle: 'arena_ai_bridge:block/tunnel_led_atlas',
    atlas: 'arena_ai_bridge:block/tunnel_led_atlas'
  },
  elements: [
    {
      from: [0.0, 6.2, 14.8], to: [16.0, 9.8, 16.0],
      faces: {
        north: { uv: [0.5, 0, 7.5, 16], rotation: 90, texture: '#atlas' },
        south: { uv: [0.5, 0, 7.5, 16], rotation: 90, texture: '#atlas' },
        up:    { uv: [0, 0, 1.5, 16], rotation: 90, texture: '#atlas' },
        down:  { uv: [6.5, 0, 8.0, 16], rotation: 90, texture: '#atlas' }
      }
    },
    {
      from: [0.0, 6.8, 14.3], to: [16.0, 9.2, 14.8],
      faces: {
        north: { uv: [8.5, 0, 15.5, 16], rotation: 90, texture: '#atlas' },
        up:    { uv: [9, 0, 10, 16], rotation: 90, texture: '#atlas' },
        down:  { uv: [14, 0, 15, 16], rotation: 90, texture: '#atlas' }
      }
    }
  ]
};
for (const f of ['tunnel_emergency_light_ceiling.json','tunnel_emergency_light_ceiling_red.json','tunnel_light_ceiling_normal.json','tunnel_light_ceiling_emergency.json']) {
  writeJson(path.join(MOD_BLOCK, f), ceilingLedModel);
}
for (const f of ['tunnel_emergency_light_wall.json','tunnel_emergency_light_wall_red.json','tunnel_light_normal.json','tunnel_light_emergency.json']) {
  writeJson(path.join(MOD_BLOCK, f), wallLedModel);
}

console.log('Generated all UV-synced 64x64 pixel-art textures, 256x256 native GUI sheets, and multi-block 3D models!');

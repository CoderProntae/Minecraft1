#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const ASSET_ROOT = '/home/user/arena-mc/mod-src/assets/arena_ai_bridge';

function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c ^= buf[i];
    for (let k = 0; k < 8; k++) c = (c >>> 1) ^ (0xedb88320 & -(c & 1));
  }
  return (c ^ 0xffffffff) >>> 0;
}
function pngChunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const t = Buffer.from(type, 'ascii');
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(Buffer.concat([t, data])), 0);
  return Buffer.concat([len, t, data, crc]);
}
function writeRgbaPng(filePath, w, h, rgba) {
  const raw = Buffer.alloc(h * (1 + w * 4));
  for (let y = 0; y < h; y++) {
    raw[y * (1 + w * 4)] = 0;
    rgba.copy(raw, y * (1 + w * 4) + 1, y * w * 4, (y + 1) * w * 4);
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0);
  ihdr.writeUInt32BE(h, 4);
  ihdr[8] = 8;
  ihdr[9] = 6;
  const out = Buffer.concat([
    Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
    pngChunk('IHDR', ihdr),
    pngChunk('IDAT', zlib.deflateSync(raw, { level: 9 })),
    pngChunk('IEND', Buffer.alloc(0))
  ]);
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, out);
}

// Crisp 5x8 glyph bitmaps (including Turkish İ, I, Ş!)
const GLYPHS = {
  'A': ['0110','1001','1001','1111','1001','1001','1001','0000'],
  'D': ['1110','1001','1001','1001','1001','1001','1110','0000'],
  'E': ['1111','1000','1000','1110','1000','1000','1111','0000'],
  'H': ['1001','1001','1001','1111','1001','1001','1001','0000'],
  'I': ['111','010','010','010','010','010','111','000'],
  'İ': ['010','000','111','010','010','010','111','000'],
  'K': ['1001','1010','1100','1100','1010','1001','1001','0000'],
  'M': ['10001','11011','10101','10001','10001','10001','10001','00000'],
  'N': ['1001','1101','1011','1001','1001','1001','1001','0000'],
  'Ş': ['0111','1000','0110','0001','1110','0100','0110','0000'],
  'T': ['11111','00100','00100','00100','00100','00100','00100','00000'],
  'Y': ['10001','01010','00100','00100','00100','00100','00100','00000'],
  'Z': ['1111','0001','0010','0100','1000','1000','1111','0000'],
  '!': ['1','1','1','1','1','0','1','0'],
  '•': ['00','00','11','11','00','00','00','00'],
  ' ': ['000','000','000','000','000','000','000','000']
};

function setPx(buf, w, x, y, r, g, b, a = 255) {
  if (x < 0 || x >= w || y < 0 || y >= w) return;
  const i = (y * w + x) * 4;
  buf[i] = r; buf[i + 1] = g; buf[i + 2] = b; buf[i + 3] = a;
}

function buildTapeTexture(label, outName) {
  const W = 64, H = 64;
  const buf = Buffer.alloc(W * H * 4);

  // Fill entire 64x64 with dark rubbery edge trim as fallback
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) setPx(buf, W, x, y, 28, 28, 30);
  }

  // UV [0..16, 0..4] in MC 16-unit UV space maps to pixels x=0..63, y=0..15!
  for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 64; x++) {
      // Top (y=0..2) and bottom (y=13..15) diagonal hazard chevron border!
      const inBorder = (y <= 2) || (y >= 13);
      if (inBorder) {
        const stripe = ((x + y * 2) % 8) < 4;
        if (stripe) setPx(buf, W, x, y, 20, 20, 22);
        else setPx(buf, W, x, y, 255, 208, 0);
      } else {
        // Vivid safety yellow ribbon body with subtle woven sheen
        const sheen = (y === 3 || y === 12) ? -12 : ((y === 7 || y === 8) ? 8 : 0);
        setPx(buf, W, x, y, 255, Math.min(255, 212 + sheen), Math.max(0, 8 + sheen));
      }
    }
  }

  // Measure & center bold dark text on y=4..11
  const chars = Array.from(label);
  let totalW = 0;
  for (let i = 0; i < chars.length; i++) {
    const g = GLYPHS[chars[i]] || GLYPHS[' '];
    totalW += g[0].length + (i < chars.length - 1 ? 1 : 0);
  }
  let curX = Math.max(1, Math.floor((64 - totalW) / 2));
  const startY = 4;
  for (const ch of chars) {
    const g = GLYPHS[ch] || GLYPHS[' '];
    const gw = g[0].length;
    for (let gy = 0; gy < g.length; gy++) {
      for (let gx = 0; gx < gw; gx++) {
        if (g[gy][gx] === '1') {
          setPx(buf, W, curX + gx, startY + gy, 16, 16, 18);
        }
      }
    }
    curX += gw + 1;
  }

  // UV [0..16, 4..6] (pixels y=16..23): top/bottom thin edge of tape (yellow/black hazard)
  for (let y = 16; y < 24; y++) {
    for (let x = 0; x < 64; x++) {
      const stripe = ((x >> 2) & 1) === 0;
      if (stripe) setPx(buf, W, x, y, 245, 198, 0);
      else setPx(buf, W, x, y, 24, 24, 26);
    }
  }

  writeRgbaPng(path.join(ASSET_ROOT, 'textures/block', outName), W, H, buf);
}

buildTapeTexture('HİZMET DIŞI', 'tape_hizmet_disi.png');
buildTapeTexture('• YAKINDA •', 'tape_yakinda.png');

function writeTapeBlockAssets(blockId, texName) {
  const blockModel = {
    credit: 'ArenaAI v7.8.0 Double-Ribbon Caution Barrier Tape',
    textures: {
      particle: `arena_ai_bridge:block/${texName}`,
      tape: `arena_ai_bridge:block/${texName}`
    },
    elements: [
      {
        name: 'upper_ribbon',
        from: [0, 10.5, 7.6],
        to: [16, 14.5, 8.4],
        shade: false,
        faces: {
          north: { uv: [0, 0, 16, 4], texture: '#tape' },
          south: { uv: [0, 0, 16, 4], texture: '#tape' },
          up:    { uv: [0, 4, 16, 5], texture: '#tape' },
          down:  { uv: [0, 4, 16, 5], texture: '#tape' },
          west:  { uv: [0, 4, 1, 6],  texture: '#tape' },
          east:  { uv: [0, 4, 1, 6],  texture: '#tape' }
        }
      },
      {
        name: 'lower_ribbon',
        from: [0, 3.0, 7.6],
        to: [16, 7.0, 8.4],
        shade: false,
        faces: {
          north: { uv: [0, 0, 16, 4], texture: '#tape' },
          south: { uv: [0, 0, 16, 4], texture: '#tape' },
          up:    { uv: [0, 4, 16, 5], texture: '#tape' },
          down:  { uv: [0, 4, 16, 5], texture: '#tape' },
          west:  { uv: [0, 4, 1, 6],  texture: '#tape' },
          east:  { uv: [0, 4, 1, 6],  texture: '#tape' }
        }
      }
    ],
    display: {
      gui: { rotation: [18, 28, 0], translation: [0, 0, 0], scale: [0.85, 0.85, 0.85] },
      ground: { translation: [0, 2, 0], scale: [0.45, 0.45, 0.45] },
      fixed: { translation: [0, 0, 0], scale: [0.85, 0.85, 0.85] },
      thirdperson_righthand: { rotation: [65, 35, 0], translation: [0, 2.5, 1], scale: [0.45, 0.45, 0.45] },
      firstperson_righthand: { rotation: [0, 35, 0], translation: [1, 2, 0], scale: [0.50, 0.50, 0.50] }
    }
  };

  fs.writeFileSync(
    path.join(ASSET_ROOT, `models/block/${blockId}.json`),
    JSON.stringify(blockModel, null, 2)
  );

  const blockState = {
    variants: {
      'facing=north': { model: `arena_ai_bridge:block/${blockId}` },
      'facing=south': { model: `arena_ai_bridge:block/${blockId}`, y: 180 },
      'facing=east':  { model: `arena_ai_bridge:block/${blockId}`, y: 90 },
      'facing=west':  { model: `arena_ai_bridge:block/${blockId}`, y: 270 }
    }
  };
  fs.writeFileSync(
    path.join(ASSET_ROOT, `blockstates/${blockId}.json`),
    JSON.stringify(blockState, null, 2)
  );

  fs.writeFileSync(
    path.join(ASSET_ROOT, `models/item/${blockId}.json`),
    JSON.stringify({ parent: `arena_ai_bridge:block/${blockId}` }, null, 2)
  );
}

writeTapeBlockAssets('hizmet_disi_serit', 'tape_hizmet_disi');
writeTapeBlockAssets('yakinda_serit', 'tape_yakinda');

// Update tr_tr.json & en_us.json cleanly
const trPath = path.join(ASSET_ROOT, 'lang/tr_tr.json');
const tr = JSON.parse(fs.readFileSync(trPath, 'utf8'));
tr['block.arena_ai_bridge.hizmet_disi_serit'] = 'Sarı Emniyet Şeridi (HİZMET DIŞI)';
tr['block.arena_ai_bridge.yakinda_serit'] = 'Sarı Emniyet Şeridi (YAKINDA)';
fs.writeFileSync(trPath, JSON.stringify(tr, null, 2));

const enPath = path.join(ASSET_ROOT, 'lang/en_us.json');
const en = JSON.parse(fs.readFileSync(enPath, 'utf8'));
en['block.arena_ai_bridge.hizmet_disi_serit'] = 'Yellow Caution Tape (OUT OF SERVICE)';
en['block.arena_ai_bridge.yakinda_serit'] = 'Yellow Caution Tape (COMING SOON)';
fs.writeFileSync(enPath, JSON.stringify(en, null, 2));

console.log('Generated 64x64 textures, double-ribbon 3D models, blockstates, items & lang for hizmet_disi_serit + yakinda_serit!');

const fs = require('fs');

let src = fs.readFileSync('/var/tmp/mcbuild/LivePatchV78F.java', 'utf8');
src = src.replace(/LivePatchV78F/g, 'LivePatchV78H');
src = src.replace(
  '"v7.8.0F-mtr-pids-board-and-gui"',
  '"v7.8.0H-true-6dof-fem-statics-and-modular-physics"'
);

const proImports = `
import ai.arena.bridge.physics.pro.ConstitutiveMaterialDB;
import ai.arena.bridge.physics.pro.FractureAndSolidifier;
import ai.arena.bridge.physics.pro.ProPhysicsRenderer;
import ai.arena.bridge.physics.pro.RigidBody6DoFDynamics;
import ai.arena.bridge.physics.pro.VerletClothAndWeatherSolver;
import ai.arena.bridge.physics.pro.VoxelFrameFEMSolver;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.item.BlockItem;
`;
src = src.replace('import net.minecraft.util.math.RotationAxis;', 'import net.minecraft.util.math.RotationAxis;\n' + proImports);

const proFields = `
    // ==================== MODULAR 6-DoF FEM & RIGID-BODY STATE ====================
    private final Set<BlockPos> pendingFEMSeeds = ConcurrentHashMap.newKeySet();
    private final Map<BlockPos, Integer> delayedPlacementChecks = new ConcurrentHashMap<>();
    private boolean initialSurfaceFEMScanDone = false;
    private volatile double physicsTimeScale = 1.0;
`;
src = src.replace('    private Identifier texBoardAtlasId = null;', proFields + '\n    private Identifier texBoardAtlasId = null;');

// Allow TNT chains on surface structures
src = src.replace(
  'if (id.startsWith("mtr:") || id.startsWith("arena_ai_bridge:") || st.isOf(Blocks.BEDROCK) || st.isOf(Blocks.TNT)) {',
  'if (id.startsWith("mtr:") || id.startsWith("arena_ai_bridge:") || st.isOf(Blocks.BEDROCK)) {'
);

// Hook PlayerBlockBreakEvents.AFTER + BlockItem placement in UseBlockCallback!
const oldPlacement = `            ItemStack held = player.getStackInHand(hand);
            if (held == null || !held.hasNbt() || !held.getNbt().contains("ArenaTape")) {
                return ActionResult.PASS;
            }`;
const newPlacement = `            ItemStack held = player.getStackInHand(hand);
            if (held != null && held.getItem() instanceof BlockItem && !world.isClient) {
                BlockPos placedTarget = hitResult.getBlockPos().offset(hitResult.getSide());
                if (placedTarget.getY() >= 61) {
                    delayedPlacementChecks.put(placedTarget.toImmutable(), 2);
                }
            }
            if (held == null || !held.hasNbt() || !held.getNbt().contains("ArenaTape")) {
                return ActionResult.PASS;
            }`;
if (!src.includes(oldPlacement)) { console.error('oldPlacement not found'); process.exit(1); }
src = src.replace(oldPlacement, newPlacement);

const oldEnsureCallbacks = '    private void ensureServerPlacementCallbacks() {';
const newEnsureCallbacks = `    private void installModularBlockBreakHook() {
        System.getProperties().put("arena.pro_break_delegate",
                (PlayerBlockBreakEvents.After) (world, player, pos, state, blockEntity) -> {
                    if (world instanceof ServerWorld sw && pos.getY() >= 61
                            && !FractureAndSolidifier.isProtectedMetroInfrastructure(pos, state)) {
                        for (Direction d : Direction.values()) {
                            BlockPos nb = pos.offset(d);
                            BlockState nst = sw.getBlockState(nb);
                            if (!nst.isAir() && nst.getFluidState().isEmpty()
                                    && !FractureAndSolidifier.isNaturalTerrainBlock(nst)
                                    && !FractureAndSolidifier.isProtectedMetroInfrastructure(nb, nst)) {
                                pendingFEMSeeds.add(nb.toImmutable());
                            }
                        }
                    }
                });
        if (!Boolean.getBoolean("arena.pro_break_hook_bound")) {
            System.setProperty("arena.pro_break_hook_bound", "true");
            PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
                Object cb = System.getProperties().get("arena.pro_break_delegate");
                if (cb instanceof PlayerBlockBreakEvents.After after) {
                    after.afterBlockBreak(world, player, pos, state, blockEntity);
                }
            });
        }
    }

    private void ensureServerPlacementCallbacks() {
        installModularBlockBreakHook();`;
if (!src.includes(oldEnsureCallbacks)) { console.error('oldEnsureCallbacks not found'); process.exit(1); }
src = src.replace(oldEnsureCallbacks, newEnsureCallbacks);

// Clean up any legacy leftover entities on first load & wire /onar rewind to FractureAndSolidifier
src = src.replace(
  '        if (!initialRepairDone) {\n            initialRepairDone = true;\n            performFullCleanRepair(world);\n            rebuildBothStationRearSections(world);\n            clearGlassPanePlaceholdersFor3DTapes(world);\n        }',
  `        if (!initialRepairDone) {
            initialRepairDone = true;
            GeoStructuralPhysicsEngine.RIGID_BODIES.clear();
            GeoStructuralPhysicsEngine.TILTING_STRUCTURES.clear();
            FractureAndSolidifier.ensureLoadedFromDisk();
            rebuildBothStationRearSections(world);
            clearGlassPanePlaceholdersFor3DTapes(world);
        }`
);

src = src.replace(
  '        if (lastAlertCountForRepairDetect > 0 && GeoStructuralPhysicsEngine.ACTIVE_ALERTS.isEmpty()\n                && (!blueprints.isEmpty() || !activeDebrisRubble.isEmpty() || !simulatedFloodWaterBlocks.isEmpty())) {\n            rewindAllBlueprintsAndFloods(world);\n        }',
  `        if (lastAlertCountForRepairDetect > 0 && GeoStructuralPhysicsEngine.ACTIVE_ALERTS.isEmpty()
                && (!FractureAndSolidifier.BLUEPRINTS.isEmpty()
                    || !FractureAndSolidifier.GLOBAL_DEPOSITED_RUBBLE.isEmpty()
                    || !blueprints.isEmpty()
                    || !activeDebrisRubble.isEmpty()
                    || !simulatedFloodWaterBlocks.isEmpty())) {
            FractureAndSolidifier.rewindAllBlueprints(world);
            rewindAllBlueprintsAndFloods(world);
        }`
);

// Replace server tick surface physics calls with modular 6-DoF FEM + RigidBody6DoFDynamics + Weather/Snow
const oldTickCalls = `        interceptExplosionsForBlocksworthCollapse(world);
        tickStagedClusters(world);
        tickRigidBodiesAndSolidifyMound(world);`;
const newTickCalls = `        VerletClothAndWeatherSolver.tickServerEnvironment(world);
        interceptExplosionsForBlocksworthCollapse(world);
        tickModularFEMIntegrityAndPlacements(world);
        RigidBody6DoFDynamics.tickAll(
                world,
                physicsTimeScale,
                VerletClothAndWeatherSolver.getCurrentSurfaceWindMs(),
                FractureAndSolidifier::solidifyBodyInWorld
        );`;
if (!src.includes(oldTickCalls)) { console.error('oldTickCalls not found'); process.exit(1); }
src = src.replace(oldTickCalls, newTickCalls);

// Replace triggerBlocksworthDemolition .. tickSafeEntityImpacts with clean modular delegation
const startDemIdx = src.indexOf('    public String triggerBlocksworthDemolition(ServerWorld world, BlockPos blastPos, double blastRadius) {');
const endDemIdx   = src.indexOf('    private void tickSafeEntityImpacts(ServerWorld world) {');
if (startDemIdx < 0 || endDemIdx < 0) { console.error('demolition markers missing'); process.exit(1); }

const modularBridgeMethods = `
    private void tickModularFEMIntegrityAndPlacements(ServerWorld world) {
        // 1. One-shot full-grid scan of existing nearby player structures (NO early break!)
        if (!initialSurfaceFEMScanDone && serverTicks >= 6) {
            for (ServerPlayerEntity sp : world.getPlayers()) {
                if (sp.getY() >= 61.0) {
                    initialSurfaceFEMScanDone = true;
                    BlockPos pc = sp.getBlockPos();
                    BlockPos.Mutable mp = new BlockPos.Mutable();
                    for (int dx = -34; dx <= 34; dx++) {
                        for (int dz = -34; dz <= 34; dz++) {
                            for (int y = 62; y <= 82; y++) {
                                mp.set(pc.getX() + dx, y, pc.getZ() + dz);
                                if (!world.isChunkLoaded(mp.getX() >> 4, mp.getZ() >> 4)) continue;
                                BlockState st = world.getBlockState(mp);
                                if (!st.isAir() && st.getFluidState().isEmpty() && !st.hasBlockEntity()
                                        && !FractureAndSolidifier.isNaturalTerrainBlock(st)
                                        && !FractureAndSolidifier.isNonStructuralAttachment(st)
                                        && !FractureAndSolidifier.isProtectedMetroInfrastructure(mp, st)) {
                                    pendingFEMSeeds.add(mp.toImmutable());
                                }
                            }
                        }
                    }
                }
            }
        }

        // 2. Process delayed BlockItem placements (runs 2 ticks after right-click once block exists in ServerWorld)
        if (!delayedPlacementChecks.isEmpty()) {
            Iterator<Map.Entry<BlockPos, Integer>> it = delayedPlacementChecks.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<BlockPos, Integer> e = it.next();
                int rem = e.getValue() - 1;
                if (rem <= 0) {
                    it.remove();
                    pendingFEMSeeds.add(e.getKey());
                } else {
                    e.setValue(rem);
                }
            }
        }

        // 3. Periodic live-load check under walking surface players (catches walking out onto an overloaded cantilever!)
        if ((serverTicks % 15) == 0) {
            for (ServerPlayerEntity sp : world.getPlayers()) {
                if (sp.getY() >= 62.0 && sp.isOnGround()) {
                    BlockPos under = sp.getBlockPos().down();
                    BlockState ust = world.getBlockState(under);
                    if (!ust.isAir() && !FractureAndSolidifier.isNaturalTerrainBlock(ust)
                            && !FractureAndSolidifier.isProtectedMetroInfrastructure(under, ust)) {
                        pendingFEMSeeds.add(under.toImmutable());
                    }
                }
            }
        }

        if (pendingFEMSeeds.isEmpty()) return;
        List<BlockPos> seeds = new ArrayList<>(pendingFEMSeeds);
        pendingFEMSeeds.clear();
        Set<BlockPos> visited = new HashSet<>();
        org.joml.Vector3d wind = VerletClothAndWeatherSolver.getCurrentSurfaceWindMs();
        for (BlockPos seed : seeds) {
            if (!visited.contains(seed)) {
                FractureAndSolidifier.evaluateAndCollapseStructure(world, seed, null, 0.0, wind, visited, true);
            }
        }
    }

    public String triggerBlocksworthDemolition(ServerWorld world, BlockPos blastPos, double blastRadius) {
        return FractureAndSolidifier.triggerExplosionWithFEM(
                world,
                blastPos,
                blastRadius,
                VerletClothAndWeatherSolver.getCurrentSurfaceWindMs()
        );
    }

`;

src = src.slice(0, startDemIdx) + modularBridgeMethods + src.slice(endDemIdx);

// Hook ProPhysicsRenderer into WorldRenderEvents.LAST
src = src.replace(
  'rewindAllBlueprintsAndFloods(ow);\n                    performFullCleanRepair(ow);',
  'FractureAndSolidifier.rewindAllBlueprints(ow);\n                    rewindAllBlueprintsAndFloods(ow);\n                    performFullCleanRepair(ow);'
);
src = src.replace(
  'GeoStructuralPhysicsEngine.detachBlockAsLiveRigidBody(world, supportPos, 0.0, -0.6, 0.0);',
  'pendingFEMSeeds.add(supportPos.toImmutable());'
);

const oldRenderAnchor = '        // 2. Render 96m Distant 3D Crimson Tunnel Emergency Strobe on damaged/flooded sectors!';
const newRenderAnchor = `        // 1B. Render 60+ FPS 6-DoF Rigid Clusters & Verlet 3D Cloth Capes (Modular ProPhysicsRenderer)
        ProPhysicsRenderer.renderAll(ctx);

        // 2. Render 96m Distant 3D Crimson Tunnel Emergency Strobe on damaged/flooded sectors!`;
if (!src.includes(oldRenderAnchor)) { console.error('oldRenderAnchor not found'); process.exit(1); }
src = src.replace(oldRenderAnchor, newRenderAnchor);

fs.writeFileSync('/var/tmp/mcbuild/LivePatchV78H.java', src, 'utf8');
console.log('Generated /var/tmp/mcbuild/LivePatchV78H.java (' + src.length + ' chars)');

const fs = require('fs');

let src = fs.readFileSync('/var/tmp/mcbuild/LivePatchV78F.java', 'utf8');
src = src.replace(/LivePatchV78F/g, 'LivePatchV78L');
src = src.replace(
  '"v7.8.0F-mtr-pids-board-and-gui"',
  '"v7.8.0K-continuous-beams-obb-hitboxes-curved-house-monolithic-topple"'
);

const proImports = `
import ai.arena.bridge.physics.pro.ConstitutiveMaterialDB;
import ai.arena.bridge.physics.pro.ContinuousOBBHitboxEngine;
import ai.arena.bridge.physics.pro.ContinuousOBBHitboxEngine.OBBRayHit;
import ai.arena.bridge.physics.pro.ContinuousOBBHitboxEngine.TargetKind;
import ai.arena.bridge.physics.pro.ContinuousStructuralBeams;
import ai.arena.bridge.physics.pro.ContinuousStructuralBeams.ContinuousBeam;
import ai.arena.bridge.physics.pro.FractureAndSolidifier;
import ai.arena.bridge.physics.pro.ProPhysicsRenderer;
import ai.arena.bridge.physics.pro.RigidBody6DoFDynamics;
import ai.arena.bridge.physics.pro.VerletClothAndWeatherSolver;
import ai.arena.bridge.physics.pro.VoxelFrameFEMSolver;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Items;
import net.minecraft.server.command.CommandManager;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;
`;
src = src.replace('import net.minecraft.util.math.RotationAxis;', 'import net.minecraft.util.math.RotationAxis;\n' + proImports);

const proFields = `
    // ==================== CONTINUOUS BEAMS, 3D OBB HITBOXES, CURVATURE & MONOLITHIC TOPPLING ====================
    private final Set<BlockPos> pendingFEMSeeds = ConcurrentHashMap.newKeySet();
    private final Map<BlockPos, Integer> delayedPlacementChecks = new ConcurrentHashMap<>();
    private final Map<java.util.UUID, Long> lastCheckedPlayerSupportBlock = new ConcurrentHashMap<>();
    private boolean initialSurfaceFEMScanDone = false;
    private boolean dagTemizleCmdRegistered = false;
    private int obbUseCooldownTicks = 0;
    private volatile double physicsTimeScale = 1.0;
    private volatile double lastServerPhysicsTickMs = 0.0;
    private volatile int lastBuiltDeckY = 75;
`;
src = src.replace('    private Identifier texBoardAtlasId = null;', proFields + '\n    private Identifier texBoardAtlasId = null;');

// Allow TNT chains on surface structures
src = src.replace(
  'if (id.startsWith("mtr:") || id.startsWith("arena_ai_bridge:") || st.isOf(Blocks.BEDROCK) || st.isOf(Blocks.TNT)) {',
  'if (id.startsWith("mtr:") || id.startsWith("arena_ai_bridge:") || st.isOf(Blocks.BEDROCK)) {'
);

// Hook OBB Left-Click (per-piece breaking of fallen 3D houses, continuous inclined columns & curved spans!)
// AND OBB Right-Click (placing blocks onto curved balconies + 2-click Continuous Beam/Column Wand!)
const oldClientAttack = `        if (breakCooldownTicks > 0) breakCooldownTicks--;
        if (client.options.attackKey.isPressed() && breakCooldownTicks == 0) {
            BlockPos hitTape = raycastLiveTape(client.player.getCameraPosVec(1.0f), client.player.getRotationVec(1.0f), 5.5);`;

const newClientAttack = `        ContinuousOBBHitboxEngine.tickClientPlayer(client.player);
        if (breakCooldownTicks > 0) breakCooldownTicks--;
        if (obbUseCooldownTicks > 0) obbUseCooldownTicks--;

        // 1. OBB Right-Click: Continuous Inclined Column Wand OR Block Placement onto Curved/Bent Structures!
        if (client.options.useKey.isPressed() && obbUseCooldownTicks == 0) {
            ItemStack mainStack = client.player.getMainHandStack();
            OBBRayHit obbHit = ContinuousOBBHitboxEngine.raycastPhysicsWorld(client.world, client.player, 5.5);

            // A) Continuous Structural Beam / Inclined Column Builder Wand (Blaze Rod)
            if (mainStack != null && mainStack.isOf(Items.BLAZE_ROD)) {
                Vec3d pickPt = null;
                if (obbHit != null) {
                    pickPt = obbHit.hitPosWorld();
                } else if (client.crosshairTarget instanceof BlockHitResult bhr && bhr.getType() == HitResult.Type.BLOCK) {
                    pickPt = bhr.getPos();
                }
                if (pickPt != null && client.getServer() != null) {
                    obbUseCooldownTicks = 7;
                    client.player.swingHand(Hand.MAIN_HAND);
                    final Vec3d chosen = pickPt;
                    final java.util.UUID pUuid = client.player.getUuid();
                    client.getServer().execute(() -> {
                        ServerWorld sw = client.getServer().getOverworld();
                        ServerPlayerEntity sp = client.getServer().getPlayerManager().getPlayer(pUuid);
                        if (sw == null || sp == null) return;
                        Vec3d first = ContinuousStructuralBeams.PLAYER_FIRST_ENDPOINT.remove(pUuid);
                        if (first == null) {
                            ContinuousStructuralBeams.PLAYER_FIRST_ENDPOINT.put(pUuid, chosen);
                            sp.sendMessage(Text.literal(String.format(Locale.US,
                                    "§e[Sürekli Eğik Kolon] 1. Nokta seçildi (%.1f, %.1f, %.1f) — 2. noktaya sağ tıkla!",
                                    chosen.x, chosen.y, chosen.z)), true);
                        } else if (first.distanceTo(chosen) >= 0.45 && first.distanceTo(chosen) <= 28.0) {
                            BlockState beamMat = Blocks.STRIPPED_OAK_WOOD.getDefaultState();
                            ItemStack off = sp.getOffHandStack();
                            if (off != null && off.getItem() instanceof BlockItem bi) {
                                beamMat = bi.getBlock().getDefaultState();
                            }
                            ContinuousBeam created = ContinuousStructuralBeams.addBeam(
                                    first.x, first.y, first.z, chosen.x, chosen.y, chosen.z,
                                    0.46, 0.46, beamMat, false);
                            sw.playSound(null, BlockPos.ofFloored(chosen.x, chosen.y, chosen.z),
                                    beamMat.getSoundGroup().getPlaceSound(), SoundCategory.BLOCKS, 1.0f, 0.9f);
                            sp.sendMessage(Text.literal(String.format(Locale.US,
                                    "§a[Sürekli Eğik Kolon] %.2fm uzunluğunda bloksuz 3D kolon/kiriş oluşturuldu!",
                                    created.lengthM)), true);
                            enqueueSeedsNear3DPoint(sw, first);
                            enqueueSeedsNear3DPoint(sw, chosen);
                        }
                    });
                }
            }
            // B) Placing ANY BlockItem (Iron, Gold, Netherite, Wood, Stone...) directly onto:
            //    - Fallen 3D Houses & Beams (attaches at exact 3D quaternion tilt & wakes physics!),
            //    - Continuous Non-Block Inclined Columns, OR
            //    - Curved/Bent Standing Structures!
            else if (obbHit != null && client.getServer() != null) {
                Hand placeHand = Hand.MAIN_HAND;
                BlockItem chosenBi = null;
                if (mainStack != null && mainStack.getItem() instanceof BlockItem mbi) {
                    chosenBi = mbi;
                } else if (client.player.getOffHandStack() != null && client.player.getOffHandStack().getItem() instanceof BlockItem obi) {
                    chosenBi = obi;
                    placeHand = Hand.OFF_HAND;
                }
                if (chosenBi != null) {
                    obbUseCooldownTicks = 5;
                    while (client.options.useKey.wasPressed()) { /* consume vanilla click so it never hits ground behind OBB */ }
                    client.player.swingHand(placeHand);
                    final Block placeBlock = chosenBi.getBlock();
                    final OBBRayHit hitSnap = obbHit;
                    final java.util.UUID pUuid = client.player.getUuid();
                    final Hand usedHand = placeHand;
                    client.getServer().execute(() -> {
                        ServerWorld sw = client.getServer().getOverworld();
                        if (sw == null) return;
                        BlockState newSt = placeBlock.getDefaultState();
                        boolean placedOk = false;
                        if (hitSnap.kind() == TargetKind.RIGID_BODY_VOXEL || hitSnap.kind() == TargetKind.RIGID_BODY_BEAM) {
                            placedOk = RigidBody6DoFDynamics.attachSingleVoxelToBody(
                                    sw, hitSnap.bodyId(), hitSnap.voxelIndex(),
                                    hitSnap.hitPosWorld(), hitSnap.hitNormalWorld(), newSt);
                        } else if (hitSnap.kind() == TargetKind.CONTINUOUS_BEAM) {
                            BlockPos attachPos = BlockPos.ofFloored(hitSnap.hitPosWorld().add(hitSnap.hitNormalWorld().multiply(0.52)));
                            if (attachPos.getY() >= 61 && FractureAndSolidifier.resolveEffectiveState(sw, attachPos).isAir()) {
                                sw.setBlockState(attachPos, newSt, 3);
                                sw.playSound(null, attachPos, newSt.getSoundGroup().getPlaceSound(), SoundCategory.BLOCKS, 1.0f, 0.92f);
                                pendingFEMSeeds.add(attachPos.toImmutable());
                                for (Direction d : Direction.values()) pendingFEMSeeds.add(attachPos.offset(d).toImmutable());
                                placedOk = true;
                            }
                        } else if (hitSnap.kind() == TargetKind.ELASTIC_VOXEL) {
                            BlockPos attachPos = hitSnap.structuralGridPos().offset(hitSnap.nearestLatticeDirection());
                            if (attachPos.getY() >= 61 && FractureAndSolidifier.resolveEffectiveState(sw, attachPos).isAir()) {
                                sw.setBlockState(attachPos, newSt, 3);
                                sw.playSound(null, attachPos, newSt.getSoundGroup().getPlaceSound(), SoundCategory.BLOCKS, 1.0f, 0.92f);
                                pendingFEMSeeds.add(attachPos.toImmutable());
                                for (Direction d : Direction.values()) pendingFEMSeeds.add(attachPos.offset(d).toImmutable());
                                placedOk = true;
                            }
                        }
                        if (placedOk) {
                            ServerPlayerEntity sp = client.getServer().getPlayerManager().getPlayer(pUuid);
                            if (sp != null && !sp.isCreative()) {
                                ItemStack st = sp.getStackInHand(usedHand);
                                if (st != null && !st.isEmpty()) st.decrement(1);
                            }
                        }
                    });
                }
            }
        }

        // 2. OBB Left-Click: Break ONLY the single targeted piece on a toppled 3D house, continuous column, or curved floor!
        if (ProPhysicsRenderer.currentClientOBBHit != null && client.interactionManager != null) {
            client.interactionManager.cancelBlockBreaking();
        }
        if (client.options.attackKey.isPressed() && breakCooldownTicks == 0) {
            OBBRayHit obbBreakHit = ContinuousOBBHitboxEngine.raycastPhysicsWorld(client.world, client.player, 5.5);
            if (obbBreakHit != null && client.getServer() != null) {
                breakCooldownTicks = 5;
                while (client.options.attackKey.wasPressed()) { /* consume attack click */ }
                if (client.interactionManager != null) client.interactionManager.cancelBlockBreaking();
                client.player.swingHand(Hand.MAIN_HAND);
                client.getServer().execute(() -> {
                    ServerWorld sw = client.getServer().getOverworld();
                    if (sw != null) handleServerOBBBreak(sw, obbBreakHit);
                });
                return;
            }
            BlockPos hitTape = raycastLiveTape(client.player.getCameraPosVec(1.0f), client.player.getRotationVec(1.0f), 5.5);`;

if (!src.includes(oldClientAttack)) { console.error('oldClientAttack not found'); process.exit(1); }
src = src.replace(oldClientAttack, newClientAttack);

// Also keep vanilla UseBlockCallback hook for ordinary un-curved grid blocks!
const oldPlacement = `            ItemStack held = player.getStackInHand(hand);
            if (held == null || !held.hasNbt() || !held.getNbt().contains("ArenaTape")) {
                return ActionResult.PASS;
            }`;
const newPlacement = `            // Prevent vanilla click-through onto background terrain when the player is aiming at a closer 3D OBB!
            OBBRayHit blockingObb = ContinuousOBBHitboxEngine.raycastPhysicsWorld(world, player, 5.5);
            if (blockingObb != null) {
                return ActionResult.FAIL;
            }
            ItemStack held = player.getStackInHand(hand);
            if (held != null && held.getItem() instanceof BlockItem && !world.isClient) {
                BlockPos hitPos = hitResult.getBlockPos();
                BlockPos placedTarget = hitPos.offset(hitResult.getSide());
                if (placedTarget.getY() >= 61) {
                    delayedPlacementChecks.put(placedTarget.toImmutable(), 2);
                    delayedPlacementChecks.put(hitPos.toImmutable(), 2);
                    lastCheckedPlayerSupportBlock.clear();
                }
            }
            if (held == null || !held.hasNbt() || !held.getNbt().contains("ArenaTape")) {
                return ActionResult.PASS;
            }`;
if (!src.includes(oldPlacement)) { console.error('oldPlacement not found'); process.exit(1); }
src = src.replace(oldPlacement, newPlacement);

const oldEnsureCallbacks = '    private void ensureServerPlacementCallbacks() {';
const newEnsureCallbacks = `    private void enqueueSeedsNear3DPoint(ServerWorld sw, Vec3d pt) {
        BlockPos c = BlockPos.ofFloored(pt.x, pt.y, pt.z);
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                for (int dz = -1; dz <= 1; dz++) {
                    BlockPos nb = c.add(dx, dy, dz);
                    if (FractureAndSolidifier.isStructuralCandidate(nb, FractureAndSolidifier.resolveEffectiveState(sw, nb))) {
                        pendingFEMSeeds.add(nb.toImmutable());
                    }
                }
            }
        }
    }

    private void handleServerOBBBreak(ServerWorld sw, OBBRayHit hit) {
        switch (hit.kind()) {
            case RIGID_BODY_VOXEL, RIGID_BODY_BEAM -> {
                // Breaks ONLY the single targeted block or beam on a toppled 3D house & wakes survivors to re-settle!
                RigidBody6DoFDynamics.breakSingleVoxelOrBeamOnBody(sw, hit.bodyId(), hit.voxelIndex(), hit.attachedBeamIndex());
            }
            case CONTINUOUS_BEAM -> {
                ContinuousBeam targetBeam = null;
                for (ContinuousBeam b : ContinuousStructuralBeams.ACTIVE_BEAMS) {
                    if (b.id == hit.beamId()) { targetBeam = b; break; }
                }
                if (ContinuousStructuralBeams.removeBeamById(sw, hit.beamId(), true) && targetBeam != null) {
                    enqueueSeedsNear3DPoint(sw, new Vec3d(targetBeam.ax, targetBeam.ay, targetBeam.az));
                    enqueueSeedsNear3DPoint(sw, new Vec3d(targetBeam.bx, targetBeam.by, targetBeam.bz));
                }
            }
            case ELASTIC_VOXEL -> {
                BlockPos gp = hit.structuralGridPos();
                sw.setBlockState(gp, Blocks.AIR.getDefaultState(), 3);
                pendingFEMSeeds.addAll(FractureAndSolidifier.handleBlockBreakAndCollectSeeds(sw, gp, hit.state()));
            }
        }
    }

    private void installModularBlockBreakHook() {
        System.getProperties().remove("arena.block_break_delegate");
        System.getProperties().put("arena.pro_break_delegate",
                (PlayerBlockBreakEvents.After) (world, player, pos, state, blockEntity) -> {
                    if (world instanceof ServerWorld sw && pos.getY() >= 61
                            && !FractureAndSolidifier.isProtectedMetroInfrastructure(pos, state)) {
                        lastCheckedPlayerSupportBlock.clear();
                        pendingFEMSeeds.addAll(FractureAndSolidifier.handleBlockBreakAndCollectSeeds(sw, pos, state));
                    }
                });
        if (!Boolean.getBoolean("arena.pro_break_hook_bound")) {
            System.setProperty("arena.pro_break_hook_bound", "true");
            PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
                Object cb = System.getProperties().get("arena.pro_break_delegate");
                if (cb instanceof PlayerBlockBreakEvents.After after) {
                    after.afterBlockBreak(world, player, pos, state, blockEntity);
                }
            });
        }
    }

    private static void removeRootLiteral(Object rootNode, String name) {
        try {
            Class<?> cnClass = Class.forName("com.mojang.brigadier.tree.CommandNode");
            for (String fName : new String[]{"children", "literals", "arguments"}) {
                java.lang.reflect.Field f = cnClass.getDeclaredField(fName);
                f.setAccessible(true);
                Object mapObj = f.get(rootNode);
                if (mapObj instanceof Map<?, ?> m) {
                    m.remove(name);
                }
            }
        } catch (Throwable ignored) {}
    }

    private void ensureDagTemizleCommand(MinecraftServer server) {
        if (dagTemizleCmdRegistered || server == null) return;
        dagTemizleCmdRegistered = true;
        try {
            var disp = server.getCommandManager().getDispatcher();
            removeRootLiteral(disp.getRoot(), "dagtemizle");
            removeRootLiteral(disp.getRoot(), "onar");

            disp.register(
                CommandManager.literal("dagtemizle").executes(ctx -> {
                    ServerWorld ow = ctx.getSource().getServer().getOverworld();
                    int restored = FractureAndSolidifier.clearTestRig(ow);
                    ctx.getSource().sendFeedback(
                        () -> Text.literal("§a[ArenaFizik] Test dagi ve uzun yamac evi temizlendi (" + restored + " blok). Tum 3D fizik kalici olarak aktif!"),
                        false
                    );
                    return 1;
                })
            );

            disp.register(
                CommandManager.literal("onar")
                    .executes(ctx -> {
                        BlockPos origin = BlockPos.ofFloored(ctx.getSource().getPosition());
                        ServerWorld sw = ctx.getSource().getWorld();
                        int proRestored = FractureAndSolidifier.repairStructuresNear(sw, origin, 80.0);
                        int geoRestored = GeoStructuralPhysicsEngine.repairStructuralDamageNear(sw, origin, 80.0);
                        int total = proRestored + geoRestored;
                        ctx.getSource().sendFeedback(
                            () -> Text.literal(total > 0
                                ? ("§a[Onarım] Eğilmiş, kalıcı bükülmüş ve yıkılmış yapılar eski haline döndürüldü (" + total + " eleman onarıldı)!")
                                : "§e[Onarım] 80m çevrede onarılacak eğilmiş veya yıkılmış yapı bulunamadı."),
                            false
                        );
                        return 1;
                    })
                    .then(CommandManager.literal("hepsi").executes(ctx -> {
                        BlockPos origin = BlockPos.ofFloored(ctx.getSource().getPosition());
                        ServerWorld sw = ctx.getSource().getWorld();
                        FractureAndSolidifier.rewindAllBlueprints(sw);
                        GeoStructuralPhysicsEngine.repairStructuralDamageNear(sw, origin, 5000.0);
                        ctx.getSource().sendFeedback(
                            () -> Text.literal("§a[Onarım] Tüm dünyadaki eğilmiş ve yıkılmış yapılar tamamen eski haline getirildi!"),
                            false
                        );
                        return 1;
                    }))
            );

            for (ServerPlayerEntity sp : server.getPlayerManager().getPlayerList()) {
                server.getCommandManager().sendCommandTree(sp);
            }
        } catch (Throwable ignored) {}
    }

    private void ensureServerPlacementCallbacks() {
        installModularBlockBreakHook();`;
if (!src.includes(oldEnsureCallbacks)) { console.error('oldEnsureCallbacks not found'); process.exit(1); }
src = src.replace(oldEnsureCallbacks, newEnsureCallbacks);

// Clean up any legacy entities & load disk blueprints + continuous beams
src = src.replace(
  '        if (!initialRepairDone) {\n            initialRepairDone = true;\n            performFullCleanRepair(world);\n            rebuildBothStationRearSections(world);\n            clearGlassPanePlaceholdersFor3DTapes(world);\n        }',
  `        ensureDagTemizleCommand(world.getServer());
        if (!initialRepairDone) {
            initialRepairDone = true;
            GeoStructuralPhysicsEngine.physicsEnabled = false;
            GeoStructuralPhysicsEngine.RIGID_BODIES.clear();
            GeoStructuralPhysicsEngine.TILTING_STRUCTURES.clear();
            FractureAndSolidifier.ensureLoadedFromDisk();
            ContinuousStructuralBeams.ensureLoadedFromDisk();
            rebuildBothStationRearSections(world);
            clearGlassPanePlaceholdersFor3DTapes(world);
        }`
);

src = src.replace(
  '        if (lastAlertCountForRepairDetect > 0 && GeoStructuralPhysicsEngine.ACTIVE_ALERTS.isEmpty()\n                && (!blueprints.isEmpty() || !activeDebrisRubble.isEmpty() || !simulatedFloodWaterBlocks.isEmpty())) {\n            rewindAllBlueprintsAndFloods(world);\n        }',
  `        if (lastAlertCountForRepairDetect > 0 && GeoStructuralPhysicsEngine.ACTIVE_ALERTS.isEmpty()
                && (!FractureAndSolidifier.BLUEPRINTS.isEmpty()
                    || !FractureAndSolidifier.ELASTIC_PROXIES.isEmpty()
                    || !RigidBody6DoFDynamics.ACTIVE_BODIES.isEmpty()
                    || !blueprints.isEmpty()
                    || !activeDebrisRubble.isEmpty()
                    || !simulatedFloodWaterBlocks.isEmpty())) {
            FractureAndSolidifier.rewindAllBlueprints(world);
            rewindAllBlueprintsAndFloods(world);
        }`
);

const oldTickCalls = `        interceptExplosionsForBlocksworthCollapse(world);
        tickStagedClusters(world);
        tickRigidBodiesAndSolidifyMound(world);`;
const newTickCalls = `        long physT0 = System.nanoTime();
        VerletClothAndWeatherSolver.tickServerEnvironment(world);
        ContinuousOBBHitboxEngine.tickServerEntities(world);
        interceptExplosionsForBlocksworthCollapse(world);
        tickModularFEMIntegrityAndPlacements(world);
        RigidBody6DoFDynamics.tickAll(
                world,
                physicsTimeScale,
                VerletClothAndWeatherSolver.getCurrentSurfaceWindMs(),
                FractureAndSolidifier::solidifyBodyInWorld
        );
        lastServerPhysicsTickMs = Math.round(((System.nanoTime() - physT0) * 1.0e-6) * 1000.0) / 1000.0;`;
if (!src.includes(oldTickCalls)) { console.error('oldTickCalls not found'); process.exit(1); }
src = src.replace(oldTickCalls, newTickCalls);

const oldInvoke = `            } else if ("flood_test".equalsIgnoreCase(op) && ow != null) {`;
const newInvoke = `            } else if ("tp_bot".equalsIgnoreCase(op) && ow != null) {
                server.execute(() -> {
                    ServerPlayerEntity ilkan = null;
                    ServerPlayerEntity bot = null;
                    for (ServerPlayerEntity sp : ow.getPlayers()) {
                        if ("ArenaAI".equalsIgnoreCase(sp.getName().getString())) bot = sp;
                        else ilkan = sp;
                    }
                    if (bot != null && ilkan != null) {
                        bot.teleport(ow, ilkan.getX() + 3.5, ilkan.getY() + 0.5, ilkan.getZ() + 2.5, ilkan.getYaw(), 0.0f);
                    }
                });
                res.addProperty("botTeleported", true);
            } else if ("give_test_items".equalsIgnoreCase(op) && ow != null) {
                server.execute(() -> {
                    for (ServerPlayerEntity sp : ow.getPlayers()) {
                        if (!"ArenaAI".equalsIgnoreCase(sp.getName().getString())) {
                            ItemStack wand = new ItemStack(Items.BLAZE_ROD, 1);
                            wand.setCustomName(Text.literal("§6Sürekli 3D Eğik Kolon & Kiriş Aracı (2 Sağ Tık)"));
                            sp.getInventory().insertStack(wand);
                            sp.getInventory().insertStack(new ItemStack(Items.NETHERITE_BLOCK, 16));
                            sp.getInventory().insertStack(new ItemStack(Items.GOLD_BLOCK, 16));
                            sp.getInventory().insertStack(new ItemStack(Items.IRON_BLOCK, 16));
                        }
                    }
                });
                res.addProperty("gaveItems", true);
            } else if ("build_hillside_test".equalsIgnoreCase(op) && ow != null) {
                int bx = payload.has("x") ? payload.get("x").getAsInt() : 14;
                int bz = payload.has("z") ? payload.get("z").getAsInt() : 1528;
                server.execute(() -> buildLongCantileverHillsideScene(ow, bx, bz));
                res.addProperty("builtLongHillsideScene", true);
                res.addProperty("baseX", bx);
                res.addProperty("baseZ", bz);
            } else if ("clear_test_rig".equalsIgnoreCase(op) && ow != null) {
                server.execute(() -> FractureAndSolidifier.clearTestRig(ow));
                res.addProperty("clearedTestRig", true);
            } else if ("place_test_block".equalsIgnoreCase(op) && ow != null) {
                int px = payload.get("x").getAsInt();
                int py = payload.get("y").getAsInt();
                int pz = payload.get("z").getAsInt();
                String blockId = payload.has("block") ? payload.get("block").getAsString() : "minecraft:gold_block";
                server.execute(() -> {
                    BlockPos tp = new BlockPos(px, py, pz);
                    Block b = Registries.BLOCK.get(new Identifier(blockId));
                    if (b == Blocks.AIR) {
                        BlockState oldSt = FractureAndSolidifier.resolveEffectiveState(ow, tp);
                        ow.setBlockState(tp, Blocks.AIR.getDefaultState(), 3);
                        pendingFEMSeeds.addAll(FractureAndSolidifier.handleBlockBreakAndCollectSeeds(ow, tp, oldSt));
                    } else {
                        FractureAndSolidifier.TEST_RIG_RESTORE_MAP.putIfAbsent(tp, ow.getBlockState(tp));
                        ow.setBlockState(tp, b.getDefaultState(), 3);
                        pendingFEMSeeds.add(tp);
                        for (Direction d : Direction.values()) pendingFEMSeeds.add(tp.offset(d));
                    }
                });
                res.addProperty("placed", blockId);
            } else if ("attach_body_voxel_test".equalsIgnoreCase(op) && ow != null) {
                long bid = payload.get("bodyId").getAsLong();
                int vIdx = payload.get("voxelIndex").getAsInt();
                String bId = payload.has("block") ? payload.get("block").getAsString() : "minecraft:gold_block";
                server.execute(() -> {
                    Block b = Registries.BLOCK.get(new Identifier(bId));
                    RigidBody6DoFDynamics.attachSingleVoxelToBody(
                            ow, bid, vIdx, new Vec3d(0, 0, 0), new Vec3d(0, 1, 0), b.getDefaultState());
                });
                res.addProperty("attachedSingleVoxel", true);
            } else if ("break_body_voxel_test".equalsIgnoreCase(op) && ow != null) {
                long bid = payload.get("bodyId").getAsLong();
                int vIdx = payload.get("voxelIndex").getAsInt();
                server.execute(() -> RigidBody6DoFDynamics.breakSingleVoxelOrBeamOnBody(ow, bid, vIdx, -1));
                res.addProperty("brokeSingleVoxel", true);
            } else if ("push_body_test".equalsIgnoreCase(op) && ow != null) {
                long bid = payload.get("bodyId").getAsLong();
                double cdx = payload.has("contactDx") ? payload.get("contactDx").getAsDouble() : 0.0;
                double cdy = payload.has("contactDy") ? payload.get("contactDy").getAsDouble() : 0.0;
                double cdz = payload.has("contactDz") ? payload.get("contactDz").getAsDouble() : 0.0;
                double nx = payload.has("dirX") ? payload.get("dirX").getAsDouble() : 1.0;
                double ny = payload.has("dirY") ? payload.get("dirY").getAsDouble() : 0.0;
                double nz = payload.has("dirZ") ? payload.get("dirZ").getAsDouble() : 0.0;
                double spd = payload.has("speedMps") ? payload.get("speedMps").getAsDouble() : 5.6;
                boolean spr = !payload.has("sprinting") || payload.get("sprinting").getAsBoolean();
                RigidBody6DoFDynamics.RigidCluster6DoF targetBody = null;
                for (RigidBody6DoFDynamics.RigidCluster6DoF b : RigidBody6DoFDynamics.ACTIVE_BODIES) {
                    if (b.bodyId == bid) { targetBody = b; break; }
                }
                if (targetBody != null) {
                    boolean moved = RigidBody6DoFDynamics.applyPlayerPushImpulse(
                        targetBody, targetBody.px + cdx, targetBody.py + cdy, targetBody.pz + cdz,
                        nx, ny, nz, spd, spr
                    );
                    res.addProperty("moved", moved);
                    res.addProperty("bodyMassKg", Math.round(targetBody.totalMassKg * 10.0) / 10.0);
                    res.addProperty("bodyVx", Math.round(targetBody.vx * 1000.0) / 1000.0);
                    res.addProperty("bodyVz", Math.round(targetBody.vz * 1000.0) / 1000.0);
                    res.addProperty("bodyWy", Math.round(targetBody.wy * 1000.0) / 1000.0);
                } else {
                    res.addProperty("moved", false);
                }
            } else if ("onar_near_test".equalsIgnoreCase(op) && ow != null) {
                int cx = payload.get("x").getAsInt();
                int cy = payload.get("y").getAsInt();
                int cz = payload.get("z").getAsInt();
                double rad = payload.has("radius") ? payload.get("radius").getAsDouble() : 80.0;
                server.execute(() -> FractureAndSolidifier.repairStructuresNear(ow, new BlockPos(cx, cy, cz), rad));
                res.addProperty("repaired", true);
            } else if ("self_test_report".equalsIgnoreCase(op)) {
                ProPhysicsRenderer.recordTelemetry = false;
                res.addProperty("clientFps", client != null ? client.getCurrentFps() : -1);
                res.addProperty("activeBodies", RigidBody6DoFDynamics.ACTIVE_BODIES.size());
                res.addProperty("continuousBeamsActive", ContinuousStructuralBeams.ACTIVE_BEAMS.size());
                int sleepingBodies = 0;
                long firstBodyId = -1L;
                int firstBodyVoxels = 0;
                int firstBodyAttachedBeams = 0;
                double sampleRestY = -1.0;
                double sampleTiltDeg = 0.0;
                for (RigidBody6DoFDynamics.RigidCluster6DoF b : RigidBody6DoFDynamics.ACTIVE_BODIES) {
                    if (b.sleeping) sleepingBodies++;
                    if (firstBodyId < 0 || b.voxels.size() > firstBodyVoxels) {
                        firstBodyId = b.bodyId;
                        int realCount = 0;
                        for (RigidBody6DoFDynamics.LocalVoxel lv : b.voxels) {
                            if (!lv.state().isAir()) realCount++;
                        }
                        firstBodyVoxels = realCount;
                        firstBodyAttachedBeams = b.attachedBeams.size();
                        sampleRestY = Math.round(b.py * 1000.0) / 1000.0;
                        sampleTiltDeg = Math.round(Math.toDegrees(2.0 * Math.acos(MathHelper.clamp(Math.abs(b.quat.w), 0.0, 1.0))) * 100.0) / 100.0;
                    }
                }
                res.addProperty("sleepingPersistent3DBodies", sleepingBodies);
                res.addProperty("largestBodyId", firstBodyId);
                res.addProperty("largestBodyVoxelCount", firstBodyVoxels);
                res.addProperty("largestBodyAttachedBeams", firstBodyAttachedBeams);
                res.addProperty("largestBodyY", sampleRestY);
                res.addProperty("largestBodyTiltDeg", sampleTiltDeg);
                res.addProperty("elasticSaggingVoxels", FractureAndSolidifier.ELASTIC_PROXIES.size());
                res.addProperty("plasticResidualVoxels", FractureAndSolidifier.PLASTIC_RESIDUAL_MAP.size());
                double maxSagDy = 0.0;
                double maxSlopeDeg = 0.0;
                for (FractureAndSolidifier.ElasticSagVoxel sv : FractureAndSolidifier.ELASTIC_PROXIES.values()) {
                    if (Math.abs(sv.targetDy()) > Math.abs(maxSagDy)) maxSagDy = sv.targetDy();
                    double deg = Math.toDegrees(Math.hypot(sv.targetRx(), sv.targetRz()));
                    if (deg > maxSlopeDeg) maxSlopeDeg = deg;
                }
                res.addProperty("maxElasticSagMeters", Math.round(maxSagDy * 1000.0) / 1000.0);
                res.addProperty("maxCurvatureSlopeDeg", Math.round(maxSlopeDeg * 100.0) / 100.0);
                res.addProperty("lastPeakStressRatio", FractureAndSolidifier.lastPeakStressRatio);
                res.addProperty("lastBuiltDeckY", lastBuiltDeckY);
                res.addProperty("lastFemSolveMs", FractureAndSolidifier.lastFemSolveMs);
                res.addProperty("lastDetachedBlocks", FractureAndSolidifier.lastDetachedBlocks);
                res.addProperty("lastServerPhysicsTickMs", lastServerPhysicsTickMs);
                res.addProperty("barrierCountMustBeZero", FractureAndSolidifier.RUBBLE_BARRIER_OWNER.size());
            } else if ("onar_rewind".equalsIgnoreCase(op) && ow != null) {
                server.execute(() -> FractureAndSolidifier.rewindAllBlueprints(ow));
                res.addProperty("rewound", true);
            } else if ("flood_test".equalsIgnoreCase(op) && ow != null) {`;
if (!src.includes(oldInvoke)) { console.error('oldInvoke not found'); process.exit(1); }
src = src.replace(oldInvoke, newInvoke);

const startDemIdx = src.indexOf('    public String triggerBlocksworthDemolition(ServerWorld world, BlockPos blastPos, double blastRadius) {');
const endDemIdx   = src.indexOf('    private void tickSafeEntityImpacts(ServerWorld world) {');
if (startDemIdx < 0 || endDemIdx < 0) { console.error('demolition markers missing'); process.exit(1); }

const modularBridgeMethods = `
    private void setTestRigBlock(ServerWorld world, BlockPos p, BlockState state) {
        FractureAndSolidifier.TEST_RIG_RESTORE_MAP.putIfAbsent(p.toImmutable(), world.getBlockState(p));
        world.setBlockState(p, state, 2);
    }

    /**
     * Builds a 100% removable Steep Rocky Cliffside + LONG 12-Meter Architectural Cantilever House
     * supported by THREE Non-Grid Continuous 3D Inclined Columns (ZERO stepped Minecraft blocks!).
     * - Long 9m overhanging span curves smoothly along a continuous parabolic arc under moderate loads,
     *   and topples MONOLITHICALLY as ONE single intact building when heavily overloaded at the tip!
     */
    private void buildLongCantileverHillsideScene(ServerWorld world, int valleyX, int centerZ) {
        FractureAndSolidifier.clearTestRig(world);

        int baseY = 64;
        for (int y = 68; y >= 61; y--) {
            BlockState st = world.getBlockState(new BlockPos(valleyX, y, centerZ));
            if (FractureAndSolidifier.isNaturalTerrainBlock(st)) {
                baseY = y + 1;
                break;
            }
        }
        int deckY = baseY + 11; // 11-meter sheer drop beneath the long cantilever house!
        this.lastBuiltDeckY = deckY;

        // Clear generous valley landing zone + mountain cliff footprint (X = valleyX-5 .. valleyX+18, Z = centerZ-8 .. centerZ+8)
        for (int x = valleyX - 5; x <= valleyX + 18; x++) {
            for (int z = centerZ - 8; z <= centerZ + 8; z++) {
                BlockPos pad = new BlockPos(x, baseY - 1, z);
                if (world.getBlockState(pad).isAir() || !world.getFluidState(pad).isEmpty()) {
                    setTestRigBlock(world, pad, Blocks.SANDSTONE.getDefaultState());
                }
                for (int y = baseY; y <= baseY + 20; y++) {
                    setTestRigBlock(world, new BlockPos(x, y, z), Blocks.AIR.getDefaultState());
                }
            }
        }

        // 1. Sculpt Dramatic Rocky Cliffside on X = valleyX + 8 .. valleyX + 17 (leaving X = valleyX-5 .. valleyX+7 wide-open valley!)
        for (int dx = 8; dx <= 17; dx++) {
            int x = valleyX + dx;
            for (int dz = -7; dz <= 7; dz++) {
                int z = centerZ + dz;
                double flankTaper = Math.max(0.0, 1.0 - (dz * dz) / 58.0);
                int h;
                if (Math.abs(dz) <= 3) {
                    if (dx == 8) h = 4;                  // Footing toe rock
                    else if (dx == 9) h = 7;             // Mid cliff face where continuous inclined columns socket into solid rock!
                    else if (dx <= 11) h = 10;           // Flat upper rock terrace at baseY + 10 (= deckY - 1) under rear 3m of house!
                    else h = 12 + (dx - 12);             // Mountain summit rising behind X >= valleyX + 12 (clear of house rear wall X=valleyX+11!)
                } else {
                    h = (int) Math.round((4.0 + (dx - 8) * 1.15) * flankTaper);
                }
                int topY = baseY + h;
                for (int y = baseY; y <= topY; y++) {
                    BlockState rock;
                    if (y == topY && dx >= 12) {
                        rock = Blocks.GRASS_BLOCK.getDefaultState();
                    } else if (((x + y + z) & 3) == 0) {
                        rock = Blocks.ANDESITE.getDefaultState();
                    } else if (((x * 3 + z) & 7) == 0) {
                        rock = Blocks.TUFF.getDefaultState();
                    } else {
                        rock = Blocks.STONE.getDefaultState();
                    }
                    setTestRigBlock(world, new BlockPos(x, y, z), rock);
                }
            }
        }

        // 2. Build the LONG 12-Meter Architectural Cantilever House (X = valleyX .. valleyX + 11, width 5m: Z = centerZ-2 .. centerZ+2)
        //    - Rear 2m (X = valleyX + 10 .. valleyX + 11) bears on the upper rock terrace (Y = deckY - 1) via unilateral uplift-pullout anchors!
        //    - Front 10m (X = valleyX .. valleyX + 9) projects 10 meters out over the 11m cliff abyss!
        BlockState oakGirder  = Blocks.STRIPPED_OAK_WOOD.getDefaultState();
        BlockState spruceDeck = Blocks.SPRUCE_PLANKS.getDefaultState();
        BlockState glassWall  = Blocks.GLASS.getDefaultState();
        BlockState darkRoof   = Blocks.DARK_OAK_PLANKS.getDefaultState();

        // Floor deck & heavy longitudinal girders (Y = deckY, full 12m length!)
        for (int x = valleyX; x <= valleyX + 11; x++) {
            for (int z = centerZ - 2; z <= centerZ + 2; z++) {
                boolean girder = (z == centerZ - 2 || z == centerZ || z == centerZ + 2
                        || x == valleyX || x == valleyX + 3 || x == valleyX + 9 || x == valleyX + 11);
                setTestRigBlock(world, new BlockPos(x, deckY, z), girder ? oakGirder : spruceDeck);
            }
        }

        // Unified 12-Meter Timber Vierendeel Box-Frame Superstructure (X = valleyX .. valleyX + 11, Y = deckY + 1 .. deckY + 3):
        // - Front 3m (X = valleyX .. valleyX + 2) is an open-sided covered observation loggia with corner columns & roof!
        // - Main 9m gallery (X = valleyX + 3 .. valleyX + 11) has panoramic glass walls + timber mullions!
        // Because top & bottom oak box-chords run the full 12m, the house curves smoothly and topples as ONE whole building!
        for (int y = deckY + 1; y <= deckY + 3; y++) {
            for (int x = valleyX; x <= valleyX + 11; x++) {
                for (int z = centerZ - 2; z <= centerZ + 2; z++) {
                    if (x < valleyX + 3) {
                        // Covered front veranda: structural posts tying all 3 floor spine girders to the roof box-chords!
                        if (x == valleyX && (z == centerZ - 2 || z == centerZ || z == centerZ + 2)) {
                            setTestRigBlock(world, new BlockPos(x, y, z), oakGirder);
                        }
                        continue;
                    }
                    boolean xEnd = (x == valleyX + 3 || x == valleyX + 11);
                    boolean zSide = (z == centerZ - 2 || z == centerZ + 2);
                    if (!xEnd && !zSide) continue;
                    // Open wide doorway out onto the front veranda & rear mountain terrace
                    if ((x == valleyX + 3 || x == valleyX + 11) && Math.abs(z - centerZ) <= 1 && y <= deckY + 2) continue;

                    boolean mullion = (zSide && (x == valleyX + 3 || x == valleyX + 6 || x == valleyX + 9 || x == valleyX + 11));
                    if (mullion) {
                        setTestRigBlock(world, new BlockPos(x, y, z), oakGirder);
                    } else if (y == deckY + 2) {
                        setTestRigBlock(world, new BlockPos(x, y, z), glassWall);
                    } else {
                        setTestRigBlock(world, new BlockPos(x, y, z), spruceDeck);
                    }
                }
            }
        }

        // Continuous Full-12-Meter Structural Box Roof (X = valleyX .. valleyX + 11, Y = deckY + 4)
        for (int x = valleyX; x <= valleyX + 11; x++) {
            for (int z = centerZ - 2; z <= centerZ + 2; z++) {
                boolean roofChord = (z == centerZ - 2 || z == centerZ || z == centerZ + 2 || x == valleyX || x == valleyX + 3 || x == valleyX + 11);
                setTestRigBlock(world, new BlockPos(x, deckY + 4, z), roofChord ? oakGirder : darkRoof);
            }
        }

        // 3. THREE Smooth Non-Grid Continuous 3D Inclined Columns (ZERO stepped Minecraft blocks!)
        //    Anchored in solid cliff rock at (valleyX + 9.35, deckY - 5.15, z) and stretching smoothly
        //    up-and-out at ~41 degrees to prop the 3 longitudinal oak girders at (valleyX + 3.25, deckY + 0.15, z)!
        double[] beamZs = { centerZ - 1.5, centerZ + 0.5, centerZ + 2.5 };
        for (double bz : beamZs) {
            ContinuousStructuralBeams.addBeam(
                    valleyX + 9.35, deckY - 5.15, bz,
                    valleyX + 3.25, deckY + 0.15, bz,
                    0.38, 0.252,
                    oakGirder,
                    true // temporaryTestRig = true -> removed cleanly by /dagtemizle!
            );
        }

        pendingFEMSeeds.add(new BlockPos(valleyX + 1, deckY, centerZ));
    }

    private void tickModularFEMIntegrityAndPlacements(ServerWorld world) {
        if (!initialSurfaceFEMScanDone && serverTicks >= 6) {
            for (ServerPlayerEntity sp : world.getPlayers()) {
                if (sp.getY() >= 61.0) {
                    initialSurfaceFEMScanDone = true;
                    BlockPos pc = sp.getBlockPos();
                    BlockPos.Mutable mp = new BlockPos.Mutable();
                    for (int dx = -30; dx <= 30; dx++) {
                        for (int dz = -30; dz <= 30; dz++) {
                            for (int y = 62; y <= 86; y++) {
                                mp.set(pc.getX() + dx, y, pc.getZ() + dz);
                                if (!world.isChunkLoaded(mp.getX() >> 4, mp.getZ() >> 4)) continue;
                                BlockState st = FractureAndSolidifier.resolveEffectiveState(world, mp);
                                if (FractureAndSolidifier.isStructuralCandidate(mp, st)) {
                                    pendingFEMSeeds.add(mp.toImmutable());
                                }
                            }
                        }
                    }
                }
            }
        }

        if (!delayedPlacementChecks.isEmpty()) {
            Iterator<Map.Entry<BlockPos, Integer>> it = delayedPlacementChecks.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<BlockPos, Integer> e = it.next();
                int rem = e.getValue() - 1;
                if (rem <= 0) {
                    it.remove();
                    BlockPos p = e.getKey();
                    pendingFEMSeeds.add(p);
                    for (Direction d : Direction.values()) {
                        pendingFEMSeeds.add(p.offset(d));
                    }
                } else {
                    e.setValue(rem);
                }
            }
        }

        if ((serverTicks % 10) == 0) {
            for (ServerPlayerEntity sp : world.getPlayers()) {
                if (sp.getY() >= 62.0 && sp.isOnGround()) {
                    BlockPos under = BlockPos.ofFloored(sp.getX(), sp.getY() - 0.35, sp.getZ());
                    long key = under.asLong();
                    Long prevKey = lastCheckedPlayerSupportBlock.get(sp.getUuid());
                    if (prevKey == null || prevKey != key) {
                        lastCheckedPlayerSupportBlock.put(sp.getUuid(), key);
                        BlockState ust = FractureAndSolidifier.resolveEffectiveState(world, under);
                        if (FractureAndSolidifier.isStructuralCandidate(under, ust)) {
                            pendingFEMSeeds.add(under.toImmutable());
                        }
                    }
                }
            }
        }

        if (pendingFEMSeeds.isEmpty()) return;
        List<BlockPos> seeds = new ArrayList<>(pendingFEMSeeds);
        pendingFEMSeeds.clear();
        Set<BlockPos> visited = new HashSet<>();
        org.joml.Vector3d wind = VerletClothAndWeatherSolver.getCurrentSurfaceWindMs();
        for (BlockPos seed : seeds) {
            if (!visited.contains(seed)) {
                FractureAndSolidifier.evaluateAndCollapseStructure(world, seed, null, 0.0, wind, visited, true);
            }
        }
    }

    public String triggerBlocksworthDemolition(ServerWorld world, BlockPos blastPos, double blastRadius) {
        return FractureAndSolidifier.triggerExplosionWithFEM(
                world,
                blastPos,
                blastRadius,
                VerletClothAndWeatherSolver.getCurrentSurfaceWindMs()
        );
    }

`;

src = src.slice(0, startDemIdx) + modularBridgeMethods + src.slice(endDemIdx);

src = src.replace(
  'rewindAllBlueprintsAndFloods(ow);\n                    performFullCleanRepair(ow);',
  'FractureAndSolidifier.rewindAllBlueprints(ow);\n                    rewindAllBlueprintsAndFloods(ow);\n                    performFullCleanRepair(ow);'
);
src = src.replace(
  'GeoStructuralPhysicsEngine.detachBlockAsLiveRigidBody(world, supportPos, 0.0, -0.6, 0.0);',
  'pendingFEMSeeds.add(supportPos.toImmutable());'
);

const oldRenderAnchor = '        // 2. Render 96m Distant 3D Crimson Tunnel Emergency Strobe on damaged/flooded sectors!';
const newRenderAnchor = `        // 1B. Render Continuous 3D Inclined Columns, Smoothly Curved Cantilevers, Monolithic Rigid Bodies & OBB Wireframe
        ProPhysicsRenderer.renderAll(ctx);

        // 2. Render 96m Distant 3D Crimson Tunnel Emergency Strobe on damaged/flooded sectors!`;
if (!src.includes(oldRenderAnchor)) { console.error('oldRenderAnchor not found'); process.exit(1); }
src = src.replace(oldRenderAnchor, newRenderAnchor);

fs.writeFileSync('/var/tmp/mcbuild/LivePatchV78L.java', src, 'utf8');
console.log('Generated /var/tmp/mcbuild/LivePatchV78L.java (' + src.length + ' chars)');

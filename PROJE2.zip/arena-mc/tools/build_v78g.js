const fs = require('fs');

let src = fs.readFileSync('/var/tmp/mcbuild/LivePatchV78F.java', 'utf8');
src = src.replace(/LivePatchV78F/g, 'LivePatchV78G');
src = src.replace('"v7.8.0F-mtr-pids-board-and-gui"', '"v7.8.0G-haubna-10of10-multiphysics-and-mtr-pids"');

const physicsImports = `
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.block.enums.BlockHalf;
import net.minecraft.block.enums.SlabType;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.Properties;
import net.minecraft.state.property.Property;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.math.MathHelper;
import org.joml.Quaternionf;
`;
src = src.replace('import net.minecraft.util.math.RotationAxis;', 'import net.minecraft.util.math.RotationAxis;\n' + physicsImports);

const extraFields = `
    // ==================== 10/10 HAUBNA-INSPIRED MULTIPHYSICS & TRUE STATICS FIELDS ====================
    public enum MaterialKind {
        GRANULAR(1650.0, 0, 0, 0.05, 0.68, false),
        FOLIAGE_LIGHT(320.0, 2, 4, 0.12, 0.72, false),
        TIMBER(640.0, 6, 15, 0.28, 0.58, false),
        BRITTLE_GLASS_ICE(2400.0, 2, 5, 0.08, 0.22, true),
        MASONRY_STONE(2400.0, 4, 13, 0.14, 0.76, false),
        STRUCTURAL_STEEL(7850.0, 9, 24, 0.22, 0.48, false);

        public final double densityKgM3;
        public final int maxCantileverM;
        public final int maxArchSpanM;
        public final double restitution;
        public final double friction;
        public final boolean shattersOnImpact;

        MaterialKind(double densityKgM3, int maxCantileverM, int maxArchSpanM,
                     double restitution, double friction, boolean shattersOnImpact) {
            this.densityKgM3 = densityKgM3;
            this.maxCantileverM = maxCantileverM;
            this.maxArchSpanM = maxArchSpanM;
            this.restitution = restitution;
            this.friction = friction;
            this.shattersOnImpact = shattersOnImpact;
        }
    }

    private static final class TrueCompoundBody {
        final String blueprintId;
        final List<GeoStructuralPhysicsEngine.RelBlock> voxels;
        final List<GeoStructuralPhysicsEngine.RelBlock> hullVoxels;
        final double massKg;
        final double invMass;
        final double ixx, iyy, izz;
        final double invIxx, invIyy, invIzz;
        final double avgDensity;
        int delayTicks;
        double px, py, pz;
        double prevPx, prevPy, prevPz;
        double vx, vy, vz;
        double wx, wy, wz;
        final Quaternionf quat = new Quaternionf();
        final Quaternionf prevQuat = new Quaternionf();
        int ageTicks = 0;
        int lowEnergyTicks = 0;
        boolean splashedWater = false;

        TrueCompoundBody(String blueprintId, double cx, double cy, double cz,
                         List<GeoStructuralPhysicsEngine.RelBlock> voxels,
                         double massKg, double ixx, double iyy, double izz,
                         int delayTicks, double vx, double vy, double vz, double wx, double wy, double wz) {
            this.blueprintId = blueprintId;
            this.voxels = voxels;
            this.hullVoxels = new ArrayList<>();
            int stride = Math.max(1, voxels.size() / 28);
            for (int i = 0; i < voxels.size(); i += stride) {
                this.hullVoxels.add(voxels.get(i));
            }
            this.massKg = Math.max(150.0, massKg);
            this.invMass = 1.0 / this.massKg;
            this.ixx = Math.max(40.0, ixx);
            this.iyy = Math.max(40.0, iyy);
            this.izz = Math.max(40.0, izz);
            this.invIxx = 1.0 / this.ixx;
            this.invIyy = 1.0 / this.iyy;
            this.invIzz = 1.0 / this.izz;
            this.avgDensity = this.massKg / Math.max(1, voxels.size());
            this.delayTicks = delayTicks;
            this.px = cx; this.py = cy; this.pz = cz;
            this.prevPx = cx; this.prevPy = cy; this.prevPz = cz;
            this.vx = vx; this.vy = vy; this.vz = vz;
            this.wx = wx; this.wy = wy; this.wz = wz;
        }
    }

    private static final class MicroVoxelShard {
        final BlockState state;
        final float scale;
        final double densityKgM3;
        final double restitution;
        double px, py, pz;
        double prevPx, prevPy, prevPz;
        double vx, vy, vz;
        double wx, wy, wz;
        final Quaternionf quat = new Quaternionf();
        final Quaternionf prevQuat = new Quaternionf();
        int age = 0;
        final int maxAge;

        MicroVoxelShard(BlockState state, float scale, double densityKgM3, double restitution,
                        double x, double y, double z, double vx, double vy, double vz,
                        double wx, double wy, double wz, int maxAge) {
            this.state = state;
            this.scale = scale;
            this.densityKgM3 = densityKgM3;
            this.restitution = restitution;
            this.px = this.prevPx = x;
            this.py = this.prevPy = y;
            this.pz = this.prevPz = z;
            this.vx = vx; this.vy = vy; this.vz = vz;
            this.wx = wx; this.wy = wy; this.wz = wz;
            this.maxAge = maxAge;
        }
    }

    private static final class WaterRippleRing {
        final double x, y, z;
        final float maxRadius;
        final int maxAge;
        int age = 0;

        WaterRippleRing(double x, double y, double z, float maxRadius, int maxAge) {
            this.x = x; this.y = y; this.z = z;
            this.maxRadius = maxRadius;
            this.maxAge = maxAge;
        }
    }

    private static final class VolumetricSmokePuff {
        double px, py, pz;
        double prevPx, prevPy, prevPz;
        double vx, vy, vz;
        float size;
        float heat;
        int age = 0;
        final int maxAge;

        VolumetricSmokePuff(double x, double y, double z, double vx, double vy, double vz, float size, float heat, int maxAge) {
            this.px = this.prevPx = x;
            this.py = this.prevPy = y;
            this.pz = this.prevPz = z;
            this.vx = vx; this.vy = vy; this.vz = vz;
            this.size = size;
            this.heat = heat;
            this.maxAge = maxAge;
        }
    }

    private final List<TrueCompoundBody> trueCompounds = new CopyOnWriteArrayList<>();
    private final List<MicroVoxelShard> microShards = new CopyOnWriteArrayList<>();
    private final List<WaterRippleRing> waterRipples = new CopyOnWriteArrayList<>();
    private final List<VolumetricSmokePuff> smokePuffs = new CopyOnWriteArrayList<>();
    private final Map<GeoStructuralPhysicsEngine.PhysicsRigidBody, String> bodyBlueprintBind = new ConcurrentHashMap<>();
    private final Set<BlockPos> pendingStructuralChecks = ConcurrentHashMap.newKeySet();
    private volatile double physicsTimeScale = 1.0;
    private boolean autoScannedNearbyCantilevers = false;
`;

src = src.replace('    private Identifier texBoardAtlasId = null;', extraFields + '\n    private Identifier texBoardAtlasId = null;');

const oldInstallHooks = '    private void ensureServerPlacementCallbacks() {';
const newInstallHooks = `    private void installBlockBreakPhysicsHook() {
        System.getProperties().put("arena.block_break_delegate",
                (PlayerBlockBreakEvents.After) (world, player, pos, state, blockEntity) -> {
                    if (world instanceof ServerWorld sw && pos.getY() >= 61 && !isProtectedMetroZone(pos, state)) {
                        spawnCrumbledMicroVoxels(sw, pos, state, 10, 2.6);
                        for (Direction d : Direction.values()) {
                            BlockPos nb = pos.offset(d);
                            BlockState nst = sw.getBlockState(nb);
                            if (!nst.isAir() && !isNaturalGroundMaterial(nst) && !isProtectedMetroZone(nb, nst)) {
                                pendingStructuralChecks.add(nb.toImmutable());
                            }
                        }
                    }
                });
        if (!Boolean.getBoolean("arena.block_break_hook_installed")) {
            System.setProperty("arena.block_break_hook_installed", "true");
            PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
                Object d = System.getProperties().get("arena.block_break_delegate");
                if (d instanceof PlayerBlockBreakEvents.After cb) {
                    cb.afterBlockBreak(world, player, pos, state, blockEntity);
                }
            });
        }
    }

    private void ensureServerPlacementCallbacks() {
        installBlockBreakPhysicsHook();`;
if (!src.includes(oldInstallHooks)) { console.error('ensureServerPlacementCallbacks not found'); process.exit(1); }
src = src.replace(oldInstallHooks, newInstallHooks);

const oldTickIntercept = '        interceptExplosionsForBlocksworthCollapse(world);\n        tickStagedClusters(world);\n        tickRigidBodiesAndSolidifyMound(world);';
const newTickIntercept = `        interceptExplosionsForBlocksworthCollapse(world);
        processPendingStructuralIntegrityChecks(world);
        tickTrueCompoundBodies(world);
        tickStagedClusters(world);
        tickRigidBodiesAndSolidifyMound(world);
        tickHaubnaMultiPhysicsEffects(world);`;
if (!src.includes(oldTickIntercept)) { console.error('oldTickIntercept not found'); process.exit(1); }
src = src.replace(oldTickIntercept, newTickIntercept);

const oldNatGround = `    private boolean isNaturalGroundMaterial(BlockState st) {
        return st.isOf(Blocks.GRASS_BLOCK) || st.isOf(Blocks.DIRT) || st.isOf(Blocks.COARSE_DIRT)
                || st.isOf(Blocks.PODZOL) || st.isOf(Blocks.STONE) || st.isOf(Blocks.DEEPSLATE)
                || st.isOf(Blocks.GRAVEL) || st.isOf(Blocks.SAND) || st.isOf(Blocks.WATER)
                || st.isIn(BlockTags.LEAVES);
    }`;
const newNatGround = `    private boolean isNaturalGroundMaterial(BlockState st) {
        return st.isOf(Blocks.GRASS_BLOCK) || st.isOf(Blocks.DIRT) || st.isOf(Blocks.COARSE_DIRT)
                || st.isOf(Blocks.PODZOL) || st.isOf(Blocks.STONE) || st.isOf(Blocks.DEEPSLATE)
                || st.isOf(Blocks.SANDSTONE) || st.isOf(Blocks.GRAVEL) || st.isOf(Blocks.SAND)
                || st.isOf(Blocks.CLAY) || st.isIn(BlockTags.LEAVES);
    }`;
if (!src.includes(oldNatGround)) { console.error('oldNatGround not found'); process.exit(1); }
src = src.replace(oldNatGround, newNatGround);

src = src.replace(
  'if (id.startsWith("mtr:") || id.startsWith("arena_ai_bridge:") || st.isOf(Blocks.BEDROCK) || st.isOf(Blocks.TNT)) {',
  'if (id.startsWith("mtr:") || id.startsWith("arena_ai_bridge:") || st.isOf(Blocks.BEDROCK)) {'
);
src = src.replace(
  '        activeClusters.clear();',
  '        activeClusters.clear();\n        trueCompounds.clear();\n        microShards.clear();\n        smokePuffs.clear();\n        waterRipples.clear();\n        bodyBlueprintBind.clear();'
);

const startDemolishIdx = src.indexOf('    public String triggerBlocksworthDemolition(ServerWorld world, BlockPos blastPos, double blastRadius) {');
const endRigidIdx = src.indexOf('    private void tickSafeEntityImpacts(ServerWorld world) {');
if (startDemolishIdx < 0 || endRigidIdx < 0) {
  console.error('Could not locate physics replacement markers:', startDemolishIdx, endRigidIdx);
  process.exit(1);
}

const replacementPhysicsBlock = `
    // ==================== 10/10 CONSTITUTIVE MATERIAL & BLOCKSTATE SERIALIZATION ====================
    public static MaterialKind classifyMaterial(BlockState st) {
        if (st == null || st.isAir()) return MaterialKind.FOLIAGE_LIGHT;
        if (st.isIn(BlockTags.SAND) || st.isOf(Blocks.GRAVEL) || st.isIn(BlockTags.CONCRETE_POWDER)) {
            return MaterialKind.GRANULAR;
        }
        if (st.isIn(BlockTags.IMPERMEABLE) || st.isIn(BlockTags.ICE)
                || Registries.BLOCK.getId(st.getBlock()).getPath().contains("glass")) {
            return MaterialKind.BRITTLE_GLASS_ICE;
        }
        if (st.isIn(BlockTags.ANVIL) || st.isOf(Blocks.IRON_BLOCK) || st.isOf(Blocks.COPPER_BLOCK)
                || st.isOf(Blocks.NETHERITE_BLOCK) || st.isOf(Blocks.OBSIDIAN)
                || st.isOf(Blocks.IRON_BARS) || st.isOf(Blocks.CHAIN)) {
            return MaterialKind.STRUCTURAL_STEEL;
        }
        if (st.isIn(BlockTags.LOGS) || st.isIn(BlockTags.PLANKS) || st.isIn(BlockTags.WOODEN_SLABS)
                || st.isIn(BlockTags.WOODEN_STAIRS) || st.isIn(BlockTags.FENCES)
                || st.isIn(BlockTags.WOODEN_DOORS) || st.isIn(BlockTags.WOODEN_TRAPDOORS)) {
            return MaterialKind.TIMBER;
        }
        if (st.isIn(BlockTags.LEAVES) || st.isIn(BlockTags.WOOL) || st.isIn(BlockTags.SNOW)
                || st.isOf(Blocks.HAY_BLOCK)) {
            return MaterialKind.FOLIAGE_LIGHT;
        }
        return MaterialKind.MASONRY_STONE;
    }

    public static double computeBlockDensityKgM3(BlockState st) {
        if (st.isIn(BlockTags.ICE)) return 917.0;
        MaterialKind mk = classifyMaterial(st);
        double factor = (st.getBlock() instanceof SlabBlock && st.contains(Properties.SLAB_TYPE)
                && st.get(Properties.SLAB_TYPE) != SlabType.DOUBLE) ? 0.52 : 1.0;
        return mk.densityKgM3 * factor;
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static String serializeBlockStateFull(BlockState state) {
        StringBuilder sb = new StringBuilder(Registries.BLOCK.getId(state.getBlock()).toString());
        if (!state.getEntries().isEmpty()) {
            sb.append('[');
            boolean first = true;
            for (Map.Entry<Property<?>, Comparable<?>> entry : state.getEntries().entrySet()) {
                if (!first) sb.append(',');
                first = false;
                Property prop = entry.getKey();
                sb.append(prop.getName()).append('=').append(prop.name(entry.getValue()));
            }
            sb.append(']');
        }
        return sb.toString();
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static BlockState deserializeBlockStateFull(String serialized) {
        if (serialized == null || serialized.isBlank()) return Blocks.AIR.getDefaultState();
        int bracket = serialized.indexOf('[');
        String blockId = bracket >= 0 ? serialized.substring(0, bracket) : serialized;
        Block block = Registries.BLOCK.get(new Identifier(blockId));
        BlockState state = block.getDefaultState();
        if (bracket >= 0 && serialized.endsWith("]")) {
            String propsPart = serialized.substring(bracket + 1, serialized.length() - 1);
            StateManager<Block, BlockState> sm = block.getStateManager();
            for (String pair : propsPart.split(",")) {
                int eq = pair.indexOf('=');
                if (eq <= 0) continue;
                String k = pair.substring(0, eq).trim();
                String v = pair.substring(eq + 1).trim();
                Property prop = sm.getProperty(k);
                if (prop != null) {
                    java.util.Optional<Comparable> parsed = prop.parse(v);
                    if (parsed.isPresent()) {
                        state = state.with(prop, parsed.get());
                    }
                }
            }
        }
        return state;
    }

    private boolean isTrueSolidFoundation(ServerWorld world, BlockPos supportPos, Set<BlockPos> structureSet) {
        if (structureSet.contains(supportPos)) return false;
        if (!world.isChunkLoaded(supportPos.getX() >> 4, supportPos.getZ() >> 4)) return true;
        BlockState below = world.getBlockState(supportPos);
        if (below.isAir() || !below.getFluidState().isEmpty()) return false;
        if (below.isIn(BlockTags.LEAVES) || below.isIn(BlockTags.FLOWERS) || below.isReplaceable()) return false;
        if (below.isOf(Blocks.SNOW) && below.contains(SnowBlock.LAYERS) && below.get(SnowBlock.LAYERS) < 8) return false;
        return !below.getCollisionShape(world, supportPos).isEmpty();
    }

    public static BlockState rotateBlockStateByQuaternion(BlockState state, Quaternionf q, boolean underwater) {
        if (state == null || state.isAir()) return state;
        Vector3f fwd = new Vector3f(0f, 0f, 1f);
        Vector3f up  = new Vector3f(0f, 1f, 0f);
        q.transform(fwd);
        q.transform(up);

        double yawDeg = Math.toDegrees(Math.atan2(-fwd.x, fwd.z));
        int quarterTurns = ((int) Math.round(yawDeg / 90.0)) & 3;
        BlockRotation rot = switch (quarterTurns) {
            case 1 -> BlockRotation.CLOCKWISE_90;
            case 2 -> BlockRotation.CLOCKWISE_180;
            case 3 -> BlockRotation.COUNTERCLOCKWISE_90;
            default -> BlockRotation.NONE;
        };
        BlockState out = state.rotate(rot);

        if (out.contains(Properties.AXIS) && Math.abs(up.y) < 0.45f) {
            Direction.Axis newAxis = (Math.abs(up.x) > Math.abs(up.z)) ? Direction.Axis.X : Direction.Axis.Z;
            out = out.with(Properties.AXIS, newAxis);
        }
        if (up.y < -0.35f) {
            if (out.contains(Properties.BLOCK_HALF)) {
                BlockHalf cur = out.get(Properties.BLOCK_HALF);
                out = out.with(Properties.BLOCK_HALF, cur == BlockHalf.TOP ? BlockHalf.BOTTOM : BlockHalf.TOP);
            }
            if (out.contains(Properties.SLAB_TYPE) && out.get(Properties.SLAB_TYPE) != SlabType.DOUBLE) {
                SlabType cur = out.get(Properties.SLAB_TYPE);
                out = out.with(Properties.SLAB_TYPE, cur == SlabType.TOP ? SlabType.BOTTOM : SlabType.TOP);
            }
        }
        if (out.contains(Properties.WATERLOGGED)) {
            out = out.with(Properties.WATERLOGGED, underwater);
        }
        return out;
    }

    private SavedStructureSnapshot getOrCreateBlueprintNear(BlockPos origin) {
        for (SavedStructureSnapshot ex : blueprints) {
            if (Math.abs(ex.center.getX() - origin.getX()) <= 42 && Math.abs(ex.center.getZ() - origin.getZ()) <= 42) {
                return ex;
            }
        }
        SavedStructureSnapshot snap = new SavedStructureSnapshot(origin.toImmutable());
        blueprints.add(snap);
        return snap;
    }

    private SavedStructureSnapshot findSnapshotById(String bpId) {
        if (bpId != null) {
            for (SavedStructureSnapshot s : blueprints) {
                String id = "bp_" + s.center.getX() + "_" + s.center.getZ();
                if (bpId.equals(id)) return s;
            }
        }
        return blueprints.isEmpty() ? null : blueprints.get(blueprints.size() - 1);
    }

    // ==================== TRUE STRUCTURAL STATICS (CANTILEVER BENDING vs TWO-PIER ARCH!) ====================
    private void processPendingStructuralIntegrityChecks(ServerWorld world) {
        if (!autoScannedNearbyCantilevers && (serverTicks % 10) == 4) {
            for (ServerPlayerEntity sp : world.getPlayers()) {
                if (sp.getY() >= 62.0) {
                    autoScannedNearbyCantilevers = true;
                    BlockPos pCenter = sp.getBlockPos();
                    BlockPos.Mutable mp = new BlockPos.Mutable();
                    outer:
                    for (int dx = -28; dx <= 28; dx += 2) {
                        for (int dz = -28; dz <= 28; dz += 2) {
                            for (int y = 62; y <= 76; y++) {
                                mp.set(pCenter.getX() + dx, y, pCenter.getZ() + dz);
                                if (!world.isChunkLoaded(mp.getX() >> 4, mp.getZ() >> 4)) continue;
                                BlockState st = world.getBlockState(mp);
                                if (!st.isAir() && !st.getFluidState().isIn(FluidTags.WATER)
                                        && !isNaturalGroundMaterial(st) && !isProtectedMetroZone(mp, st)) {
                                    pendingStructuralChecks.add(mp.toImmutable());
                                    break outer;
                                }
                            }
                        }
                    }
                }
            }
        }

        if (pendingStructuralChecks.isEmpty()) return;
        List<BlockPos> seeds = new ArrayList<>(pendingStructuralChecks);
        pendingStructuralChecks.clear();
        Set<BlockPos> visited = new HashSet<>();
        for (BlockPos seed : seeds) {
            if (visited.contains(seed)) continue;
            evaluateConnectedStructureStatics(world, seed, null, visited);
        }
    }

    public String triggerBlocksworthDemolition(ServerWorld world, BlockPos blastPos, double blastRadius) {
        world.playSound(null, blastPos, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.BLOCKS, 1.5f, 0.74f);
        world.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, blastPos.getX() + 0.5, blastPos.getY() + 0.5, blastPos.getZ() + 0.5, 2, 0.5, 0.5, 0.5, 0.0);
        spawnVolumetricBlastSmoke(world, blastPos.getX() + 0.5, blastPos.getY() + 0.8, blastPos.getZ() + 0.5, 26, true);

        Vec3d blastCenter = Vec3d.ofCenter(blastPos);
        for (Entity ent : world.getOtherEntities(null, new Box(blastPos).expand(blastRadius * 2.4))) {
            if (ent instanceof PlayerEntity pe && (pe.isCreative() || pe.isSpectator())) continue;
            double dist = Math.max(1.0, ent.getPos().distanceTo(blastCenter));
            if (dist <= blastRadius * 2.4) {
                Vec3d dir = ent.getPos().subtract(blastCenter).normalize();
                double imp = (2.2 * blastRadius) / (dist * dist * 0.45 + 1.0);
                ent.addVelocity(dir.x * imp, Math.min(1.1, 0.35 + imp * 0.45), dir.z * imp);
                ent.velocityModified = true;
            }
        }

        int rx = 36, rz = 36;
        int minY = Math.max(58, blastPos.getY() - 14);
        int maxY = Math.min(world.getTopY() - 1, blastPos.getY() + 84);

        List<BlockPos> structureBlocks = new ArrayList<>();
        for (int y = minY; y <= maxY; y++) {
            for (int x = blastPos.getX() - rx; x <= blastPos.getX() + rx; x++) {
                for (int z = blastPos.getZ() - rz; z <= blastPos.getZ() + rz; z++) {
                    if (!world.isChunkLoaded(x >> 4, z >> 4)) continue;
                    BlockPos p = new BlockPos(x, y, z);
                    BlockState st = world.getBlockState(p);
                    if (st.isAir() || !st.getFluidState().isEmpty() || isProtectedMetroZone(p, st)
                            || isNaturalGroundMaterial(st) || st.hasBlockEntity()) continue;
                    structureBlocks.add(p);
                }
            }
        }
        if (structureBlocks.isEmpty()) {
            return "Patlama noktasında yıkılacak yüzey yapısı bulunamadı.";
        }

        SavedStructureSnapshot snap = getOrCreateBlueprintNear(blastPos);
        String bpId = "bp_" + snap.center.getX() + "_" + snap.center.getZ();
        for (BlockPos p : structureBlocks) {
            snap.originalBlocks.putIfAbsent(p, world.getBlockState(p));
        }

        List<BlockPos> blasts = new ArrayList<>();
        blasts.add(blastPos);
        for (BlockPos p : structureBlocks) {
            if (world.getBlockState(p).isOf(Blocks.TNT)) {
                world.setBlockState(p, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);
                blasts.add(p);
                spawnVolumetricBlastSmoke(world, p.getX() + 0.5, p.getY() + 0.8, p.getZ() + 0.5, 14, true);
            }
        }

        Set<BlockPos> survivorSeeds = new HashSet<>();
        for (BlockPos p : structureBlocks) {
            BlockPos nearestB = blastPos;
            double bestD2 = p.getSquaredDistance(blastPos);
            for (BlockPos bc : blasts) {
                double d2 = p.getSquaredDistance(bc);
                if (d2 < bestD2) { bestD2 = d2; nearestB = bc; }
            }
            if (bestD2 <= blastRadius * blastRadius) {
                BlockState st = world.getBlockState(p);
                if (st.isAir()) continue;
                world.setBlockState(p, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);
                if (!isNonStructuralDecor(st)) {
                    double d = Math.max(0.8, Math.sqrt(bestD2));
                    double ux = (p.getX() - nearestB.getX()) / d;
                    double uy = (p.getY() - nearestB.getY() + 0.42) / d;
                    double uz = (p.getZ() - nearestB.getZ()) / d;
                    double spd = 10.5 / (1.0 + 0.28 * bestD2);
                    if (bestD2 < 4.5) {
                        spawnCrumbledMicroVoxels(world, p, st, 8, spd * 0.85);
                    } else if (world.random.nextFloat() < 0.72f) {
                        spawnBoundRigidBody(world, p, st, bpId, ux * spd, Math.max(0.9, uy * spd), uz * spd);
                    }
                }
            } else if (bestD2 <= (blastRadius + 3.5) * (blastRadius + 3.5)) {
                survivorSeeds.add(p);
            }
        }

        Set<BlockPos> visited = new HashSet<>();
        int totalCollapsed = 0;
        for (BlockPos seed : survivorSeeds) {
            if (!visited.contains(seed) && !world.getBlockState(seed).isAir()) {
                totalCollapsed += evaluateConnectedStructureStatics(world, seed, blastPos, visited);
            }
        }
        return String.format(Locale.US, "10/10 Yapısal Yıkım: %d blok konsol/kolon statiğiyle çöktü! (/onar ile geri sarılır)", totalCollapsed);
    }

    private int evaluateConnectedStructureStatics(ServerWorld world, BlockPos seed, BlockPos blastOrigin, Set<BlockPos> globalVisited) {
        if (!world.isChunkLoaded(seed.getX() >> 4, seed.getZ() >> 4)) return 0;
        BlockState seedSt = world.getBlockState(seed);
        if (seedSt.isAir() || !seedSt.getFluidState().isEmpty() || isNaturalGroundMaterial(seedSt) || isProtectedMetroZone(seed, seedSt)) {
            return 0;
        }

        Set<BlockPos> component = new LinkedHashSet<>();
        ArrayDeque<BlockPos> bfs = new ArrayDeque<>();
        component.add(seed.toImmutable());
        bfs.add(seed.toImmutable());

        while (!bfs.isEmpty() && component.size() < 3200) {
            BlockPos cur = bfs.poll();
            for (Direction d : Direction.values()) {
                BlockPos nb = cur.offset(d);
                if (Math.abs(nb.getX() - seed.getX()) > 38 || Math.abs(nb.getZ() - seed.getZ()) > 38) continue;
                if (nb.getY() < 58 || nb.getY() >= world.getTopY() - 1) continue;
                if (component.contains(nb)) continue;
                if (!world.isChunkLoaded(nb.getX() >> 4, nb.getZ() >> 4)) continue;
                BlockState nst = world.getBlockState(nb);
                if (nst.isAir() || !nst.getFluidState().isEmpty() || nst.hasBlockEntity()) continue;
                if (isProtectedMetroZone(nb, nst) || isNaturalGroundMaterial(nst)) continue;
                BlockPos imm = nb.toImmutable();
                component.add(imm);
                bfs.add(imm);
            }
        }
        globalVisited.addAll(component);
        if (component.isEmpty()) return 0;

        int minY = Integer.MAX_VALUE, maxY = Integer.MIN_VALUE;
        Map<Integer, Integer> countByY = new HashMap<>();
        for (BlockPos p : component) {
            minY = Math.min(minY, p.getY());
            maxY = Math.max(maxY, p.getY());
            countByY.merge(p.getY(), 1, Integer::sum);
        }
        int buckleY = Integer.MAX_VALUE;
        if (maxY - minY >= 6 && blastOrigin != null) {
            int peakArea = 1;
            for (int c : countByY.values()) peakArea = Math.max(peakArea, c);
            for (int y = minY; y <= maxY - 2; y++) {
                if (countByY.getOrDefault(y, 0) < peakArea * 0.48) {
                    buckleY = y;
                    break;
                }
            }
        }

        List<BlockPos> anchors = new ArrayList<>();
        for (BlockPos p : component) {
            if (p.getY() >= buckleY) continue;
            boolean supportedBelow = isTrueSolidFoundation(world, p.down(), component);
            boolean supportedBank = false;
            if (!supportedBelow) {
                for (Direction hd : Direction.Type.HORIZONTAL) {
                    BlockPos side = p.offset(hd);
                    if (isTrueSolidFoundation(world, side, component) && isTrueSolidFoundation(world, side.down(), component)) {
                        supportedBank = true;
                        break;
                    }
                }
            }
            if (supportedBelow || supportedBank) {
                anchors.add(p);
            }
        }

        List<List<BlockPos>> piers = new ArrayList<>();
        Set<BlockPos> assignedAnchors = new HashSet<>();
        for (BlockPos a : anchors) {
            if (!assignedAnchors.add(a)) continue;
            List<BlockPos> pier = new ArrayList<>();
            ArrayDeque<BlockPos> pq = new ArrayDeque<>();
            pier.add(a);
            pq.add(a);
            while (!pq.isEmpty()) {
                BlockPos ca = pq.poll();
                for (BlockPos other : anchors) {
                    if (!assignedAnchors.contains(other)
                            && Math.abs(other.getX() - ca.getX()) <= 4
                            && Math.abs(other.getZ() - ca.getZ()) <= 4
                            && Math.abs(other.getY() - ca.getY()) <= 5) {
                        assignedAnchors.add(other);
                        pier.add(other);
                        pq.add(other);
                    }
                }
            }
            piers.add(pier);
        }

        double[] pierCx = new double[piers.size()];
        double[] pierCz = new double[piers.size()];
        for (int i = 0; i < piers.size(); i++) {
            double sx = 0, sz = 0;
            for (BlockPos p : piers.get(i)) { sx += p.getX(); sz += p.getZ(); }
            pierCx[i] = sx / piers.get(i).size();
            pierCz[i] = sz / piers.get(i).size();
        }

        Map<BlockPos, int[]> distToPiers = new HashMap<>(component.size());
        for (BlockPos p : component) {
            int[] arr = new int[piers.size()];
            Arrays.fill(arr, 9999);
            distToPiers.put(p, arr);
        }
        for (int pi = 0; pi < piers.size(); pi++) {
            ArrayDeque<BlockPos> q = new ArrayDeque<>();
            for (BlockPos a : piers.get(pi)) {
                distToPiers.get(a)[pi] = 0;
                q.add(a);
            }
            while (!q.isEmpty()) {
                BlockPos cur = q.poll();
                int cd = distToPiers.get(cur)[pi];
                if (cd >= 30) continue;
                for (Direction d : Direction.values()) {
                    BlockPos nb = cur.offset(d);
                    if (nb.getY() >= buckleY) continue;
                    int[] ndArr = distToPiers.get(nb);
                    if (ndArr != null && cd + 1 < ndArr[pi]) {
                        ndArr[pi] = cd + 1;
                        q.add(nb);
                    }
                }
            }
        }

        Set<BlockPos> stableBlocks = new HashSet<>();
        for (BlockPos p : component) {
            if (p.getY() >= buckleY || piers.isEmpty()) continue;
            BlockState st = world.getBlockState(p);
            MaterialKind mat = classifyMaterial(st);
            int[] dArr = distToPiers.get(p);

            if (mat == MaterialKind.GRANULAR) {
                if (anchors.contains(p) || stableBlocks.contains(p.down())) {
                    stableBlocks.add(p);
                }
                continue;
            }

            int bestP1 = -1, d1 = 9999;
            for (int pi = 0; pi < piers.size(); pi++) {
                if (dArr[pi] < d1) { d1 = dArr[pi]; bestP1 = pi; }
            }
            if (bestP1 < 0 || d1 >= 9999) continue;

            double vx1 = p.getX() - pierCx[bestP1];
            double vz1 = p.getZ() - pierCz[bestP1];
            double horizOverhangM = Math.hypot(vx1, vz1);

            int hSec = 1;
            if (component.contains(p.up())) hSec++;
            if (component.contains(p.down())) hSec++;

            boolean hasTwoSidedArchSupport = false;
            for (int pi = 0; pi < piers.size(); pi++) {
                if (pi == bestP1 || dArr[pi] > mat.maxArchSpanM + 4) continue;
                double vx2 = p.getX() - pierCx[pi];
                double vz2 = p.getZ() - pierCz[pi];
                double dot = vx1 * vx2 + vz1 * vz2;
                if (dot <= 1.5 && (d1 + dArr[pi]) <= mat.maxArchSpanM * 2) {
                    hasTwoSidedArchSupport = true;
                    break;
                }
            }

            if (hasTwoSidedArchSupport) {
                if (horizOverhangM <= mat.maxArchSpanM) {
                    stableBlocks.add(p);
                }
            } else {
                double maxCantM = mat.maxCantileverM * Math.sqrt(Math.min(1.75, 0.72 + 0.32 * hSec));
                if (horizOverhangM <= maxCantM) {
                    stableBlocks.add(p);
                }
            }
        }

        boolean grew = true;
        while (grew) {
            grew = false;
            for (BlockPos p : component) {
                if (p.getY() < buckleY && !stableBlocks.contains(p) && stableBlocks.contains(p.down())) {
                    stableBlocks.add(p);
                    grew = true;
                }
            }
        }

        List<BlockPos> failing = new ArrayList<>();
        for (BlockPos p : component) {
            if (!stableBlocks.contains(p)) failing.add(p);
        }
        if (failing.isEmpty()) return 0;

        SavedStructureSnapshot snap = getOrCreateBlueprintNear(seed);
        String bpId = "bp_" + snap.center.getX() + "_" + snap.center.getZ();
        for (BlockPos p : component) {
            snap.originalBlocks.putIfAbsent(p, world.getBlockState(p));
        }

        double hingeX = seed.getX() + 0.5, hingeY = seed.getY() + 0.5, hingeZ = seed.getZ() + 0.5;
        int hingeCount = 0;
        double hSumX = 0, hSumY = 0, hSumZ = 0;
        for (BlockPos fp : failing) {
            for (Direction d : Direction.values()) {
                BlockPos nb = fp.offset(d);
                if (stableBlocks.contains(nb)) {
                    hSumX += nb.getX() + 0.5; hSumY += nb.getY() + 0.5; hSumZ += nb.getZ() + 0.5;
                    hingeCount++;
                    spawnCrumbledMicroVoxels(world, fp, world.getBlockState(fp), 5, 1.8);
                    break;
                }
            }
        }
        if (hingeCount > 0) {
            hingeX = hSumX / hingeCount; hingeY = hSumY / hingeCount; hingeZ = hSumZ / hingeCount;
        }
        world.playSound(null, BlockPos.ofFloored(hingeX, hingeY, hingeZ),
                SoundEvents.BLOCK_STONE_BREAK, SoundCategory.BLOCKS, 1.35f, 0.58f);
        spawnVolumetricBlastSmoke(world, hingeX, hingeY, hingeZ, 12, false);

        Map<Long, List<BlockPos>> clusterCells = new LinkedHashMap<>();
        for (BlockPos p : failing) {
            BlockState st = world.getBlockState(p);
            if (isNonStructuralDecor(st)) {
                world.setBlockState(p, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);
                continue;
            }
            int cx = Math.floorDiv(p.getX(), 5);
            int cy = Math.floorDiv(p.getY(), 5);
            int cz = Math.floorDiv(p.getZ(), 5);
            long key = (((long) (cy & 0x3FF)) << 40) | (((long) (cx & 0xFFFFF)) << 20) | (cz & 0xFFFFFL);
            clusterCells.computeIfAbsent(key, k -> new ArrayList<>()).add(p);
        }

        for (List<BlockPos> cell : clusterCells.values()) {
            if (cell.size() == 1) {
                BlockPos p = cell.get(0);
                BlockState st = world.getBlockState(p);
                world.setBlockState(p, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);
                spawnBoundRigidBody(world, p, st, bpId,
                        (world.random.nextDouble() - 0.5) * 0.8, -0.4, (world.random.nextDouble() - 0.5) * 0.8);
                continue;
            }

            double totalM = 0.0, mx = 0.0, my = 0.0, mz = 0.0;
            List<BlockState> capturedStates = new ArrayList<>(cell.size());
            for (BlockPos p : cell) {
                BlockState st = world.getBlockState(p);
                capturedStates.add(st);
                double m = computeBlockDensityKgM3(st);
                totalM += m;
                mx += m * (p.getX() + 0.5);
                my += m * (p.getY() + 0.5);
                mz += m * (p.getZ() + 0.5);
                world.setBlockState(p, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);
            }
            double cmX = mx / totalM, cmY = my / totalM, cmZ = mz / totalM;
            int refX = (int) Math.floor(cmX), refY = (int) Math.floor(cmY), refZ = (int) Math.floor(cmZ);

            double ixx = 0.0, iyy = 0.0, izz = 0.0;
            List<GeoStructuralPhysicsEngine.RelBlock> rels = new ArrayList<>(cell.size());
            for (int i = 0; i < cell.size(); i++) {
                BlockPos p = cell.get(i);
                BlockState st = capturedStates.get(i);
                double m = computeBlockDensityKgM3(st);
                double rx = (p.getX() + 0.5) - cmX;
                double ry = (p.getY() + 0.5) - cmY;
                double rz = (p.getZ() + 0.5) - cmZ;
                ixx += m * (ry * ry + rz * rz + (1.0 / 6.0));
                iyy += m * (rx * rx + rz * rz + (1.0 / 6.0));
                izz += m * (rx * rx + ry * ry + (1.0 / 6.0));
                rels.add(new GeoStructuralPhysicsEngine.RelBlock(p.getX() - refX, p.getY() - refY, p.getZ() - refZ, st));
            }

            double distFromHinge = Math.hypot(cmX - hingeX, cmZ - hingeZ);
            int delay = Math.min(18, (int) Math.round(distFromHinge * 0.45));

            double armX = cmX - hingeX;
            double armZ = cmZ - hingeZ;
            double armLen = Math.max(1.0, Math.hypot(armX, armZ));
            double wx = (armZ / armLen) * 0.55 + (world.random.nextDouble() - 0.5) * 0.18;
            double wy = (world.random.nextDouble() - 0.5) * 0.12;
            double wz = (-armX / armLen) * 0.55 + (world.random.nextDouble() - 0.5) * 0.18;
            double vx = (armX / armLen) * 0.35;
            double vz = (armZ / armLen) * 0.35;

            trueCompounds.add(new TrueCompoundBody(bpId, refX + 0.5, refY + 0.5, refZ + 0.5,
                    rels, totalM, ixx, iyy, izz, delay, vx, -0.25, vz, wx, wy, wz));
        }

        GeoStructuralPhysicsEngine.ACTIVE_ALERTS.removeIf(a -> a.id.startsWith("collapse_"));
        GeoStructuralPhysicsEngine.ACTIVE_ALERTS.add(0, new GeoStructuralPhysicsEngine.StructuralAlert(
                "collapse_" + seed.getX() + "_" + seed.getZ(),
                "CANTILEVER_COLLAPSE",
                String.format(Locale.US, "Statik Konsol/Kemer Kırılması (%d blok, %d rijit gövde — /onar ile geri sar)",
                        failing.size(), clusterCells.size()),
                seed, 0.94
        ));
        return failing.size();
    }

    private void tickStagedClusters(ServerWorld world) {
        // Legacy cluster list kept empty; all multi-block bodies run in tickTrueCompoundBodies!
        activeClusters.clear();
    }

    private void tickTrueCompoundBodies(ServerWorld world) {
        if (trueCompounds.isEmpty()) return;
        final double dtSub = (0.05 * physicsTimeScale) / 4.0;
        Vector3f rWorld = new Vector3f();
        BlockPos.Mutable mp = new BlockPos.Mutable();

        for (TrueCompoundBody cb : trueCompounds) {
            cb.prevPx = cb.px; cb.prevPy = cb.py; cb.prevPz = cb.pz;
            cb.prevQuat.set(cb.quat);
            if (cb.delayTicks > 0) {
                cb.delayTicks--;
                continue;
            }
            cb.ageTicks++;

            boolean hadHardImpact = false;
            double peakImpactVn = 0.0;

            for (int step = 0; step < 4; step++) {
                int subCount = 0;
                double waterTopY = -999.0;
                for (GeoStructuralPhysicsEngine.RelBlock hv : cb.hullVoxels) {
                    rWorld.set(hv.dx(), hv.dy(), hv.dz());
                    cb.quat.transform(rWorld);
                    int wx = (int) Math.floor(cb.px + rWorld.x);
                    int wy = (int) Math.floor(cb.py + rWorld.y);
                    int wz = (int) Math.floor(cb.pz + rWorld.z);
                    if (world.isChunkLoaded(wx >> 4, wz >> 4)) {
                        FluidState fs = world.getFluidState(mp.set(wx, wy, wz));
                        if (fs.isIn(FluidTags.WATER)) {
                            subCount++;
                            waterTopY = Math.max(waterTopY, wy + fs.getHeight(world, mp));
                        }
                    }
                }
                double subFrac = cb.hullVoxels.isEmpty() ? 0.0 : ((double) subCount / cb.hullVoxels.size());

                if (subFrac > 0.08 && !cb.splashedWater && cb.vy < -1.8) {
                    cb.splashedWater = true;
                    spawnWaterSplashAndRipple(world, cb.px, waterTopY > 0 ? waterTopY : cb.py, cb.pz,
                            Math.min(5.5f, 1.8f + (float) Math.abs(cb.vy) * 0.35f), Math.min(35, cb.voxels.size() * 2));
                }

                double buoyRatio = subFrac * (1000.0 / Math.max(250.0, cb.avgDensity));
                cb.vy -= 9.80665 * (1.0 - buoyRatio) * dtSub;

                double linDrag = subFrac > 0.05 ? (1.0 - 0.16 * subFrac) : 0.996;
                double angDrag = subFrac > 0.05 ? (1.0 - 0.18 * subFrac) : 0.990;
                cb.vx *= linDrag; cb.vy *= linDrag; cb.vz *= linDrag;

                double gyroX = (cb.iyy - cb.izz) * cb.wy * cb.wz * cb.invIxx;
                double gyroY = (cb.izz - cb.ixx) * cb.wz * cb.wx * cb.invIyy;
                double gyroZ = (cb.ixx - cb.iyy) * cb.wx * cb.wy * cb.invIzz;
                cb.wx = (cb.wx - gyroX * dtSub) * angDrag;
                cb.wy = (cb.wy - gyroY * dtSub) * angDrag;
                cb.wz = (cb.wz - gyroZ * dtSub) * angDrag;

                cb.px += cb.vx * dtSub;
                cb.py += cb.vy * dtSub;
                cb.pz += cb.vz * dtSub;

                float hdt = (float) (0.5 * dtSub);
                float qx = cb.quat.x, qy = cb.quat.y, qz = cb.quat.z, qw = cb.quat.w;
                float owx = (float) cb.wx, owy = (float) cb.wy, owz = (float) cb.wz;
                cb.quat.set(
                        qx + hdt * (owx * qw + owy * qz - owz * qy),
                        qy + hdt * (owy * qw + owz * qx - owx * qz),
                        qz + hdt * (owz * qw + owx * qy - owy * qx),
                        qw + hdt * (-owx * qx - owy * qy - owz * qz)
                ).normalize();

                for (GeoStructuralPhysicsEngine.RelBlock hv : cb.hullVoxels) {
                    rWorld.set(hv.dx(), hv.dy(), hv.dz());
                    cb.quat.transform(rWorld);
                    double vxW = cb.px + rWorld.x;
                    double vyW = cb.py + rWorld.y - 0.45;
                    double vzW = cb.pz + rWorld.z;
                    int bx = (int) Math.floor(vxW), by = (int) Math.floor(vyW), bz = (int) Math.floor(vzW);
                    if (!world.isChunkLoaded(bx >> 4, bz >> 4)) continue;
                    BlockState hit = world.getBlockState(mp.set(bx, by, bz));
                    if (hit.isAir() || !hit.getFluidState().isEmpty() || hit.getCollisionShape(world, mp).isEmpty()) continue;

                    double topY = by + hit.getCollisionShape(world, mp).getMax(Direction.Axis.Y);
                    double pen = topY - vyW;
                    if (pen > 0.0 && pen < 1.35) {
                        cb.py += pen * 0.55;
                        double rx = rWorld.x, rz = rWorld.z;
                        double vpy = cb.vy + (cb.wz * rx - cb.wx * rz);
                        if (vpy < 0.0) {
                            peakImpactVn = Math.max(peakImpactVn, -vpy);
                            if (-vpy > 3.2) hadHardImpact = true;
                            double angTerm = (rz * rz) * cb.invIxx + (rx * rx) * cb.invIzz;
                            double rest = (-vpy < 1.0) ? 0.0 : 0.14;
                            double jn = -(1.0 + rest) * vpy / (cb.invMass + angTerm);
                            cb.vy += jn * cb.invMass;
                            cb.wx += (-rz * jn) * cb.invIxx;
                            cb.wz += ( rx * jn) * cb.invIzz;
                            cb.vx *= 0.88;
                            cb.vz *= 0.88;
                        }
                    }
                }
            }

            if (hadHardImpact && peakImpactVn > 5.2 && cb.voxels.size() > 3) {
                BlockPos ip = BlockPos.ofFloored(cb.px, cb.py, cb.pz);
                world.playSound(null, ip, SoundEvents.BLOCK_DEEPSLATE_BRICKS_BREAK, SoundCategory.BLOCKS, 1.0f, 0.65f);
                spawnVolumetricBlastSmoke(world, cb.px, cb.py + 0.4, cb.pz, 8, false);
                SavedStructureSnapshot snap = findSnapshotById(cb.blueprintId);
                for (GeoStructuralPhysicsEngine.RelBlock rb : cb.voxels) {
                    rWorld.set(rb.dx(), rb.dy(), rb.dz());
                    cb.quat.transform(rWorld);
                    BlockPos wPos = BlockPos.ofFloored(cb.px + rWorld.x, cb.py + rWorld.y, cb.pz + rWorld.z);
                    BlockState rotState = rotateBlockStateByQuaternion(rb.state(), cb.quat, false);
                    if (GeoStructuralPhysicsEngine.RIGID_BODIES.size() < MAX_LIVE_RIGID && world.random.nextFloat() < 0.55f) {
                        spawnBoundRigidBody(world, wPos, rotState, cb.blueprintId,
                                cb.vx * 0.5 + (world.random.nextDouble() - 0.5) * 3.2,
                                Math.min(2.4, peakImpactVn * 0.22 + world.random.nextDouble() * 1.1),
                                cb.vz * 0.5 + (world.random.nextDouble() - 0.5) * 3.2);
                    } else {
                        solidifyRotatedVoxelInWorld(world, wPos, rb.state(), cb.quat, snap);
                    }
                }
                trueCompounds.remove(cb);
                continue;
            }

            double linE = cb.vx * cb.vx + cb.vy * cb.vy + cb.vz * cb.vz;
            double rotE = cb.wx * cb.wx + cb.wy * cb.wy + cb.wz * cb.wz;
            if ((linE < 0.025 && rotE < 0.035 && cb.ageTicks > 18) || cb.ageTicks > 160) {
                cb.lowEnergyTicks++;
                if (cb.lowEnergyTicks > 10 || cb.ageTicks > 160) {
                    SavedStructureSnapshot snap = findSnapshotById(cb.blueprintId);
                    for (GeoStructuralPhysicsEngine.RelBlock rb : cb.voxels) {
                        rWorld.set(rb.dx(), rb.dy(), rb.dz());
                        cb.quat.transform(rWorld);
                        BlockPos wPos = BlockPos.ofFloored(cb.px + rWorld.x, cb.py + rWorld.y, cb.pz + rWorld.z);
                        solidifyRotatedVoxelInWorld(world, wPos, rb.state(), cb.quat, snap);
                    }
                    trueCompounds.remove(cb);
                }
            } else {
                cb.lowEnergyTicks = 0;
            }
        }
    }

    private void spawnBoundRigidBody(ServerWorld world, BlockPos pos, BlockState st, String bpId, double vx, double vy, double vz) {
        if (GeoStructuralPhysicsEngine.RIGID_BODIES.size() >= MAX_LIVE_RIGID) {
            GeoStructuralPhysicsEngine.PhysicsRigidBody oldest = GeoStructuralPhysicsEngine.RIGID_BODIES.remove(0);
            String oldBp = bodyBlueprintBind.remove(oldest);
            solidifyRotatedVoxelInWorld(world, BlockPos.ofFloored(oldest.px, oldest.py, oldest.pz),
                    oldest.state, oldest.quat, findSnapshotById(oldBp));
        }
        GeoStructuralPhysicsEngine.PhysicsRigidBody rb = new GeoStructuralPhysicsEngine.PhysicsRigidBody(
                pos, st, vx, vy, vz,
                (world.random.nextDouble() - 0.5) * 5.8,
                (world.random.nextDouble() - 0.5) * 4.0,
                (world.random.nextDouble() - 0.5) * 5.8
        );
        rb.fromSurfaceDemolition = true;
        if (bpId != null) bodyBlueprintBind.put(rb, bpId);
        GeoStructuralPhysicsEngine.RIGID_BODIES.add(rb);
    }

    private void spawnLiveRigidBody(ServerWorld world, BlockPos pos, BlockState st, double vx, double vy, double vz) {
        spawnBoundRigidBody(world, pos, st, null, vx, vy, vz);
    }

    private void solidifyRotatedVoxelInWorld(ServerWorld world, BlockPos approx, BlockState rawState,
                                             Quaternionf quat, SavedStructureSnapshot snap) {
        if (rawState == null || rawState.isAir() || isNonStructuralDecor(rawState)) return;
        int x = approx.getX(), z = approx.getZ();
        if (!world.isChunkLoaded(x >> 4, z >> 4)) return;

        double density = computeBlockDensityKgM3(rawState);
        boolean floatsInWater = density < 960.0;

        int y = MathHelper.clamp(approx.getY(), world.getBottomY() + 2, world.getTopY() - 2);
        BlockPos.Mutable mp = new BlockPos.Mutable();

        while (y > world.getBottomY() + 2) {
            BlockState below = world.getBlockState(mp.set(x, y - 1, z));
            boolean belowWater = below.getFluidState().isIn(FluidTags.WATER);
            if (below.isAir() || (below.isReplaceable() && !belowWater)) {
                y--;
            } else if (belowWater && !floatsInWater) {
                y--;
            } else {
                break;
            }
        }

        int guard = 0;
        while (guard++ < 32) {
            BlockState cur = world.getBlockState(mp.set(x, y, z));
            boolean canOccupy = cur.isAir() || cur.isOf(Blocks.WATER) || (cur.isReplaceable() && !isProtectedMetroZone(mp, cur));
            if (canOccupy) break;

            int bestNx = x, bestNz = z, lowestY = y;
            for (Direction d : Direction.Type.HORIZONTAL) {
                int nx = x + d.getOffsetX(), nz = z + d.getOffsetZ();
                if (!world.isChunkLoaded(nx >> 4, nz >> 4)) continue;
                BlockState side = world.getBlockState(mp.set(nx, y, nz));
                BlockState sideBelow = world.getBlockState(mp.set(nx, y - 1, nz));
                boolean sideFree = side.isAir() || side.isOf(Blocks.WATER);
                boolean sideBelowFree = sideBelow.isAir() || (!floatsInWater && sideBelow.isOf(Blocks.WATER));
                if (sideFree && sideBelowFree) {
                    bestNx = nx; bestNz = nz; lowestY = y - 1;
                    break;
                }
            }
            if (lowestY < y) {
                x = bestNx; z = bestNz; y = lowestY;
            } else {
                y++;
            }
        }

        BlockPos target = new BlockPos(x, y, z);
        if (isProtectedMetroZone(target, world.getBlockState(target))) return;
        BlockState existing = world.getBlockState(target);
        boolean underwater = existing.getFluidState().isIn(FluidTags.WATER);
        if (existing.isAir() || existing.isOf(Blocks.WATER) || existing.isReplaceable()) {
            BlockState rotated = rotateBlockStateByQuaternion(rawState, quat != null ? quat : new Quaternionf(), underwater);
            world.setBlockState(target, rotated, Block.NOTIFY_ALL);
            activeDebrisRubble.add(target);
            if (snap != null) snap.depositedRubble.add(target);
        }
    }

    private void depositBlockOntoRubblePile(ServerWorld world, BlockPos approx, BlockState st, SavedStructureSnapshot snap) {
        solidifyRotatedVoxelInWorld(world, approx, st, new Quaternionf(), snap);
    }

    private void tickRigidBodiesAndSolidifyMound(ServerWorld world) {
        if (GeoStructuralPhysicsEngine.RIGID_BODIES.isEmpty()) return;
        final double dtSub = (0.05 * physicsTimeScale) / 4.0;
        final double[][] unitCorners = {
                {-0.46, -0.46, -0.46}, {0.46, -0.46, -0.46}, {-0.46, 0.46, -0.46}, {0.46, 0.46, -0.46},
                {-0.46, -0.46,  0.46}, {0.46, -0.46,  0.46}, {-0.46, 0.46,  0.46}, {0.46, 0.46,  0.46}
        };
        Vector3f tmp = new Vector3f();
        BlockPos.Mutable mp = new BlockPos.Mutable();

        for (GeoStructuralPhysicsEngine.PhysicsRigidBody rb : GeoStructuralPhysicsEngine.RIGID_BODIES) {
            rb.prevPx = rb.px; rb.prevPy = rb.py; rb.prevPz = rb.pz;
            rb.prevQuat.set(rb.quat);
            rb.ageTicks++;

            if (rb.sleeping) {
                if (rb.ageTicks > 25) {
                    GeoStructuralPhysicsEngine.RIGID_BODIES.remove(rb);
                    String bpId = bodyBlueprintBind.remove(rb);
                    if (rb.py >= 58.0) {
                        solidifyRotatedVoxelInWorld(world, BlockPos.ofFloored(rb.px, rb.py, rb.pz),
                                rb.state, rb.quat, findSnapshotById(bpId));
                    }
                }
                continue;
            }
            if (!world.isChunkLoaded(((int) Math.floor(rb.px)) >> 4, ((int) Math.floor(rb.pz)) >> 4)) continue;

            MaterialKind mat = classifyMaterial(rb.state);
            double density = computeBlockDensityKgM3(rb.state);
            boolean hitHard = false;
            double maxImpactVn = 0.0;
            boolean wasInWater = world.getFluidState(mp.set((int) Math.floor(rb.prevPx), (int) Math.floor(rb.prevPy), (int) Math.floor(rb.prevPz))).isIn(FluidTags.WATER);

            for (int step = 0; step < 4; step++) {
                FluidState fs = world.getFluidState(mp.set((int) Math.floor(rb.px), (int) Math.floor(rb.py), (int) Math.floor(rb.pz)));
                boolean inWater = fs.isIn(FluidTags.WATER);
                if (inWater && !wasInWater && rb.vy < -1.8) {
                    wasInWater = true;
                    double surfY = Math.floor(rb.py) + fs.getHeight(world, mp);
                    spawnWaterSplashAndRipple(world, rb.px, surfY, rb.pz,
                            Math.min(3.2f, 1.0f + (float) Math.abs(rb.vy) * 0.25f), 8);
                }

                double effG = inWater ? (9.80665 * (1.0 - 1000.0 / Math.max(250.0, density))) : 9.80665;
                double linDrag = inWater ? 0.90 : 0.995;
                rb.vy -= effG * dtSub;
                rb.vx *= linDrag; rb.vy *= (inWater ? 0.88 : 0.998); rb.vz *= linDrag;
                rb.wx *= (inWater ? 0.90 : 0.985); rb.wy *= (inWater ? 0.90 : 0.985); rb.wz *= (inWater ? 0.90 : 0.985);

                rb.px += rb.vx * dtSub; rb.py += rb.vy * dtSub; rb.pz += rb.vz * dtSub;

                float hdt = (float) (0.5 * dtSub);
                float qx = rb.quat.x, qy = rb.quat.y, qz = rb.quat.z, qw = rb.quat.w;
                float owx = (float) rb.wx, owy = (float) rb.wy, owz = (float) rb.wz;
                rb.quat.set(
                        qx + hdt * (owx * qw + owy * qz - owz * qy),
                        qy + hdt * (owy * qw + owz * qx - owx * qz),
                        qz + hdt * (owz * qw + owx * qy - owy * qx),
                        qw + hdt * (-owx * qx - owy * qy - owz * qz)
                ).normalize();

                for (double[] c : unitCorners) {
                    tmp.set((float) c[0], (float) c[1], (float) c[2]);
                    rb.quat.transform(tmp);
                    double cx = rb.px + tmp.x, cy = rb.py + tmp.y, cz = rb.pz + tmp.z;
                    int bx = (int) Math.floor(cx), by = (int) Math.floor(cy), bz = (int) Math.floor(cz);
                    if (!world.isChunkLoaded(bx >> 4, bz >> 4)) continue;
                    BlockState hitState = world.getBlockState(mp.set(bx, by, bz));
                    if (hitState.isAir() || !hitState.getFluidState().isEmpty() || hitState.getCollisionShape(world, mp).isEmpty()) continue;

                    double boxTop = by + hitState.getCollisionShape(world, mp).getMax(Direction.Axis.Y);
                    if (cy > boxTop) continue;

                    double penY = boxTop - cy;
                    double penX0 = cx - bx, penX1 = (bx + 1.0) - cx;
                    double penZ0 = cz - bz, penZ1 = (bz + 1.0) - cz;
                    double nx = 0.0, ny = 1.0, nz = 0.0, minPen = penY;
                    if (penX0 < minPen) { minPen = penX0; nx = -1.0; ny = 0.0; nz = 0.0; }
                    if (penX1 < minPen) { minPen = penX1; nx =  1.0; ny = 0.0; nz = 0.0; }
                    if (penZ0 < minPen) { minPen = penZ0; nx =  0.0; ny = 0.0; nz = -1.0; }
                    if (penZ1 < minPen) { minPen = penZ1; nx =  0.0; ny = 0.0; nz =  1.0; }

                    rb.px += nx * minPen * 0.65;
                    rb.py += ny * minPen * 0.65;
                    rb.pz += nz * minPen * 0.65;

                    double rx = tmp.x, ry = tmp.y, rz = tmp.z;
                    double vpx = rb.vx + (rb.wy * rz - rb.wz * ry);
                    double vpy = rb.vy + (rb.wz * rx - rb.wx * rz);
                    double vpz = rb.vz + (rb.wx * ry - rb.wy * rx);
                    double vn = vpx * nx + vpy * ny + vpz * nz;

                    if (vn < 0.0) {
                        maxImpactVn = Math.max(maxImpactVn, -vn);
                        if (vn < -2.6) hitHard = true;
                        double rcnX = ry * nz - rz * ny, rcnY = rz * nx - rx * nz, rcnZ = rx * ny - ry * nx;
                        double angTerm = rb.invInertia * (rcnX * rcnX + rcnY * rcnY + rcnZ * rcnZ);
                        double rest = (-vn < 0.9) ? 0.0 : mat.restitution;
                        double jn = -(1.0 + rest) * vn / (rb.invMass + angTerm);

                        rb.vx += (jn * nx) * rb.invMass; rb.vy += (jn * ny) * rb.invMass; rb.vz += (jn * nz) * rb.invMass;
                        rb.wx += (rcnX * jn) * rb.invInertia; rb.wy += (rcnY * jn) * rb.invInertia; rb.wz += (rcnZ * jn) * rb.invInertia;

                        double tx = vpx - vn * nx, ty = vpy - vn * ny, tz = vpz - vn * nz;
                        double tLen = Math.sqrt(tx * tx + ty * ty + tz * tz);
                        if (tLen > 1e-4) {
                            tx /= tLen; ty /= tLen; tz /= tLen;
                            double jt = MathHelper.clamp(-tLen / (rb.invMass + angTerm), -mat.friction * jn, mat.friction * jn);
                            rb.vx += (jt * tx) * rb.invMass; rb.vy += (jt * ty) * rb.invMass; rb.vz += (jt * tz) * rb.invMass;
                            rb.wx += ((ry * tz - rz * ty) * jt) * rb.invInertia;
                            rb.wy += ((rz * tx - rx * tz) * jt) * rb.invInertia;
                            rb.wz += ((rx * ty - ry * tx) * jt) * rb.invInertia;
                        }
                    }
                }
            }

            if (mat.shattersOnImpact && maxImpactVn > 2.4) {
                BlockPos ip = BlockPos.ofFloored(rb.px, rb.py, rb.pz);
                world.playSound(null, ip, SoundEvents.BLOCK_GLASS_BREAK, SoundCategory.BLOCKS, 0.9f, 1.05f);
                spawnCrumbledMicroVoxels(world, ip, rb.state, 12, 3.2);
                bodyBlueprintBind.remove(rb);
                GeoStructuralPhysicsEngine.RIGID_BODIES.remove(rb);
                continue;
            }

            if (hitHard) {
                BlockPos ip = BlockPos.ofFloored(rb.px, rb.py, rb.pz);
                world.playSound(null, ip, rb.state.getSoundGroup().getFallSound(), SoundCategory.BLOCKS, 0.6f, 0.82f);
                if (maxImpactVn > 4.2) {
                    spawnCrumbledMicroVoxels(world, ip, rb.state, 4, 2.0);
                }
            }

            double speedSq = rb.vx * rb.vx + rb.vy * rb.vy + rb.vz * rb.vz;
            double rotSq = rb.wx * rb.wx + rb.wy * rb.wy + rb.wz * rb.wz;
            boolean floatingAtRest = density < 960.0 && world.getFluidState(mp.set((int) Math.floor(rb.px), (int) Math.floor(rb.py - 0.3), (int) Math.floor(rb.pz))).isIn(FluidTags.WATER)
                    && speedSq < 0.08;
            if ((speedSq < 0.005 && rotSq < 0.012) || floatingAtRest || rb.ageTicks > 180) {
                rb.lowEnergyTicks++;
                if (rb.lowEnergyTicks > 12 || rb.ageTicks > 180) {
                    rb.vx = rb.vy = rb.vz = 0.0;
                    rb.wx = rb.wy = rb.wz = 0.0;
                    rb.sleeping = true;
                }
            } else {
                rb.lowEnergyTicks = 0;
            }
        }
    }

    // ==================== HAUBNA V146 MICRO-VOXELS, V188 WATER RIPPLES, V189 SMOKE & V37 SNOW ====================
    private void spawnCrumbledMicroVoxels(ServerWorld world, BlockPos pos, BlockState st, int count, double speedScale) {
        if (st == null || st.isAir() || microShards.size() > 260) return;
        MaterialKind mk = classifyMaterial(st);
        double dens = computeBlockDensityKgM3(st);
        for (int i = 0; i < count && microShards.size() < 280; i++) {
            double ox = pos.getX() + 0.2 + world.random.nextDouble() * 0.6;
            double oy = pos.getY() + 0.2 + world.random.nextDouble() * 0.6;
            double oz = pos.getZ() + 0.2 + world.random.nextDouble() * 0.6;
            double vx = (world.random.nextDouble() - 0.5) * speedScale * 1.6;
            double vy = 0.4 + world.random.nextDouble() * speedScale * 0.85;
            double vz = (world.random.nextDouble() - 0.5) * speedScale * 1.6;
            float sc = 0.20f + world.random.nextFloat() * 0.11f;
            microShards.add(new MicroVoxelShard(st, sc, dens, mk.restitution, ox, oy, oz, vx, vy, vz,
                    (world.random.nextDouble() - 0.5) * 11.0,
                    (world.random.nextDouble() - 0.5) * 11.0,
                    (world.random.nextDouble() - 0.5) * 11.0,
                    75 + world.random.nextInt(45)));
        }
    }

    private void spawnWaterSplashAndRipple(ServerWorld world, double x, double surfY, double z, float maxRadius, int splashParticles) {
        if (waterRipples.size() < 48) {
            waterRipples.add(new WaterRippleRing(x, surfY + 0.03, z, maxRadius, 38));
        }
        world.spawnParticles(ParticleTypes.SPLASH, x, surfY + 0.1, z, splashParticles, 0.45, 0.15, 0.45, 0.22);
        world.spawnParticles(ParticleTypes.BUBBLE_POP, x, surfY + 0.05, z, Math.max(4, splashParticles / 2), 0.5, 0.08, 0.5, 0.04);
        world.playSound(null, BlockPos.ofFloored(x, surfY, z), SoundEvents.ENTITY_GENERIC_SPLASH,
                SoundCategory.BLOCKS, Math.min(1.2f, 0.45f + maxRadius * 0.18f), 0.85f + world.random.nextFloat() * 0.25f);
    }

    private void spawnVolumetricBlastSmoke(ServerWorld world, double x, double y, double z, int count, boolean fieryCore) {
        for (int i = 0; i < count && smokePuffs.size() < 160; i++) {
            double ang = world.random.nextDouble() * Math.PI * 2.0;
            double spd = 0.2 + world.random.nextDouble() * 1.3;
            float heat = fieryCore ? (0.45f + world.random.nextFloat() * 0.55f) : 0.0f;
            smokePuffs.add(new VolumetricSmokePuff(
                    x + (world.random.nextDouble() - 0.5) * 1.1,
                    y + world.random.nextDouble() * 0.6,
                    z + (world.random.nextDouble() - 0.5) * 1.1,
                    Math.cos(ang) * spd * 0.45,
                    0.55 + world.random.nextDouble() * 1.15,
                    Math.sin(ang) * spd * 0.45,
                    0.42f + world.random.nextFloat() * 0.35f,
                    heat,
                    70 + world.random.nextInt(55)
            ));
        }
    }

    private void tickHaubnaMultiPhysicsEffects(ServerWorld world) {
        final double dt = 0.05 * physicsTimeScale;
        BlockPos.Mutable mp = new BlockPos.Mutable();
        boolean storm = world.isThundering();
        boolean rain  = world.isRaining();
        double windX = storm ? 0.55 : (rain ? 0.24 : 0.06);
        double windZ = storm ? 0.32 : (rain ? 0.14 : 0.03);

        for (MicroVoxelShard ms : microShards) {
            ms.prevPx = ms.px; ms.prevPy = ms.py; ms.prevPz = ms.pz;
            ms.prevQuat.set(ms.quat);
            ms.age++;
            if (ms.age >= ms.maxAge) {
                microShards.remove(ms);
                continue;
            }
            int bx = (int) Math.floor(ms.px), by = (int) Math.floor(ms.py), bz = (int) Math.floor(ms.pz);
            if (!world.isChunkLoaded(bx >> 4, bz >> 4)) continue;
            boolean inWater = world.getFluidState(mp.set(bx, by, bz)).isIn(FluidTags.WATER);
            double effG = inWater ? (9.81 * (1.0 - 1000.0 / Math.max(250.0, ms.densityKgM3))) : 9.81;
            ms.vy -= effG * dt;
            double drag = inWater ? 0.86 : 0.98;
            ms.vx *= drag; ms.vy *= drag; ms.vz *= drag;
            ms.px += ms.vx * dt; ms.py += ms.vy * dt; ms.pz += ms.vz * dt;

            float hdt = (float) (0.5 * dt);
            ms.quat.set(
                    ms.quat.x + hdt * ((float) ms.wx * ms.quat.w + (float) ms.wy * ms.quat.z - (float) ms.wz * ms.quat.y),
                    ms.quat.y + hdt * ((float) ms.wy * ms.quat.w + (float) ms.wz * ms.quat.x - (float) ms.wx * ms.quat.z),
                    ms.quat.z + hdt * ((float) ms.wz * ms.quat.w + (float) ms.wx * ms.quat.y - (float) ms.wy * ms.quat.x),
                    ms.quat.w + hdt * (-(float) ms.wx * ms.quat.x - (float) ms.wy * ms.quat.y - (float) ms.wz * ms.quat.z)
            ).normalize();

            int gBy = (int) Math.floor(ms.py - ms.scale * 0.5);
            BlockState below = world.getBlockState(mp.set((int) Math.floor(ms.px), gBy, (int) Math.floor(ms.pz)));
            if (!below.isAir() && below.getFluidState().isEmpty() && !below.getCollisionShape(world, mp).isEmpty()) {
                double top = gBy + below.getCollisionShape(world, mp).getMax(Direction.Axis.Y);
                if (ms.py - ms.scale * 0.5 < top) {
                    ms.py = top + ms.scale * 0.5;
                    if (ms.vy < 0) ms.vy = -ms.vy * ms.restitution;
                    ms.vx *= 0.72; ms.vz *= 0.72;
                    ms.wx *= 0.75; ms.wy *= 0.75; ms.wz *= 0.75;
                }
            }
        }

        for (VolumetricSmokePuff sp : smokePuffs) {
            sp.prevPx = sp.px; sp.prevPy = sp.py; sp.prevPz = sp.pz;
            sp.age++;
            if (sp.age >= sp.maxAge) {
                smokePuffs.remove(sp);
                continue;
            }
            sp.heat = Math.max(0.0f, sp.heat - 0.032f);
            sp.size = Math.min(1.65f, sp.size + 0.012f);
            sp.vy = Math.min(1.45, sp.vy + 0.35 * dt);
            sp.vx = sp.vx * 0.94 + windX * 0.06;
            sp.vz = sp.vz * 0.94 + windZ * 0.06;

            double nextY = sp.py + sp.vy * dt;
            BlockPos ceilPos = BlockPos.ofFloored(sp.px, nextY + sp.size * 0.45, sp.pz);
            if (world.isChunkLoaded(ceilPos.getX() >> 4, ceilPos.getZ() >> 4)) {
                BlockState ceilSt = world.getBlockState(ceilPos);
                if (!ceilSt.isAir() && ceilSt.getFluidState().isEmpty() && !ceilSt.getCollisionShape(world, ceilPos).isEmpty()) {
                    sp.vy = -0.02;
                    sp.vx += (world.random.nextDouble() - 0.5) * 0.55;
                    sp.vz += (world.random.nextDouble() - 0.5) * 0.55;
                } else {
                    sp.py = nextY;
                }
            }
            sp.px += sp.vx * dt;
            sp.pz += sp.vz * dt;
        }

        for (WaterRippleRing wr : waterRipples) {
            wr.age++;
            if (wr.age >= wr.maxAge) waterRipples.remove(wr);
        }

        for (ServerPlayerEntity pl : world.getPlayers()) {
            BlockPos foot = pl.getBlockPos();
            BlockState snowSt = world.getBlockState(foot);
            if (snowSt.isOf(Blocks.SNOW) && snowSt.contains(SnowBlock.LAYERS)) {
                int layers = snowSt.get(SnowBlock.LAYERS);
                if (layers > 1 && pl.getVelocity().horizontalLengthSquared() > 0.002) {
                    world.setBlockState(foot, snowSt.with(SnowBlock.LAYERS, Math.max(1, layers - 1)), Block.NOTIFY_LISTENERS);
                }
            }
            if (pl.isTouchingWater() && (serverTicks % 8) == 0 && pl.getVelocity().horizontalLengthSquared() > 0.002) {
                if (waterRipples.size() < 48) {
                    waterRipples.add(new WaterRippleRing(pl.getX(), Math.floor(pl.getY()) + 0.92, pl.getZ(), 1.65f, 28));
                }
            }
            if ((serverTicks % 5) == 0) {
                for (int i = 0; i < 3; i++) {
                    int rx = foot.getX() + world.random.nextInt(25) - 12;
                    int rz = foot.getZ() + world.random.nextInt(25) - 12;
                    if (!world.isChunkLoaded(rx >> 4, rz >> 4)) continue;
                    int topY = world.getTopY(Heightmap.Type.MOTION_BLOCKING, rx, rz) - 1;
                    BlockState topSt = world.getBlockState(mp.set(rx, topY, rz));
                    if (rain && topSt.getFluidState().isIn(FluidTags.WATER) && waterRipples.size() < 48) {
                        waterRipples.add(new WaterRippleRing(rx + world.random.nextDouble(), topY + 0.92, rz + world.random.nextDouble(), 0.75f, 18));
                    }
                    for (int dy = -2; dy <= 3; dy++) {
                        BlockState fs = world.getBlockState(mp.set(rx, foot.getY() + dy, rz));
                        if ((fs.isOf(Blocks.FIRE) || fs.isOf(Blocks.SOUL_FIRE) || fs.isOf(Blocks.CAMPFIRE)) && smokePuffs.size() < 120) {
                            smokePuffs.add(new VolumetricSmokePuff(
                                    rx + 0.5, foot.getY() + dy + 0.7, rz + 0.5,
                                    windX * 0.15, 0.65, windZ * 0.15, 0.36f, 0.75f, 65));
                        }
                    }
                }
            }
        }
    }

`;

src = src.slice(0, startDemolishIdx) + replacementPhysicsBlock + src.slice(endRigidIdx);

const oldRenderEnd = `        // 2. Render 96m Distant 3D Crimson Tunnel Emergency Strobe on damaged/flooded sectors!`;
const newMultiPhysicsRender = `        // 1B. Render 60 FPS TrueCompoundBodies, V146 MicroVoxelShards, V188 Water Ripples & V189 Volumetric Smoke!
        renderHaubnaMultiPhysicsWorld(ctx, world, matrices, vcp, cam);

        // 2. Render 96m Distant 3D Crimson Tunnel Emergency Strobe on damaged/flooded sectors!`;
if (!src.includes(oldRenderEnd)) { console.error('oldRenderEnd not found'); process.exit(1); }
src = src.replace(oldRenderEnd, newMultiPhysicsRender);

const clientMultiPhysicsRenderer = `
    private void renderHaubnaMultiPhysicsWorld(WorldRenderContext ctx, ClientWorld world,
                                               MatrixStack matrices, VertexConsumerProvider vcp, Vec3d cam) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null) return;
        BlockRenderManager brm = mc.getBlockRenderManager();
        float td = ctx.tickDelta();
        Quaternionf interpQ = new Quaternionf();

        for (TrueCompoundBody cb : trueCompounds) {
            double lx = MathHelper.lerp(td, cb.prevPx, cb.px);
            double ly = MathHelper.lerp(td, cb.prevPy, cb.py);
            double lz = MathHelper.lerp(td, cb.prevPz, cb.pz);
            double dx = lx - cam.x, dy = ly - cam.y, dz = lz - cam.z;
            if (dx * dx + dy * dy + dz * dz > 128.0 * 128.0) continue;

            interpQ.set(cb.prevQuat).nlerp(cb.quat, td);
            int light = WorldRenderer.getLightmapCoordinates(world, BlockPos.ofFloored(lx, ly + 0.6, lz));
            matrices.push();
            matrices.translate(dx, dy, dz);
            matrices.multiply(interpQ);
            for (GeoStructuralPhysicsEngine.RelBlock rel : cb.voxels) {
                matrices.push();
                matrices.translate(rel.dx() - 0.5f, rel.dy() - 0.5f, rel.dz() - 0.5f);
                brm.renderBlockAsEntity(rel.state(), matrices, vcp, light, OverlayTexture.DEFAULT_UV);
                matrices.pop();
            }
            matrices.pop();
        }

        for (MicroVoxelShard ms : microShards) {
            double lx = MathHelper.lerp(td, ms.prevPx, ms.px);
            double ly = MathHelper.lerp(td, ms.prevPy, ms.py);
            double lz = MathHelper.lerp(td, ms.prevPz, ms.pz);
            double dx = lx - cam.x, dy = ly - cam.y, dz = lz - cam.z;
            if (dx * dx + dy * dy + dz * dz > 68.0 * 68.0) continue;

            interpQ.set(ms.prevQuat).nlerp(ms.quat, td);
            int light = WorldRenderer.getLightmapCoordinates(world, BlockPos.ofFloored(lx, ly, lz));
            float fade = ms.age > ms.maxAge - 15 ? Math.max(0.05f, (ms.maxAge - ms.age - td) / 15.0f) : 1.0f;
            float s = ms.scale * fade;
            matrices.push();
            matrices.translate(dx, dy, dz);
            matrices.multiply(interpQ);
            matrices.scale(s, s, s);
            matrices.translate(-0.5f, -0.5f, -0.5f);
            brm.renderBlockAsEntity(ms.state, matrices, vcp, light, OverlayTexture.DEFAULT_UV);
            matrices.pop();
        }

        BlockState fireGlowCore = Blocks.ORANGE_STAINED_GLASS.getDefaultState();
        BlockState ashSmokeCube = Blocks.GRAY_STAINED_GLASS.getDefaultState();
        BlockState darkSmokeCube = Blocks.BLACK_STAINED_GLASS.getDefaultState();
        for (VolumetricSmokePuff sp : smokePuffs) {
            double lx = MathHelper.lerp(td, sp.prevPx, sp.px);
            double ly = MathHelper.lerp(td, sp.prevPy, sp.py);
            double lz = MathHelper.lerp(td, sp.prevPz, sp.pz);
            double dx = lx - cam.x, dy = ly - cam.y, dz = lz - cam.z;
            if (dx * dx + dy * dy + dz * dz > 96.0 * 96.0) continue;

            float lifeFrac = (sp.age + td) / sp.maxAge;
            float fade = lifeFrac > 0.7f ? Math.max(0.05f, (1.0f - lifeFrac) / 0.3f) : 1.0f;
            float sz = sp.size * fade;
            BlockState puffState = sp.heat > 0.38f ? fireGlowCore : (lifeFrac < 0.45f ? darkSmokeCube : ashSmokeCube);
            int light = sp.heat > 0.38f ? LightmapTextureManager.MAX_LIGHT_COORDINATE
                    : WorldRenderer.getLightmapCoordinates(world, BlockPos.ofFloored(lx, ly, lz));

            matrices.push();
            matrices.translate(dx, dy, dz);
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees((sp.age + td) * 4.5f));
            matrices.scale(sz, sz * 0.82f, sz);
            matrices.translate(-0.5f, -0.5f, -0.5f);
            brm.renderBlockAsEntity(puffState, matrices, vcp, light, OverlayTexture.DEFAULT_UV);
            matrices.pop();
        }

        if (!waterRipples.isEmpty()) {
            VertexConsumer lvc = vcp.getBuffer(RenderLayer.getLines());
            for (WaterRippleRing wr : waterRipples) {
                double dx = wr.x - cam.x, dy = wr.y - cam.y, dz = wr.z - cam.z;
                if (dx * dx + dy * dy + dz * dz > 72.0 * 72.0) continue;
                float prog = Math.min(1.0f, (wr.age + td) / wr.maxAge);
                float rad = 0.25f + wr.maxRadius * prog;
                int alpha = Math.max(15, (int) (215 * (1.0f - prog)));

                matrices.push();
                matrices.translate(dx, dy, dz);
                Matrix4f m4 = matrices.peek().getPositionMatrix();
                Matrix3f m3 = matrices.peek().getNormalMatrix();
                int segs = 20;
                for (int s = 0; s < segs; s++) {
                    double a0 = (Math.PI * 2.0 * s) / segs;
                    double a1 = (Math.PI * 2.0 * (s + 1)) / segs;
                    float x0 = (float) Math.cos(a0) * rad, z0 = (float) Math.sin(a0) * rad;
                    float x1 = (float) Math.cos(a1) * rad, z1 = (float) Math.sin(a1) * rad;
                    lvc.vertex(m4, x0, 0f, z0).color(235, 248, 255, alpha).normal(m3, 0f, 1f, 0f).next();
                    lvc.vertex(m4, x1, 0f, z1).color(235, 248, 255, alpha).normal(m3, 0f, 1f, 0f).next();
                }
                matrices.pop();
            }
        }
    }
`;

const lastBrace = src.lastIndexOf('}');
src = src.slice(0, lastBrace) + clientMultiPhysicsRenderer + '\n}\n';
fs.writeFileSync('/var/tmp/mcbuild/LivePatchV78G.java', src, 'utf8');
console.log('Generated LivePatchV78G.java (' + src.length + ' chars)');

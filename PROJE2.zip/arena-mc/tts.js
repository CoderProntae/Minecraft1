// ArenaAI v5.0 — In-Process EMA Lightning (8.6M, 34 MB, 48 kHz Turkish Neural TTS) + Metro Bell Chime
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const ort = require('onnxruntime-node');
const trnorm = require('@ozgurguler/trnorm');

const MODEL_DIR = path.join(__dirname, 'ema-models');
const CACHE_DIR = path.join(__dirname, 'tts', 'cache');
fs.mkdirSync(CACHE_DIR, { recursive: true });

const RATE = 48000;
const FIRST_WINDOW = 25;
const WINDOW = 100;
const CONTEXT = 8;
const MAX_WORD_FRAMES = 250;
const MAX_FRAMES = 3000;

const TURKISH = new Set('çğıöşüÇĞİÖŞÜ');
const TYPOGRAPHY = {
  '’': "'", '‘': "'", 'ʼ': "'", '´': "'", '`': "'",
  '“': '"', '”': '"', '„': '"', '«': '"', '»': '"',
  '–': '-', '—': '-', '−': '-', '…': '...'
};
const UNSAFE = /[\x00-\x08\x0b-\x1f\x7f-\x9f]/g;

const LETTERS_PER_SECOND = 18, MAX_SECONDS = 10, MAX_LETTERS = 250;
const SENTENCE_PAUSE = 0.25, CLAUSE_PAUSE = 0.12;
const CUTS = [
  [/[.!?]+["')]*(?= )/g, SENTENCE_PAUSE],
  [/[,;:](?= )/g, CLAUSE_PAUSE],
  [/\S(?= )/g, CLAUSE_PAUSE]
];

function alphabet(text, vocab) {
  text = text.replace(UNSAFE, ' ');
  text = [...text].map((ch) => TYPOGRAPHY[ch] ?? ch).join('');
  text = text.replace(/İ/g, 'i').replace(/I/g, 'ı').toLocaleLowerCase('tr');
  let out = '';
  for (let ch of text) {
    if (!TURKISH.has(ch)) ch = ch.normalize('NFKD').replace(/\p{M}/gu, '');
    out += ch && [...ch].every((c) => vocab.has(c)) ? ch : ' ';
  }
  return out.replace(/\s+/g, ' ').trim();
}

function frontend(text, vocab) {
  text = String(text || '').replace(UNSAFE, ' ');
  if (!text.trim()) return '';
  const normalized = trnorm.normalize ? trnorm.normalize(text) : text;
  return alphabet(String(normalized), vocab);
}

function finish(piece) {
  if (/[.!?]$/.test(piece.replace(/["')]+$/, ''))) return piece;
  return piece.replace(/[,;:\- ]+$/, '') + '.';
}

function chunkText(text, speed) {
  const limit = Math.floor(Math.min(MAX_LETTERS, LETTERS_PER_SECOND * MAX_SECONDS * speed));
  const pieces = [];
  let rest = text.trim();
  while (rest) {
    let cut = rest.length, pause = 0;
    if (rest.length > limit) {
      cut = limit;
      const head = rest.slice(0, limit + 1);
      for (const [pattern, gap] of CUTS) {
        const ends = [...head.matchAll(pattern)].map((m) => m.index + m[0].length);
        if (ends.length) { cut = ends.at(-1); pause = gap; break; }
      }
    }
    const piece = rest.slice(0, cut).trim();
    rest = rest.slice(cut).trim();
    if (/\p{L}/u.test(piece)) pieces.push([finish(piece), pause]);
  }
  if (pieces.length) pieces[pieces.length - 1][1] = 0;
  return pieces;
}

function gaussian(seed) {
  let a = seed >>> 0;
  const uniform = () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  return (n) => {
    const out = new Float32Array(n);
    for (let i = 0; i < n; i += 2) {
      const r = Math.sqrt(-2 * Math.log(1 - uniform())), th = 2 * Math.PI * uniform();
      out[i] = r * Math.cos(th);
      if (i + 1 < n) out[i + 1] = r * Math.sin(th);
    }
    return out;
  };
}

function words(text) {
  const starts = [];
  for (let i = 0; i < text.length; i++) if (text[i] !== ' ' && (i === 0 || text[i - 1] === ' ')) starts.push(i);
  if (!starts.length) starts.push(0);
  const bounds = [0, ...starts.slice(1), text.length];
  const cw = [], wstart = [];
  for (let w = 0; w + 1 < bounds.length; w++) {
    for (let i = bounds[w]; i < bounds[w + 1]; i++) { cw.push(w); wstart.push(bounds[w]); }
  }
  return { cw, wstart };
}

function plan(cw, wstart, dur, speed) {
  const L = cw.length, nWords = cw[L - 1] + 1;
  const d = Float32Array.from(dur, (x) => x / speed);
  const sums = new Float64Array(nWords);
  for (let i = 0; i < L; i++) sums[cw[i]] += d[i];
  const counts = Array.from(sums, (s) => Math.min(MAX_WORD_FRAMES, Math.max(1, Math.round(s))));
  const T = Math.min(counts.reduce((a, b) => a + b, 0), MAX_FRAMES);
  const fw = new Int32Array(T), fp = new Float32Array(T);
  for (let w = 0, f = 0; w < nWords; w++) {
    for (let j = 0; j < counts[w] && f < T; j++, f++) { fw[f] = w; fp[f] = j / counts[w]; }
  }
  const c = Float32Array.from(d, (x) => Math.max(x, 1e-4));
  const done = new Float32Array(L), total = new Float32Array(nWords);
  for (let i = 0, acc = 0; i < L; i++) { acc += c[i]; done[i] = acc; total[cw[i]] += c[i]; }
  const before = (i) => done[i] - c[i];
  const wlen = new Float32Array(nWords);
  for (const w of cw) wlen[w] += 1;
  const woff = new Float32Array(nWords);
  for (let w = 1; w < nWords; w++) woff[w] = woff[w - 1] + Math.max(wlen[w - 1], 1);
  const cg = new Float32Array(L), fg = new Float32Array(T);
  for (let i = 0; i < L; i++) {
    const cp = Math.min(1, Math.max(0, (done[i] - before(wstart[i]) - 0.5 * c[i]) / Math.max(total[cw[i]], 1e-8)));
    cg[i] = woff[cw[i]] + cp * Math.max(wlen[cw[i]], 1);
  }
  for (let f = 0; f < T; f++) fg[f] = woff[fw[f]] + fp[f] * Math.max(wlen[fw[f]], 1);
  return { T, fw, cg, fg };
}

function windows(frames, first) {
  const spans = [];
  for (let s = 0; s < frames;) {
    const e = Math.min(frames, s + (s === 0 ? first : WINDOW));
    spans.push([s, e]);
    s = e;
  }
  return spans;
}

const i64 = (arr) => new ort.Tensor('int64', BigInt64Array.from(arr, (x) => BigInt(x)), [1, arr.length]);
const f32 = (arr, dims) => new ort.Tensor('float32', arr, dims);

let emaPromise = null;

async function getEmaEngine() {
  if (!emaPromise) {
    emaPromise = (async () => {
      const meta = JSON.parse(fs.readFileSync(path.join(MODEL_DIR, 'meta.json'), 'utf8'));
      const opts = { graphOptimizationLevel: 'all' };
      const [textSess, soundSess, decSess] = await Promise.all([
        ort.InferenceSession.create(path.join(MODEL_DIR, 'text.onnx'), opts),
        ort.InferenceSession.create(path.join(MODEL_DIR, 'sound.onnx'), opts),
        ort.InferenceSession.create(path.join(MODEL_DIR, 'decoder.onnx'), opts)
      ]);
      const stoi = new Map(meta.vocab.map((ch, i) => [ch, i]));
      const alpha = new Set(meta.vocab.filter((v) => v.length === 1));
      return { meta, textSess, soundSess, decSess, stoi, alpha };
    })();
  }
  return emaPromise;
}

function generateMetroChimeFloat32(sampleRate, mode = 'station') {
  const notes = mode === 'onboard'
    ? [
        { freq: 880.0, start: 0.0, dur: 0.42 },
        { freq: 659.25, start: 0.34, dur: 0.65 }
      ]
    : mode === 'none'
    ? []
    : [
        { freq: 659.25, start: 0.0, dur: 0.38 },
        { freq: 830.61, start: 0.30, dur: 0.38 },
        { freq: 987.77, start: 0.60, dur: 0.72 }
      ];
  if (!notes.length) return new Float32Array(0);
  const totalSec = notes[notes.length - 1].start + notes[notes.length - 1].dur + 0.22;
  const nSamples = Math.floor(totalSec * sampleRate);
  const out = new Float32Array(nSamples);
  for (let i = 0; i < nSamples; i++) {
    const t = i / sampleRate;
    let s = 0;
    for (const n of notes) {
      if (t >= n.start && t <= n.start + n.dur) {
        const dt = t - n.start;
        const env = Math.min(1.0, dt / 0.008) * Math.exp(-4.2 * dt / n.dur);
        const w =
          0.68 * Math.sin(2 * Math.PI * n.freq * dt) +
          0.22 * Math.sin(2 * Math.PI * (n.freq * 2.0) * dt) * Math.exp(-6 * dt) +
          0.10 * Math.sin(2 * Math.PI * (n.freq * 3.0) * dt) * Math.exp(-9 * dt);
        s += env * w * 0.45;
      }
    }
    out[i] = Math.max(-0.95, Math.min(0.95, s));
  }
  return out;
}

function encodeAdaptiveWav(floatChunks, srcRate = RATE) {
  const total48 = floatChunks.reduce((acc, c) => acc + c.length, 0);
  const full = new Float32Array(total48);
  let p = 0;
  for (const c of floatChunks) { full.set(c, p); p += c.length; }

  // Keep Base64 RPC payload safely below Cloudflare's 1 MB WebSocket frame limit:
  // <= 13.0s -> 24,000 Hz (studio PA clarity, max ~624 KB WAV / ~832 KB b64)
  // >  13.0s -> 16,000 Hz (up to ~20s speech in a single RPC frame)
  const factor = (total48 / srcRate) <= 13.0 ? 2 : 3;
  const dstRate = Math.floor(srcRate / factor);
  const outLen = Math.floor(total48 / factor);

  const buf = Buffer.allocUnsafe(44 + outLen * 2);
  buf.write('RIFF', 0);
  buf.writeUInt32LE(36 + outLen * 2, 4);
  buf.write('WAVEfmt ', 8);
  buf.writeUInt32LE(16, 16);
  buf.writeUInt16LE(1, 20);
  buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(dstRate, 24);
  buf.writeUInt32LE(dstRate * 2, 28);
  buf.writeUInt16LE(2, 32);
  buf.writeUInt16LE(16, 34);
  buf.write('data', 36);
  buf.writeUInt32LE(outLen * 2, 40);

  let offset = 44;
  for (let i = 0; i < outLen; i++) {
    const idx = i * factor;
    // 5-tap symmetric low-pass anti-aliasing filter before decimation
    const s0 = full[Math.max(0, idx - 2)];
    const s1 = full[Math.max(0, idx - 1)];
    const s2 = full[idx];
    const s3 = full[Math.min(total48 - 1, idx + 1)];
    const s4 = full[Math.min(total48 - 1, idx + 2)];
    const v = Math.max(-1, Math.min(1, 0.10 * s0 + 0.24 * s1 + 0.32 * s2 + 0.24 * s3 + 0.10 * s4));
    buf.writeInt16LE(Math.round(v * 32767), offset);
    offset += 2;
  }
  return buf;
}

async function synthesizeTurkishPA(text, voice = 'ema', chimeMode = 'station', opts = {}) {
  const speed = typeof opts.speed === 'number' ? opts.speed : 1.0;
  const seed = typeof opts.seed === 'number' ? opts.seed : (voice === 'erkek' ? 42 : 7);
  const key = crypto.createHash('sha1').update(`ema-v2|${chimeMode}|${speed}|${seed}|${text}`).digest('hex');
  const cachedFile = path.join(CACHE_DIR, `${key}.wav`);
  if (fs.existsSync(cachedFile)) {
    return fs.readFileSync(cachedFile);
  }

  const eng = await getEmaEngine();
  const clean = frontend(text, eng.alpha);
  const pieces = chunkText(clean, speed);
  const floatChunks = [];

  const chimeArr = generateMetroChimeFloat32(RATE, chimeMode);
  if (chimeArr.length) floatChunks.push(chimeArr);

  const nSteps = eng.meta.times.length;
  const D = eng.meta.latent_dim;
  const hop = eng.meta.hop;

  for (let k = 0; k < pieces.length; k++) {
    const [piece, pause] = pieces[k];
    const ids = [...piece].map((ch) => eng.stoi.get(ch) ?? 1);
    const { cw, wstart } = words(piece);
    const { h, dur } = await eng.textSess.run({ ids: i64(ids) });
    const { T, fw, cg, fg } = plan(cw, wstart, dur.data, speed);

    const noise = gaussian(seed * 1000003 + k)(nSteps * T * D);
    const { latents } = await eng.soundSess.run({
      h,
      cg: f32(cg, [1, cg.length]),
      fg: f32(fg, [1, T]),
      cw: i64(cw),
      fw: i64(fw),
      noise: f32(noise, [1, nSteps, T, D])
    });
    const lat = latents.data;

    for (const [s, e] of windows(T, k === 0 ? FIRST_WINDOW : WINDOW)) {
      const a = Math.max(0, s - CONTEXT), b = Math.min(T, e + CONTEXT), n = b - a;
      const z = new Float32Array(D * n);
      for (let f = 0; f < n; f++) {
        for (let d = 0; d < D; d++) z[d * n + f] = lat[(a + f) * D + d];
      }
      const { audio } = await eng.decSess.run({ z: f32(z, [1, D, n]) });
      floatChunks.push(audio.data.slice((s - a) * hop, (e - a) * hop));
    }
    if (pause) floatChunks.push(new Float32Array(Math.round(pause * RATE)));
  }

  floatChunks.push(new Float32Array(Math.round(0.15 * RATE)));
  const wavBuf = encodeAdaptiveWav(floatChunks, RATE);
  fs.writeFileSync(cachedFile, wavBuf);
  return wavBuf;
}

module.exports = { synthesizeTurkishPA, getEmaEngine };

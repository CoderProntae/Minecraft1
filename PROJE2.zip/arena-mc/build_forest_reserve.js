const fs = require('fs');

async function buildForestReserve() {
  const act = (body) =>
    fetch('http://127.0.0.1:8080/api/act', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    }).then((r) => r.json());

  // 1. Scan full 100x65 region covering HQ bank, River, and the entire West Forest!
  const [s1, s2] = await Promise.all([
    fetch('http://127.0.0.1:8080/api/scan?x=-12&z=-28&r=32&step=1').then((r) => r.json()),
    fetch('http://127.0.0.1:8080/api/scan?x=-48&z=-28&r=28&step=1').then((r) => r.json())
  ]);

  const map = new Map();
  const treeTrunks = [];
  for (const s of [s1, s2]) {
    for (const row of s.grid || []) {
      for (const c of row) {
        const key = `${c.x},${c.z}`;
        if (!map.has(key)) {
          map.set(key, c);
          if (c.b.includes('log')) treeTrunks.push(c);
        }
      }
    }
  }

  const cell = (x, z) => map.get(`${x},${z}`) || { x, y: 65, z, b: 'grass_block' };
  const isWater = (x, z) => cell(x, z).b.includes('water');
  const isTrunk = (x, z) => cell(x, z).b.includes('log');

  // Inspect exact river crossing along z = -27
  console.log(
    'River profile at z=-27 (x=-24..+6):',
    Array.from({ length: 31 }, (_, i) => i - 24)
      .map((x) => `${x}:${cell(x, -27).b.slice(0, 4)}@${cell(x, -27).y}`)
      .join(' ')
  );

  // Find exact East water edge and West water edge along z = -27
  let eastBankX = 2, westBankX = -20;
  for (let x = 8; x >= -28; x--) {
    if (isWater(x, -27) || isWater(x, -26) || isWater(x, -28)) {
      eastBankX = Math.max(eastBankX === 2 ? -99 : eastBankX, x + 2);
      westBankX = Math.min(westBankX, x - 2);
    }
  }
  if (eastBankX < -50) { eastBankX = -3; westBankX = -17; }
  console.log('Bridge span X:', westBankX, '<-->', eastBankX);

  const ops = [];
  const planned = new Map(); // "x,y,z" -> block
  const set = (x, y, z, block, onlyAir = false) => {
    if (isTrunk(x, z) && y <= cell(x, z).y) return; // Never overwrite natural tree trunks!
    planned.set(`${x},${y},${z}`, block);
    ops.push({ op: 'set', x, y, z, block, onlyAir });
  };

  // ==================== 1. TRAIL FROM HQ MEADOW TO BRIDGE EAST APPROACH ====================
  // Connect from HQ lawn (x=14, z=-33) smoothly to (eastBankX+1, z=-27)
  const approachPts = [];
  const stepsToBridge = Math.max(1, 14 - (eastBankX + 1));
  for (let i = 0; i <= stepsToBridge; i++) {
    const t = i / stepsToBridge;
    const px = Math.round(14 + (eastBankX + 1 - 14) * t);
    const pz = Math.round(-33 + (-27 - -33) * t);
    approachPts.push([px, pz]);
  }
  const trailMats = ['minecraft:coarse_dirt', 'minecraft:podzol', 'minecraft:mossy_cobblestone', 'minecraft:gravel', 'minecraft:cobblestone'];
  for (let i = 0; i < approachPts.length; i++) {
    const [px, pz] = approachPts[i];
    for (let dz = -1; dz <= 1; dz++) {
      const c = cell(px, pz + dz);
      if (!c.b.includes('water') && !c.b.includes('log')) {
        set(px, c.y, pz + dz, trailMats[(Math.abs(px + pz + dz)) % trailMats.length]);
      }
    }
  }

  // ==================== 2. ARCHED TIMBER & STONE BRIDGE ACROSS THE RIVER (z = -28..-26) ====================
  const eastY = cell(eastBankX, -27).y;
  const westY = cell(westBankX, -27).y;
  const baseDeckY = Math.max(eastY, westY, 64) + 1;
  const spanLen = Math.max(1, eastBankX - westBankX);

  for (let x = westBankX; x <= eastBankX; x++) {
    const u = (x - westBankX) / spanLen; // 0 at westBank, 1 at eastBank
    const archLift = Math.round(Math.sin(u * Math.PI) * 2.2); // smooth 2-block arch!
    const deckY = baseDeckY + archLift;

    // Clear headroom above bridge
    for (let z = -28; z <= -26; z++) {
      for (let y = deckY; y <= deckY + 4; y++) {
        if (!isTrunk(x, z)) set(x, y, z, 'minecraft:air');
      }
    }

    // Bridge walkway (z = -28..-26)
    for (let z = -28; z <= -26; z++) {
      set(x, deckY - 1, z, z === -27 ? 'minecraft:spruce_planks' : 'minecraft:stripped_spruce_log[axis=x]');
    }

    // Bridge side railings on z = -29 and z = -25
    const isPillar = x === westBankX || x === eastBankX || x === Math.round((westBankX + eastBankX) / 2);
    for (const rz of [-29, -25]) {
      if (isPillar) {
        const ground = cell(x, rz).y;
        for (let y = Math.min(ground, 60); y <= deckY + 1; y++) {
          set(x, y, rz, y < deckY - 1 ? 'minecraft:stone_bricks' : 'minecraft:spruce_log[axis=y]');
        }
        set(x, deckY + 2, rz, 'minecraft:lantern');
      } else {
        set(x, deckY - 1, rz, 'minecraft:dark_oak_slab[type=top]');
        set(x, deckY, rz, 'minecraft:spruce_fence[east=true,west=true]');
      }
    }
  }

  // Entry/exit stairs on East and West ends of bridge
  for (let z = -28; z <= -26; z++) {
    const eGround = cell(eastBankX + 1, z).y;
    for (let y = eGround + 1; y < baseDeckY; y++) set(eastBankX + 1, y, z, 'minecraft:stone_bricks');
    set(eastBankX + 1, baseDeckY - 1, z, 'minecraft:stone_brick_stairs[facing=west,half=bottom]');

    const wGround = cell(westBankX - 1, z).y;
    for (let y = wGround + 1; y < baseDeckY; y++) set(westBankX - 1, y, z, 'minecraft:stone_bricks');
    set(westBankX - 1, baseDeckY - 1, z, 'minecraft:stone_brick_stairs[facing=east,half=bottom]');
  }

  // ==================== 3. GRAND FOREST RESERVE ENTRANCE GATEWAY (ANA ORMAN GIRISI!) ====================
  const gateX = westBankX - 3;
  const gateBaseY = Math.max(cell(gateX, -30).y, cell(gateX, -24).y, cell(gateX, -27).y) + 1;

  // Level gateway plaza (gateX-1 .. westBankX-1, z = -30..-24)
  for (let x = gateX - 2; x <= westBankX - 1; x++) {
    for (let z = -30; z <= -24; z++) {
      if (isTrunk(x, z)) continue;
      const g = cell(x, z).y;
      for (let y = g; y < gateBaseY; y++) {
        set(x, y, z, y === gateBaseY - 1 ? 'minecraft:mossy_stone_bricks' : 'minecraft:cobblestone');
      }
      for (let y = gateBaseY; y <= gateBaseY + 6; y++) {
        set(x, y, z, 'minecraft:air');
      }
    }
  }

  // Twin Monumental Gate Towers at (gateX, z = -31..-30) and (gateX, z = -24..-23)
  for (const tz of [-31, -23]) {
    const g0 = cell(gateX, tz).y;
    for (let dx = -1; dx <= 1; dx++) {
      for (let y = g0; y <= gateBaseY + 1; y++) {
        set(gateX + dx, y, tz, 'minecraft:stone_bricks');
      }
    }
    for (let y = gateBaseY + 2; y <= gateBaseY + 6; y++) {
      set(gateX, y, tz, 'minecraft:spruce_log[axis=y]');
      set(gateX + 1, y, tz, y <= gateBaseY + 3 ? 'minecraft:cobblestone_wall' : 'minecraft:air');
      set(gateX - 1, y, tz, y <= gateBaseY + 3 ? 'minecraft:cobblestone_wall' : 'minecraft:air');
    }
  }

  // Grand Overhead Timber & Dark-Oak Archway spanning z = -32 .. -22!
  for (let z = -32; z <= -22; z++) {
    set(gateX, gateBaseY + 6, z, 'minecraft:stripped_spruce_log[axis=z]');
    set(gateX - 1, gateBaseY + 7, z, 'minecraft:dark_oak_stairs[facing=east,half=bottom]');
    set(gateX + 1, gateBaseY + 7, z, 'minecraft:dark_oak_stairs[facing=west,half=bottom]');
    set(gateX, gateBaseY + 7, z, 'minecraft:spruce_planks');
    set(gateX, gateBaseY + 8, z, z % 2 === 0 ? 'minecraft:dark_oak_slab[type=bottom]' : 'minecraft:deepslate_brick_slab[type=bottom]');
  }
  // Curved arch brackets under beam + hanging lanterns + Forestry Banners!
  set(gateX, gateBaseY + 5, -30, 'minecraft:spruce_stairs[facing=north,half=top]');
  set(gateX, gateBaseY + 5, -24, 'minecraft:spruce_stairs[facing=south,half=top]');
  set(gateX, gateBaseY + 5, -27, 'minecraft:chain[axis=y]');
  set(gateX, gateBaseY + 4, -27, 'minecraft:lantern[hanging=true]');
  set(gateX + 1, gateBaseY + 5, -31, 'minecraft:green_wall_banner[facing=east]');
  set(gateX + 1, gateBaseY + 5, -23, 'minecraft:green_wall_banner[facing=east]');
  set(gateX + 1, gateBaseY + 6, -29, 'minecraft:spruce_trapdoor[facing=east,half=top,open=false]');
  set(gateX + 1, gateBaseY + 6, -25, 'minecraft:spruce_trapdoor[facing=east,half=top,open=false]');

  // ==================== 4. GRAND PERIMETER BORDER AROUND THE ENTIRE FOREST ====================
  // A) Eastern River-Front Border running North from Gate (z = -32 -> -56) and South from Gate (z = -22 -> +2)
  function findWestShoreX(z) {
    for (let x = -4; x >= -32; x--) {
      if (!isWater(x, z) && !isWater(x + 1, z)) {
        // step 1 block inland from water
        return x - 1;
      }
    }
    return gateX;
  }

  const borderPoints = [];
  // North-West border line (x = -56 -> shore at z = -54)
  for (let x = -54; x <= -22; x++) borderPoints.push([x, -54]);
  // East shore border north of gate (z = -54 -> -32)
  for (let z = -53; z <= -32; z++) borderPoints.push([gateX, z]);
  // (Gap at z = -31..-23 IS the Grand Forest Entrance Gate!)
  // East shore border south of gate (z = -22 -> 0)
  for (let z = -22; z <= 0; z++) borderPoints.push([gateX, z]);
  // South border line heading West into forest (z = 0, x = gateX-1 -> -54)
  for (let x = gateX - 1; x >= -54; x--) borderPoints.push([x, 0]);
  // West deep-forest border closing the reserve (x = -54, z = -1 -> -53)
  for (let z = -1; z >= -53; z--) borderPoints.push([-54, z]);

  // Place Stone-Brick & Spruce Boundary Pillars every 6 blocks + Connected Fence Barriers between them!
  const borderHeights = new Map();
  for (let i = 0; i < borderPoints.length; i++) {
    const [bx, bz] = borderPoints[i];
    if (isWater(bx, bz) || isTrunk(bx, bz)) continue;
    const by = cell(bx, bz).y + 1;
    borderHeights.set(`${bx},${bz}`, { idx: i, y: by });
  }

  for (let i = 0; i < borderPoints.length; i++) {
    const [bx, bz] = borderPoints[i];
    const info = borderHeights.get(`${bx},${bz}`);
    if (!info) continue;
    const by = info.y;
    const isMajorPillar = i % 6 === 0;

    if (isMajorPillar) {
      set(bx, by, bz, 'minecraft:stone_bricks');
      set(bx, by + 1, bz, 'minecraft:spruce_log[axis=y]');
      set(bx, by + 2, bz, i % 12 === 0 ? 'minecraft:lantern' : 'minecraft:stone_brick_slab[type=bottom]');
    } else {
      // Check N/S/E/W neighbors on border to connect fence cleanly!
      const n = borderHeights.has(`${bx},${bz - 1}`);
      const s = borderHeights.has(`${bx},${bz + 1}`);
      const e = borderHeights.has(`${bx + 1},${bz}`);
      const w = borderHeights.has(`${bx - 1},${bz}`);
      set(bx, by, bz, `minecraft:spruce_fence[north=${n},south=${s},east=${e},west=${w}]`);
      // Fill 1-block step gaps so animals/intruders can't slip under steep terrain!
      const prev = i > 0 ? borderPoints[i - 1] : null;
      if (prev) {
        const pInfo = borderHeights.get(`${prev[0]},${prev[1]}`);
        if (pInfo && Math.abs(pInfo.y - by) >= 1) {
          const highY = Math.max(pInfo.y, by);
          set(bx, highY, bz, `minecraft:spruce_fence[north=${n},south=${s},east=${e},west=${w}]`);
        }
      }
    }
  }

  // ==================== 5. DEEP FOREST MODIFICATIONS (TRAILS, TREE BIRDHOUSES, RANGER CAMP, WATCHTOWER!) ====================
  // Winding Main Forest Trail from Gate (gateX-2, -27) West to (-44, -30) + North branch to (-38, -46)
  for (let x = gateX - 2; x >= -44; x--) {
    const cz = -27 + Math.round(Math.sin((x - gateX) * 0.22) * 3);
    for (let dz = -1; dz <= 1; dz++) {
      const tx = x, tz = cz + dz;
      if (isTrunk(tx, tz) || isWater(tx, tz)) continue;
      const ty = cell(tx, tz).y;
      set(tx, ty, tz, trailMats[Math.abs(tx * 3 + tz) % trailMats.length]);
      // Clear low bushes/ferns on path so walking through the forest is wide & inviting!
      set(tx, ty + 1, tz, 'minecraft:air');
      set(tx, ty + 2, tz, 'minecraft:air');
    }
    // Trailside lantern post every 9 blocks along the deep forest path!
    if (Math.abs(x - gateX) % 9 === 4 && !isTrunk(x, cz + 2)) {
      const ly = cell(x, cz + 2).y + 1;
      set(x, ly, cz + 2, 'minecraft:mossy_cobblestone');
      set(x, ly + 1, cz + 2, 'minecraft:spruce_fence');
      set(x, ly + 2, cz + 2, 'minecraft:lantern');
    }
  }

  // Attach Birdhouses directly onto real natural forest trees inside the Reserve!
  let birdhousesMounted = 0;
  for (const tr of treeTrunks) {
    if (tr.x <= gateX - 2 && tr.x >= -52 && tr.z >= -52 && tr.z <= -3 && birdhousesMounted < 10) {
      // Mount birdhouse at trunk side 3 blocks below top of trunk (or ground + 4)
      const neighborGround = cell(tr.x + 1, tr.z).y;
      if (!isTrunk(tr.x + 1, tr.z) && tr.y >= neighborGround + 4) {
        const bhY = neighborGround + 4;
        set(tr.x + 1, bhY, tr.z, 'minecraft:beehive[facing=east]', true);
        set(tr.x + 1, bhY + 1, tr.z, 'minecraft:dark_oak_slab[type=bottom]', true);
        set(tr.x + 2, bhY, tr.z, 'minecraft:tripwire_hook[facing=east]', true);
        birdhousesMounted++;
      }
    }
  }
  console.log('Mounted natural tree birdhouses:', birdhousesMounted);

  // Forest Ranger Camp & Tall Wooden Fire-Watch Tower inside the Forest at (-45, -30)!
  const twX = -45, twZ = -30;
  const twBase = cell(twX, twZ).y + 1;
  // Clear 5x5 base for tower
  for (let dx = -2; dx <= 2; dx++) {
    for (let dz = -2; dz <= 2; dz++) {
      if (isTrunk(twX + dx, twZ + dz)) continue;
      const g = cell(twX + dx, twZ + dz).y;
      for (let y = g; y < twBase; y++) set(twX + dx, y, twZ + dz, 'minecraft:mossy_cobblestone');
    }
  }
  // 4 tall spruce log legs rising 11 blocks above forest floor!
  const topY = twBase + 10;
  for (let y = twBase; y <= topY + 3; y++) {
    for (const [lx, lz] of [[-2, -2], [2, -2], [-2, 2], [2, 2]]) {
      set(twX + lx, y, twZ + lz, 'minecraft:spruce_log[axis=y]');
    }
    // Central ladder column so player can climb all the way up!
    if (y <= topY) {
      set(twX, y, twZ - 1, 'minecraft:spruce_log[axis=y]');
      set(twX, y, twZ, 'minecraft:ladder[facing=south]');
    }
  }
  // Cross-bracing halfway up
  for (let d = -1; d <= 1; d++) {
    set(twX + d, twBase + 5, twZ - 2, 'minecraft:spruce_fence[east=true,west=true]');
    set(twX + d, twBase + 5, twZ + 2, 'minecraft:spruce_fence[east=true,west=true]');
    set(twX - 2, twBase + 5, twZ + d, 'minecraft:spruce_fence[north=true,south=true]');
    set(twX + 2, twBase + 5, twZ + d, 'minecraft:spruce_fence[north=true,south=true]');
  }
  // Observation Deck at topY
  for (let dx = -2; dx <= 2; dx++) {
    for (let dz = -2; dz <= 2; dz++) {
      if (dx === 0 && dz === 0) continue; // ladder hatch!
      set(twX + dx, topY, twZ + dz, 'minecraft:spruce_planks');
    }
  }
  for (let d = -1; d <= 1; d++) {
    set(twX + d, topY + 1, twZ - 2, 'minecraft:spruce_fence[east=true,west=true]');
    set(twX + d, topY + 1, twZ + 2, 'minecraft:spruce_fence[east=true,west=true]');
    set(twX - 2, topY + 1, twZ + d, 'minecraft:spruce_fence[north=true,south=true]');
    set(twX + 2, topY + 1, twZ + d, 'minecraft:spruce_fence[north=true,south=true]');
  }
  // Watchtower Pyramid Roof (topY + 4..5)
  for (let dx = -3; dx <= 3; dx++) {
    for (let dz = -3; dz <= 3; dz++) {
      const edge = Math.max(Math.abs(dx), Math.abs(dz));
      if (edge === 3) set(twX + dx, topY + 4, twZ + dz, 'minecraft:dark_oak_slab[type=bottom]');
      else if (edge === 2) set(twX + dx, topY + 4, twZ + dz, 'minecraft:dark_oak_planks');
      else set(twX + dx, topY + 5, twZ + dz, 'minecraft:dark_oak_slab[type=bottom]');
    }
  }
  set(twX, topY + 3, twZ, 'minecraft:lantern[hanging=true]');
  set(twX + 2, topY + 1, twZ, 'minecraft:bell[attachment=floor,facing=east]');

  console.log('Total Forest Reserve ops:', ops.length, 'GateX:', gateX, 'GateBaseY:', gateBaseY);
  fs.writeFileSync('/home/user/arena-mc/gate_meta.json', JSON.stringify({ gateX, gateBaseY, eastBankX, westBankX }));

  await act({ action: 'build', ops, delayMs: 25, async: true });
}

buildForestReserve().catch(console.error);

// Finish z=860..1568 now that chunks are generated, with automatic retry on heartbeat blink!
const BASE = 'http://127.0.0.1:8080';
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

async function postActRetry(body) {
  for (let attempt = 0; attempt < 6; attempt++) {
    const r = await fetch(BASE + '/api/act', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    const d = await r.json();
    if (d && d.error !== 'Mod bagli degil' && d.error !== 'Bagli degil') return d;
    await sleep(1200);
  }
  return { ok: false };
}

async function connectRail(z1, y1, z2, y2, item) {
  const r1 = await postActRetry({ action: 'interact', x: -18, y: y1, z: z1, side: 'up', item });
  const r2 = await postActRetry({ action: 'interact', x: -18, y: y2, z: z2, side: 'up', item });
  const ok = (r1.result === 'SUCCESS' && r2.result === 'SUCCESS');
  if (!ok) console.log(`  [WARN] ${z1}->${z2}:`, r1.result, r2.result);
  return ok;
}

async function main() {
  let okCount = 0;
  for (let segStart = 852; segStart < 1524; segStart += 96) {
    const segEnd = Math.min(1524, segStart + 96);
    const midZ = Math.round((segStart + segEnd) / 2);
    await postActRetry({ action: 'command', command: `tp ArenaAI -18 49 ${midZ}` });
    await sleep(900);

    const tunOps = [];
    for (let z = segStart; z <= segEnd; z++) {
      const isRib = (z % 16 === 0);
      const isLight = (z % 8 === 0);
      for (let y = 47; y <= 53; y++) {
        for (let x = -21; x <= -15; x++) {
          if (y === 47) {
            tunOps.push({ x, y, z, block: (x >= -19 && x <= -17) ? 'minecraft:andesite' : 'minecraft:polished_andesite' });
          } else if (y === 53 || x === -21 || x === -15) {
            if (isLight && y === 50 && (x === -21 || x === -15)) {
              tunOps.push({ x, y, z, block: 'minecraft:sea_lantern' });
            } else if (isRib) {
              tunOps.push({ x, y, z, block: 'minecraft:polished_deepslate' });
            } else {
              tunOps.push({ x, y, z, block: 'minecraft:stone_bricks' });
            }
          } else if (y === 52 && (x === -20 || x === -16)) {
            tunOps.push({ x, y, z, block: isRib ? 'minecraft:polished_deepslate' : 'minecraft:stone_brick_slab[type=top]' });
          } else {
            tunOps.push({ x, y, z, block: 'minecraft:air' });
          }
        }
      }
    }
    await postActRetry({ action: 'build', ops: tunOps, recordUndo: false, strictPhysics: false, cleanFloating: false });

    const railSteps = [];
    for (let rz = segStart; rz <= segEnd; rz += 32) {
      railSteps.push({ x: -18, y: 48, z: rz, item: 'mtr:rail', against: 'down', look: 'south', replace: true });
    }
    await postActRetry({ action: 'place_real', steps: railSteps, recordUndo: false });

    for (let rz = segStart; rz < segEnd; rz += 32) {
      if (await connectRail(rz, 48, rz + 32, 48, 'mtr:rail_connector_200')) okCount++;
    }
  }
  console.log(`[852->1524 Tamamlama]: ${okCount}/21 segment bağlandı!`);

  // Connect 820->852 bridge if needed just in case 852 was overwritten
  await postActRetry({ action: 'command', command: 'tp ArenaAI -18 49 852' });
  await sleep(600);
  const okBridge = await connectRail(820, 48, 852, 48, 'mtr:rail_connector_200');
  console.log('[820->852 Köprü]:', okBridge);

  // Now complete South Ascent Ramp & Grand Southern Portal (z=1524 -> 1568)!
  await postActRetry({ action: 'command', command: 'tp ArenaAI -18 68 1550' });
  await sleep(1000);

  const southOps = [];
  for (let z = 1525; z <= 1548; z++) {
    const t = (z - 1524) / 24.0;
    const floorY = Math.round(47 + 12 * t);
    const ceilY = floorY + 6;
    for (let y = floorY; y <= ceilY; y++) {
      for (let x = -21; x <= -15; x++) {
        if (y === floorY) {
          southOps.push({ x, y, z, block: (x >= -19 && x <= -17) ? 'minecraft:andesite' : 'minecraft:stone_bricks' });
        } else if (y === ceilY || x === -21 || x === -15) {
          const isLight = (z % 8 === 0 && y === floorY + 3 && (x === -21 || x === -15));
          southOps.push({ x, y, z, block: isLight ? 'minecraft:sea_lantern' : 'minecraft:stone_bricks' });
        } else {
          southOps.push({ x, y, z, block: 'minecraft:air' });
        }
      }
    }
  }

  for (let z = 1549; z <= 1567; z++) {
    const t = (z - 1548) / 20.0;
    const floorY = Math.round(59 + 13 * t);
    for (let x = -20; x <= -16; x++) {
      if (z % 5 === 0 || x === -20 || x === -16 || floorY <= 67) {
        for (let y = 58; y < floorY; y++) {
          southOps.push({ x, y, z, block: 'minecraft:stone_bricks' });
        }
      }
      southOps.push({ x, y: floorY - 1, z, block: 'minecraft:stone_bricks' });
      southOps.push({ x, y: floorY, z, block: (x >= -19 && x <= -17) ? 'minecraft:andesite' : 'minecraft:stone_bricks' });
    }
    for (let y = floorY + 1; y <= floorY + 6; y++) {
      for (let x = -20; x <= -16; x++) {
        southOps.push({ x, y, z, block: 'minecraft:air' });
      }
    }
    if (z <= 1556) {
      const ceilY = floorY + 6;
      for (let y = floorY; y <= ceilY; y++) {
        southOps.push({ x: -21, y, z, block: z === 1556 ? 'minecraft:chiseled_stone_bricks' : 'minecraft:stone_bricks' });
        southOps.push({ x: -15, y, z, block: z === 1556 ? 'minecraft:chiseled_stone_bricks' : 'minecraft:stone_bricks' });
      }
      for (let x = -21; x <= -15; x++) {
        southOps.push({ x, y: ceilY, z, block: z === 1556 ? 'minecraft:chiseled_stone_bricks' : 'minecraft:stone_bricks' });
      }
    } else {
      southOps.push({ x: -20, y: floorY + 1, z, block: 'minecraft:stone_brick_wall' });
      southOps.push({ x: -16, y: floorY + 1, z, block: 'minecraft:stone_brick_wall' });
    }
  }
  await postActRetry({ action: 'build', ops: southOps, recordUndo: true, strictPhysics: false, cleanFloating: false });

  await postActRetry({
    action: 'place_real',
    steps: [
      { x: -18, y: 48, z: 1524, item: 'mtr:rail', against: 'down', look: 'south', replace: true },
      { x: -18, y: 60, z: 1548, item: 'mtr:rail', against: 'down', look: 'south', replace: true },
      { x: -21, y: 68, z: 1557, item: 'minecraft:lantern', against: 'north', look: 'north' },
      { x: -15, y: 68, z: 1557, item: 'minecraft:lantern', against: 'north', look: 'north' }
    ]
  });
  // Re-link 1492->1524 after replacing 1524 rail node, then 1524->1548->1568!
  const okPre = await connectRail(1492, 48, 1524, 48, 'mtr:rail_connector_200');
  const okS1 = await connectRail(1524, 48, 1548, 60, 'mtr:rail_connector_120');
  const okS2 = await connectRail(1548, 60, 1568, 73, 'mtr:rail_connector_80');
  console.log('[Güney Portal + Viyadük Bağlantısı]:', { okPre, okS1, okS2 });
}

main().catch(console.error);

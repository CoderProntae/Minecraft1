package ai.arena.bridge.physics.pro;

import ai.arena.bridge.physics.pro.ContinuousOBBHitboxEngine.OBBRayHit;
import ai.arena.bridge.physics.pro.ContinuousStructuralBeams.ContinuousBeam;
import ai.arena.bridge.physics.pro.ContinuousStructuralBeams.DetachedContinuousBeam;
import ai.arena.bridge.physics.pro.FractureAndSolidifier.ElasticSagVoxel;
import ai.arena.bridge.physics.pro.RigidBody6DoFDynamics.LocalVoxel;
import ai.arena.bridge.physics.pro.RigidBody6DoFDynamics.RenderSnapshot;
import ai.arena.bridge.physics.pro.RigidBody6DoFDynamics.RigidCluster6DoF;
import ai.arena.bridge.physics.pro.VerletClothAndWeatherSolver.ClothMesh;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.BlockRenderManager;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.render.model.BakedQuad;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.LightType;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * 60–240 FPS Chunk-Light-Matched Renderer:
 * - Renders curved/bent structures with 100% exact pre-deformation per-face indoor/outdoor chunk lighting
 *   and vanilla directional face shading (DOWN=0.5, E/W=0.6, N/S=0.8, UP=1.0) -> ZERO brightness pop!
 * - Renders smooth non-grid Continuous 3D Structural Beams & Inclined Columns.
 * - Renders monolithic 6-DoF rigid bodies + rotated 3D OBB crosshair wireframe.
 */
public final class ProPhysicsRenderer {

    private static final Identifier WOVEN_CLOTH_TEX = new Identifier("minecraft", "textures/block/gray_wool.png");
    private static final Direction[] DIRS = Direction.values();

    public record FrameMotionSample(
            long bodyId,
            double frameDtMs,
            int clientFps,
            double renderX,
            double renderY,
            double renderZ,
            double deltaY,
            double tiltDeg
    ) {}

    private static final class SmoothRenderTrack {
        double rx, ry, rz;
        final Quaternionf rq = new Quaternionf();
        long lastFrameNano = 0L;
        boolean initialized = false;
    }

    private static final class DampedSagTrack {
        double dx, dy, dz;
        double vx, vy, vz;
        float rx, ry, rz;
        long lastNano = 0L;
    }

    private static final Map<Long, SmoothRenderTrack> SMOOTH_TRACKS = new ConcurrentHashMap<>();
    private static final Map<BlockPos, DampedSagTrack> SAG_TRACKS = new ConcurrentHashMap<>();
    public static final List<FrameMotionSample> FRAME_TELEMETRY = new CopyOnWriteArrayList<>();
    public static volatile boolean recordTelemetry = false;
    public static volatile OBBRayHit currentClientOBBHit = null;
    private static long lastGlobalFrameNano = 0L;

    private static final float[][] WIRE_EDGES = {
            {-1,-1,-1,  1,-1,-1}, { 1,-1,-1,  1,-1, 1}, { 1,-1, 1, -1,-1, 1}, {-1,-1, 1, -1,-1,-1},
            {-1, 1,-1,  1, 1,-1}, { 1, 1,-1,  1, 1, 1}, { 1, 1, 1, -1, 1, 1}, {-1, 1, 1, -1, 1,-1},
            {-1,-1,-1, -1, 1,-1}, { 1,-1,-1,  1, 1,-1}, { 1,-1, 1,  1, 1, 1}, {-1,-1, 1, -1, 1, 1}
    };

    private ProPhysicsRenderer() {}

    public static void renderAll(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientWorld world = ctx.world();
        MatrixStack matrices = ctx.matrixStack();
        VertexConsumerProvider consumers = ctx.consumers();
        if (mc == null || world == null || matrices == null || consumers == null) return;

        if (mc.player != null && !mc.isPaused()) {
            ContinuousOBBHitboxEngine.tickClientPlayer(mc.player);
            currentClientOBBHit = ContinuousOBBHitboxEngine.raycastPhysicsWorld(world, mc.player, 5.5);
        } else {
            currentClientOBBHit = null;
        }

        long nowNano = System.nanoTime();
        double frameDtSec = (lastGlobalFrameNano == 0L)
                ? (1.0 / 60.0)
                : MathHelper.clamp((nowNano - lastGlobalFrameNano) * 1.0e-9, 0.0004, 0.10);
        lastGlobalFrameNano = nowNano;

        Vec3d cam = ctx.camera().getPos();
        float td = ctx.tickDelta();

        renderContinuousStructuralBeams(mc, world, matrices, consumers, cam);
        renderElasticSaggingStructures(mc, world, matrices, consumers, cam, nowNano);
        renderRigidBodiesSmooth(mc, world, matrices, consumers, cam, nowNano, frameDtSec);
        renderTargetedOBBWireframe(matrices, consumers, cam, currentClientOBBHit);
        renderVerletPlayerCloaks(mc, world, matrices, consumers, cam, td);
    }

    private static int sampleAmbientVoxelLight(ClientWorld world, int wx, int wy, int wz, BlockPos.Mutable mp) {
        int bestSky = world.getLightLevel(LightType.SKY, mp.set(wx, wy, wz));
        int bestBlk = world.getLightLevel(LightType.BLOCK, mp);
        for (Direction d : DIRS) {
            mp.set(wx + d.getOffsetX(), wy + d.getOffsetY(), wz + d.getOffsetZ());
            if (!world.getBlockState(mp).isOpaqueFullCube(world, mp)) {
                int s = world.getLightLevel(LightType.SKY, mp);
                int b = world.getLightLevel(LightType.BLOCK, mp);
                if (s > bestSky) bestSky = s;
                if (b > bestBlk) bestBlk = b;
            }
        }
        return LightmapTextureManager.pack(bestBlk, bestSky);
    }

    /**
     * Computes exact Minecraft chunk directional shade for any world-rotated face normal:
     * UP (0,+1,0) -> 1.00, DOWN (0,-1,0) -> 0.50, NORTH/SOUTH (0,0,±1) -> 0.80, EAST/WEST (±1,0,0) -> 0.60!
     * Matches vanilla BlockModelRenderer 1:1 at zero rotation AND shades smoothly when tilted!
     */
    private static float computeChunkDirectionalShade(Direction localDir, Quaternionf worldRot, Vector3f scratch) {
        if (localDir == null) return 0.90f;
        if (worldRot == null) {
            return switch (localDir) {
                case DOWN -> 0.50f;
                case UP -> 1.00f;
                case NORTH, SOUTH -> 0.80f;
                case WEST, EAST -> 0.60f;
            };
        }
        scratch.set(localDir.getOffsetX(), localDir.getOffsetY(), localDir.getOffsetZ());
        worldRot.transform(scratch);
        float ax = Math.abs(scratch.x);
        float ay = scratch.y;
        float az = Math.abs(scratch.z);
        float yShade = (ay >= 0f) ? (0.80f + 0.20f * ay) : (0.80f + 0.30f * ay);
        float horizPenalty = 0.20f * ax * ax;
        return MathHelper.clamp(yShade - horizPenalty + 0.0f * az, 0.50f, 1.00f);
    }

    /**
     * Renders any BlockState using vanilla BakedQuads + RenderLayers.getMovingBlockLayer + exact chunk directional
     * shading + biome grass/foliage color tint + optional pre-deformation per-face lights (ZERO GUI brightness flash!).
     */
    private static void renderChunkMatchedBlock(
            MinecraftClient mc,
            ClientWorld world,
            BlockRenderManager brm,
            BlockState state,
            BlockPos tintPos,
            MatrixStack matrices,
            VertexConsumerProvider consumers,
            int[] faceBlk,
            int[] faceSky,
            int fallbackLight,
            Quaternionf worldRot,
            Random rand,
            Vector3f scratchNormal
    ) {
        BakedModel model = brm.getModel(state);
        if (model == null) return;

        // If block has no baked quads (e.g. chest/banner built-in entity model), fall back safely
        if (model.isBuiltin()) {
            brm.renderBlockAsEntity(state, matrices, consumers, fallbackLight, OverlayTexture.DEFAULT_UV);
            return;
        }

        VertexConsumer vc = consumers.getBuffer(RenderLayers.getMovingBlockLayer(state));
        MatrixStack.Entry entry = matrices.peek();
        long seed = 42L;

        for (int d = 0; d < 6; d++) {
            Direction dir = DIRS[d];
            rand.setSeed(seed);
            List<BakedQuad> quads = model.getQuads(state, dir, rand);
            if (quads.isEmpty()) continue;

            int light = (faceBlk != null && faceSky != null)
                    ? LightmapTextureManager.pack(faceBlk[d], faceSky[d])
                    : fallbackLight;
            float dirShade = computeChunkDirectionalShade(dir, worldRot, scratchNormal);

            for (int qIdx = 0, qSize = quads.size(); qIdx < qSize; qIdx++) {
                BakedQuad quad = quads.get(qIdx);
                float shade = quad.hasShade() ? dirShade : 1.0f;
                float r = shade, g = shade, b = shade;
                if (quad.hasColor()) {
                    int col = mc.getBlockColors().getColor(state, world, tintPos, quad.getColorIndex());
                    r *= ((col >> 16) & 0xFF) / 255.0f;
                    g *= ((col >> 8) & 0xFF) / 255.0f;
                    b *= (col & 0xFF) / 255.0f;
                }
                vc.quad(entry, quad, r, g, b, light, OverlayTexture.DEFAULT_UV);
            }
        }

        // Unculled interior/crossed quads (e.g. glass panes, fences, stairs, lanterns)
        rand.setSeed(seed);
        List<BakedQuad> unculled = model.getQuads(state, null, rand);
        if (!unculled.isEmpty()) {
            for (int qIdx = 0, qSize = unculled.size(); qIdx < qSize; qIdx++) {
                BakedQuad quad = unculled.get(qIdx);
                Direction qFace = quad.getFace();
                int fOrd = qFace != null ? qFace.ordinal() : 1;
                int light = (faceBlk != null && faceSky != null)
                        ? LightmapTextureManager.pack(faceBlk[fOrd], faceSky[fOrd])
                        : fallbackLight;
                float shade = quad.hasShade() ? computeChunkDirectionalShade(qFace, worldRot, scratchNormal) : 1.0f;
                float r = shade, g = shade, b = shade;
                if (quad.hasColor()) {
                    int col = mc.getBlockColors().getColor(state, world, tintPos, quad.getColorIndex());
                    r *= ((col >> 16) & 0xFF) / 255.0f;
                    g *= ((col >> 8) & 0xFF) / 255.0f;
                    b *= (col & 0xFF) / 255.0f;
                }
                vc.quad(entry, quad, r, g, b, light, OverlayTexture.DEFAULT_UV);
            }
        }
    }

    private static void renderContinuousStructuralBeams(
            MinecraftClient mc,
            ClientWorld world,
            MatrixStack matrices,
            VertexConsumerProvider consumers,
            Vec3d cam
    ) {
        if (ContinuousStructuralBeams.ACTIVE_BEAMS.isEmpty()) return;

        BlockRenderManager brm = mc.getBlockRenderManager();
        BlockPos.Mutable lightPos = new BlockPos.Mutable();
        Quaternionf segQ = new Quaternionf();
        Random rand = Random.create();
        Vector3f scratchN = new Vector3f();

        for (ContinuousBeam beam : ContinuousStructuralBeams.ACTIVE_BEAMS) {
            double midX = 0.5 * (beam.ax + beam.bx) - cam.x;
            double midY = 0.5 * (beam.ay + beam.by) - cam.y;
            double midZ = 0.5 * (beam.az + beam.bz) - cam.z;
            if (midX * midX + midY * midY + midZ * midZ > 144.0 * 144.0) continue;

            boolean curved = (Math.abs(beam.dispAx) + Math.abs(beam.dispAy) + Math.abs(beam.dispBx) + Math.abs(beam.dispBy) + Math.abs(beam.lateralBowM)) > 0.015;
            int segCount = curved ? 8 : Math.max(1, (int) Math.ceil(beam.lengthM / 1.75));

            for (int s = 0; s < segCount; s++) {
                Vec3d p0 = beam.sampleDeformedPoint((double) s / segCount);
                Vec3d p1 = beam.sampleDeformedPoint((double) (s + 1) / segCount);
                double cx = 0.5 * (p0.x + p1.x);
                double cy = 0.5 * (p0.y + p1.y);
                double cz = 0.5 * (p0.z + p1.z);
                double segLen = Math.max(0.08, p0.distanceTo(p1));

                ContinuousOBBHitboxEngine.buildSegmentOrientation(p0, p1, segLen, segQ);
                int bx = (int) Math.floor(cx), by = (int) Math.floor(cy), bz = (int) Math.floor(cz);
                int light = sampleAmbientVoxelLight(world, bx, by, bz, lightPos);

                float sx = (float) (segLen * 1.025);
                float sy = (float) beam.depthM;
                float sz = (float) beam.widthM;

                matrices.push();
                matrices.translate(cx - cam.x, cy - cam.y, cz - cam.z);
                matrices.multiply(segQ);
                matrices.scale(sx, sy, sz);
                matrices.translate(-0.5f, -0.5f, -0.5f);
                renderChunkMatchedBlock(mc, world, brm, beam.materialState, lightPos.set(bx, by, bz),
                        matrices, consumers, null, null, light, segQ, rand, scratchN);
                matrices.pop();
            }
        }
    }

    private static void renderElasticSaggingStructures(
            MinecraftClient mc,
            ClientWorld world,
            MatrixStack matrices,
            VertexConsumerProvider consumers,
            Vec3d cam,
            long nowNano
    ) {
        if (FractureAndSolidifier.ELASTIC_PROXIES.isEmpty()) {
            if (!SAG_TRACKS.isEmpty()) SAG_TRACKS.clear();
            return;
        }

        BlockRenderManager brm = mc.getBlockRenderManager();
        BlockPos.Mutable lightPos = new BlockPos.Mutable();
        Quaternionf rotQ = new Quaternionf();
        Random rand = Random.create();
        Vector3f scratchN = new Vector3f();
        Set<BlockPos> activeKeys = new HashSet<>(FractureAndSolidifier.ELASTIC_PROXIES.size() * 2);

        for (ElasticSagVoxel sag : FractureAndSolidifier.ELASTIC_PROXIES.values()) {
            BlockPos p = sag.pos();
            activeKeys.add(p);

            double relCamX = (p.getX() + 0.5) - cam.x;
            double relCamY = (p.getY() + 0.5) - cam.y;
            double relCamZ = (p.getZ() + 0.5) - cam.z;
            if (relCamX * relCamX + relCamY * relCamY + relCamZ * relCamZ > 136.0 * 136.0) continue;

            DampedSagTrack trk = SAG_TRACKS.computeIfAbsent(p, k -> new DampedSagTrack());
            double dt = (trk.lastNano == 0L)
                    ? (1.0 / 60.0)
                    : MathHelper.clamp((nowNano - trk.lastNano) * 1.0e-9, 0.0005, 0.05);
            trk.lastNano = nowNano;

            final double kSpring = 105.0;
            final double cDamp   = 14.5;
            trk.vx += ((sag.targetDx() - trk.dx) * kSpring - trk.vx * cDamp) * dt;
            trk.vy += ((sag.targetDy() - trk.dy) * kSpring - trk.vy * cDamp) * dt;
            trk.vz += ((sag.targetDz() - trk.dz) * kSpring - trk.vz * cDamp) * dt;
            trk.dx += trk.vx * dt;
            trk.dy += trk.vy * dt;
            trk.dz += trk.vz * dt;

            float rBlend = (float) (1.0 - Math.exp(-14.0 * dt));
            trk.rx += (sag.targetRx() - trk.rx) * rBlend;
            trk.ry += (sag.targetRy() - trk.ry) * rBlend;
            trk.rz += (sag.targetRz() - trk.rz) * rBlend;

            int fallbackLight = sampleAmbientVoxelLight(world, p.getX(), p.getY(), p.getZ(), lightPos);
            rotQ.rotationXYZ(trk.rx, trk.ry, trk.rz);

            float curveMag = Math.abs(trk.rx) + Math.abs(trk.rz);
            float joinScale = 1.0f + Math.min(0.050f, curveMag * 0.20f);

            matrices.push();
            matrices.translate(relCamX + trk.dx, relCamY + trk.dy, relCamZ + trk.dz);
            matrices.multiply(rotQ);
            matrices.scale(joinScale, 1.006f, joinScale);
            matrices.translate(-0.5f, -0.5f, -0.5f);
            renderChunkMatchedBlock(mc, world, brm, sag.realState(), p, matrices, consumers,
                    sag.faceBlockLight(), sag.faceSkyLight(), fallbackLight, rotQ, rand, scratchN);
            matrices.pop();
        }

        if (SAG_TRACKS.size() > activeKeys.size() + 16) {
            SAG_TRACKS.keySet().retainAll(activeKeys);
        }
    }

    private static void renderRigidBodiesSmooth(
            MinecraftClient mc,
            ClientWorld world,
            MatrixStack matrices,
            VertexConsumerProvider consumers,
            Vec3d cam,
            long nowNano,
            double frameDtSec
    ) {
        if (RigidBody6DoFDynamics.ACTIVE_BODIES.isEmpty()) {
            if (!SMOOTH_TRACKS.isEmpty()) SMOOTH_TRACKS.clear();
            return;
        }

        BlockRenderManager brm = mc.getBlockRenderManager();
        Quaternionf q1 = new Quaternionf();
        Quaternionf qTarget = new Quaternionf();
        Quaternionf combinedBeamQ = new Quaternionf();
        Vector3f voxWorld = new Vector3f();
        Vector3f scratchN = new Vector3f();
        Random rand = Random.create();
        BlockPos.Mutable lightPos = new BlockPos.Mutable();
        Set<Long> aliveIds = new HashSet<>(RigidBody6DoFDynamics.ACTIVE_BODIES.size() * 2);

        for (RigidCluster6DoF body : RigidBody6DoFDynamics.ACTIVE_BODIES) {
            aliveIds.add(body.bodyId);
            RenderSnapshot snap = body.renderSnap;
            if (snap == null) continue;

            double dtPred = snap.sleeping()
                    ? 0.0
                    : MathHelper.clamp((nowNano - snap.publishNano()) * 1.0e-9, 0.0, 0.085);

            double tx = snap.x1() + snap.vx1() * dtPred;
            double ty = snap.y1() + snap.vy1() * dtPred + 0.5 * snap.netAccelY() * dtPred * dtPred;
            double tz = snap.z1() + snap.vz1() * dtPred;

            q1.set(snap.qx1(), snap.qy1(), snap.qz1(), snap.qw1());
            if (!snap.sleeping() && dtPred > 0.0) {
                float h = (float) (0.5 * dtPred);
                float owx = (float) snap.wx1(), owy = (float) snap.wy1(), owz = (float) snap.wz1();
                qTarget.set(
                        q1.x + h * (owx * q1.w + owy * q1.z - owz * q1.y),
                        q1.y + h * (owy * q1.w + owz * q1.x - owx * q1.z),
                        q1.z + h * (owz * q1.w + owx * q1.y - owy * q1.x),
                        q1.w + h * (-owx * q1.x - owy * q1.y - owz * q1.z)
                ).normalize();
            } else {
                qTarget.set(q1);
            }

            SmoothRenderTrack track = SMOOTH_TRACKS.computeIfAbsent(body.bodyId, k -> new SmoothRenderTrack());
            double prevTrackY = track.ry;
            if (!track.initialized) {
                track.initialized = true;
                track.rx = tx; track.ry = ty; track.rz = tz;
                track.rq.set(qTarget);
                prevTrackY = ty;
            } else {
                double dtTrack = MathHelper.clamp((nowNano - track.lastFrameNano) * 1.0e-9, 0.0004, 0.08);
                double blend = 1.0 - Math.exp(-52.0 * dtTrack);
                track.rx += (tx - track.rx) * blend;
                track.ry += (ty - track.ry) * blend;
                track.rz += (tz - track.rz) * blend;
                if (!snap.inContact() && !snap.sleeping() && snap.vy1() <= 0.0 && snap.netAccelY() < -1.0 && track.ry > prevTrackY) {
                    track.ry = prevTrackY;
                }
                if (track.rq.dot(qTarget) < 0.0f) {
                    qTarget.set(-qTarget.x, -qTarget.y, -qTarget.z, -qTarget.w);
                }
                track.rq.nlerp(qTarget, (float) blend);
            }
            track.lastFrameNano = nowNano;

            if (recordTelemetry && !snap.sleeping() && FRAME_TELEMETRY.size() < 400) {
                double tiltDeg = Math.toDegrees(2.0 * Math.acos(MathHelper.clamp(Math.abs(track.rq.w), 0.0, 1.0)));
                FRAME_TELEMETRY.add(new FrameMotionSample(
                        body.bodyId,
                        Math.round(frameDtSec * 10000.0) / 10.0,
                        mc.getCurrentFps(),
                        Math.round(track.rx * 10000.0) / 10000.0,
                        Math.round(track.ry * 10000.0) / 10000.0,
                        Math.round(track.rz * 10000.0) / 10000.0,
                        Math.round((track.ry - prevTrackY) * 10000.0) / 10000.0,
                        Math.round(tiltDeg * 100.0) / 100.0
                ));
            }

            double dx = track.rx - cam.x;
            double dy = track.ry - cam.y;
            double dz = track.rz - cam.z;
            if (dx * dx + dy * dy + dz * dz > 156.0 * 156.0) continue;

            matrices.push();
            matrices.translate(dx, dy, dz);
            matrices.multiply(track.rq);

            for (LocalVoxel lv : body.voxels) {
                if (lv.state().isAir()) continue;
                voxWorld.set((float) lv.lx(), (float) lv.ly(), (float) lv.lz());
                track.rq.transform(voxWorld);
                int wx = (int) Math.floor(track.rx + voxWorld.x);
                int wy = (int) Math.floor(track.ry + voxWorld.y);
                int wz = (int) Math.floor(track.rz + voxWorld.z);
                int voxLight = sampleAmbientVoxelLight(world, wx, wy, wz, lightPos);

                matrices.push();
                matrices.translate((float) (lv.lx() - 0.5), (float) (lv.ly() - 0.5), (float) (lv.lz() - 0.5));
                renderChunkMatchedBlock(mc, world, brm, lv.state(), lightPos.set(wx, wy, wz),
                        matrices, consumers, null, null, voxLight, track.rq, rand, scratchN);
                matrices.pop();
            }

            for (DetachedContinuousBeam db : body.attachedBeams) {
                float mLx = (float) (0.5 * (db.lax() + db.lbx()));
                float mLy = (float) (0.5 * (db.lay() + db.lby()));
                float mLz = (float) (0.5 * (db.laz() + db.lbz()));
                voxWorld.set(mLx, mLy, mLz);
                track.rq.transform(voxWorld);
                int bx = (int) Math.floor(track.rx + voxWorld.x);
                int by = (int) Math.floor(track.ry + voxWorld.y);
                int bz = (int) Math.floor(track.rz + voxWorld.z);
                int bLight = sampleAmbientVoxelLight(world, bx, by, bz, lightPos);
                combinedBeamQ.set(track.rq).mul(db.localOrientation());

                int subSegs = Math.max(1, (int) Math.ceil(db.lengthM() / 1.75));
                float segLen = (float) (db.lengthM() / subSegs);
                for (int s = 0; s < subSegs; s++) {
                    float frac = ((s + 0.5f) / subSegs) - 0.5f;
                    matrices.push();
                    matrices.translate(mLx, mLy, mLz);
                    matrices.multiply(db.localOrientation());
                    matrices.translate(frac * (float) db.lengthM(), 0f, 0f);
                    matrices.scale(segLen * 1.02f, (float) db.depthM(), (float) db.widthM());
                    matrices.translate(-0.5f, -0.5f, -0.5f);
                    renderChunkMatchedBlock(mc, world, brm, db.materialState(), lightPos.set(bx, by, bz),
                            matrices, consumers, null, null, bLight, combinedBeamQ, rand, scratchN);
                    matrices.pop();
                }
            }

            matrices.pop();
        }

        if (SMOOTH_TRACKS.size() > aliveIds.size() + 8) {
            SMOOTH_TRACKS.keySet().retainAll(aliveIds);
        }
    }

    private static void renderTargetedOBBWireframe(
            MatrixStack matrices,
            VertexConsumerProvider consumers,
            Vec3d cam,
            OBBRayHit hit
    ) {
        if (hit == null) return;
        VertexConsumer vc = consumers.getBuffer(RenderLayer.getLines());
        Vec3d c = hit.obbCenter();
        Vector3f h = hit.obbHalfExtents();
        float hx = h.x + 0.004f, hy = h.y + 0.004f, hz = h.z + 0.004f;

        matrices.push();
        matrices.translate(c.x - cam.x, c.y - cam.y, c.z - cam.z);
        matrices.multiply(hit.obbOrientation());

        Matrix4f m4 = matrices.peek().getPositionMatrix();
        Matrix3f n3 = matrices.peek().getNormalMatrix();

        for (float[] e : WIRE_EDGES) {
            float x0 = e[0] * hx, y0 = e[1] * hy, z0 = e[2] * hz;
            float x1 = e[3] * hx, y1 = e[4] * hy, z1 = e[5] * hz;
            float dx = x1 - x0, dy = y1 - y0, dz = z1 - z0;
            float len = MathHelper.sqrt(dx * dx + dy * dy + dz * dz);
            float nx = len > 1e-5f ? dx / len : 0f;
            float ny = len > 1e-5f ? dy / len : 1f;
            float nz = len > 1e-5f ? dz / len : 0f;
            vc.vertex(m4, x0, y0, z0).color(15, 15, 15, 185).normal(n3, nx, ny, nz).next();
            vc.vertex(m4, x1, y1, z1).color(15, 15, 15, 185).normal(n3, nx, ny, nz).next();
        }
        matrices.pop();
    }

    private static void renderVerletPlayerCloaks(
            MinecraftClient mc,
            ClientWorld world,
            MatrixStack matrices,
            VertexConsumerProvider consumers,
            Vec3d cam,
            float td
    ) {
        boolean firstPerson = mc.options.getPerspective().isFirstPerson();
        boolean raining = world.isRaining();
        boolean thundering = world.isThundering();
        long wt = world.getTime();
        BlockPos.Mutable lightPos = new BlockPos.Mutable();

        for (AbstractClientPlayerEntity pl : world.getPlayers()) {
            if (pl.isSpectator() || pl.isInvisible()) continue;
            if (pl == mc.player && firstPerson) continue;
            if (pl.squaredDistanceTo(cam) > 64.0 * 64.0) continue;

            ClothMesh mesh = VerletClothAndWeatherSolver.stepPlayerClothClient(pl, td, raining, thundering, wt);
            if (!mesh.initialized) continue;

            BlockPos pbp = pl.getBlockPos().up();
            int light = sampleAmbientVoxelLight(world, pbp.getX(), pbp.getY(), pbp.getZ(), lightPos);
            VertexConsumer vc = consumers.getBuffer(RenderLayer.getEntityCutoutNoCull(WOVEN_CLOTH_TEX));

            matrices.push();
            matrices.translate(-cam.x, -cam.y, -cam.z);
            Matrix4f posMat = matrices.peek().getPositionMatrix();
            Matrix3f nrmMat = matrices.peek().getNormalMatrix();

            int cols = VerletClothAndWeatherSolver.CLOTH_COLS;
            int rows = VerletClothAndWeatherSolver.CLOTH_ROWS;

            for (int r = 0; r < rows - 1; r++) {
                float v0 = (float) r / (rows - 1);
                float v1 = (float) (r + 1) / (rows - 1);
                for (int c = 0; c < cols - 1; c++) {
                    float u0 = (float) c / (cols - 1);
                    float u1 = (float) (c + 1) / (cols - 1);

                    int i00 = mesh.idx(c, r);
                    int i10 = mesh.idx(c + 1, r);
                    int i11 = mesh.idx(c + 1, r + 1);
                    int i01 = mesh.idx(c, r + 1);

                    float x00 = (float) mesh.px[i00], y00 = (float) mesh.py[i00], z00 = (float) mesh.pz[i00];
                    float x10 = (float) mesh.px[i10], y10 = (float) mesh.py[i10], z10 = (float) mesh.pz[i10];
                    float x11 = (float) mesh.px[i11], y11 = (float) mesh.py[i11], z11 = (float) mesh.pz[i11];
                    float x01 = (float) mesh.px[i01], y01 = (float) mesh.py[i01], z01 = (float) mesh.pz[i01];

                    float ex1 = x10 - x00, ey1 = y10 - y00, ez1 = z10 - z00;
                    float ex2 = x01 - x00, ey2 = y01 - y00, ez2 = z01 - z00;
                    float nx = ey1 * ez2 - ez1 * ey2;
                    float ny = ez1 * ex2 - ex1 * ez2;
                    float nz = ex1 * ey2 - ey1 * ex2;
                    float nLen = MathHelper.sqrt(nx * nx + ny * ny + nz * nz);
                    if (nLen > 1.0e-5f) {
                        nx /= nLen; ny /= nLen; nz /= nLen;
                    } else {
                        nx = 0f; ny = 1f; nz = 0f;
                    }

                    int shade = MathHelper.clamp((int) (185 + 45 * ny), 135, 235);
                    int borderTrim = (r == rows - 2) ? 215 : shade;
                    int rCol = (r == rows - 2) ? borderTrim : (int) (shade * 0.88f);
                    int gCol = (r == rows - 2) ? (int) (borderTrim * 0.72f) : (int) (shade * 0.90f);
                    int bCol = (r == rows - 2) ? (int) (borderTrim * 0.28f) : (int) (shade * 0.94f);

                    vc.vertex(posMat, x00, y00, z00).color(rCol, gCol, bCol, 255).texture(u0, v0).overlay(OverlayTexture.DEFAULT_UV).light(light).normal(nrmMat, nx, ny, nz).next();
                    vc.vertex(posMat, x10, y10, z10).color(rCol, gCol, bCol, 255).texture(u1, v0).overlay(OverlayTexture.DEFAULT_UV).light(light).normal(nrmMat, nx, ny, nz).next();
                    vc.vertex(posMat, x11, y11, z11).color(rCol, gCol, bCol, 255).texture(u1, v1).overlay(OverlayTexture.DEFAULT_UV).light(light).normal(nrmMat, nx, ny, nz).next();
                    vc.vertex(posMat, x01, y01, z01).color(rCol, gCol, bCol, 255).texture(u0, v1).overlay(OverlayTexture.DEFAULT_UV).light(light).normal(nrmMat, nx, ny, nz).next();
                }
            }

            matrices.pop();
        }
    }
}

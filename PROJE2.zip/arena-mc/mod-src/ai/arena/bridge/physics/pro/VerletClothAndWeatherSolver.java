package ai.arena.bridge.physics.pro;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.SnowBlock;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import org.joml.Vector3d;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Genuine Atmospheric Boundary-Layer Wind Solver, Snow-Layer Compaction Mechanics,
 * and 2D Verlet/XPBD Soft-Body Cloth Mesh Simulation (structural + shear + bending constraints
 * with triangle-normal aerodynamic pressure and player torso/leg capsule collision).
 */
public final class VerletClothAndWeatherSolver {

    public static final int CLOTH_COLS = 7;
    public static final int CLOTH_ROWS = 10;
    private static final double REST_DX = 0.095; // ~0.57m shoulder width
    private static final double REST_DY = 0.115; // ~1.04m cape length

    public static final class ClothMesh {
        public final int totalNodes = CLOTH_COLS * CLOTH_ROWS;
        public final double[] px = new double[totalNodes];
        public final double[] py = new double[totalNodes];
        public final double[] pz = new double[totalNodes];
        public final double[] oldPx = new double[totalNodes];
        public final double[] oldPy = new double[totalNodes];
        public final double[] oldPz = new double[totalNodes];
        public boolean initialized = false;
        public long lastUpdateNano = 0L;

        public int idx(int col, int row) {
            return row * CLOTH_COLS + col;
        }
    }

    public static final Map<UUID, ClothMesh> PLAYER_CAPES = new ConcurrentHashMap<>();
    private static final Vector3d CURRENT_SURFACE_WIND_MS = new Vector3d(1.2, 0.0, 0.6);

    private VerletClothAndWeatherSolver() {}

    /**
     * Computes real-time atmospheric boundary-layer wind velocity vector (m/s) at altitude Y.
     * Uses power-law wind shear v(z) = v_ref * (z_agl / 10)^0.22 + turbulent gust harmonics.
     */
    public static Vector3d sampleWindAtAltitude(long worldTimeTicks, boolean raining, boolean thundering, double worldY) {
        double t = worldTimeTicks * 0.05;
        double baseSpeedMs = thundering ? 13.5 : (raining ? 6.8 : 1.8);
        double gust = 1.0 + 0.28 * Math.sin(t * 0.43) + 0.17 * Math.cos(t * 1.13);
        double dirRad = 0.52 + 0.22 * Math.sin(t * 0.09);

        double zAgl = Math.max(1.5, worldY - 62.0);
        double shearFactor = Math.pow(zAgl / 10.0, 0.22);
        double speed = baseSpeedMs * gust * shearFactor;

        return new Vector3d(Math.cos(dirRad) * speed, 0.0, Math.sin(dirRad) * speed);
    }

    public static Vector3d getCurrentSurfaceWindMs() {
        return new Vector3d(CURRENT_SURFACE_WIND_MS);
    }

    /**
     * Server-side environmental physics tick: updates boundary-layer wind and snow-layer compaction.
     */
    public static void tickServerEnvironment(ServerWorld world) {
        Vector3d w = sampleWindAtAltitude(world.getTime(), world.isRaining(), world.isThundering(), 72.0);
        CURRENT_SURFACE_WIND_MS.set(w);

        for (ServerPlayerEntity sp : world.getPlayers()) {
            if (sp.isSpectator()) continue;
            double horizSpdSq = sp.getVelocity().horizontalLengthSquared();
            if (horizSpdSq > 0.0025 || sp.fallDistance > 1.5f) {
                BlockPos foot = sp.getBlockPos();
                BlockState st = world.getBlockState(foot);
                if (st.isOf(Blocks.SNOW) && st.contains(SnowBlock.LAYERS)) {
                    int layers = st.get(SnowBlock.LAYERS);
                    if (layers > 1 && (world.getTime() % 5L) == 0L) {
                        int drop = sp.fallDistance > 2.0f ? 2 : 1;
                        world.setBlockState(foot, st.with(SnowBlock.LAYERS, Math.max(1, layers - drop)), 2);
                    }
                }
            }
        }
    }

    /**
     * Advances a player's 7x10 Verlet/XPBD cloth cape mesh at client frame rate (60+ FPS).
     */
    public static ClothMesh stepPlayerClothClient(
            PlayerEntity player,
            float tickDelta,
            boolean raining,
            boolean thundering,
            long worldTime
    ) {
        ClothMesh mesh = PLAYER_CAPES.computeIfAbsent(player.getUuid(), k -> new ClothMesh());
        long now = System.nanoTime();
        double dt = mesh.lastUpdateNano == 0L ? (1.0 / 60.0) : ((now - mesh.lastUpdateNano) * 1.0e-9);
        mesh.lastUpdateNano = now;
        dt = MathHelper.clamp(dt, 1.0 / 240.0, 1.0 / 25.0);

        double baseX = MathHelper.lerp(tickDelta, player.prevX, player.getX());
        double baseY = MathHelper.lerp(tickDelta, player.prevY, player.getY());
        double baseZ = MathHelper.lerp(tickDelta, player.prevZ, player.getZ());
        float bodyYawDeg = MathHelper.lerpAngleDegrees(tickDelta, player.prevBodyYaw, player.bodyYaw);
        double yawRad = Math.toRadians(bodyYawDeg);

        // Player local frame: right = (-cos(yaw), 0, -sin(yaw)), back = (sin(yaw), 0, -cos(yaw))
        // Note: MC yaw 0 faces +Z (South), so forward = (-sin(yaw), 0, cos(yaw)), back = (sin(yaw), 0, -cos(yaw))!
        double rightX = -Math.cos(yawRad);
        double rightZ = -Math.sin(yawRad);
        double backX  =  Math.sin(yawRad);
        double backZ  = -Math.cos(yawRad);

        double shoulderY = baseY + (player.isInSneakingPose() ? 1.18 : 1.40);
        double shoulderBackOffset = 0.15;

        if (!mesh.initialized) {
            mesh.initialized = true;
            for (int r = 0; r < CLOTH_ROWS; r++) {
                for (int c = 0; c < CLOTH_COLS; c++) {
                    int k = mesh.idx(c, r);
                    double lateral = (c - (CLOTH_COLS - 1) * 0.5) * REST_DX;
                    double nx = baseX + rightX * lateral + backX * (shoulderBackOffset + r * 0.02);
                    double ny = shoulderY - r * REST_DY;
                    double nz = baseZ + rightZ * lateral + backZ * (shoulderBackOffset + r * 0.02);
                    mesh.px[k] = mesh.oldPx[k] = nx;
                    mesh.py[k] = mesh.oldPy[k] = ny;
                    mesh.pz[k] = mesh.oldPz[k] = nz;
                }
            }
            return mesh;
        }

        // Reset if player teleported > 6m
        double dTele = (mesh.px[0] - baseX) * (mesh.px[0] - baseX) + (mesh.pz[0] - baseZ) * (mesh.pz[0] - baseZ);
        if (dTele > 36.0) {
            mesh.initialized = false;
            return stepPlayerClothClient(player, tickDelta, raining, thundering, worldTime);
        }

        Vector3d wind = sampleWindAtAltitude(worldTime, raining, thundering, shoulderY);
        double damping = 0.982;
        double grav = -9.80665;

        // 1. Verlet position integration + gravity
        for (int r = 1; r < CLOTH_ROWS; r++) {
            for (int c = 0; c < CLOTH_COLS; c++) {
                int k = mesh.idx(c, r);
                double vx = (mesh.px[k] - mesh.oldPx[k]) * damping;
                double vy = (mesh.py[k] - mesh.oldPy[k]) * damping;
                double vz = (mesh.pz[k] - mesh.oldPz[k]) * damping;

                mesh.oldPx[k] = mesh.px[k];
                mesh.oldPy[k] = mesh.py[k];
                mesh.oldPz[k] = mesh.pz[k];

                mesh.px[k] += vx;
                mesh.py[k] += vy + grav * dt * dt;
                mesh.pz[k] += vz;
            }
        }

        // 2. Triangle-normal aerodynamic lift & wind pressure: F_aero = 0.5 * rho * A * (v_rel . n) * n
        for (int r = 0; r < CLOTH_ROWS - 1; r++) {
            for (int c = 0; c < CLOTH_COLS - 1; c++) {
                int i00 = mesh.idx(c, r);
                int i10 = mesh.idx(c + 1, r);
                int i01 = mesh.idx(c, r + 1);

                double e1x = mesh.px[i10] - mesh.px[i00];
                double e1y = mesh.py[i10] - mesh.py[i00];
                double e1z = mesh.pz[i10] - mesh.pz[i00];
                double e2x = mesh.px[i01] - mesh.px[i00];
                double e2y = mesh.py[i01] - mesh.py[i00];
                double e2z = mesh.pz[i01] - mesh.pz[i00];

                double nx = e1y * e2z - e1z * e2y;
                double ny = e1z * e2x - e1x * e2z;
                double nz = e1x * e2y - e1y * e2x;
                double nLen = Math.sqrt(nx * nx + ny * ny + nz * nz);
                if (nLen < 1.0e-6) continue;
                nx /= nLen; ny /= nLen; nz /= nLen;

                double vNodeX = (mesh.px[i01] - mesh.oldPx[i01]) / dt;
                double vNodeY = (mesh.py[i01] - mesh.oldPy[i01]) / dt;
                double vNodeZ = (mesh.pz[i01] - mesh.oldPz[i01]) / dt;

                double rvx = wind.x - vNodeX;
                double rvy = wind.y - vNodeY;
                double rvz = wind.z - vNodeZ;
                double vn = rvx * nx + rvy * ny + rvz * nz;
                double accelScale = 0.95 * vn * Math.abs(vn) * dt * dt;
                accelScale = MathHelper.clamp(accelScale, -0.025, 0.025);

                if (r > 0) {
                    mesh.px[i00] += nx * accelScale; mesh.py[i00] += ny * accelScale; mesh.pz[i00] += nz * accelScale;
                    mesh.px[i10] += nx * accelScale; mesh.py[i10] += ny * accelScale; mesh.pz[i10] += nz * accelScale;
                }
                mesh.px[i01] += nx * accelScale; mesh.py[i01] += ny * accelScale; mesh.pz[i01] += nz * accelScale;
            }
        }

        // 3. Gauss-Seidel XPBD Distance Constraints (structural + shear + bending) + Player Body Capsule Collision!
        final double diagRest = Math.hypot(REST_DX, REST_DY);
        final double bendRestX = 2.0 * REST_DX;
        final double bendRestY = 2.0 * REST_DY;

        for (int iter = 0; iter < 10; iter++) {
            // Pin top row (r = 0) rigidly to player shoulders
            for (int c = 0; c < CLOTH_COLS; c++) {
                int k = mesh.idx(c, 0);
                double lateral = (c - (CLOTH_COLS - 1) * 0.5) * REST_DX;
                mesh.px[k] = baseX + rightX * lateral + backX * shoulderBackOffset;
                mesh.py[k] = shoulderY;
                mesh.pz[k] = baseZ + rightZ * lateral + backZ * shoulderBackOffset;
            }

            // Structural horizontal & vertical links
            for (int r = 0; r < CLOTH_ROWS; r++) {
                for (int c = 0; c < CLOTH_COLS; c++) {
                    int i = mesh.idx(c, r);
                    if (c + 1 < CLOTH_COLS) satisfyDistance(mesh, i, mesh.idx(c + 1, r), REST_DX, r == 0, r == 0, 1.0);
                    if (r + 1 < CLOTH_ROWS) satisfyDistance(mesh, i, mesh.idx(c, r + 1), REST_DY, r == 0, false, 1.0);
                    // Shear diagonals
                    if (c + 1 < CLOTH_COLS && r + 1 < CLOTH_ROWS) {
                        satisfyDistance(mesh, i, mesh.idx(c + 1, r + 1), diagRest, r == 0, false, 0.75);
                        satisfyDistance(mesh, mesh.idx(c + 1, r), mesh.idx(c, r + 1), diagRest, r == 0, false, 0.75);
                    }
                    // Bending (2-hop) stiffness
                    if (c + 2 < CLOTH_COLS) satisfyDistance(mesh, i, mesh.idx(c + 2, r), bendRestX, r == 0, r == 0, 0.35);
                    if (r + 2 < CLOTH_ROWS) satisfyDistance(mesh, i, mesh.idx(c, r + 2), bendRestY, r == 0, false, 0.35);
                }
            }

            // Player torso & leg sphere-plane collision so cape never clips forward through the player's body!
            for (int r = 1; r < CLOTH_ROWS; r++) {
                for (int c = 0; c < CLOTH_COLS; c++) {
                    int k = mesh.idx(c, r);
                    double relX = mesh.px[k] - baseX;
                    double relZ = mesh.pz[k] - baseZ;
                    double backProj = relX * backX + relZ * backZ;
                    double minBack = 0.145 + (r >= 5 ? 0.045 * Math.abs(Math.sin(player.limbAnimator.getPos(tickDelta) * 0.6662)) : 0.0);
                    if (backProj < minBack) {
                        double push = minBack - backProj;
                        mesh.px[k] += backX * push;
                        mesh.pz[k] += backZ * push;
                    }
                    if (mesh.py[k] < baseY + 0.05) {
                        mesh.py[k] = baseY + 0.05;
                    }
                }
            }
        }

        return mesh;
    }

    private static void satisfyDistance(ClothMesh m, int a, int b, double restLen, boolean pinA, boolean pinB, double stiffness) {
        if (pinA && pinB) return;
        double dx = m.px[b] - m.px[a];
        double dy = m.py[b] - m.py[a];
        double dz = m.pz[b] - m.pz[a];
        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (dist < 1.0e-7) return;
        double diff = ((dist - restLen) / dist) * stiffness;
        if (pinA) {
            m.px[b] -= dx * diff;
            m.py[b] -= dy * diff;
            m.pz[b] -= dz * diff;
        } else if (pinB) {
            m.px[a] += dx * diff;
            m.py[a] += dy * diff;
            m.pz[a] += dz * diff;
        } else {
            double half = 0.5 * diff;
            m.px[a] += dx * half; m.py[a] += dy * half; m.pz[a] += dz * half;
            m.px[b] -= dx * half; m.py[b] -= dy * half; m.pz[b] -= dz * half;
        }
    }
}

package ai.arena.bridge.physics.pro;

import ai.arena.bridge.physics.pro.ConstitutiveMaterialDB.SectionProperties;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.SnowBlock;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import org.joml.Matrix3d;
import org.joml.Quaternionf;
import org.joml.Vector3d;
import org.joml.Vector3f;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Unified 160 Hz (8 substeps/tick) 6-DoF Rigid-Body & Multi-Voxel Compound Dynamics Engine.
 *
 * Features:
 * 1. Lock-free immutable RenderSnapshot published atomically at tick commit with System.nanoTime()
 *    plus inContact/submerged flags for exact zero-latency parabolic client forward prediction.
 * 2. True 0.496m cube half-extents + 0.003m contact slop + exposed-face seam guard:
 *    eliminates internal floor/wall seam snagging AND eliminates the 5cm solidification pop!
 * 3. Zero-blink solidification handoff: writes blocks to ServerWorld first, keeps client mesh alive
 *    for 2 ticks while ClientWorld receives chunk block packets (hiding per-voxel once solid on client).
 * 4. Rigid-body vs rigid-body impulse collisions so multiple falling blocks collide in mid-air.
 */
public final class RigidBody6DoFDynamics {

    public static final int MAX_ACTIVE_BODIES = 180;
    public static final List<RigidCluster6DoF> ACTIVE_BODIES = new CopyOnWriteArrayList<>();

    public static void wakeBodiesNear(BlockPos center, double radius) {
        double r2 = radius * radius;
        for (RigidCluster6DoF b : ACTIVE_BODIES) {
            if (!b.sleeping) continue;
            double dx = b.px - (center.getX() + 0.5);
            double dy = b.py - (center.getY() + 0.5);
            double dz = b.pz - (center.getZ() + 0.5);
            if (dx * dx + dy * dy + dz * dz <= r2) {
                b.sleeping = false;
                b.solidifiedOnServer = false;
                b.lowEnergyTicks = 0;
                b.postSolidifyTicks = 0;
                b.lastPublishNano = System.nanoTime();
            }
        }
    }

    public record LocalVoxel(
            double lx, double ly, double lz,
            BlockState state,
            SectionProperties section,
            boolean isBoundaryHull
    ) {}

    public record RenderSnapshot(
            double x1, double y1, double z1,
            double vx1, double vy1, double vz1,
            float qx1, float qy1, float qz1, float qw1,
            double wx1, double wy1, double wz1,
            double netAccelY,
            long publishNano,
            boolean inContact,
            boolean sleeping,
            boolean solidifiedOnServer
    ) {}

    public static final class RigidCluster6DoF {
        public final long bodyId;
        public final String blueprintId;
        public final List<LocalVoxel> voxels;
        public final List<LocalVoxel> collisionHull;
        public final List<ContinuousStructuralBeams.DetachedContinuousBeam> attachedBeams = new CopyOnWriteArrayList<>();
        public final double totalMassKg;
        public final double invMass;
        public final double averageDensityKgM3;
        public final double restitution;
        public final double friction;
        public final boolean brittleShatter;

        public final Matrix3d inertiaBody = new Matrix3d();
        public final Matrix3d invInertiaBody = new Matrix3d();

        public double px, py, pz;
        public double vx, vy, vz;
        public double wx, wy, wz;
        public final Quaternionf quat = new Quaternionf();
        public long lastPublishNano;

        public volatile RenderSnapshot renderSnap;

        public double boundingRadius = 0.86;
        public int ageTicks = 0;
        public int lowEnergyTicks = 0;
        public int postSolidifyTicks = 0;
        public boolean sleeping = false;
        public boolean solidifiedOnServer = false;
        public boolean enteredWater = false;

        private static long NEXT_ID = 1L;

        public RigidCluster6DoF(
                String blueprintId,
                double cmX, double cmY, double cmZ,
                Quaternionf initialQuat,
                List<LocalVoxel> voxels,
                double totalMassKg,
                Matrix3d inertiaTensor,
                double restitution,
                double friction,
                boolean brittleShatter,
                double vx, double vy, double vz,
                double wx, double wy, double wz
        ) {
            this.bodyId = NEXT_ID++;
            this.blueprintId = blueprintId;
            this.voxels = voxels;
            this.collisionHull = new ArrayList<>();
            int boundaryCount = 0;
            for (LocalVoxel v : voxels) {
                if (v.isBoundaryHull()) boundaryCount++;
            }
            // Keep 100% of boundary hull blocks up to 512 so fallen houses never clip into uneven terrain steps!
            int stride = Math.max(1, boundaryCount / 512);
            int seen = 0;
            double maxR2 = 0.72;
            for (LocalVoxel v : voxels) {
                double r2 = (Math.abs(v.lx()) + 0.5) * (Math.abs(v.lx()) + 0.5)
                        + (Math.abs(v.ly()) + 0.5) * (Math.abs(v.ly()) + 0.5)
                        + (Math.abs(v.lz()) + 0.5) * (Math.abs(v.lz()) + 0.5);
                if (r2 > maxR2) maxR2 = r2;
                if (v.isBoundaryHull() && (seen++ % stride) == 0) {
                    this.collisionHull.add(v);
                }
            }
            if (this.collisionHull.isEmpty() && !voxels.isEmpty()) {
                this.collisionHull.add(voxels.get(0));
            }
            this.boundingRadius = Math.sqrt(maxR2);

            this.totalMassKg = Math.max(25.0, totalMassKg);
            this.invMass = 1.0 / this.totalMassKg;
            this.averageDensityKgM3 = this.totalMassKg / Math.max(0.25, voxels.size());
            this.restitution = restitution;
            this.friction = friction;
            this.brittleShatter = brittleShatter;

            this.inertiaBody.set(inertiaTensor);
            this.invInertiaBody.set(inertiaTensor).invert();

            this.px = cmX;
            this.py = cmY;
            this.pz = cmZ;
            if (initialQuat != null) {
                this.quat.set(initialQuat).normalize();
            }
            this.vx = vx;
            this.vy = vy;
            this.vz = vz;
            this.wx = wx;
            this.wy = wy;
            this.wz = wz;
            this.lastPublishNano = System.nanoTime();
            this.renderSnap = new RenderSnapshot(
                    cmX, cmY, cmZ, vx, vy, vz,
                    this.quat.x, this.quat.y, this.quat.z, this.quat.w,
                    wx, wy, wz, -9.80665, this.lastPublishNano, false, false, false
            );
        }
    }

    public static RigidCluster6DoF createFromWorldVoxels(
            String blueprintId,
            List<BlockPos> worldPositions,
            List<BlockState> blockStates,
            Vector3d initLinearVel,
            Vector3d initAngularVel
    ) {
        int count = worldPositions.size();
        SectionProperties[] secs = new SectionProperties[count];
        java.util.Set<BlockPos> posSet = new java.util.HashSet<>(worldPositions);

        double totalM = 0.0;
        double sumMx = 0.0, sumMy = 0.0, sumMz = 0.0;
        double sumRest = 0.0, sumFric = 0.0;
        boolean allBrittle = count > 0;

        for (int i = 0; i < count; i++) {
            SectionProperties sp = ConstitutiveMaterialDB.computeSection(blockStates.get(i));
            secs[i] = sp;
            BlockPos p = worldPositions.get(i);
            double m = sp.massKg();
            totalM += m;
            sumMx += m * (p.getX() + 0.5);
            sumMy += m * (p.getY() + 0.5);
            sumMz += m * (p.getZ() + 0.5);
            sumRest += m * sp.category().restitution;
            sumFric += m * sp.category().slidingFriction;
            if (!sp.category().shattersOnImpact) allBrittle = false;
        }

        totalM = Math.max(25.0, totalM);
        double cmX = sumMx / totalM;
        double cmY = sumMy / totalM;
        double cmZ = sumMz / totalM;

        double ixx = 0.0, iyy = 0.0, izz = 0.0;
        double ixy = 0.0, ixz = 0.0, iyz = 0.0;

        List<LocalVoxel> locals = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            BlockPos p = worldPositions.get(i);
            double rx = (p.getX() + 0.5) - cmX;
            double ry = (p.getY() + 0.5) - cmY;
            double rz = (p.getZ() + 0.5) - cmZ;
            double m = secs[i].massKg();
            double selfCube = m * (1.0 / 6.0);

            ixx += selfCube + m * (ry * ry + rz * rz);
            iyy += selfCube + m * (rx * rx + rz * rz);
            izz += selfCube + m * (rx * rx + ry * ry);
            ixy -= m * rx * ry;
            ixz -= m * rx * rz;
            iyz -= m * ry * rz;

            boolean hull = false;
            for (Direction d : Direction.values()) {
                if (!posSet.contains(p.offset(d))) {
                    hull = true;
                    break;
                }
            }
            locals.add(new LocalVoxel(rx, ry, rz, blockStates.get(i), secs[i], hull));
        }

        Matrix3d inertia = new Matrix3d(
                Math.max(5.0, ixx), ixy, ixz,
                ixy, Math.max(5.0, iyy), iyz,
                ixz, iyz, Math.max(5.0, izz)
        );
        if (Math.abs(inertia.determinant()) < 1.0) {
            inertia.identity().scale(Math.max(10.0, totalM / 6.0));
        }

        return new RigidCluster6DoF(
                blueprintId, cmX, cmY, cmZ, null, locals, totalM, inertia,
                sumRest / totalM, sumFric / totalM, allBrittle && count <= 4,
                initLinearVel.x, initLinearVel.y, initLinearVel.z,
                initAngularVel.x, initAngularVel.y, initAngularVel.z
        );
    }

    private static RigidCluster6DoF createChildFromContinuousParent(
            RigidCluster6DoF parent,
            double parentX, double parentY, double parentZ,
            Quaternionf parentQuat,
            List<LocalVoxel> subset,
            Vector3d childLinVel,
            Vector3d childAngVel
    ) {
        double totalM = 0.0;
        double dLx = 0.0, dLy = 0.0, dLz = 0.0;
        double sumRest = 0.0, sumFric = 0.0;
        for (LocalVoxel lv : subset) {
            double m = lv.section().massKg();
            totalM += m;
            dLx += m * lv.lx();
            dLy += m * lv.ly();
            dLz += m * lv.lz();
            sumRest += m * lv.section().category().restitution;
            sumFric += m * lv.section().category().slidingFriction;
        }
        totalM = Math.max(25.0, totalM);
        dLx /= totalM; dLy /= totalM; dLz /= totalM;

        Vector3f worldOffset = new Vector3f((float) dLx, (float) dLy, (float) dLz);
        parentQuat.transform(worldOffset);
        double newCmX = parentX + worldOffset.x;
        double newCmY = parentY + worldOffset.y;
        double newCmZ = parentZ + worldOffset.z;

        double ixx = 0, iyy = 0, izz = 0, ixy = 0, ixz = 0, iyz = 0;
        List<LocalVoxel> recentered = new ArrayList<>(subset.size());
        for (LocalVoxel lv : subset) {
            double rx = lv.lx() - dLx;
            double ry = lv.ly() - dLy;
            double rz = lv.lz() - dLz;
            double m = lv.section().massKg();
            double selfCube = m * (1.0 / 6.0);
            ixx += selfCube + m * (ry * ry + rz * rz);
            iyy += selfCube + m * (rx * rx + rz * rz);
            izz += selfCube + m * (rx * rx + ry * ry);
            ixy -= m * rx * ry;
            ixz -= m * rx * rz;
            iyz -= m * ry * rz;
            recentered.add(new LocalVoxel(rx, ry, rz, lv.state(), lv.section(), true));
        }

        Matrix3d inertia = new Matrix3d(
                Math.max(5.0, ixx), ixy, ixz,
                ixy, Math.max(5.0, iyy), iyz,
                ixz, iyz, Math.max(5.0, izz)
        );
        if (Math.abs(inertia.determinant()) < 1.0) {
            inertia.identity().scale(Math.max(10.0, totalM / 6.0));
        }

        return new RigidCluster6DoF(
                parent.blueprintId, newCmX, newCmY, newCmZ, parentQuat,
                recentered, totalM, inertia, sumRest / totalM, sumFric / totalM, false,
                childLinVel.x, childLinVel.y, childLinVel.z,
                childAngVel.x, childAngVel.y, childAngVel.z
        );
    }

    public interface SolidifyCallback {
        void onBodySettled(ServerWorld world, RigidCluster6DoF body);
    }

    // Exact 0.496m half-extent matches 1.000m Minecraft blocks within 4mm so solidification has ZERO upward pop!
    private static final double[][] CUBE_CORNERS = {
            {-0.494, -0.496, -0.494}, { 0.494, -0.496, -0.494}, {-0.494,  0.496, -0.494}, { 0.494,  0.496, -0.494},
            {-0.494, -0.496,  0.494}, { 0.494, -0.496,  0.494}, {-0.494,  0.496,  0.494}, { 0.494,  0.496,  0.494}
    };
    private static final double CONTACT_SLOP_M = 0.0035;

    private static boolean isExposedFace(ServerWorld world, BlockPos.Mutable nbPos, int nx, int ny, int nz) {
        if (!world.isChunkLoaded(nx >> 4, nz >> 4)) return true;
        nbPos.set(nx, ny, nz);
        BlockState st = FractureAndSolidifier.resolveEffectiveState(world, nbPos);
        return st.isAir() || !st.getFluidState().isEmpty() || st.getCollisionShape(world, nbPos).isEmpty();
    }

    /**
     * Exact Per-Voxel 3D Rigid-Body vs Rigid-Body Contact & Impulse Solver (handles BOTH awake-vs-awake
     * AND awake-vs-sleeping so fallen beams/planks pile up ON TOP OF fallen house walls instead of passing through!).
     */
    private static void resolveExactVoxelBodyCollisions() {
        int nBodies = ACTIVE_BODIES.size();
        if (nBodies < 2) return;

        Vector3f vA = new Vector3f();
        Vector3f vB = new Vector3f();
        Vector3d rcA = new Vector3d();
        Vector3d rcB = new Vector3d();
        Vector3d iRcA = new Vector3d();
        Vector3d iRcB = new Vector3d();
        Matrix3d rot = new Matrix3d();
        Matrix3d rotT = new Matrix3d();
        Matrix3d invIaW = new Matrix3d();
        Matrix3d invIbW = new Matrix3d();

        for (int i = 0; i < nBodies; i++) {
            RigidCluster6DoF a = ACTIVE_BODIES.get(i);
            for (int j = i + 1; j < nBodies; j++) {
                RigidCluster6DoF b = ACTIVE_BODIES.get(j);
                if (a.sleeping && b.sleeping) continue;

                double bdx = b.px - a.px, bdy = b.py - a.py, bdz = b.pz - a.pz;
                double maxRange = a.boundingRadius + b.boundingRadius + 1.15;
                if (bdx * bdx + bdy * bdy + bdz * bdz > maxRange * maxRange) continue;

                // Index larger body's hull voxels into a 1m spatial grid, test smaller body's hull voxels against 3x3x3 cells
                RigidCluster6DoF heavy = (a.collisionHull.size() >= b.collisionHull.size()) ? a : b;
                RigidCluster6DoF light = (heavy == a) ? b : a;

                Map<Long, List<double[]>> grid = new HashMap<>(heavy.collisionHull.size() * 2);
                for (LocalVoxel hv : heavy.collisionHull) {
                    vB.set((float) hv.lx(), (float) hv.ly(), (float) hv.lz());
                    heavy.quat.transform(vB);
                    double wx = heavy.px + vB.x, wy = heavy.py + vB.y, wz = heavy.pz + vB.z;
                    long key = BlockPos.asLong((int) Math.floor(wx), (int) Math.floor(wy), (int) Math.floor(wz));
                    grid.computeIfAbsent(key, k -> new ArrayList<>(2)).add(new double[]{wx, wy, wz});
                }

                double invMa = light.sleeping ? 0.0 : light.invMass;
                double invMb = heavy.sleeping ? 0.0 : heavy.invMass;
                if (invMa + invMb <= 0.0) continue;

                rot.set(light.quat); rot.transpose(rotT);
                invIaW.set(rot).mul(light.invInertiaBody).mul(rotT);
                rot.set(heavy.quat); rot.transpose(rotT);
                invIbW.set(rot).mul(heavy.invInertiaBody).mul(rotT);

                int contactCount = 0;
                double sumNx = 0.0, sumNy = 0.0, sumNz = 0.0, maxPen = 0.0;
                double sumCx = 0.0, sumCy = 0.0, sumCz = 0.0;

                for (LocalVoxel lv : light.collisionHull) {
                    vA.set((float) lv.lx(), (float) lv.ly(), (float) lv.lz());
                    light.quat.transform(vA);
                    double ax = light.px + vA.x, ay = light.py + vA.y, az = light.pz + vA.z;
                    int cx = (int) Math.floor(ax), cy = (int) Math.floor(ay), cz = (int) Math.floor(az);

                    for (int ox = -1; ox <= 1; ox++) {
                        for (int oy = -1; oy <= 1; oy++) {
                            for (int oz = -1; oz <= 1; oz++) {
                                List<double[]> bucket = grid.get(BlockPos.asLong(cx + ox, cy + oy, cz + oz));
                                if (bucket == null) continue;
                                for (double[] bp : bucket) {
                                    double dx = ax - bp[0], dy = ay - bp[1], dz = az - bp[2];
                                    double d2 = dx * dx + dy * dy + dz * dz;
                                    // Two 1x1x1 blocks / 0.42m beam spheres overlap when center distance < 0.90m
                                    double minSep = (lv.state().isAir()) ? 0.72 : 0.90;
                                    if (d2 < minSep * minSep && d2 > 1.0e-7) {
                                        double d = Math.sqrt(d2);
                                        double pen = minSep - d;
                                        sumNx += (dx / d) * pen;
                                        sumNy += (dy / d) * pen;
                                        sumNz += (dz / d) * pen;
                                        sumCx += 0.5 * (ax + bp[0]);
                                        sumCy += 0.5 * (ay + bp[1]);
                                        sumCz += 0.5 * (az + bp[2]);
                                        if (pen > maxPen) maxPen = pen;
                                        contactCount++;
                                    }
                                }
                            }
                        }
                    }
                }

                if (contactCount == 0 || maxPen <= 0.002) continue;
                double nLen = Math.sqrt(sumNx * sumNx + sumNy * sumNy + sumNz * sumNz);
                if (nLen < 1.0e-6) continue;
                double nx = sumNx / nLen, ny = sumNy / nLen, nz = sumNz / nLen; // points from heavy -> light
                double pcx = sumCx / contactCount, pcy = sumCy / contactCount, pcz = sumCz / contactCount;

                // Positional Baumgarte separation weighted by inverse mass (sleeping heavy body stays rock-steady!)
                double corr = (maxPen - 0.002) * 0.78 / (invMa + invMb);
                if (!light.sleeping) {
                    light.px += nx * corr * invMa;
                    light.py += ny * corr * invMa;
                    light.pz += nz * corr * invMa;
                }
                if (!heavy.sleeping) {
                    heavy.px -= nx * corr * invMb;
                    heavy.py -= ny * corr * invMb;
                    heavy.pz -= nz * corr * invMb;
                }

                double rAx = pcx - light.px, rAy = pcy - light.py, rAz = pcz - light.pz;
                double rBx = pcx - heavy.px, rBy = pcy - heavy.py, rBz = pcz - heavy.pz;

                double vAx = light.vx + (light.wy * rAz - light.wz * rAy);
                double vAy = light.vy + (light.wz * rAx - light.wx * rAz);
                double vAz = light.vz + (light.wx * rAy - light.wy * rAx);

                double vBx = heavy.vx + (heavy.wy * rBz - heavy.wz * rBy);
                double vBy = heavy.vy + (heavy.wz * rBx - heavy.wx * rBz);
                double vBz = heavy.vz + (heavy.wx * rBy - heavy.wy * rBx);

                double rvx = vAx - vBx, rvy = vAy - vBy, rvz = vAz - vBz;
                double vn = rvx * nx + rvy * ny + rvz * nz;
                if (vn >= 0.0) continue;

                rcA.set(rAy * nz - rAz * ny, rAz * nx - rAx * nz, rAx * ny - rAy * nx);
                invIaW.transform(rcA, iRcA);
                double angA = light.sleeping ? 0.0 : (rcA.dot(iRcA));

                rcB.set(rBy * nz - rBz * ny, rBz * nx - rBx * nz, rBx * ny - rBy * nx);
                invIbW.transform(rcB, iRcB);
                double angB = heavy.sleeping ? 0.0 : (rcB.dot(iRcB));

                double kEff = invMa + invMb + Math.max(0.0, angA) + Math.max(0.0, angB);
                double eRest = (-vn < 1.1) ? 0.0 : 0.5 * (light.restitution + heavy.restitution);
                double jn = -(1.0 + eRest) * vn / kEff;

                // Wake a sleeping body ONLY if hit with meaningful momentum relative to its weight
                if (heavy.sleeping && jn > heavy.totalMassKg * 1.35) {
                    heavy.sleeping = false;
                    heavy.lowEnergyTicks = 0;
                }
                if (light.sleeping && jn > light.totalMassKg * 1.35) {
                    light.sleeping = false;
                    light.lowEnergyTicks = 0;
                }

                if (!light.sleeping) {
                    light.vx += (jn * nx) * invMa;
                    light.vy += (jn * ny) * invMa;
                    light.vz += (jn * nz) * invMa;
                    light.wx += iRcA.x * jn;
                    light.wy += iRcA.y * jn;
                    light.wz += iRcA.z * jn;
                    // Coulomb tangential friction so beams resting on tilted roofs don't skate frictionlessly!
                    double tx = rvx - vn * nx, ty = rvy - vn * ny, tz = rvz - vn * nz;
                    double tLen = Math.sqrt(tx * tx + ty * ty + tz * tz);
                    if (tLen > 1.0e-5) {
                        tx /= tLen; ty /= tLen; tz /= tLen;
                        double mu = 0.5 * (light.friction + heavy.friction);
                        double jt = Math.min(mu * jn, tLen / kEff);
                        light.vx -= (jt * tx) * invMa;
                        light.vy -= (jt * ty) * invMa;
                        light.vz -= (jt * tz) * invMa;
                    }
                }
                if (!heavy.sleeping) {
                    heavy.vx -= (jn * nx) * invMb;
                    heavy.vy -= (jn * ny) * invMb;
                    heavy.vz -= (jn * nz) * invMb;
                    heavy.wx -= iRcB.x * jn;
                    heavy.wy -= iRcB.y * jn;
                    heavy.wz -= iRcB.z * jn;
                }
            }
        }
    }

    public static void tickAll(ServerWorld world, double timeScale, Vector3d windVecMs, SolidifyCallback solidifier) {
        if (ACTIVE_BODIES.isEmpty()) return;

        final int substeps = 8; // 160 Hz internal solver precision
        final double scaledTickSec = 0.05 * MathHelper.clamp(timeScale, 0.05, 2.0);
        final double dt = scaledTickSec / substeps;
        final double waveTime = world.getTime() * 0.14;

        Matrix3d rotMat = new Matrix3d();
        Matrix3d rotMatT = new Matrix3d();
        Matrix3d invIWorld = new Matrix3d();
        Matrix3d iWorld = new Matrix3d();
        Vector3f rTmp = new Vector3f();
        Quaternionf curQ = new Quaternionf();
        Vector3d omegaVec = new Vector3d();
        Vector3d iOmega = new Vector3d();
        Vector3d gyro = new Vector3d();
        Vector3d hydroTorque = new Vector3d();
        Vector3d rCrossN = new Vector3d();
        Vector3d iInvRCrossN = new Vector3d();
        BlockPos.Mutable mp = new BlockPos.Mutable();
        BlockPos.Mutable nbPos = new BlockPos.Mutable();

        List<RigidCluster6DoF> spawnedChildren = null;

        // Exact per-voxel 3D rigid-body vs rigid-body collision (awake-vs-awake AND awake-vs-sleeping!)
        resolveExactVoxelBodyCollisions();

        for (RigidCluster6DoF body : ACTIVE_BODIES) {
            body.ageTicks++;

            // Persistent Sleeping 3D Rubble:
            // Once settled, install walkable invisible collision proxies once and KEEP the 3D rigid body
            // permanently at its exact continuous tilted pose (0.000 ms CPU cost, ZERO vanishing or 90° grid snap!).
            if (body.sleeping) {
                if (!body.solidifiedOnServer && body.ageTicks > 10) {
                    body.solidifiedOnServer = true;
                    solidifier.onBodySettled(world, body);
                    body.renderSnap = new RenderSnapshot(
                            body.px, body.py, body.pz, 0, 0, 0,
                            body.quat.x, body.quat.y, body.quat.z, body.quat.w,
                            0, 0, 0, 0.0, System.nanoTime(), true, true, false
                    );
                }
                continue;
            }

            int chunkX = ((int) Math.floor(body.px)) >> 4;
            int chunkZ = ((int) Math.floor(body.pz)) >> 4;
            if (!world.isChunkLoaded(chunkX, chunkZ)) continue;

            double curX = body.px, curY = body.py, curZ = body.pz;
            double curVx = body.vx, curVy = body.vy, curVz = body.vz;
            double curWx = body.wx, curWy = body.wy, curWz = body.wz;
            curQ.set(body.quat);

            double maxNormalImpactSpeed = 0.0;
            BlockPos impactBlockPos = null;
            boolean hadWorldContact = false;
            double lastNetAccelY = -9.80665;

            for (int step = 0; step < substeps; step++) {
                rotMat.set(curQ);
                rotMatT.set(rotMat).transpose();
                rotMat.mul(body.invInertiaBody, invIWorld).mul(rotMatT);
                rotMat.mul(body.inertiaBody, iWorld).mul(rotMatT);

                double fx = 0.0, fy = -body.totalMassKg * 9.80665, fz = 0.0;
                hydroTorque.zero();
                int submergedHullCount = 0;
                double highestWaterSurf = -999.0;

                double hullScale = (double) body.voxels.size() / Math.max(1, body.collisionHull.size());
                for (LocalVoxel hv : body.collisionHull) {
                    rTmp.set((float) hv.lx(), (float) hv.ly(), (float) hv.lz());
                    curQ.transform(rTmp);
                    double wxPos = curX + rTmp.x;
                    double wyPos = curY + rTmp.y;
                    double wzPos = curZ + rTmp.z;

                    int bx = (int) Math.floor(wxPos);
                    int by = (int) Math.floor(wyPos);
                    int bz = (int) Math.floor(wzPos);
                    if (!world.isChunkLoaded(bx >> 4, bz >> 4)) continue;

                    FluidState fs = world.getFluidState(mp.set(bx, by, bz));
                    if (fs.isIn(FluidTags.WATER)) {
                        submergedHullCount++;
                        double waveDisp = 0.05 * Math.sin(wxPos * 0.55 + waveTime) + 0.035 * Math.cos(wzPos * 0.48 - waveTime * 0.85);
                        double surfY = by + fs.getHeight(world, mp) + waveDisp;
                        highestWaterSurf = Math.max(highestWaterSurf, surfY);
                        double subDepth = MathHelper.clamp(surfY - (wyPos - 0.5), 0.0, 1.0);

                        double fBuoy = 1000.0 * hv.section().volumeFraction() * subDepth * 9.80665 * hullScale;
                        fy += fBuoy;

                        double vpx = curVx + (curWy * rTmp.z - curWz * rTmp.y);
                        double vpy = curVy + (curWz * rTmp.x - curWx * rTmp.z);
                        double vpz = curVz + (curWx * rTmp.y - curWy * rTmp.x);
                        double spd = Math.sqrt(vpx * vpx + vpy * vpy + vpz * vpz);

                        double dragCoeff = (220.0 + 480.0 * spd) * subDepth * hullScale;
                        double dfx = -dragCoeff * vpx;
                        double dfy = -dragCoeff * vpy;
                        double dfz = -dragCoeff * vpz;
                        fx += dfx; fy += dfy; fz += dfz;

                        double totFy = fBuoy + dfy;
                        hydroTorque.x += rTmp.y * dfz - rTmp.z * totFy;
                        hydroTorque.y += rTmp.z * dfx - rTmp.x * dfz;
                        hydroTorque.z += rTmp.x * totFy - rTmp.y * dfx;
                    }
                }

                if (submergedHullCount == 0 && windVecMs != null) {
                    double rvx = windVecMs.x - curVx;
                    double rvz = windVecMs.z - curVz;
                    double relSpd = Math.hypot(rvx, rvz);
                    double aero = 0.6125 * 1.05 * Math.max(1.0, Math.pow(body.voxels.size(), 0.67)) * relSpd;
                    fx += aero * rvx;
                    fz += aero * rvz;
                }

                if (submergedHullCount > 0 && !body.enteredWater && curVy < -1.8) {
                    body.enteredWater = true;
                    double sy = highestWaterSurf > -900 ? highestWaterSurf : curY;
                    int splashCount = Math.min(36, 8 + body.voxels.size() * 2);
                    world.spawnParticles(ParticleTypes.SPLASH, curX, sy + 0.08, curZ, splashCount, 0.5, 0.12, 0.5, 0.22);
                    world.spawnParticles(ParticleTypes.BUBBLE_POP, curX, sy + 0.04, curZ, splashCount / 2, 0.5, 0.08, 0.5, 0.05);
                    world.playSound(null, BlockPos.ofFloored(curX, sy, curZ), SoundEvents.ENTITY_GENERIC_SPLASH,
                            SoundCategory.BLOCKS, Math.min(1.2f, 0.45f + (float) Math.abs(curVy) * 0.08f), 0.88f);
                }

                lastNetAccelY = fy * body.invMass;
                curVx = (curVx + (fx * body.invMass) * dt) * 0.9992;
                curVy = (curVy + lastNetAccelY * dt) * 0.9992;
                curVz = (curVz + (fz * body.invMass) * dt) * 0.9992;

                omegaVec.set(curWx, curWy, curWz);
                iWorld.transform(omegaVec, iOmega);
                omegaVec.cross(iOmega, gyro);
                hydroTorque.sub(gyro);
                invIWorld.transform(hydroTorque);

                double angDamp = submergedHullCount > 0 ? 0.980 : 0.997;
                curWx = (curWx + hydroTorque.x * dt) * angDamp;
                curWy = (curWy + hydroTorque.y * dt) * angDamp;
                curWz = (curWz + hydroTorque.z * dt) * angDamp;

                curX += curVx * dt;
                curY += curVy * dt;
                curZ += curVz * dt;

                float hdt = (float) (0.5 * dt);
                float qx = curQ.x, qy = curQ.y, qz = curQ.z, qw = curQ.w;
                float owx = (float) curWx, owy = (float) curWy, owz = (float) curWz;
                curQ.set(
                        qx + hdt * (owx * qw + owy * qz - owz * qy),
                        qy + hdt * (owy * qw + owz * qx - owx * qz),
                        qz + hdt * (owz * qw + owx * qy - owy * qx),
                        qw + hdt * (-owx * qx - owy * qy - owz * qz)
                ).normalize();

                for (LocalVoxel hv : body.collisionHull) {
                    double bestPen = 0.0;
                    double bestNx = 0.0, bestNy = 1.0, bestNz = 0.0;
                    double sumRx = 0.0, sumRy = 0.0, sumRz = 0.0, sumPenW = 0.0;
                    int hitBx = 0, hitBy = 0, hitBz = 0;

                    for (int ci = 0; ci < CUBE_CORNERS.length; ci++) {
                        rTmp.set((float) (hv.lx() + CUBE_CORNERS[ci][0]),
                                 (float) (hv.ly() + CUBE_CORNERS[ci][1]),
                                 (float) (hv.lz() + CUBE_CORNERS[ci][2]));
                        curQ.transform(rTmp);

                        double cx = curX + rTmp.x;
                        double cy = curY + rTmp.y;
                        double cz = curZ + rTmp.z;
                        int bx = (int) Math.floor(cx);
                        int by = (int) Math.floor(cy);
                        int bz = (int) Math.floor(cz);
                        if (!world.isChunkLoaded(bx >> 4, bz >> 4)) continue;

                        BlockState hitSt = FractureAndSolidifier.resolveEffectiveState(world, mp.set(bx, by, bz));
                        if (hitSt.isAir() || !hitSt.getFluidState().isEmpty()) continue;
                        if (hitSt.isOf(Blocks.BARRIER)) {
                            Long owner = FractureAndSolidifier.RUBBLE_BARRIER_OWNER.get(mp);
                            if (owner != null && owner == body.bodyId) continue;
                        }

                        if (hitSt.isOf(Blocks.SNOW) && hitSt.contains(SnowBlock.LAYERS) && step == 0 && ci == 0) {
                            int layers = hitSt.get(SnowBlock.LAYERS);
                            if (layers > 1 && curVy < -1.0) {
                                world.setBlockState(mp, hitSt.with(SnowBlock.LAYERS, Math.max(1, layers - 2)), 2);
                            }
                        }
                        if (hitSt.getCollisionShape(world, mp).isEmpty()) continue;

                        FractureAndSolidifier.ElasticSagVoxel sagged = FractureAndSolidifier.ELASTIC_PROXIES.get(mp);
                        double sagShiftY = sagged != null ? sagged.targetDy() : 0.0;
                        double boxTop = by + hitSt.getCollisionShape(world, mp).getMax(Direction.Axis.Y) + sagShiftY;
                        if (cy > boxTop) continue;

                        double penY  = boxTop - cy;
                        double penX0 = cx - bx;
                        double penX1 = (bx + 1.0) - cx;
                        double penZ0 = cz - bz;
                        double penZ1 = (bz + 1.0) - cz;

                        double nx = 0.0, ny = 1.0, nz = 0.0;
                        double minPen = Double.POSITIVE_INFINITY;
                        if (isExposedFace(world, nbPos, bx, by + 1, bz) && penY < minPen) {
                            minPen = penY; nx = 0.0; ny = 1.0; nz = 0.0;
                        }
                        if (isExposedFace(world, nbPos, bx - 1, by, bz) && penX0 < minPen) {
                            minPen = penX0; nx = -1.0; ny = 0.0; nz = 0.0;
                        }
                        if (isExposedFace(world, nbPos, bx + 1, by, bz) && penX1 < minPen) {
                            minPen = penX1; nx = 1.0; ny = 0.0; nz = 0.0;
                        }
                        if (isExposedFace(world, nbPos, bx, by, bz - 1) && penZ0 < minPen) {
                            minPen = penZ0; nx = 0.0; ny = 0.0; nz = -1.0;
                        }
                        if (isExposedFace(world, nbPos, bx, by, bz + 1) && penZ1 < minPen) {
                            minPen = penZ1; nx = 0.0; ny = 0.0; nz = 1.0;
                        }

                        if (minPen < 1.35 && minPen > 0.0) {
                            double w = minPen + 0.002;
                            sumRx += rTmp.x * w;
                            sumRy += rTmp.y * w;
                            sumRz += rTmp.z * w;
                            sumPenW += w;
                            if (minPen > bestPen) {
                                bestPen = minPen;
                                bestNx = nx; bestNy = ny; bestNz = nz;
                                hitBx = bx; hitBy = by; hitBz = bz;
                            }
                        }
                    }

                    if (bestPen <= 0.0 || sumPenW <= 0.0) continue;
                    double bestRx = sumRx / sumPenW;
                    double bestRy = sumRy / sumPenW;
                    double bestRz = sumRz / sumPenW;
                    hadWorldContact = true;

                    if (bestPen > CONTACT_SLOP_M) {
                        double corr = (bestPen - CONTACT_SLOP_M) * 0.55;
                        curX += bestNx * corr;
                        curY += bestNy * corr;
                        curZ += bestNz * corr;
                    }

                    double vpx = curVx + (curWy * bestRz - curWz * bestRy);
                    double vpy = curVy + (curWz * bestRx - curWx * bestRz);
                    double vpz = curVz + (curWx * bestRy - curWy * bestRx);
                    double vn = vpx * bestNx + vpy * bestNy + vpz * bestNz;

                    if (vn < 0.0) {
                        if (-vn > maxNormalImpactSpeed) {
                            maxNormalImpactSpeed = -vn;
                            impactBlockPos = new BlockPos(hitBx, hitBy, hitBz);
                        }

                        rCrossN.set(bestRy * bestNz - bestRz * bestNy,
                                    bestRz * bestNx - bestRx * bestNz,
                                    bestRx * bestNy - bestRy * bestNx);
                        invIWorld.transform(rCrossN, iInvRCrossN);
                        double angEff = (iInvRCrossN.y * bestRz - iInvRCrossN.z * bestRy) * bestNx
                                      + (iInvRCrossN.z * bestRx - iInvRCrossN.x * bestRz) * bestNy
                                      + (iInvRCrossN.x * bestRy - iInvRCrossN.y * bestRx) * bestNz;
                        double kNormal = body.invMass + Math.max(0.0, angEff);

                        double eRest = (-vn < 1.25) ? 0.0 : body.restitution;
                        double jn = -(1.0 + eRest) * vn / kNormal;

                        curVx += (jn * bestNx) * body.invMass;
                        curVy += (jn * bestNy) * body.invMass;
                        curVz += (jn * bestNz) * body.invMass;
                        curWx += iInvRCrossN.x * jn;
                        curWy += iInvRCrossN.y * jn;
                        curWz += iInvRCrossN.z * jn;

                        double tx = vpx - vn * bestNx;
                        double ty = vpy - vn * bestNy;
                        double tz = vpz - vn * bestNz;
                        double tSpd = Math.sqrt(tx * tx + ty * ty + tz * tz);
                        if (tSpd > 1.0e-4) {
                            tx /= tSpd; ty /= tSpd; tz /= tSpd;
                            rCrossN.set(bestRy * tz - bestRz * ty, bestRz * tx - bestRx * tz, bestRx * ty - bestRy * tx);
                            invIWorld.transform(rCrossN, iInvRCrossN);
                            double angTan = (iInvRCrossN.y * bestRz - iInvRCrossN.z * bestRy) * tx
                                          + (iInvRCrossN.z * bestRx - iInvRCrossN.x * bestRz) * ty
                                          + (iInvRCrossN.x * bestRy - iInvRCrossN.y * bestRx) * tz;
                            double jtUnclamped = -tSpd / (body.invMass + Math.max(0.0, angTan));
                            double maxFrictionJ = body.friction * jn;
                            double jt = MathHelper.clamp(jtUnclamped, -maxFrictionJ, maxFrictionJ);

                            curVx += (jt * tx) * body.invMass;
                            curVy += (jt * ty) * body.invMass;
                            curVz += (jt * tz) * body.invMass;
                            curWx += iInvRCrossN.x * jt;
                            curWy += iInvRCrossN.y * jt;
                            curWz += iInvRCrossN.z * jt;
                        }
                    }
                }
                if (hadWorldContact) {
                    curWx *= 0.955;
                    curWy *= 0.955;
                    curWz *= 0.955;
                }
            }

            long nowNano = System.nanoTime();
            body.lastPublishNano = nowNano;
            body.px = curX; body.py = curY; body.pz = curZ;
            body.vx = curVx; body.vy = curVy; body.vz = curVz;
            body.wx = curWx; body.wy = curWy; body.wz = curWz;
            body.quat.set(curQ);

            double speedSq = curVx * curVx + curVy * curVy + curVz * curVz;
            double rotSq = curWx * curWx + curWy * curWy + curWz * curWz;

            if (speedSq > 2.25 && body.totalMassKg > 400.0) {
                Box hitBox = new Box(
                        curX - body.boundingRadius, curY - body.boundingRadius, curZ - body.boundingRadius,
                        curX + body.boundingRadius, curY + body.boundingRadius, curZ + body.boundingRadius
                );
                for (Entity ent : world.getOtherEntities(null, hitBox)) {
                    if (!(ent instanceof LivingEntity le)) continue;
                    if (le instanceof PlayerEntity pe && (pe.isCreative() || pe.isSpectator())) continue;
                    double pushScale = Math.min(0.85, body.totalMassKg / (body.totalMassKg + 180.0));
                    le.addVelocity(curVx * pushScale * 0.25, Math.max(0.15, Math.abs(curVy) * 0.18), curVz * pushScale * 0.25);
                    le.velocityModified = true;
                }
            }

            if (body.brittleShatter && maxNormalImpactSpeed > 3.2) {
                BlockPos ip = impactBlockPos != null ? impactBlockPos : BlockPos.ofFloored(curX, curY, curZ);
                BlockState sample = body.voxels.get(0).state();
                world.playSound(null, ip, SoundEvents.BLOCK_GLASS_BREAK, SoundCategory.BLOCKS, 0.95f, 1.05f);
                world.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, sample),
                        curX, curY, curZ, 18 * body.voxels.size(), 0.35, 0.35, 0.35, 0.12);
                ACTIVE_BODIES.remove(body);
                continue;
            }

            if (maxNormalImpactSpeed > 5.5 && impactBlockPos != null && !body.voxels.isEmpty()) {
                BlockState sample = body.voxels.get(0).state();
                world.playSound(null, impactBlockPos, sample.getSoundGroup().getBreakSound(), SoundCategory.BLOCKS, 1.0f, 0.72f);
                world.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, sample),
                        ipOrCenter(impactBlockPos, curX), ipOrCenterY(impactBlockPos, curY), ipOrCenterZ(impactBlockPos, curZ),
                        14, 0.4, 0.3, 0.4, 0.08);
            } else if (maxNormalImpactSpeed > 2.4 && impactBlockPos != null && !body.voxels.isEmpty()) {
                BlockState sample = body.voxels.get(0).state();
                world.playSound(null, impactBlockPos, sample.getSoundGroup().getFallSound(), SoundCategory.BLOCKS, 0.65f, 0.85f);
            }

            boolean floatingAtEquilibrium = body.averageDensityKgM3 < 960.0
                    && world.getFluidState(mp.set((int) Math.floor(curX), (int) Math.floor(curY - 0.35), (int) Math.floor(curZ))).isIn(FluidTags.WATER)
                    && speedSq < 0.05 && body.ageTicks > 35;

            if ((speedSq < 0.004 && rotSq < 0.008 && body.ageTicks > 12) || floatingAtEquilibrium || body.ageTicks > 170) {
                body.lowEnergyTicks++;
                if (body.lowEnergyTicks > 8 || body.ageTicks > 170) {
                    body.vx = body.vy = body.vz = 0.0;
                    body.wx = body.wy = body.wz = 0.0;
                    body.sleeping = true;
                }
            } else {
                body.lowEnergyTicks = 0;
            }

            body.renderSnap = new RenderSnapshot(
                    curX, curY, curZ, body.vx, body.vy, body.vz,
                    curQ.x, curQ.y, curQ.z, curQ.w,
                    body.wx, body.wy, body.wz,
                    hadWorldContact ? 0.0 : (lastNetAccelY * (scaledTickSec / 0.05)),
                    nowNano, hadWorldContact, body.sleeping, false
            );
        }

        if (spawnedChildren != null) {
            ACTIVE_BODIES.addAll(spawnedChildren);
        }
    }

    private static double ipOrCenter(BlockPos ip, double fallback)  { return ip != null ? ip.getX() + 0.5 : fallback; }
    private static double ipOrCenterY(BlockPos ip, double fallback) { return ip != null ? ip.getY() + 0.8 : fallback; }
    private static double ipOrCenterZ(BlockPos ip, double fallback) { return ip != null ? ip.getZ() + 0.5 : fallback; }

    /**
     * Spawns a buckled/detached ContinuousBeam as a standalone continuous 3D rigid body (ZERO Minecraft blocks!).
     */
    public static RigidCluster6DoF createFromContinuousBeam(
            String blueprintId,
            ContinuousStructuralBeams.ContinuousBeam beam,
            Vector3d initLinVel,
            Vector3d initAngVel
    ) {
        double cmX = 0.5 * (beam.ax + beam.dispAx + beam.bx + beam.dispBx);
        double cmY = 0.5 * (beam.ay + beam.dispAy + beam.by + beam.dispBy);
        double cmZ = 0.5 * (beam.az + beam.dispAz + beam.bz + beam.dispBz);

        // Dense 0.55m-spaced collision hull proxies along the entire continuous beam so it NEVER clips through walls or terrain!
        int sampleCount = Math.max(5, (int) Math.ceil(beam.lengthM / 0.55) + 1);
        List<LocalVoxel> hullProxies = new ArrayList<>(sampleCount);
        SectionProperties sec = beam.baseSection;
        for (int sIdx = 0; sIdx < sampleCount; sIdx++) {
            double s = ((double) sIdx / (sampleCount - 1)) - 0.5; // -0.5 .. +0.5
            double lx = beam.e1x * beam.lengthM * s;
            double ly = beam.e1y * beam.lengthM * s;
            double lz = beam.e1z * beam.lengthM * s;
            hullProxies.add(new LocalVoxel(lx, ly, lz, Blocks.AIR.getDefaultState(), sec, true));
        }

        double m = Math.max(40.0, beam.massKg());
        double iLong = m * (beam.lengthM * beam.lengthM) / 12.0;
        Matrix3d inertia = new Matrix3d().identity().scale(Math.max(12.0, iLong));

        RigidCluster6DoF cluster = new RigidCluster6DoF(
                blueprintId, cmX, cmY, cmZ, null, hullProxies, m, inertia,
                sec.category().restitution, sec.category().slidingFriction, false,
                initLinVel.x, initLinVel.y, initLinVel.z,
                initAngVel.x, initAngVel.y, initAngVel.z
        );
        cluster.attachedBeams.add(ContinuousStructuralBeams.toDetachedLocal(beam, cmX, cmY, cmZ));
        return cluster;
    }

    /**
     * Per-Piece Rubble Breaking ("Tek Vuruşta Sadece Baktığın Parça Kırılsın!"):
     * Removes ONLY the single targeted voxel (or continuous beam) from a fallen/tilted 3D rigid body,
     * preserves exact world pose of every surviving piece, splits disconnected sub-parts if severed,
     * and wakes the remaining body so it settles naturally if a supporting corner was broken!
     */
    public static boolean breakSingleVoxelOrBeamOnBody(ServerWorld world, long bodyId, int voxelIdx, int beamIdx) {
        RigidCluster6DoF target = null;
        for (RigidCluster6DoF b : ACTIVE_BODIES) {
            if (b.bodyId == bodyId) { target = b; break; }
        }
        if (target == null) return false;

        if (beamIdx >= 0 && beamIdx < target.attachedBeams.size()) {
            ContinuousStructuralBeams.DetachedContinuousBeam db = target.attachedBeams.remove(beamIdx);
            Vector3f mid = new Vector3f((float) (0.5 * (db.lax() + db.lbx())), (float) (0.5 * (db.lay() + db.lby())), (float) (0.5 * (db.laz() + db.lbz())));
            target.quat.transform(mid);
            double wx = target.px + mid.x, wy = target.py + mid.y, wz = target.pz + mid.z;
            world.playSound(null, BlockPos.ofFloored(wx, wy, wz), db.materialState().getSoundGroup().getBreakSound(), SoundCategory.BLOCKS, 1.0f, 0.9f);
            world.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, db.materialState()), wx, wy, wz, 18, 0.3, 0.3, 0.3, 0.08);
            boolean hasRealVoxels = false;
            for (LocalVoxel lv : target.voxels) { if (!lv.state().isAir()) { hasRealVoxels = true; break; } }
            if (!hasRealVoxels && target.attachedBeams.isEmpty()) {
                ACTIVE_BODIES.remove(target);
            }
            return true;
        }

        if (voxelIdx < 0 || voxelIdx >= target.voxels.size()) return false;
        LocalVoxel broken = target.voxels.get(voxelIdx);
        if (broken.state().isAir()) return false;

        Vector3f wOff = new Vector3f((float) broken.lx(), (float) broken.ly(), (float) broken.lz());
        target.quat.transform(wOff);
        double bx = target.px + wOff.x, by = target.py + wOff.y, bz = target.pz + wOff.z;
        world.playSound(null, BlockPos.ofFloored(bx, by, bz), broken.state().getSoundGroup().getBreakSound(), SoundCategory.BLOCKS, 1.0f, 0.92f);
        world.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, broken.state()), bx, by, bz, 16, 0.25, 0.25, 0.25, 0.08);

        List<LocalVoxel> survivors = new ArrayList<>(target.voxels.size() - 1);
        for (int i = 0; i < target.voxels.size(); i++) {
            if (i != voxelIdx && !target.voxels.get(i).state().isAir()) {
                survivors.add(target.voxels.get(i));
            }
        }

        ACTIVE_BODIES.remove(target);
        if (survivors.isEmpty() && target.attachedBeams.isEmpty()) {
            return true;
        }
        if (survivors.isEmpty()) {
            // Only attached beams remain
            RigidCluster6DoF beamOnly = createChildFromContinuousParent(
                    target, target.px, target.py, target.pz, target.quat,
                    List.of(new LocalVoxel(0, 0, 0, Blocks.AIR.getDefaultState(), broken.section(), true)),
                    new Vector3d(0, -0.05, 0), new Vector3d(0, 0, 0));
            beamOnly.attachedBeams.addAll(target.attachedBeams);
            ACTIVE_BODIES.add(beamOnly);
            return true;
        }

        // Partition survivors into 18-connected local sub-clusters so if the player chops a fallen beam in two, it splits naturally!
        int m = survivors.size();
        boolean[] vis = new boolean[m];
        ArrayDeque<Integer> q = new ArrayDeque<>();
        boolean attachedBeamsAssigned = false;

        for (int i = 0; i < m; i++) {
            if (vis[i]) continue;
            List<LocalVoxel> part = new ArrayList<>();
            vis[i] = true;
            q.add(i);
            while (!q.isEmpty()) {
                int cur = q.poll();
                LocalVoxel cv = survivors.get(cur);
                part.add(cv);
                for (int j = 0; j < m; j++) {
                    if (vis[j]) continue;
                    LocalVoxel nv = survivors.get(j);
                    double d2 = sq(cv.lx() - nv.lx()) + sq(cv.ly() - nv.ly()) + sq(cv.lz() - nv.lz());
                    if (d2 <= 2.15) {
                        vis[j] = true;
                        q.add(j);
                    }
                }
            }
            RigidCluster6DoF child = createChildFromContinuousParent(
                    target, target.px, target.py, target.pz, target.quat,
                    part, new Vector3d(0.0, -0.04, 0.0), new Vector3d(0.0, 0.0, 0.0)
            );
            if (!attachedBeamsAssigned && !target.attachedBeams.isEmpty()) {
                attachedBeamsAssigned = true;
                double dCx = child.px - target.px, dCy = child.py - target.py, dCz = child.pz - target.pz;
                Quaternionf invQ = new Quaternionf(target.quat).invert();
                Vector3f localShift = new Vector3f((float) dCx, (float) dCy, (float) dCz);
                invQ.transform(localShift);
                for (ContinuousStructuralBeams.DetachedContinuousBeam db : target.attachedBeams) {
                    child.attachedBeams.add(new ContinuousStructuralBeams.DetachedContinuousBeam(
                            db.lax() - localShift.x, db.lay() - localShift.y, db.laz() - localShift.z,
                            db.lbx() - localShift.x, db.lby() - localShift.y, db.lbz() - localShift.z,
                            db.widthM(), db.depthM(), db.lengthM(), db.localOrientation(), db.materialState(), db.massKg()
                    ));
                }
            }
            ACTIVE_BODIES.add(child);
        }
        return true;
    }

    /**
     * Attaches a new block directly onto a tilted/fallen 3D RigidCluster6DoF at its exact 3D quaternion orientation,
     * seamlessly shifting CoM, updating the 3x3 inertia tensor (so heavy Gold/Netherite blocks rock/tip the fallen house!),
     * and waking the body so it settles naturally under the added weight!
     */
    public static boolean attachSingleVoxelToBody(
            ServerWorld world,
            long bodyId,
            int hitVoxelIdx,
            net.minecraft.util.math.Vec3d hitPosWorld,
            net.minecraft.util.math.Vec3d hitNormalWorld,
            BlockState newState
    ) {
        if (newState == null || newState.isAir()) return false;
        RigidCluster6DoF target = null;
        for (RigidCluster6DoF b : ACTIVE_BODIES) {
            if (b.bodyId == bodyId) { target = b; break; }
        }
        if (target == null) return false;

        Quaternionf invQ = new Quaternionf(target.quat).invert();
        Vector3f localN = new Vector3f((float) hitNormalWorld.x, (float) hitNormalWorld.y, (float) hitNormalWorld.z);
        invQ.transform(localN);

        double ax = Math.abs(localN.x), ay = Math.abs(localN.y), az = Math.abs(localN.z);
        double dlx = 0.0, dly = 0.0, dlz = 0.0;
        if (ax >= ay && ax >= az) dlx = localN.x >= 0f ? 1.0 : -1.0;
        else if (ay >= ax && ay >= az) dly = localN.y >= 0f ? 1.0 : -1.0;
        else dlz = localN.z >= 0f ? 1.0 : -1.0;

        double nlx, nly, nlz;
        if (hitVoxelIdx >= 0 && hitVoxelIdx < target.voxels.size() && !target.voxels.get(hitVoxelIdx).state().isAir()) {
            LocalVoxel base = target.voxels.get(hitVoxelIdx);
            nlx = base.lx() + dlx;
            nly = base.ly() + dly;
            nlz = base.lz() + dlz;
        } else {
            Vector3f rel = new Vector3f(
                    (float) (hitPosWorld.x + hitNormalWorld.x * 0.5 - target.px),
                    (float) (hitPosWorld.y + hitNormalWorld.y * 0.5 - target.py),
                    (float) (hitPosWorld.z + hitNormalWorld.z * 0.5 - target.pz)
            );
            invQ.transform(rel);
            nlx = rel.x; nly = rel.y; nlz = rel.z;
        }

        // Prevent duplicate overlap on the same local cell
        for (LocalVoxel lv : target.voxels) {
            if (lv.state().isAir()) continue;
            if (sq(lv.lx() - nlx) + sq(lv.ly() - nly) + sq(lv.lz() - nlz) < 0.25) {
                return false;
            }
        }

        // Prevent placing directly inside a standing player's capsule
        Vector3f wNew = new Vector3f((float) nlx, (float) nly, (float) nlz);
        target.quat.transform(wNew);
        double wx = target.px + wNew.x, wy = target.py + wNew.y, wz = target.pz + wNew.z;
        for (PlayerEntity pl : world.getPlayers()) {
            if (pl.isSpectator()) continue;
            if (pl.getBoundingBox().intersects(wx - 0.38, wy - 0.38, wz - 0.38, wx + 0.38, wy + 0.38, wz + 0.38)) {
                return false;
            }
        }

        SectionProperties newSec = ConstitutiveMaterialDB.computeSection(newState);
        List<LocalVoxel> combined = new ArrayList<>(target.voxels.size() + 1);
        for (LocalVoxel lv : target.voxels) {
            if (!lv.state().isAir()) combined.add(lv);
        }
        combined.add(new LocalVoxel(nlx, nly, nlz, newState, newSec, true));

        RigidCluster6DoF updated = createChildFromContinuousParent(
                target, target.px, target.py, target.pz, target.quat,
                combined,
                new Vector3d(target.vx, Math.min(target.vy, -0.03), target.vz),
                new Vector3d(target.wx, target.wy, target.wz)
        );
        if (!target.attachedBeams.isEmpty()) {
            double dCx = updated.px - target.px, dCy = updated.py - target.py, dCz = updated.pz - target.pz;
            Vector3f localShift = new Vector3f((float) dCx, (float) dCy, (float) dCz);
            invQ.transform(localShift);
            for (ContinuousStructuralBeams.DetachedContinuousBeam db : target.attachedBeams) {
                updated.attachedBeams.add(new ContinuousStructuralBeams.DetachedContinuousBeam(
                        db.lax() - localShift.x, db.lay() - localShift.y, db.laz() - localShift.z,
                        db.lbx() - localShift.x, db.lby() - localShift.y, db.lbz() - localShift.z,
                        db.widthM(), db.depthM(), db.lengthM(), db.localOrientation(), db.materialState(), db.massKg()
                ));
            }
        }
        updated.sleeping = false;
        updated.lowEnergyTicks = 0;

        ACTIVE_BODIES.remove(target);
        ACTIVE_BODIES.add(updated);
        world.playSound(null, BlockPos.ofFloored(wx, wy, wz), newState.getSoundGroup().getPlaceSound(), SoundCategory.BLOCKS, 1.0f, 0.92f);
        return true;
    }

    /**
     * Newton's 3rd Law Player-Pushing-Debris Dynamics ("Evin Parçasını İttiğimde Gidecek Mi?"):
     * Applies realistic SI human pushing impulse + 3D lever-arm torque (r x J) at the exact 3D contact point:
     * - Light/medium broken pieces & fallen columns (60 kg .. ~3,200 kg) overcome static friction, wake up,
     *   slide, pivot around their CoM when pushed at one end, and can be shoved off cliffs!
     * - Massive 100-ton intact buildings naturally stay put unless carved into smaller movable pieces!
     */
    public static boolean applyPlayerPushImpulse(
            RigidCluster6DoF body,
            double contactX, double contactY, double contactZ,
            double pushDirX, double pushDirY, double pushDirZ,
            double playerSpeedMps,
            boolean sprinting
    ) {
        if (body == null) return false;
        double dLen = Math.sqrt(pushDirX * pushDirX + pushDirY * pushDirY + pushDirZ * pushDirZ);
        if (dLen < 1.0e-5) return false;
        double nx = pushDirX / dLen;
        double ny = MathHelper.clamp(pushDirY / dLen, -0.35, 0.35);
        double nz = pushDirZ / dLen;

        // Physical human leg drive force (walk ~3.4 kN, sprint/shoulder-shove ~9.8 kN) vs Coulomb static breakaway
        double driveForceN = (sprinting ? 9800.0 : 3400.0) + 95.0 * Math.max(0.0, playerSpeedMps) * 18.0;
        double staticBreakawayN = body.totalMassKg * 9.80665 * body.friction * 0.24;
        if (driveForceN <= staticBreakawayN) {
            return false; // Too heavy for one human to budge (e.g. 110-ton intact toppled building!)
        }

        double netForceN = driveForceN - staticBreakawayN * 0.65;
        double dtTick = 0.05;
        double jMag = Math.min(netForceN * dtTick, body.totalMassKg * (sprinting ? 3.2 : 1.6));

        double jx = nx * jMag;
        double jy = Math.max(0.04 * jMag, ny * jMag); // tiny lift over micro-friction edges
        double jz = nz * jMag;

        body.sleeping = false;
        body.lowEnergyTicks = 0;
        if (body.ageTicks > 120) body.ageTicks = 60; // give pushed body fresh simulation ticks before auto-sleep!

        body.vx = MathHelper.clamp(body.vx + jx * body.invMass, -8.0, 8.0);
        body.vy = MathHelper.clamp(body.vy + jy * body.invMass, -6.0, 4.0);
        body.vz = MathHelper.clamp(body.vz + jz * body.invMass, -8.0, 8.0);

        // 3D Rotational Torque Impulse: delta_omega = I_world^-1 * ((contact - CoM) x J)
        double rx = contactX - body.px;
        double ry = contactY - body.py;
        double rz = contactZ - body.pz;
        Vector3d tauJ = new Vector3d(
                ry * jz - rz * jy,
                rz * jx - rx * jz,
                rx * jy - ry * jx
        );
        Matrix3d rot = new Matrix3d().set(body.quat);
        Matrix3d rotT = new Matrix3d();
        rot.transpose(rotT);
        Matrix3d invIW = new Matrix3d(rot).mul(body.invInertiaBody).mul(rotT);
        invIW.transform(tauJ);

        body.wx = MathHelper.clamp(body.wx + tauJ.x, -6.0, 6.0);
        body.wy = MathHelper.clamp(body.wy + tauJ.y, -6.0, 6.0);
        body.wz = MathHelper.clamp(body.wz + tauJ.z, -6.0, 6.0);
        return true;
    }

    private static double sq(double v) { return v * v; }
}

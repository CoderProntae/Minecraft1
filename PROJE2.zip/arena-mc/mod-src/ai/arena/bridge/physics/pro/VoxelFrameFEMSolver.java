package ai.arena.bridge.physics.pro;

import ai.arena.bridge.physics.pro.ConstitutiveMaterialDB.MaterialCategory;
import ai.arena.bridge.physics.pro.ConstitutiveMaterialDB.SectionProperties;
import ai.arena.bridge.physics.pro.ContinuousStructuralBeams.ContinuousBeam;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import org.joml.Vector3d;

import java.util.*;

/**
 * Universal 3D 6-DoF Direct-Stiffness Finite-Element Structural Solver (K * u = f) with:
 * 1. Arbitrary-vector 12x12 Timoshenko-Euler-Bernoulli 3D frame elements for:
 *    - Orthogonal structural bonds (L = 1.0 m),
 *    - 45-degree diagonal voxel struts (L = sqrt(2) m),
 *    - Non-grid Continuous 3D Structural Beams & Inclined Columns (arbitrary L & 3D angle!), and
 *    - Unilateral Rock/Soil Foundation Bearing & Uplift Pullout Interfaces (enables true monolithic toppling!).
 * 2. Euler-Rankine slenderness column buckling + Mohr-Coulomb shear-torsion + Rankine axial-flexural fracture.
 * 3. Exact 6-DoF nodal displacement & rotation field export for smooth continuous curvature rendering.
 */
public final class VoxelFrameFEMSolver {

    private static final double STIFFNESS_SCALE = 1.0e-6;
    private static final int MAX_FRACTURE_PASSES = 8;

    public record ExternalBeamAttachment(
            ContinuousBeam beam,
            int nodeA,
            boolean groundedTerrainA,
            int nodeB,
            boolean groundedTerrainB
    ) {}

    public record DetachedFragment(
            List<Integer> nodeIndices,
            Vector3d fractureHingeWorld,
            Vector3d initialLinearVel,
            Vector3d initialAngularVel,
            double peakUtilizationRatio,
            String failureMode
    ) {}

    public record FEMSolveReport(
            int totalNodes,
            int totalBonds,
            int fracturedBondCount,
            int pcgIterationsTotal,
            double maxStressRatioBeforeCollapse,
            List<DetachedFragment> detachedFragments,
            List<BlockPos> fracturedFacePositions,
            double[] nodalDisplacements,
            double[] nodalMaxUtilization,
            Set<Long> buckledBeamIds
    ) {}

    private static final class BondElement {
        final int ni;
        final int nj;
        final boolean isDiagonalStrut;
        final boolean isFoundationAnchor;
        final ContinuousBeam continuousBeam;
        final double lengthM;
        final double e1x, e1y, e1z;
        final double e2x, e2y, e2z;
        final double e3x, e3y, e3z;

        final double kAx;
        final double kTor;
        final double k12;
        final double k6;
        final double k4;
        final double k2;
        final double eiRaw;

        final double areaM2;
        final double sectionModulusWM3;
        final double fcKpa;
        final double ftDirectKpa;
        final double frFlexKpa;
        final double cohesionKpa;
        final double muInternal;
        double effectiveColumnLengthM;
        boolean intact = true;

        // Constructor 1: Standard voxel-to-voxel or virtual-foundation-anchor bond
        BondElement(int ni, int nj, double dx, double dy, double dz, boolean diagonal, boolean foundationAnchor,
                    SectionProperties si, SectionProperties sj) {
            this.ni = ni;
            this.nj = nj;
            this.isDiagonalStrut = diagonal;
            this.isFoundationAnchor = foundationAnchor;
            this.continuousBeam = null;
            this.lengthM = Math.max(0.25, Math.sqrt(dx * dx + dy * dy + dz * dz));

            this.e1x = dx / this.lengthM;
            this.e1y = dy / this.lengthM;
            this.e1z = dz / this.lengthM;

            double rx = (Math.abs(this.e1y) < 0.90) ? 0.0 : 1.0;
            double ry = (Math.abs(this.e1y) < 0.90) ? 1.0 : 0.0;
            double rz = 0.0;
            double c3x = this.e1y * rz - this.e1z * ry;
            double c3y = this.e1z * rx - this.e1x * rz;
            double c3z = this.e1x * ry - this.e1y * rx;
            double c3Len = Math.max(1.0e-8, Math.sqrt(c3x * c3x + c3y * c3y + c3z * c3z));
            this.e3x = c3x / c3Len;
            this.e3y = c3y / c3Len;
            this.e3z = c3z / c3Len;
            this.e2x = this.e3y * this.e1z - this.e3z * this.e1y;
            this.e2y = this.e3z * this.e1x - this.e3x * this.e1z;
            this.e2z = this.e3x * this.e1y - this.e3y * this.e1x;

            double eHarm = (2.0 * si.category().youngsModulusKpa * sj.category().youngsModulusKpa)
                    / Math.max(1.0, si.category().youngsModulusKpa + sj.category().youngsModulusKpa);
            double gHarm = (2.0 * si.category().shearModulusKpa * sj.category().shearModulusKpa)
                    / Math.max(1.0, si.category().shearModulusKpa + sj.category().shearModulusKpa);

            double diagAreaFactor = diagonal ? 0.85 : 1.0;
            double diagInertiaFactor = diagonal ? 0.75 : 1.0;

            this.areaM2 = Math.min(si.areaM2(), sj.areaM2()) * diagAreaFactor;
            double iEff = Math.min(si.secondMomentIM4(), sj.secondMomentIM4()) * diagInertiaFactor;
            double jEff = Math.min(si.polarMomentJM4(), sj.polarMomentJM4()) * diagInertiaFactor;
            this.sectionModulusWM3 = Math.min(si.sectionModulusWM3(), sj.sectionModulusWM3()) * (diagonal ? 0.82 : 1.0);

            double L = this.lengthM;
            double L2 = L * L;
            double L3 = L2 * L;

            double padRotScale = foundationAnchor ? 0.02 : 1.0;
            double padAxScale  = foundationAnchor ? 0.022 : 1.0;
            this.eiRaw = eHarm * iEff;
            this.kAx = ((eHarm * this.areaM2) / L) * padAxScale;
            this.kTor = ((gHarm * jEff) / L) * padRotScale;

            double ksGa = (5.0 / 6.0) * gHarm * this.areaM2;
            double phi = (12.0 * this.eiRaw) / Math.max(1.0, ksGa * L2);
            double phiFactor = 1.0 / (1.0 + phi);

            this.k12 = (12.0 * this.eiRaw / L3) * phiFactor * (foundationAnchor ? 0.18 : 1.0);
            this.k6  = (6.0  * this.eiRaw / L2) * phiFactor * padRotScale;
            this.k4  = ((4.0 + phi) * this.eiRaw / L) * phiFactor * padRotScale;
            this.k2  = ((2.0 - phi) * this.eiRaw / L) * phiFactor * padRotScale;

            MaterialCategory ci = si.category();
            MaterialCategory cj = sj.category();
            this.fcKpa = Math.min(ci.compressiveStrengthKpa, cj.compressiveStrengthKpa);
            // Shallow foundation sill bearing pad: realistic timber-on-stone bedding stiffness, pinned in rotation,
            // and releases cleanly under seesaw uplift tension once struts buckle -> monolithic building toppling!
            double baseFt = Math.min(ci.directTensileStrengthKpa, cj.directTensileStrengthKpa);
            double baseFr = Math.min(ci.flexuralRuptureStrengthKpa, cj.flexuralRuptureStrengthKpa);
            this.ftDirectKpa = foundationAnchor ? 92.0 : baseFt;
            this.frFlexKpa   = foundationAnchor ? 1.0e9 : baseFr;
            this.cohesionKpa = foundationAnchor
                    ? 260.0
                    : Math.min(ci.shearCohesionKpa, cj.shearCohesionKpa);
            this.muInternal = Math.min(ci.internalFrictionCoeff, cj.internalFrictionCoeff);
            this.effectiveColumnLengthM = L;
        }

        // Constructor 2: Non-grid Continuous 3D Structural Beam / Inclined Column (exact arbitrary 3D geometry!)
        BondElement(int ni, int nj, ContinuousBeam beam) {
            this.ni = ni;
            this.nj = nj;
            this.isDiagonalStrut = true;
            this.isFoundationAnchor = false;
            this.continuousBeam = beam;
            this.lengthM = beam.lengthM;
            this.e1x = beam.e1x; this.e1y = beam.e1y; this.e1z = beam.e1z;
            this.e2x = beam.e2x; this.e2y = beam.e2y; this.e2z = beam.e2z;
            this.e3x = beam.e3x; this.e3y = beam.e3y; this.e3z = beam.e3z;

            MaterialCategory cat = beam.category();
            double E = cat.youngsModulusKpa;
            double G = cat.shearModulusKpa;

            this.areaM2 = beam.areaM2();
            double iEff = beam.secondMomentIM4();
            double jEff = iEff * 1.65;
            this.sectionModulusWM3 = beam.sectionModulusWM3();

            double L = this.lengthM;
            double L2 = L * L;
            double L3 = L2 * L;

            boolean clevisStrut = Math.abs(beam.e1y) > 0.15;
            double clevisRotScale = clevisStrut ? 0.04 : 1.0;

            this.eiRaw = E * iEff;
            this.kAx = (E * this.areaM2) / L;
            this.kTor = ((G * jEff) / L) * clevisRotScale;

            double ksGa = (5.0 / 6.0) * G * this.areaM2;
            double phi = (12.0 * this.eiRaw) / Math.max(1.0, ksGa * L2);
            double phiFactor = 1.0 / (1.0 + phi);

            this.k12 = (12.0 * this.eiRaw / L3) * phiFactor * (clevisStrut ? 0.25 : 1.0);
            this.k6  = (6.0  * this.eiRaw / L2) * phiFactor * clevisRotScale;
            this.k4  = ((4.0 + phi) * this.eiRaw / L) * phiFactor * clevisRotScale;
            this.k2  = ((2.0 - phi) * this.eiRaw / L) * phiFactor * clevisRotScale;

            this.fcKpa = cat.compressiveStrengthKpa;
            this.ftDirectKpa = cat.directTensileStrengthKpa;
            this.frFlexKpa = clevisStrut ? cat.flexuralRuptureStrengthKpa * 3.5 : cat.flexuralRuptureStrengthKpa;
            this.cohesionKpa = cat.shearCohesionKpa;
            this.muInternal = cat.internalFrictionCoeff;
            this.effectiveColumnLengthM = L;
        }
    }

    private static final int[][] FACE_OFFSETS = {
            {1, 0, 0}, {0, 1, 0}, {0, 0, 1}
    };
    private static final int[][] DIAG_OFFSETS = {
            { 1,  1,  0,   1, 0, 0,   0, 1, 0},
            { 1, -1,  0,   1, 0, 0,   0,-1, 0},
            { 0,  1,  1,   0, 1, 0,   0, 0, 1},
            { 0,  1, -1,   0, 1, 0,   0, 0,-1},
            { 1,  0,  1,   1, 0, 0,   0, 0, 1},
            { 1,  0, -1,   1, 0, 0,   0, 0,-1}
    };

    private VoxelFrameFEMSolver() {}

    public static FEMSolveReport solveStructure(
            List<BlockPos> positions,
            List<BlockState> states,
            boolean[] groundedMask,
            double[] externalLoadsKn
    ) {
        return solveStructure(positions, states, groundedMask, externalLoadsKn, List.of());
    }

    public static FEMSolveReport solveStructure(
            List<BlockPos> positions,
            List<BlockState> states,
            boolean[] groundedMask,
            double[] externalLoadsKn,
            List<ExternalBeamAttachment> externalBeams
    ) {
        final int nReal = positions.size();
        if (nReal == 0) {
            return new FEMSolveReport(0, 0, 0, 0, 0.0, List.of(), List.of(), new double[0], new double[0], Set.of());
        }

        // Count virtual rock foundation anchor nodes:
        // 1 virtual anchor per grounded structure block (unilateral compression / uplift-pullout foundation interface!)
        // + 1 virtual anchor per terrain-grounded ContinuousBeam endpoint!
        int extraGroundNodes = 0;
        for (int i = 0; i < nReal; i++) {
            if (groundedMask[i]) extraGroundNodes++;
        }
        if (externalBeams != null) {
            for (ExternalBeamAttachment eb : externalBeams) {
                if (eb.groundedTerrainA() && eb.nodeA() < 0) extraGroundNodes++;
                if (eb.groundedTerrainB() && eb.nodeB() < 0) extraGroundNodes++;
            }
        }

        final int nTotal = nReal + extraGroundNodes;
        SectionProperties[] sections = new SectionProperties[nTotal];
        BlockPos[] allPositions = new BlockPos[nTotal];
        boolean[] fixedNodeMask = new boolean[nTotal]; // ONLY virtual rock foundation nodes are fixed (u = 0)!
        Map<BlockPos, Integer> indexMap = new HashMap<>(nReal * 2);

        for (int i = 0; i < nReal; i++) {
            sections[i] = ConstitutiveMaterialDB.computeSection(states.get(i));
            allPositions[i] = positions.get(i);
            indexMap.put(positions.get(i), i);
        }

        List<BondElement> bonds = new ArrayList<>(nReal * 4 + extraGroundNodes);

        // 1. Structural internal bonds (orthogonal faces + 45-deg voxel diagonals)
        for (int i = 0; i < nReal; i++) {
            BlockPos pi = positions.get(i);
            for (int[] off : FACE_OFFSETS) {
                BlockPos pj = pi.add(off[0], off[1], off[2]);
                Integer jObj = indexMap.get(pj);
                if (jObj != null) {
                    BondElement be = new BondElement(i, jObj, off[0], off[1], off[2], false, false, sections[i], sections[jObj]);
                    be.effectiveColumnLengthM = measureCollinearChainLength(pi, off[0], off[1], off[2], indexMap, 1.0);
                    bonds.add(be);
                }
            }
            for (int[] dOff : DIAG_OFFSETS) {
                BlockPos pj = pi.add(dOff[0], dOff[1], dOff[2]);
                Integer jObj = indexMap.get(pj);
                if (jObj != null) {
                    BlockPos b1 = pi.add(dOff[3], dOff[4], dOff[5]);
                    BlockPos b2 = pi.add(dOff[6], dOff[7], dOff[8]);
                    if (!indexMap.containsKey(b1) && !indexMap.containsKey(b2)) {
                        BondElement be = new BondElement(i, jObj, dOff[0], dOff[1], dOff[2], true, false, sections[i], sections[jObj]);
                        be.effectiveColumnLengthM = measureCollinearChainLength(pi, dOff[0], dOff[1], dOff[2], indexMap, Math.sqrt(2.0));
                        bonds.add(be);
                    }
                }
            }
        }

        // 2. Virtual Rock Foundation Bearing / Uplift-Pullout Interface Bonds for grounded structure blocks
        int cursor = nReal;
        SectionProperties rockFoundationSec = ConstitutiveMaterialDB.computeSection(net.minecraft.block.Blocks.STONE.getDefaultState());
        for (int i = 0; i < nReal; i++) {
            if (!groundedMask[i]) continue;
            int vIdx = cursor++;
            BlockPos p = positions.get(i);
            allPositions[vIdx] = p.down();
            sections[vIdx] = rockFoundationSec;
            fixedNodeMask[vIdx] = true;
            // Vertical rock-to-sill bearing interface (strong in compression, releases cleanly in seesaw uplift!)
            BondElement anchor = new BondElement(vIdx, i, 0.0, 1.0, 0.0, false, true, rockFoundationSec, sections[i]);
            bonds.add(anchor);
        }

        // 3. Non-Grid Continuous 3D Structural Beams & Inclined Columns
        if (externalBeams != null) {
            for (ExternalBeamAttachment eb : externalBeams) {
                ContinuousBeam cb = eb.beam();
                int idxA = eb.nodeA();
                int idxB = eb.nodeB();
                if (idxA < 0 && eb.groundedTerrainA()) {
                    idxA = cursor++;
                    allPositions[idxA] = BlockPos.ofFloored(cb.ax, cb.ay, cb.az);
                    sections[idxA] = rockFoundationSec;
                    fixedNodeMask[idxA] = true;
                }
                if (idxB < 0 && eb.groundedTerrainB()) {
                    idxB = cursor++;
                    allPositions[idxB] = BlockPos.ofFloored(cb.bx, cb.by, cb.bz);
                    sections[idxB] = rockFoundationSec;
                    fixedNodeMask[idxB] = true;
                }
                if (idxA >= 0 && idxB >= 0 && idxA != idxB) {
                    bonds.add(new BondElement(idxA, idxB, cb));
                }
            }
        }

        final int ndof = nTotal * 6;
        double[] fGlobal = new double[ndof];
        for (int i = 0; i < nReal; i++) {
            fGlobal[i * 6 + 1] = -sections[i].weightKn();
            if (externalLoadsKn != null && externalLoadsKn.length >= (i + 1) * 3) {
                fGlobal[i * 6]     += externalLoadsKn[i * 3];
                fGlobal[i * 6 + 1] += externalLoadsKn[i * 3 + 1];
                fGlobal[i * 6 + 2] += externalLoadsKn[i * 3 + 2];
            }
        }
        // Add half of each ContinuousBeam's own dead weight to its structural endpoint(s)
        if (externalBeams != null) {
            for (ExternalBeamAttachment eb : externalBeams) {
                double halfWKn = 0.5 * (eb.beam().massKg() * 9.80665 * 1.0e-3);
                if (eb.nodeA() >= 0 && eb.nodeA() < nReal) fGlobal[eb.nodeA() * 6 + 1] -= halfWKn;
                if (eb.nodeB() >= 0 && eb.nodeB() < nReal) fGlobal[eb.nodeB() * 6 + 1] -= halfWKn;
            }
        }

        boolean[] detachedNode = new boolean[nTotal];
        List<DetachedFragment> detachedOut = new ArrayList<>();
        List<BlockPos> fracturedFaces = new ArrayList<>();
        Set<Long> buckledBeamIds = new LinkedHashSet<>();
        int totalFracturedBonds = 0;
        int totalPcgIters = 0;
        double peakStressSeen = 0.0;

        Vector3d[] lastFractureHinge = new Vector3d[nTotal];
        String[] lastFailureReason = new String[nTotal];
        double[] u = new double[ndof];
        double[] nodalMaxUtil = new double[nReal];

        for (int pass = 0; pass < MAX_FRACTURE_PASSES; pass++) {
            Arrays.fill(nodalMaxUtil, 0.0);

            for (BondElement b : bonds) {
                if (!b.intact || b.isFoundationAnchor || b.continuousBeam != null) continue;
                boolean granI = sections[b.ni].category() == MaterialCategory.GRANULAR_COHESIONLESS;
                boolean granJ = sections[b.nj].category() == MaterialCategory.GRANULAR_COHESIONLESS;
                if ((granI || granJ) && Math.abs(b.e1y) < 0.99) {
                    b.intact = false;
                    totalFracturedBonds++;
                }
            }

            List<List<Integer>> adj = new ArrayList<>(nTotal);
            for (int i = 0; i < nTotal; i++) adj.add(new ArrayList<>(8));
            for (BondElement b : bonds) {
                if (b.intact && !detachedNode[b.ni] && !detachedNode[b.nj]) {
                    adj.get(b.ni).add(b.nj);
                    adj.get(b.nj).add(b.ni);
                }
            }

            boolean[] visited = new boolean[nTotal];
            boolean[] activeGroundedSubgraph = new boolean[nTotal];
            ArrayDeque<Integer> bfs = new ArrayDeque<>();

            for (int i = 0; i < nReal; i++) {
                if (detachedNode[i] || visited[i]) continue;
                List<Integer> compAll = new ArrayList<>();
                List<Integer> compReal = new ArrayList<>();
                boolean hasGround = false;
                visited[i] = true;
                bfs.add(i);
                while (!bfs.isEmpty()) {
                    int cur = bfs.poll();
                    compAll.add(cur);
                    if (cur < nReal) compReal.add(cur);
                    if (fixedNodeMask[cur]) hasGround = true;
                    for (int nb : adj.get(cur)) {
                        if (!visited[nb] && !detachedNode[nb]) {
                            visited[nb] = true;
                            bfs.add(nb);
                        }
                    }
                }

                if (!hasGround) {
                    emitDetachedMonolithicFragment(compReal, compAll, detachedNode, positions, sections,
                            lastFractureHinge, lastFailureReason, peakStressSeen, detachedOut);
                } else {
                    for (int idx : compAll) activeGroundedSubgraph[idx] = true;
                }
            }

            int freeCount = 0;
            for (int i = 0; i < nReal; i++) {
                if (activeGroundedSubgraph[i]) freeCount++;
            }
            if (freeCount == 0) break;

            List<BondElement> activeBonds = new ArrayList<>(bonds.size());
            for (BondElement b : bonds) {
                if (b.intact && activeGroundedSubgraph[b.ni] && activeGroundedSubgraph[b.nj]) {
                    activeBonds.add(b);
                }
            }
            if (activeBonds.isEmpty()) break;

            int maxIter = Math.min(620, Math.max(150, freeCount * 3));
            totalPcgIters += solvePCG(nTotal, activeGroundedSubgraph, fixedNodeMask, activeBonds, fGlobal, u, maxIter);

            int bCount = activeBonds.size();
            double[] utilRatios = new double[bCount];
            String[] failModes = new String[bCount];
            double passMaxUtil = 0.0;

            for (int bi = 0; bi < bCount; bi++) {
                BondElement b = activeBonds.get(bi);
                int baseI = b.ni * 6;
                int baseJ = b.nj * 6;
                boolean fixI = fixedNodeMask[b.ni];
                boolean fixJ = fixedNodeMask[b.nj];

                double uxi = fixI ? 0.0 : u[baseI],     uyi = fixI ? 0.0 : u[baseI + 1], uzi = fixI ? 0.0 : u[baseI + 2];
                double txi = fixI ? 0.0 : u[baseI + 3], tyi = fixI ? 0.0 : u[baseI + 4], tzi = fixI ? 0.0 : u[baseI + 5];

                double uxj = fixJ ? 0.0 : u[baseJ],     uyj = fixJ ? 0.0 : u[baseJ + 1], uzj = fixJ ? 0.0 : u[baseJ + 2];
                double txj = fixJ ? 0.0 : u[baseJ + 3], tyj = fixJ ? 0.0 : u[baseJ + 4], tzj = fixJ ? 0.0 : u[baseJ + 5];

                double u1i = b.e1x * uxi + b.e1y * uyi + b.e1z * uzi;
                double u2i = b.e2x * uxi + b.e2y * uyi + b.e2z * uzi;
                double u3i = b.e3x * uxi + b.e3y * uyi + b.e3z * uzi;
                double r1i = b.e1x * txi + b.e1y * tyi + b.e1z * tzi;
                double r2i = b.e2x * txi + b.e2y * tyi + b.e2z * tzi;
                double r3i = b.e3x * txi + b.e3y * tyi + b.e3z * tzi;

                double u1j = b.e1x * uxj + b.e1y * uyj + b.e1z * uzj;
                double u2j = b.e2x * uxj + b.e2y * uyj + b.e2z * uzj;
                double u3j = b.e3x * uxj + b.e3y * uyj + b.e3z * uzj;
                double r1j = b.e1x * txj + b.e1y * tyj + b.e1z * tzj;
                double r2j = b.e2x * txj + b.e2y * tyj + b.e2z * tzj;
                double r3j = b.e3x * txj + b.e3y * tyj + b.e3z * tzj;

                double nAxialCompKn = b.kAx * (u1i - u1j);

                double v2Kn = b.k12 * (u2i - u2j) + b.k6 * (r3i + r3j);
                double m3i  = b.k6  * (u2i - u2j) + b.k4 * r3i + b.k2 * r3j;
                double m3j  = b.k6  * (u2i - u2j) + b.k2 * r3i + b.k4 * r3j;

                double v3Kn = b.k12 * (u3i - u3j) - b.k6 * (r2i + r2j);
                double m2i  = -b.k6 * (u3i - u3j) + b.k4 * r2i + b.k2 * r2j;
                double m2j  = -b.k6 * (u3i - u3j) + b.k2 * r2i + b.k4 * r2j;

                double torsKnM = b.kTor * (r1i - r1j);

                double m3Joint = 0.5 * (m3i - m3j);
                double m2Joint = 0.5 * (m2i - m2j);
                double mDesignKnM = Math.hypot(m2Joint, m3Joint);
                double vShearKn = Math.hypot(v2Kn, v3Kn);

                double sigmaNormalKpa = nAxialCompKn / b.areaM2;
                double util = 0.0;
                String mode = "OK";

                // Criterion A: Direct Axial Tension / Seesaw Foundation Uplift Pullout
                if (sigmaNormalKpa < 0.0) {
                    double uTens = (-sigmaNormalKpa) / Math.max(0.5, b.ftDirectKpa);
                    if (uTens > util) {
                        util = uTens;
                        mode = b.isFoundationAnchor ? "ANCHOR_UPLIFT_PULLOUT" : "AXIAL_TENSION_FRACTURE";
                    }
                }

                // Criterion B: Rankine-Euler Compressive Crushing + Slenderness Column Buckling
                if (nAxialCompKn > 0.0) {
                    double pSquashKn = b.areaM2 * Math.max(10.0, b.fcKpa);
                    double kLen = Math.max(0.85, 0.85 * b.effectiveColumnLengthM);
                    double buckFactor = (b.continuousBeam != null) ? 0.65 : (b.isDiagonalStrut ? 0.22 : 1.0);
                    double pEulerKn = buckFactor * (Math.PI * Math.PI * b.eiRaw) / (kLen * kLen);
                    double pAllowKn = (pSquashKn * pEulerKn) / Math.max(1.0, pSquashKn + pEulerKn);
                    double uComp = nAxialCompKn / Math.max(1.0, pAllowKn);
                    if (uComp > util) {
                        util = uComp;
                        mode = (pEulerKn < pSquashKn) ? "EULER_COLUMN_BUCKLING" : "COMPRESSIVE_CRUSHING";
                    }
                }

                // Criterion C: Combined Flexural Bending + Axial Interaction
                if (!b.isFoundationAnchor) {
                    double flexuralTensileKpa = (mDesignKnM / b.sectionModulusWM3)
                            - (sigmaNormalKpa >= 0.0 ? 0.72 * sigmaNormalKpa : sigmaNormalKpa);
                    if (flexuralTensileKpa > 0.0) {
                        double uFlex = flexuralTensileKpa / Math.max(0.5, b.frFlexKpa);
                        if (uFlex > util) { util = uFlex; mode = "FLEXURAL_BENDING_MOMENT"; }
                    }
                }

                // Criterion D: Mohr-Coulomb Shear + Torsion
                double tauShearKpa = (vShearKn / b.areaM2) + (Math.abs(torsKnM) / (2.0 * b.sectionModulusWM3));
                double tauAllowKpa = b.cohesionKpa + b.muInternal * Math.max(0.0, sigmaNormalKpa);
                double uShear = tauShearKpa / Math.max(0.5, tauAllowKpa);
                if (uShear > util) { util = uShear; mode = "MOHR_COULOMB_SHEAR"; }

                utilRatios[bi] = util;
                failModes[bi] = mode;
                if (b.ni < nReal && util > nodalMaxUtil[b.ni]) nodalMaxUtil[b.ni] = util;
                if (b.nj < nReal && util > nodalMaxUtil[b.nj]) nodalMaxUtil[b.nj] = util;
                if (b.continuousBeam != null) {
                    b.continuousBeam.currentUtilization = util;
                }
                if (util > passMaxUtil) passMaxUtil = util;
            }

            if (passMaxUtil <= 1.0) {
                peakStressSeen = passMaxUtil;
                break;
            }
            if (pass == 0 || peakStressSeen == 0.0) {
                peakStressSeen = passMaxUtil;
            }

            double severThreshold = Math.max(1.001, Math.min(1.85, passMaxUtil * 0.76));
            int severedThisPass = 0;
            for (int bi = 0; bi < bCount; bi++) {
                if (utilRatios[bi] >= severThreshold) {
                    BondElement b = activeBonds.get(bi);
                    b.intact = false;
                    severedThisPass++;
                    totalFracturedBonds++;
                    if (b.continuousBeam != null) {
                        buckledBeamIds.add(b.continuousBeam.id);
                    }

                    BlockPos pi = allPositions[b.ni];
                    BlockPos pj = allPositions[b.nj];
                    Vector3d midFace = (b.continuousBeam != null)
                            ? new Vector3d(b.continuousBeam.bx, b.continuousBeam.by, b.continuousBeam.bz)
                            : new Vector3d(
                                    0.5 * (pi.getX() + pj.getX()) + 0.5,
                                    0.5 * (pi.getY() + pj.getY()) + 0.5,
                                    0.5 * (pi.getZ() + pj.getZ()) + 0.5);
                    lastFractureHinge[b.ni] = midFace;
                    lastFractureHinge[b.nj] = midFace;
                    lastFailureReason[b.ni] = failModes[bi];
                    lastFailureReason[b.nj] = failModes[bi];
                    if (b.ni < nReal && fracturedFaces.size() < 24) fracturedFaces.add(pi);
                }
            }

            if (severedThisPass == 0) {
                int worstBi = -1;
                double worstU = 1.0;
                for (int bi = 0; bi < bCount; bi++) {
                    if (utilRatios[bi] > worstU) { worstU = utilRatios[bi]; worstBi = bi; }
                }
                if (worstBi >= 0) {
                    BondElement wb = activeBonds.get(worstBi);
                    wb.intact = false;
                    if (wb.continuousBeam != null) buckledBeamIds.add(wb.continuousBeam.id);
                    totalFracturedBonds++;
                } else {
                    break;
                }
            }
        }

        // Final sweep for newly ungrounded monolithic structures
        List<List<Integer>> finalAdj = new ArrayList<>(nTotal);
        for (int i = 0; i < nTotal; i++) finalAdj.add(new ArrayList<>(8));
        for (BondElement b : bonds) {
            if (b.intact && !detachedNode[b.ni] && !detachedNode[b.nj]) {
                finalAdj.get(b.ni).add(b.nj);
                finalAdj.get(b.nj).add(b.ni);
            }
        }
        boolean[] visFinal = new boolean[nTotal];
        ArrayDeque<Integer> qFinal = new ArrayDeque<>();
        for (int i = 0; i < nReal; i++) {
            if (detachedNode[i] || visFinal[i]) continue;
            List<Integer> compAll = new ArrayList<>();
            List<Integer> compReal = new ArrayList<>();
            boolean grounded = false;
            visFinal[i] = true;
            qFinal.add(i);
            while (!qFinal.isEmpty()) {
                int cur = qFinal.poll();
                compAll.add(cur);
                if (cur < nReal) compReal.add(cur);
                if (fixedNodeMask[cur]) grounded = true;
                for (int nb : finalAdj.get(cur)) {
                    if (!visFinal[nb] && !detachedNode[nb]) {
                        visFinal[nb] = true;
                        qFinal.add(nb);
                    }
                }
            }
            if (!grounded) {
                emitDetachedMonolithicFragment(compReal, compAll, detachedNode, positions, sections,
                        lastFractureHinge, lastFailureReason, peakStressSeen, detachedOut);
            }
        }

        // Export only the real nodes' 6*nReal displacement slice
        double[] uReal = Arrays.copyOf(u, nReal * 6);
        return new FEMSolveReport(nReal, bonds.size(), totalFracturedBonds, totalPcgIters,
                peakStressSeen, detachedOut, fracturedFaces, uReal, nodalMaxUtil, buckledBeamIds);
    }

    private static void emitDetachedMonolithicFragment(
            List<Integer> compReal,
            List<Integer> compAll,
            boolean[] detachedNode,
            List<BlockPos> positions,
            SectionProperties[] sections,
            Vector3d[] lastFractureHinge,
            String[] lastFailureReason,
            double peakStressSeen,
            List<DetachedFragment> detachedOut
    ) {
        for (int idx : compAll) detachedNode[idx] = true;
        if (compReal.isEmpty()) return;

        Vector3d hinge = null;
        String reason = "MONOLITHIC_OVERTURN";
        double cmX = 0, cmY = 0, cmZ = 0, mSum = 0;
        for (int idx : compReal) {
            BlockPos bp = positions.get(idx);
            double m = sections[idx].massKg();
            cmX += m * (bp.getX() + 0.5);
            cmY += m * (bp.getY() + 0.5);
            cmZ += m * (bp.getZ() + 0.5);
            mSum += m;
            // Prefer the most recent fulcrum hinge (e.g. front column head) for natural overturning pitch!
            if (lastFractureHinge[idx] != null) hinge = lastFractureHinge[idx];
            if (lastFailureReason[idx] != null) reason = lastFailureReason[idx];
        }
        if (mSum > 0) { cmX /= mSum; cmY /= mSum; cmZ /= mSum; }

        Vector3d initVel = new Vector3d(0.0, -0.22, 0.0);
        Vector3d initOmega = new Vector3d(0.0, 0.0, 0.0);
        if (hinge != null) {
            double rx = cmX - hinge.x, rz = cmZ - hinge.z;
            double rh = Math.hypot(rx, rz);
            if (rh > 0.20) {
                double mag = Math.min(1.15, 0.45 + 0.08 * rh);
                initOmega.set((rz / rh) * mag, 0.0, (-rx / rh) * mag);
                initVel.set((rx / rh) * 0.35, -0.30, (rz / rh) * 0.35);
            }
        }
        detachedOut.add(new DetachedFragment(compReal,
                hinge != null ? hinge : new Vector3d(cmX, cmY, cmZ),
                initVel, initOmega, Math.max(1.0, peakStressSeen), reason));
    }

    private static double measureCollinearChainLength(
            BlockPos start, int dx, int dy, int dz, Map<BlockPos, Integer> indexMap, double stepLengthM
    ) {
        int steps = 1;
        BlockPos cur = start.add(dx, dy, dz);
        while (steps < 24 && indexMap.containsKey(cur.add(dx, dy, dz))) {
            steps++;
            cur = cur.add(dx, dy, dz);
        }
        cur = start;
        while (steps < 24 && indexMap.containsKey(cur.add(-dx, -dy, -dz))) {
            steps++;
            cur = cur.add(-dx, -dy, -dz);
        }
        return steps * stepLengthM;
    }

    private static int solvePCG(
            int n,
            boolean[] activeMask,
            boolean[] groundedMask,
            List<BondElement> bonds,
            double[] fGlobal,
            double[] u,
            int maxIter
    ) {
        final int ndof = n * 6;
        Arrays.fill(u, 0.0);

        double[] invDiag = new double[ndof];
        for (BondElement b : bonds) {
            int bi = b.ni * 6;
            int bj = b.nj * 6;
            double kTrans = (b.kAx + b.k12 + b.k12) * 0.5 * STIFFNESS_SCALE;
            double kRot   = (b.kTor + b.k4 + b.k4)  * 0.5 * STIFFNESS_SCALE;
            if (!groundedMask[b.ni]) {
                invDiag[bi] += kTrans; invDiag[bi + 1] += kTrans; invDiag[bi + 2] += kTrans;
                invDiag[bi + 3] += kRot; invDiag[bi + 4] += kRot; invDiag[bi + 5] += kRot;
            }
            if (!groundedMask[b.nj]) {
                invDiag[bj] += kTrans; invDiag[bj + 1] += kTrans; invDiag[bj + 2] += kTrans;
                invDiag[bj + 3] += kRot; invDiag[bj + 4] += kRot; invDiag[bj + 5] += kRot;
            }
        }

        double[] r = new double[ndof];
        double[] z = new double[ndof];
        double[] p = new double[ndof];
        double[] ap = new double[ndof];

        double rhsNormSq = 0.0;
        for (int i = 0; i < n; i++) {
            if (!activeMask[i] || groundedMask[i]) continue;
            int base = i * 6;
            for (int d = 0; d < 6; d++) {
                double diag = invDiag[base + d];
                invDiag[base + d] = diag > 1.0e-12 ? (1.0 / diag) : 1.0;
                double fv = fGlobal[base + d] * STIFFNESS_SCALE;
                r[base + d] = fv;
                z[base + d] = invDiag[base + d] * fv;
                p[base + d] = z[base + d];
                rhsNormSq += fv * fv;
            }
        }

        if (rhsNormSq < 1.0e-22) return 0;
        final double tolSq = rhsNormSq * 1.0e-9;

        double rzOld = dot(ndof, r, z);
        int iter = 0;
        for (; iter < maxIter; iter++) {
            multiplyStiffness(n, activeMask, groundedMask, bonds, p, ap);
            double pAp = dot(ndof, p, ap);
            if (Math.abs(pAp) < 1.0e-24) break;

            double alpha = rzOld / pAp;
            double rNormSq = 0.0;
            for (int k = 0; k < ndof; k++) {
                u[k] += alpha * p[k];
                double rk = r[k] - alpha * ap[k];
                r[k] = rk;
                rNormSq += rk * rk;
            }
            if (rNormSq <= tolSq) {
                iter++;
                break;
            }

            double rzNew = 0.0;
            for (int k = 0; k < ndof; k++) {
                double zk = invDiag[k] * r[k];
                z[k] = zk;
                rzNew += r[k] * zk;
            }
            if (Math.abs(rzOld) < 1.0e-26) break;
            double beta = rzNew / rzOld;
            for (int k = 0; k < ndof; k++) {
                p[k] = z[k] + beta * p[k];
            }
            rzOld = rzNew;
        }
        return iter;
    }

    private static void multiplyStiffness(
            int n,
            boolean[] activeMask,
            boolean[] groundedMask,
            List<BondElement> bonds,
            double[] x,
            double[] y
    ) {
        Arrays.fill(y, 0.0);
        for (BondElement b : bonds) {
            int bi = b.ni * 6;
            int bj = b.nj * 6;
            boolean fixI = groundedMask[b.ni];
            boolean fixJ = groundedMask[b.nj];

            double uxi = fixI ? 0.0 : x[bi],     uyi = fixI ? 0.0 : x[bi + 1], uzi = fixI ? 0.0 : x[bi + 2];
            double txi = fixI ? 0.0 : x[bi + 3], tyi = fixI ? 0.0 : x[bi + 4], tzi = fixI ? 0.0 : x[bi + 5];
            double uxj = fixJ ? 0.0 : x[bj],     uyj = fixJ ? 0.0 : x[bj + 1], uzj = fixJ ? 0.0 : x[bj + 2];
            double txj = fixJ ? 0.0 : x[bj + 3], tyj = fixJ ? 0.0 : x[bj + 4], tzj = fixJ ? 0.0 : x[bj + 5];

            double u1i = b.e1x * uxi + b.e1y * uyi + b.e1z * uzi;
            double u2i = b.e2x * uxi + b.e2y * uyi + b.e2z * uzi;
            double u3i = b.e3x * uxi + b.e3y * uyi + b.e3z * uzi;
            double r1i = b.e1x * txi + b.e1y * tyi + b.e1z * tzi;
            double r2i = b.e2x * txi + b.e2y * tyi + b.e2z * tzi;
            double r3i = b.e3x * txi + b.e3y * tyi + b.e3z * tzi;

            double u1j = b.e1x * uxj + b.e1y * uyj + b.e1z * uzj;
            double u2j = b.e2x * uxj + b.e2y * uyj + b.e2z * uzj;
            double u3j = b.e3x * uxj + b.e3y * uyj + b.e3z * uzj;
            double r1j = b.e1x * txj + b.e1y * tyj + b.e1z * tzj;
            double r2j = b.e2x * txj + b.e2y * tyj + b.e2z * tzj;
            double r3j = b.e3x * txj + b.e3y * tyj + b.e3z * tzj;

            double du1 = u1i - u1j;
            double du2 = u2i - u2j;
            double du3 = u3i - u3j;
            double dr1 = r1i - r1j;

            double f1i = (b.kAx  * du1) * STIFFNESS_SCALE;
            double m1i = (b.kTor * dr1) * STIFFNESS_SCALE;

            double f2i = (b.k12 * du2 + b.k6 * (r3i + r3j)) * STIFFNESS_SCALE;
            double m3i = (b.k6  * du2 + b.k4 * r3i + b.k2 * r3j) * STIFFNESS_SCALE;
            double m3j = (b.k6  * du2 + b.k2 * r3i + b.k4 * r3j) * STIFFNESS_SCALE;

            double f3i = (b.k12 * du3 - b.k6 * (r2i + r2j)) * STIFFNESS_SCALE;
            double m2i = (-b.k6 * du3 + b.k4 * r2i + b.k2 * r2j) * STIFFNESS_SCALE;
            double m2j = (-b.k6 * du3 + b.k2 * r2i + b.k4 * r2j) * STIFFNESS_SCALE;

            if (!fixI) {
                y[bi]     += b.e1x * f1i + b.e2x * f2i + b.e3x * f3i;
                y[bi + 1] += b.e1y * f1i + b.e2y * f2i + b.e3y * f3i;
                y[bi + 2] += b.e1z * f1i + b.e2z * f2i + b.e3z * f3i;
                y[bi + 3] += b.e1x * m1i + b.e2x * m2i + b.e3x * m3i;
                y[bi + 4] += b.e1y * m1i + b.e2y * m2i + b.e3y * m3i;
                y[bi + 5] += b.e1z * m1i + b.e2z * m2i + b.e3z * m3i;
            }
            if (!fixJ) {
                y[bj]     -= b.e1x * f1i + b.e2x * f2i + b.e3x * f3i;
                y[bj + 1] -= b.e1y * f1i + b.e2y * f2i + b.e3y * f3i;
                y[bj + 2] -= b.e1z * f1i + b.e2z * f2i + b.e3z * f3i;
                y[bj + 3] += -b.e1x * m1i + b.e2x * m2j + b.e3x * m3j;
                y[bj + 4] += -b.e1y * m1i + b.e2y * m2j + b.e3y * m3j;
                y[bj + 5] += -b.e1z * m1i + b.e2z * m2j + b.e3z * m3j;
            }
        }
        for (int i = 0; i < n; i++) {
            if (activeMask[i] && !groundedMask[i]) {
                int base = i * 6;
                for (int d = 0; d < 6; d++) {
                    y[base + d] += 1.0e-7 * x[base + d];
                }
            }
        }
    }

    private static double dot(int n, double[] a, double[] b) {
        double sum = 0.0;
        for (int i = 0; i < n; i++) sum += a[i] * b[i];
        return sum;
    }
}

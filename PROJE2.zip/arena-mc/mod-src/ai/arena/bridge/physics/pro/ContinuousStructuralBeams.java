package ai.arena.bridge.physics.pro;

import ai.arena.bridge.physics.pro.ConstitutiveMaterialDB.MaterialCategory;
import ai.arena.bridge.physics.pro.ConstitutiveMaterialDB.SectionProperties;
import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.sound.SoundCategory;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.joml.Quaternionf;
import org.joml.Vector3d;
import org.joml.Vector3f;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Module 7: Non-Grid Continuous 3D Structural Beams & Inclined Columns ("Bloksuz Sürekli Eğik Kolon & Kiriş Motoru").
 *
 * Breaks free of Minecraft's 90-degree 1x1x1 voxel staircase limitation:
 * - Defines smooth, continuous 3D structural members between arbitrary 3D endpoints A(x1,y1,z1) -> B(x2,y2,z2)
 *   at ANY inclination angle (e.g. 32°, 45°, 58°) and ANY cross-section width/depth (e.g. 0.46m x 0.46m).
 * - Participates directly in the 6-DoF Timoshenko-Euler-Bernoulli FEM stiffness matrix & Euler column buckling!
 * - Deforms smoothly along a continuous cubic Hermite curve when loaded, and detaches as a continuous 3D beam
 *   when buckled or toppled (never turning into stepped Minecraft blocks!).
 */
public final class ContinuousStructuralBeams {

    private static final AtomicLong NEXT_BEAM_ID = new AtomicLong(1L);

    public static final class ContinuousBeam {
        public final long id;
        public final double ax, ay, az;
        public final double bx, by, bz;
        public final double widthM;
        public final double depthM;
        public final double lengthM;
        public final BlockState materialState;
        public final SectionProperties baseSection;
        public final boolean temporaryTestRig;

        // Unit local triad: e1 along A->B, e2, e3 transverse cross-section axes
        public final double e1x, e1y, e1z;
        public final double e2x, e2y, e2z;
        public final double e3x, e3y, e3z;
        public final Quaternionf restOrientation = new Quaternionf();

        // Live elasto-plastic deformation at endpoints A and B (from coupled FEM solve)
        public volatile double dispAx, dispAy, dispAz;
        public volatile double dispBx, dispBy, dispBz;
        public volatile double lateralBowM = 0.0; // Mid-span Euler buckling bow amplitude
        public volatile double currentUtilization = 0.0;

        public ContinuousBeam(
                long id,
                double ax, double ay, double az,
                double bx, double by, double bz,
                double widthM, double depthM,
                BlockState materialState,
                boolean temporaryTestRig
        ) {
            this.id = id;
            this.ax = ax; this.ay = ay; this.az = az;
            this.bx = bx; this.by = by; this.bz = bz;
            this.widthM = Math.max(0.18, widthM);
            this.depthM = Math.max(0.18, depthM);
            this.materialState = materialState != null ? materialState : Blocks.STRIPPED_OAK_WOOD.getDefaultState();
            this.baseSection = ConstitutiveMaterialDB.computeSection(this.materialState);
            this.temporaryTestRig = temporaryTestRig;

            double dx = bx - ax, dy = by - ay, dz = bz - az;
            this.lengthM = Math.max(0.25, Math.sqrt(dx * dx + dy * dy + dz * dz));
            this.e1x = dx / this.lengthM;
            this.e1y = dy / this.lengthM;
            this.e1z = dz / this.lengthM;

            double rx, ry, rz;
            if (Math.abs(this.e1y) < 0.92) {
                rx = 0.0; ry = 1.0; rz = 0.0;
            } else {
                rx = 1.0; ry = 0.0; rz = 0.0;
            }
            double c2x = ry * this.e1z - rz * this.e1y;
            double c2y = rz * this.e1x - rx * this.e1z;
            double c2z = rx * this.e1y - ry * this.e1x;
            double c2Len = Math.max(1.0e-8, Math.sqrt(c2x * c2x + c2y * c2y + c2z * c2z));
            this.e3x = c2x / c2Len;
            this.e3y = c2y / c2Len;
            this.e3z = c2z / c2Len;

            this.e2x = this.e3y * this.e1z - this.e3z * this.e1y;
            this.e2y = this.e3z * this.e1x - this.e3x * this.e1z;
            this.e2z = this.e3x * this.e1y - this.e3y * this.e1x;

            // Build rest quaternion mapping local X->e1 (length), Y->e2 (depth), Z->e3 (width)
            org.joml.Matrix3f basis = new org.joml.Matrix3f(
                    (float) this.e1x, (float) this.e1y, (float) this.e1z,
                    (float) this.e2x, (float) this.e2y, (float) this.e2z,
                    (float) this.e3x, (float) this.e3y, (float) this.e3z
            );
            this.restOrientation.setFromNormalized(basis);
        }

        public double areaM2() {
            return widthM * depthM;
        }

        public double secondMomentIM4() {
            double b = Math.max(widthM, depthM);
            double h = Math.min(widthM, depthM);
            return (b * h * h * h) / 12.0;
        }

        public double sectionModulusWM3() {
            double b = Math.max(widthM, depthM);
            double h = Math.min(widthM, depthM);
            return (b * h * h) / 6.0;
        }

        public double massKg() {
            return baseSection.densityKgM3() * areaM2() * lengthM;
        }

        public MaterialCategory category() {
            return baseSection.category();
        }

        /**
         * Evaluates deformed 3D centerline point along parameter s in [0, 1], including smooth
         * endpoint sagging and sinusoidal column buckling bow!
         */
        public Vec3d sampleDeformedPoint(double s) {
            double px = ax + (bx - ax) * s + dispAx * (1.0 - s) + dispBx * s;
            double py = ay + (by - ay) * s + dispAy * (1.0 - s) + dispBy * s;
            double pz = az + (bz - az) * s + dispAz * (1.0 - s) + dispBz * s;
            if (Math.abs(lateralBowM) > 1.0e-4) {
                double bow = lateralBowM * Math.sin(Math.PI * s);
                px += e2x * bow;
                py += e2y * bow;
                pz += e2z * bow;
            }
            return new Vec3d(px, py, pz);
        }
    }

    /**
     * Detached continuous 3D beam carried inside a 6-DoF RigidCluster6DoF (local coordinates relative to cluster CoM).
     */
    public record DetachedContinuousBeam(
            double lax, double lay, double laz,
            double lbx, double lby, double lbz,
            double widthM, double depthM,
            double lengthM,
            Quaternionf localOrientation,
            BlockState materialState,
            double massKg
    ) {}

    public static final List<ContinuousBeam> ACTIVE_BEAMS = new CopyOnWriteArrayList<>();
    public static final List<ContinuousBeam> SNAPSHOT_BEAMS_FOR_REWIND = new CopyOnWriteArrayList<>();
    public static final Map<UUID, Vec3d> PLAYER_FIRST_ENDPOINT = new ConcurrentHashMap<>();
    private static boolean diskLoaded = false;

    private ContinuousStructuralBeams() {}

    public static ContinuousBeam addBeam(
            double ax, double ay, double az,
            double bx, double by, double bz,
            double widthM, double depthM,
            BlockState materialState,
            boolean temporaryTestRig
    ) {
        ensureLoadedFromDisk();
        long id = NEXT_BEAM_ID.getAndIncrement();
        ContinuousBeam beam = new ContinuousBeam(id, ax, ay, az, bx, by, bz, widthM, depthM, materialState, temporaryTestRig);
        ACTIVE_BEAMS.add(beam);
        SNAPSHOT_BEAMS_FOR_REWIND.removeIf(b -> b.id == id);
        SNAPSHOT_BEAMS_FOR_REWIND.add(beam);
        if (!temporaryTestRig) {
            saveToDisk();
        }
        return beam;
    }

    public static boolean removeBeamById(ServerWorld world, long id, boolean playBreakFx) {
        for (ContinuousBeam b : ACTIVE_BEAMS) {
            if (b.id == id) {
                ACTIVE_BEAMS.remove(b);
                if (playBreakFx && world != null) {
                    Vec3d mid = b.sampleDeformedPoint(0.5);
                    world.playSound(null, BlockPos.ofFloored(mid.x, mid.y, mid.z),
                            b.materialState.getSoundGroup().getBreakSound(), SoundCategory.BLOCKS, 1.1f, 0.85f);
                }
                if (!b.temporaryTestRig) saveToDisk();
                return true;
            }
        }
        return false;
    }

    public static void clearTemporaryTestBeams() {
        ACTIVE_BEAMS.removeIf(b -> b.temporaryTestRig);
        SNAPSHOT_BEAMS_FOR_REWIND.removeIf(b -> b.temporaryTestRig);
    }

    public static void rewindAllDetachedBeams() {
        ACTIVE_BEAMS.clear();
        for (ContinuousBeam b : SNAPSHOT_BEAMS_FOR_REWIND) {
            b.dispAx = b.dispAy = b.dispAz = 0.0;
            b.dispBx = b.dispBy = b.dispBz = 0.0;
            b.lateralBowM = 0.0;
            b.currentUtilization = 0.0;
            ACTIVE_BEAMS.add(b);
        }
    }

    public static DetachedContinuousBeam toDetachedLocal(ContinuousBeam b, double cmX, double cmY, double cmZ) {
        double lax = (b.ax + b.dispAx) - cmX;
        double lay = (b.ay + b.dispAy) - cmY;
        double laz = (b.az + b.dispAz) - cmZ;
        double lbx = (b.bx + b.dispBx) - cmX;
        double lby = (b.by + b.dispBy) - cmY;
        double lbz = (b.bz + b.dispBz) - cmZ;
        double dx = lbx - lax, dy = lby - lay, dz = lbz - laz;
        double len = Math.max(0.25, Math.sqrt(dx * dx + dy * dy + dz * dz));
        double e1x = dx / len, e1y = dy / len, e1z = dz / len;
        double rx = Math.abs(e1y) < 0.92 ? 0.0 : 1.0;
        double ry = Math.abs(e1y) < 0.92 ? 1.0 : 0.0;
        double rz = 0.0;
        double c2x = ry * e1z - rz * e1y;
        double c2y = rz * e1x - rx * e1z;
        double c2z = rx * e1y - ry * e1x;
        double c2L = Math.max(1.0e-8, Math.sqrt(c2x * c2x + c2y * c2y + c2z * c2z));
        double e3x = c2x / c2L, e3y = c2y / c2L, e3z = c2z / c2L;
        double e2x = e3y * e1z - e3z * e1y;
        double e2y = e3z * e1x - e3x * e1z;
        double e2z = e3x * e1y - e3y * e1x;
        Quaternionf q = new Quaternionf().setFromNormalized(new org.joml.Matrix3f(
                (float) e1x, (float) e1y, (float) e1z,
                (float) e2x, (float) e2y, (float) e2z,
                (float) e3x, (float) e3y, (float) e3z
        ));
        return new DetachedContinuousBeam(lax, lay, laz, lbx, lby, lbz, b.widthM, b.depthM, len, q, b.materialState, b.massKg());
    }

    /**
     * Finds all continuous beams whose endpoint A or B touches or is embedded within 0.85m of any voxel in `componentSet`.
     */
    public static List<ContinuousBeam> findConnectedBeams(Set<BlockPos> componentSet) {
        if (ACTIVE_BEAMS.isEmpty() || componentSet.isEmpty()) return List.of();
        List<ContinuousBeam> out = new ArrayList<>();
        for (ContinuousBeam b : ACTIVE_BEAMS) {
            if (touchesComponent(b.ax, b.ay, b.az, componentSet) || touchesComponent(b.bx, b.by, b.bz, componentSet)) {
                out.add(b);
            }
        }
        return out;
    }

    public static int findNearestNodeIndex(double px, double py, double pz, List<BlockPos> positions, Map<BlockPos, Integer> indexMap) {
        BlockPos exact = BlockPos.ofFloored(px, py, pz);
        Integer idx = indexMap.get(exact);
        if (idx != null) return idx;

        int bestIdx = -1;
        double bestD2 = 1.65 * 1.65; // 1.65m structural socket capture radius
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                for (int dz = -1; dz <= 1; dz++) {
                    BlockPos cand = exact.add(dx, dy, dz);
                    Integer ci = indexMap.get(cand);
                    if (ci != null) {
                        double d2 = sq(px - (cand.getX() + 0.5)) + sq(py - (cand.getY() + 0.5)) + sq(pz - (cand.getZ() + 0.5));
                        if (d2 < bestD2) {
                            bestD2 = d2;
                            bestIdx = ci;
                        }
                    }
                }
            }
        }
        return bestIdx;
    }

    public static boolean isEndpointGroundedInTerrain(ServerWorld world, double px, double py, double pz, Set<BlockPos> componentSet) {
        BlockPos p0 = BlockPos.ofFloored(px, py, pz);
        if (ConstitutiveMaterialDB.isTrueSolidTerrainFoundation(world, p0, componentSet)) return true;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 0; dy++) {
                for (int dz = -1; dz <= 1; dz++) {
                    BlockPos nb = p0.add(dx, dy, dz);
                    double d2 = sq(px - (nb.getX() + 0.5)) + sq(py - (nb.getY() + 0.5)) + sq(pz - (nb.getZ() + 0.5));
                    if (d2 <= 1.35 * 1.35 && ConstitutiveMaterialDB.isTrueSolidTerrainFoundation(world, nb, componentSet)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private static boolean touchesComponent(double px, double py, double pz, Set<BlockPos> componentSet) {
        BlockPos base = BlockPos.ofFloored(px, py, pz);
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                for (int dz = -1; dz <= 1; dz++) {
                    BlockPos cand = base.add(dx, dy, dz);
                    if (componentSet.contains(cand)) {
                        double d2 = sq(px - (cand.getX() + 0.5)) + sq(py - (cand.getY() + 0.5)) + sq(pz - (cand.getZ() + 0.5));
                        if (d2 <= 1.65 * 1.65) return true;
                    }
                }
            }
        }
        return false;
    }

    private static double sq(double v) { return v * v; }

    private static Path getDiskPath() {
        return FabricLoader.getInstance().getGameDir().resolve("arena-continuous-beams-v1.json");
    }

    public static synchronized void saveToDisk() {
        try {
            JsonArray arr = new JsonArray();
            for (ContinuousBeam b : ACTIVE_BEAMS) {
                if (b.temporaryTestRig) continue;
                JsonObject o = new JsonObject();
                o.addProperty("id", b.id);
                o.addProperty("ax", b.ax); o.addProperty("ay", b.ay); o.addProperty("az", b.az);
                o.addProperty("bx", b.bx); o.addProperty("by", b.by); o.addProperty("bz", b.bz);
                o.addProperty("w", b.widthM); o.addProperty("d", b.depthM);
                o.addProperty("mat", ConstitutiveMaterialDB.serializeBlockState(b.materialState));
                arr.add(o);
            }
            String json = new GsonBuilder().create().toJson(arr);
            Path path = getDiskPath();
            CompletableFuture.runAsync(() -> {
                try {
                    Files.writeString(path, json, StandardCharsets.UTF_8);
                } catch (Throwable ignored) {}
            });
        } catch (Throwable ignored) {}
    }

    public static synchronized void ensureLoadedFromDisk() {
        if (diskLoaded) return;
        diskLoaded = true;
        try {
            Path path = getDiskPath();
            if (!Files.exists(path)) return;
            JsonArray arr = JsonParser.parseString(Files.readString(path, StandardCharsets.UTF_8)).getAsJsonArray();
            long maxId = 1L;
            for (JsonElement el : arr) {
                JsonObject o = el.getAsJsonObject();
                long id = o.get("id").getAsLong();
                maxId = Math.max(maxId, id + 1L);
                ContinuousBeam b = new ContinuousBeam(
                        id,
                        o.get("ax").getAsDouble(), o.get("ay").getAsDouble(), o.get("az").getAsDouble(),
                        o.get("bx").getAsDouble(), o.get("by").getAsDouble(), o.get("bz").getAsDouble(),
                        o.get("w").getAsDouble(), o.get("d").getAsDouble(),
                        ConstitutiveMaterialDB.deserializeBlockState(o.get("mat").getAsString()),
                        false
                );
                ACTIVE_BEAMS.add(b);
                SNAPSHOT_BEAMS_FOR_REWIND.add(b);
            }
            NEXT_BEAM_ID.set(maxId);
        } catch (Throwable ignored) {}
    }
}

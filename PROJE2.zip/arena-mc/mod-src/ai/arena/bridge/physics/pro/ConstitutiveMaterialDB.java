package ai.arena.bridge.physics.pro;

import net.minecraft.block.*;
import net.minecraft.block.enums.BlockHalf;
import net.minecraft.block.enums.SlabType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.Properties;
import net.minecraft.state.property.Property;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.WorldView;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.Map;
import java.util.Optional;

/**
 * Constitutive Material Mechanics & Lossless BlockState Codec (SI Units: kg/m^3, kPa, kN, kN*m).
 * Classifies every Minecraft BlockState via Fabric/Vanilla BlockTags, block geometry, and hardness
 * into genuine structural engineering constitutive profiles.
 */
public final class ConstitutiveMaterialDB {

    private ConstitutiveMaterialDB() {}

    public enum MaterialCategory {
        GRANULAR_COHESIONLESS(
                1650.0,      // density (kg/m^3)
                45_000.0,    // Young's modulus E (kPa)
                18_000.0,    // Shear modulus G (kPa)
                600.0,       // Compressive strength fc (kPa)
                0.0,         // Direct tensile bond strength ft (kPa) -> zero tension!
                0.0,         // Flexural modulus of rupture fr (kPa) -> zero cantilever!
                0.0,         // Shear cohesion c0 (kPa)
                0.62,        // Mohr-Coulomb internal friction coeff mu_int
                0.04,        // Restitution e
                0.68,        // Dynamic Coulomb friction mu_slide
                false        // Brittle shatter on impact
        ),
        UNREINFORCED_MASONRY(
                2400.0,      // Stone brick / masonry: 2400 kg/m^3 -> W = 23.54 kN/block
                14_000_000.0,// E = 14 GPa
                5_600_000.0, // G = 5.6 GPa
                15_000.0,    // fc = 15 MPa (strong in column/arch compression!)
                36.0,        // ft = 36 kPa (mortar joint fails if >= 2 blocks hang vertically in tension!)
                780.0,       // fr = 780 kPa -> Mr = fr * (1/6) = 130 kN*m (~3.3m 1x1 cantilever, ~7.8m flat span, 18m+ true arch!)
                220.0,       // c0 = 220 kPa shear cohesion
                0.72,        // mu_int = 0.72 (arch compression dramatically boosts shear & flexural capacity)
                0.12,        // Low stone restitution
                0.76,        // High masonry rubble friction
                false
        ),
        REINFORCED_CONCRETE_POLISHED(
                2450.0,
                28_000_000.0,// E = 28 GPa
                11_200_000.0,
                32_000.0,    // fc = 32 MPa
                1_400.0,     // ft = 1.4 MPa
                2_100.0,     // fr = 2.1 MPa -> Mr = 350 kN*m (~5.3m cantilever, ~13m flat span)
                950.0,
                0.75,
                0.14,
                0.72,
                false
        ),
        STRUCTURAL_TIMBER(
                620.0,       // Density < 1000 kg/m^3 -> FLOATS ON WATER! (W = 6.08 kN/block)
                11_000_000.0,// E = 11 GPa parallel to grain
                750_000.0,
                22_000.0,
                340.0,       // Mortise/tenon timber tension capacity
                690.0,       // fr = 690 kPa -> Mr = 115 kN*m (~6.1m cantilever due to low self-weight, ~15m span!)
                420.0,
                0.55,
                0.26,
                0.58,
                false
        ),
        BRITTLE_GLASS_ICE(
                2480.0,      // Overridden to 917 kg/m^3 for BlockTags.ICE so ice floats!
                1_800_000.0, // Gasket-mounted architectural glazing effective modulus (load flows through frame mullions, not glass!)
                720_000.0,
                18_000.0,
                190.0,       // Glazing frame tensile retention before pane pop-out
                320.0,
                220.0,
                0.35,
                0.08,
                0.20,
                true         // Shatters on hard high-velocity impact!
        ),
        STRUCTURAL_STEEL(
                7850.0,      // W = 77.0 kN/block
                200_000_000.0,// E = 200 GPa
                79_000_000.0,
                250_000.0,   // fc = 250 MPa
                18_000.0,    // ft = 18 MPa (chains/steel hangers support heavy tension suspension decks!)
                18_500.0,    // fr = 18.5 MPa -> Mr = 3083 kN*m (~8.9m 1x1 cantilever, ~22m flat span!)
                11_000.0,
                0.50,
                0.22,
                0.46,
                false
        ),
        LIGHT_FOLIAGE_FABRIC(
                280.0,       // Floats on water
                600_000.0,
                220_000.0,
                800.0,
                14.0,
                42.0,
                30.0,
                0.45,
                0.10,
                0.70,
                false
        );

        public final double baseDensityKgM3;
        public final double youngsModulusKpa;
        public final double shearModulusKpa;
        public final double compressiveStrengthKpa;
        public final double directTensileStrengthKpa;
        public final double flexuralRuptureStrengthKpa;
        public final double shearCohesionKpa;
        public final double internalFrictionCoeff;
        public final double restitution;
        public final double slidingFriction;
        public final boolean shattersOnImpact;

        MaterialCategory(double baseDensityKgM3, double youngsModulusKpa, double shearModulusKpa,
                         double compressiveStrengthKpa, double directTensileStrengthKpa,
                         double flexuralRuptureStrengthKpa, double shearCohesionKpa,
                         double internalFrictionCoeff, double restitution,
                         double slidingFriction, boolean shattersOnImpact) {
            this.baseDensityKgM3 = baseDensityKgM3;
            this.youngsModulusKpa = youngsModulusKpa;
            this.shearModulusKpa = shearModulusKpa;
            this.compressiveStrengthKpa = compressiveStrengthKpa;
            this.directTensileStrengthKpa = directTensileStrengthKpa;
            this.flexuralRuptureStrengthKpa = flexuralRuptureStrengthKpa;
            this.shearCohesionKpa = shearCohesionKpa;
            this.internalFrictionCoeff = internalFrictionCoeff;
            this.restitution = restitution;
            this.slidingFriction = slidingFriction;
            this.shattersOnImpact = shattersOnImpact;
        }
    }

    public record SectionProperties(
            MaterialCategory category,
            double densityKgM3,
            double volumeFraction,
            double areaM2,
            double secondMomentIM4,
            double sectionModulusWM3,
            double polarMomentJM4,
            double massKg,
            double weightKn
    ) {}

    public static MaterialCategory classify(BlockState st) {
        if (st == null || st.isAir()) return MaterialCategory.LIGHT_FOLIAGE_FABRIC;
        if (st.isIn(BlockTags.SAND) || st.isOf(Blocks.GRAVEL) || st.isIn(BlockTags.CONCRETE_POWDER)
                || st.isOf(Blocks.SUSPICIOUS_SAND) || st.isOf(Blocks.SUSPICIOUS_GRAVEL)) {
            return MaterialCategory.GRANULAR_COHESIONLESS;
        }
        String path = Registries.BLOCK.getId(st.getBlock()).getPath();
        if (st.isIn(BlockTags.ICE) || st.isIn(BlockTags.IMPERMEABLE)
                || path.contains("glass") || st.isOf(Blocks.SEA_LANTERN) || st.isOf(Blocks.GLOWSTONE)) {
            return MaterialCategory.BRITTLE_GLASS_ICE;
        }
        if (st.isIn(BlockTags.ANVIL) || st.isOf(Blocks.IRON_BLOCK) || st.isOf(Blocks.RAW_IRON_BLOCK)
                || st.isOf(Blocks.COPPER_BLOCK) || st.isOf(Blocks.EXPOSED_COPPER)
                || st.isOf(Blocks.WEATHERED_COPPER) || st.isOf(Blocks.OXIDIZED_COPPER)
                || st.isOf(Blocks.NETHERITE_BLOCK) || st.isOf(Blocks.GOLD_BLOCK)
                || st.isOf(Blocks.DIAMOND_BLOCK) || st.isOf(Blocks.OBSIDIAN)
                || st.isOf(Blocks.CRYING_OBSIDIAN) || st.isOf(Blocks.IRON_BARS)
                || st.isOf(Blocks.CHAIN) || st.isOf(Blocks.IRON_DOOR) || st.isOf(Blocks.IRON_TRAPDOOR)) {
            return MaterialCategory.STRUCTURAL_STEEL;
        }
        if (st.isIn(BlockTags.PLANKS) || st.isIn(BlockTags.LOGS) || st.isIn(BlockTags.WOODEN_SLABS)
                || st.isIn(BlockTags.WOODEN_STAIRS) || st.isIn(BlockTags.WOODEN_FENCES)
                || st.isIn(BlockTags.FENCE_GATES) || st.isIn(BlockTags.WOODEN_DOORS)
                || st.isIn(BlockTags.WOODEN_TRAPDOORS) || st.isOf(Blocks.BAMBOO_BLOCK)
                || st.isOf(Blocks.BAMBOO_MOSAIC) || st.isOf(Blocks.BOOKSHELF)
                || st.isOf(Blocks.BARREL) || st.isOf(Blocks.CRAFTING_TABLE) || st.isOf(Blocks.LADDER)) {
            return MaterialCategory.STRUCTURAL_TIMBER;
        }
        if (st.isIn(BlockTags.LEAVES) || st.isIn(BlockTags.WOOL) || st.isIn(BlockTags.WOOL_CARPETS)
                || st.isIn(BlockTags.SNOW) || st.isOf(Blocks.HAY_BLOCK) || st.isOf(Blocks.MOSS_BLOCK)
                || st.isOf(Blocks.SPONGE) || st.isOf(Blocks.WET_SPONGE)) {
            return MaterialCategory.LIGHT_FOLIAGE_FABRIC;
        }
        if (path.endsWith("_concrete") && !path.endsWith("_concrete_powder")) {
            return MaterialCategory.REINFORCED_CONCRETE_POLISHED;
        }
        return MaterialCategory.UNREINFORCED_MASONRY;
    }

    public static SectionProperties computeSection(BlockState st) {
        MaterialCategory cat = classify(st);
        double rho = cat.baseDensityKgM3;
        if (st != null) {
            if (st.isIn(BlockTags.ICE)) {
                rho = 917.0;
            } else if (st.isOf(Blocks.NETHERITE_BLOCK) || st.isOf(Blocks.ANCIENT_DEBRIS)) {
                rho = 28_500.0; // Ultra-dense platinum/gold/debris alloy: 28.5 tons/m^3 (W = 279.5 kN/block!)
            } else if (st.isOf(Blocks.GOLD_BLOCK) || st.isOf(Blocks.RAW_GOLD_BLOCK) || st.isOf(Blocks.GILDED_BLACKSTONE)) {
                rho = 19_320.0; // Pure gold: 19.32 tons/m^3 (W = 189.5 kN/block!)
            } else if (st.isOf(Blocks.COPPER_BLOCK) || st.isOf(Blocks.EXPOSED_COPPER)
                    || st.isOf(Blocks.WEATHERED_COPPER) || st.isOf(Blocks.OXIDIZED_COPPER)
                    || st.isOf(Blocks.RAW_COPPER_BLOCK)) {
                rho = 8_960.0;  // Copper: 8.96 tons/m^3
            } else if (st.isOf(Blocks.DIAMOND_BLOCK) || st.isOf(Blocks.EMERALD_BLOCK) || st.isOf(Blocks.LAPIS_BLOCK)) {
                rho = 3_515.0;  // Crystalline gem block: 3.52 tons/m^3
            } else if (st.isOf(Blocks.OBSIDIAN) || st.isOf(Blocks.CRYING_OBSIDIAN)) {
                rho = 2_600.0;  // Volcanic glass/basalt
            }
        }

        double vol = 1.0;
        double b = 1.0;
        double h = 1.0;
        Block blk = st.getBlock();
        if (blk instanceof SlabBlock && st.contains(Properties.SLAB_TYPE) && st.get(Properties.SLAB_TYPE) != SlabType.DOUBLE) {
            vol = 0.50;
            h = 0.50; // Half-depth slab has I = b*(0.5)^3/12 = 1/8th stiffness and W = b*(0.5)^2/6 = 1/4th bending strength!
        } else if (blk instanceof StairsBlock) {
            vol = 0.75;
            h = 0.78;
        } else if (blk instanceof WallBlock || blk instanceof FenceBlock) {
            vol = 0.36;
            b = 0.60;
            h = 0.60;
        } else if (blk instanceof PaneBlock || blk instanceof ChainBlock) {
            vol = 0.22;
            b = 0.45;
            h = 0.45;
        } else if (blk instanceof TrapdoorBlock || blk instanceof DoorBlock) {
            vol = 0.25;
            h = 0.35;
        }

        double area = b * h;
        double iSecond = (b * h * h * h) / 12.0;
        double wModulus = (b * h * h) / 6.0;
        double jPolar = iSecond * 1.68; // Saint-Venant rectangular torsion constant (0.1406 * b * h^3 = 1.687 * I)
        double massKg = rho * vol;
        double weightKn = (massKg * 9.80665) * 1e-3; // N -> kN
        return new SectionProperties(cat, rho, vol, area, iSecond, wModulus, jPolar, massKg, weightKn);
    }

    public static boolean isTrueSolidTerrainFoundation(WorldView world, BlockPos pos, java.util.Set<BlockPos> structureSet) {
        if (structureSet != null && structureSet.contains(pos)) return false;
        if (!world.isChunkLoaded(pos.getX() >> 4, pos.getZ() >> 4)) return true;
        BlockState st = world.getBlockState(pos);
        if (st.isAir() || st.isOf(Blocks.BARRIER) || !st.getFluidState().isEmpty()) return false;
        if (st.isIn(BlockTags.LEAVES) || st.isIn(BlockTags.FLOWERS) || st.isReplaceable()) return false;
        if (st.isOf(Blocks.SNOW) && st.contains(SnowBlock.LAYERS) && st.get(SnowBlock.LAYERS) < 8) return false;
        return !st.getCollisionShape(world, pos).isEmpty();
    }

    public static BlockState rotateStateByQuaternion(BlockState state, Quaternionf q, boolean underwater) {
        if (state == null || state.isAir() || q == null) return state;
        Vector3f fwd = new Vector3f(0f, 0f, 1f);
        Vector3f up  = new Vector3f(0f, 1f, 0f);
        q.transform(fwd);
        q.transform(up);

        double yawDeg = Math.toDegrees(Math.atan2(-fwd.x, fwd.z));
        int quarterTurns = ((int) Math.round(yawDeg / 90.0)) & 3;
        BlockRotation rot = switch (quarterTurns) {
            case 1 -> BlockRotation.CLOCKWISE_90;
            case 2 -> BlockRotation.CLOCKWISE_180;
            case 3 -> BlockRotation.COUNTERCLOCKWISE_90;
            default -> BlockRotation.NONE;
        };
        BlockState out = state.rotate(rot);

        if (out.contains(Properties.AXIS) && Math.abs(up.y) < 0.45f) {
            Direction.Axis newAxis = (Math.abs(up.x) > Math.abs(up.z)) ? Direction.Axis.X : Direction.Axis.Z;
            out = out.with(Properties.AXIS, newAxis);
        }
        if (up.y < -0.35f) {
            if (out.contains(Properties.BLOCK_HALF)) {
                BlockHalf cur = out.get(Properties.BLOCK_HALF);
                out = out.with(Properties.BLOCK_HALF, cur == BlockHalf.TOP ? BlockHalf.BOTTOM : BlockHalf.TOP);
            }
            if (out.contains(Properties.SLAB_TYPE) && out.get(Properties.SLAB_TYPE) != SlabType.DOUBLE) {
                SlabType cur = out.get(Properties.SLAB_TYPE);
                out = out.with(Properties.SLAB_TYPE, cur == SlabType.TOP ? SlabType.BOTTOM : SlabType.TOP);
            }
        }
        if (out.contains(Properties.WATERLOGGED)) {
            out = out.with(Properties.WATERLOGGED, underwater);
        }
        return out;
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static String serializeBlockState(BlockState state) {
        if (state == null) return "minecraft:air";
        StringBuilder sb = new StringBuilder(Registries.BLOCK.getId(state.getBlock()).toString());
        if (!state.getEntries().isEmpty()) {
            sb.append('[');
            boolean first = true;
            for (Map.Entry<Property<?>, Comparable<?>> entry : state.getEntries().entrySet()) {
                if (!first) sb.append(',');
                first = false;
                Property prop = entry.getKey();
                sb.append(prop.getName()).append('=').append(prop.name(entry.getValue()));
            }
            sb.append(']');
        }
        return sb.toString();
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static BlockState deserializeBlockState(String serialized) {
        if (serialized == null || serialized.isBlank()) return Blocks.AIR.getDefaultState();
        int bracket = serialized.indexOf('[');
        String blockId = bracket >= 0 ? serialized.substring(0, bracket) : serialized;
        Block block = Registries.BLOCK.get(new Identifier(blockId));
        BlockState state = block.getDefaultState();
        if (bracket >= 0 && serialized.endsWith("]")) {
            String propsPart = serialized.substring(bracket + 1, serialized.length() - 1);
            StateManager<Block, BlockState> sm = block.getStateManager();
            for (String pair : propsPart.split(",")) {
                int eq = pair.indexOf('=');
                if (eq <= 0) continue;
                String k = pair.substring(0, eq).trim();
                String v = pair.substring(eq + 1).trim();
                Property prop = sm.getProperty(k);
                if (prop != null) {
                    Optional<Comparable> parsed = prop.parse(v);
                    if (parsed.isPresent()) {
                        state = state.with(prop, parsed.get());
                    }
                }
            }
        }
        return state;
    }
}

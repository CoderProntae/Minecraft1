package ai.arena.bridge.physics.pro;

import ai.arena.bridge.physics.GeoStructuralPhysicsEngine;
import ai.arena.bridge.physics.pro.ContinuousStructuralBeams.ContinuousBeam;
import ai.arena.bridge.physics.pro.RigidBody6DoFDynamics.RigidCluster6DoF;
import ai.arena.bridge.physics.pro.VoxelFrameFEMSolver.DetachedFragment;
import ai.arena.bridge.physics.pro.VoxelFrameFEMSolver.ExternalBeamAttachment;
import ai.arena.bridge.physics.pro.VoxelFrameFEMSolver.FEMSolveReport;
import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.*;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.passive.IronGolemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.LightType;
import org.joml.Vector3d;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Universal Structural Extraction, Coupled Continuous-Beam + Voxel 6-DoF FEM Solver,
 * Smooth Continuous Curvature ("Sürekli Eğrilik"), Monolithic Toppling ("Tek Parça Devrilme"),
 * BARRIER-Free 3D OBB Persistence, & Lossless /onar Rewind.
 */
public final class FractureAndSolidifier {

    public static final class BlueprintRecord {
        public final String id;
        public final BlockPos origin;
        public final Map<BlockPos, BlockState> originalStates = new LinkedHashMap<>();
        public final Set<BlockPos> depositedRubble = ConcurrentHashMap.newKeySet();

        public BlueprintRecord(String id, BlockPos origin) {
            this.id = id;
            this.origin = origin.toImmutable();
        }
    }

    public record ElasticSagVoxel(
            BlockPos pos,
            BlockState realState,
            double targetDx,
            double targetDy,
            double targetDz,
            float targetRx,
            float targetRy,
            float targetRz,
            double stressRatio,
            int[] faceBlockLight,
            int[] faceSkyLight
    ) {}

    public static final List<BlueprintRecord> BLUEPRINTS = new CopyOnWriteArrayList<>();
    public static final Set<BlockPos> GLOBAL_DEPOSITED_RUBBLE = ConcurrentHashMap.newKeySet();
    public static final Map<BlockPos, ElasticSagVoxel> ELASTIC_PROXIES = new ConcurrentHashMap<>();
    // Stores permanent plastic yield deformation {dx, dy, dz, rx, ry, rz} so removing heavy loads leaves realistic plastic set instead of snapping to zero!
    public static final Map<BlockPos, double[]> PLASTIC_RESIDUAL_MAP = new ConcurrentHashMap<>();
    public static final Map<BlockPos, Long> RUBBLE_BARRIER_OWNER = new ConcurrentHashMap<>();
    public static final Map<BlockPos, BlockState> TEST_RIG_RESTORE_MAP = new LinkedHashMap<>();

    public static volatile double lastFemSolveMs = 0.0;
    public static volatile double lastPeakStressRatio = 0.0;
    public static volatile int lastDetachedBlocks = 0;
    private static boolean diskLoaded = false;

    private static final int[][] DIAG_12 = {
            { 1,  1,  0,   1, 0, 0,   0, 1, 0},
            {-1, -1,  0,  -1, 0, 0,   0,-1, 0},
            { 1, -1,  0,   1, 0, 0,   0,-1, 0},
            {-1,  1,  0,  -1, 0, 0,   0, 1, 0},
            { 0,  1,  1,   0, 1, 0,   0, 0, 1},
            { 0, -1, -1,   0,-1, 0,   0, 0,-1},
            { 0,  1, -1,   0, 1, 0,   0, 0,-1},
            { 0, -1,  1,   0,-1, 0,   0, 0, 1},
            { 1,  0,  1,   1, 0, 0,   0, 0, 1},
            {-1,  0, -1,  -1, 0, 0,   0, 0,-1},
            { 1,  0, -1,   1, 0, 0,   0, 0,-1},
            {-1,  0,  1,  -1, 0, 0,   0, 0, 1}
    };

    private FractureAndSolidifier() {}

    public static BlockState resolveEffectiveState(ServerWorld world, BlockPos pos) {
        ElasticSagVoxel sag = ELASTIC_PROXIES.get(pos);
        if (sag != null) return sag.realState();
        BlockState st = world.getBlockState(pos);
        if (st.isOf(Blocks.BARRIER)) {
            return Blocks.AIR.getDefaultState();
        }
        return st;
    }

    public static boolean isProtectedMetroInfrastructure(BlockPos p, BlockState st) {
        if (p.getY() < 61) return true;
        String id = Registries.BLOCK.getId(st.getBlock()).toString();
        if (id.startsWith("mtr:") || id.startsWith("arena_ai_bridge:") || st.isOf(Blocks.BEDROCK)) {
            return true;
        }
        return p.getX() >= -48 && p.getX() <= 10
                && ((p.getZ() >= -20 && p.getZ() <= 68) || (p.getZ() >= 1548 && p.getZ() <= 1612));
    }

    public static boolean isNaturalTerrainBlock(BlockState st) {
        return st.isOf(Blocks.GRASS_BLOCK) || st.isOf(Blocks.DIRT) || st.isOf(Blocks.COARSE_DIRT)
                || st.isOf(Blocks.PODZOL) || st.isOf(Blocks.ROOTED_DIRT) || st.isOf(Blocks.MYCELIUM)
                || st.isOf(Blocks.MUD) || st.isOf(Blocks.CLAY) || st.isOf(Blocks.STONE)
                || st.isOf(Blocks.DEEPSLATE) || st.isOf(Blocks.TUFF) || st.isOf(Blocks.CALCITE)
                || st.isOf(Blocks.GRANITE) || st.isOf(Blocks.DIORITE) || st.isOf(Blocks.ANDESITE)
                || st.isOf(Blocks.SAND) || st.isOf(Blocks.RED_SAND) || st.isOf(Blocks.SANDSTONE)
                || st.isOf(Blocks.RED_SANDSTONE) || st.isOf(Blocks.GRAVEL) || st.isIn(BlockTags.LEAVES)
                || st.isIn(BlockTags.COAL_ORES) || st.isIn(BlockTags.IRON_ORES) || st.isIn(BlockTags.COPPER_ORES);
    }

    public static boolean isNonStructuralAttachment(BlockState st) {
        Block b = st.getBlock();
        return b instanceof CarpetBlock || b instanceof BedBlock || b instanceof LanternBlock
                || b instanceof TorchBlock || b instanceof VineBlock || b instanceof AbstractPlantPartBlock
                || st.isIn(BlockTags.FLOWERS) || st.isIn(BlockTags.BANNERS) || st.isIn(BlockTags.SIGNS)
                || st.isIn(BlockTags.BUTTONS) || st.isIn(BlockTags.PRESSURE_PLATES);
    }

    public static boolean isStructuralCandidate(BlockPos p, BlockState st) {
        if (st == null || st.isAir() || st.isOf(Blocks.BARRIER)) return false;
        if (!st.getFluidState().isEmpty() || st.hasBlockEntity()) return false;
        return !isProtectedMetroInfrastructure(p, st) && !isNaturalTerrainBlock(st) && !isNonStructuralAttachment(st);
    }

    public static List<BlockPos> handleBlockBreakAndCollectSeeds(ServerWorld world, BlockPos pos, BlockState brokenState) {
        List<BlockPos> seeds = new ArrayList<>();

        PLASTIC_RESIDUAL_MAP.remove(pos);
        ElasticSagVoxel sagged = ELASTIC_PROXIES.remove(pos);
        if (sagged != null) {
            BlockState real = sagged.realState();
            world.playSound(null, pos, real.getSoundGroup().getBreakSound(), SoundCategory.BLOCKS, 1.0f, 0.92f);
            world.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, real),
                    pos.getX() + 0.5 + sagged.targetDx(), pos.getY() + 0.5 + sagged.targetDy(), pos.getZ() + 0.5 + sagged.targetDz(),
                    14, 0.25, 0.25, 0.25, 0.08);
        }

        wakeNearbyRubble(world, pos, 3.2);

        for (Direction d : Direction.values()) {
            BlockPos nb = pos.offset(d);
            BlockState nst = resolveEffectiveState(world, nb);
            if (isStructuralCandidate(nb, nst)) {
                seeds.add(nb.toImmutable());
            }
        }
        for (int[] dg : DIAG_12) {
            BlockPos nb = pos.add(dg[0], dg[1], dg[2]);
            BlockState nst = resolveEffectiveState(world, nb);
            if (isStructuralCandidate(nb, nst)) {
                seeds.add(nb.toImmutable());
            }
        }
        return seeds;
    }

    public static void wakeNearbyRubble(ServerWorld world, BlockPos center, double radius) {
        RigidBody6DoFDynamics.wakeBodiesNear(center, radius);
    }

    public static BlueprintRecord getOrCreateBlueprint(BlockPos pos) {
        ensureLoadedFromDisk();
        for (BlueprintRecord bp : BLUEPRINTS) {
            if (Math.abs(bp.origin.getX() - pos.getX()) <= 56 && Math.abs(bp.origin.getZ() - pos.getZ()) <= 56) {
                return bp;
            }
        }
        String id = "bp_" + pos.getX() + "_" + pos.getY() + "_" + pos.getZ();
        BlueprintRecord created = new BlueprintRecord(id, pos);
        BLUEPRINTS.add(created);
        return created;
    }

    public static BlueprintRecord findBlueprint(String id) {
        if (id != null) {
            for (BlueprintRecord bp : BLUEPRINTS) {
                if (id.equals(bp.id)) return bp;
            }
        }
        return BLUEPRINTS.isEmpty() ? null : BLUEPRINTS.get(BLUEPRINTS.size() - 1);
    }

    public static int evaluateAndCollapseStructure(
            ServerWorld world,
            BlockPos seed,
            BlockPos blastOrigin,
            double blastImpulseKn,
            Vector3d windVecMs,
            Set<BlockPos> globalVisited,
            boolean skipNaturalTrees
    ) {
        ensureLoadedFromDisk();
        ContinuousStructuralBeams.ensureLoadedFromDisk();
        if (!world.isChunkLoaded(seed.getX() >> 4, seed.getZ() >> 4)) return 0;
        BlockState seedSt = resolveEffectiveState(world, seed);
        if (!isStructuralCandidate(seed, seedSt)) {
            return 0;
        }

        // 1. Extract 18-connected structural graph (works seamlessly across both world blocks AND curved ELASTIC_PROXIES!)
        Set<BlockPos> componentSet = new LinkedHashSet<>();
        ArrayDeque<BlockPos> queue = new ArrayDeque<>();
        BlockPos immSeed = seed.toImmutable();
        componentSet.add(immSeed);
        queue.add(immSeed);

        boolean touchesLeaves = false;
        boolean hasManufacturedBlock = false;

        while (!queue.isEmpty() && componentSet.size() < 3200) {
            BlockPos cur = queue.poll();
            BlockState cst = resolveEffectiveState(world, cur);
            if (!cst.isIn(BlockTags.LOGS)) hasManufacturedBlock = true;

            for (Direction d : Direction.values()) {
                BlockPos nb = cur.offset(d);
                if (Math.abs(nb.getX() - seed.getX()) > 52 || Math.abs(nb.getZ() - seed.getZ()) > 52) continue;
                if (nb.getY() < 58 || nb.getY() >= world.getTopY() - 1) continue;
                if (componentSet.contains(nb)) continue;
                if (!world.isChunkLoaded(nb.getX() >> 4, nb.getZ() >> 4)) continue;

                BlockState rawNb = world.getBlockState(nb);
                if (rawNb.isIn(BlockTags.LEAVES)) {
                    touchesLeaves = true;
                    continue;
                }
                BlockState nst = resolveEffectiveState(world, nb);
                if (!isStructuralCandidate(nb, nst)) continue;

                BlockPos imm = nb.toImmutable();
                componentSet.add(imm);
                queue.add(imm);
            }

            for (int[] dg : DIAG_12) {
                BlockPos nb = cur.add(dg[0], dg[1], dg[2]);
                if (Math.abs(nb.getX() - seed.getX()) > 52 || Math.abs(nb.getZ() - seed.getZ()) > 52) continue;
                if (nb.getY() < 58 || nb.getY() >= world.getTopY() - 1) continue;
                if (componentSet.contains(nb)) continue;
                if (!world.isChunkLoaded(nb.getX() >> 4, nb.getZ() >> 4)) continue;

                BlockState nst = resolveEffectiveState(world, nb);
                if (!isStructuralCandidate(nb, nst)) continue;

                BlockPos imm = nb.toImmutable();
                componentSet.add(imm);
                queue.add(imm);
            }
        }

        if (globalVisited != null) globalVisited.addAll(componentSet);
        if (componentSet.isEmpty()) return 0;
        if (skipNaturalTrees && touchesLeaves && !hasManufacturedBlock) {
            return 0;
        }

        int n = componentSet.size();
        List<BlockPos> positions = new ArrayList<>(componentSet);
        List<BlockState> states = new ArrayList<>(n);
        boolean[] grounded = new boolean[n];
        double[] extLoadsKn = new double[n * 3];

        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE, maxZ = Integer.MIN_VALUE;

        Map<BlockPos, Integer> posToIdx = new HashMap<>(n * 2);
        for (int i = 0; i < n; i++) {
            BlockPos p = positions.get(i);
            posToIdx.put(p, i);
            BlockState st = resolveEffectiveState(world, p);
            states.add(st);

            minX = Math.min(minX, p.getX()); maxX = Math.max(maxX, p.getX());
            minY = Math.min(minY, p.getY()); maxY = Math.max(maxY, p.getY());
            minZ = Math.min(minZ, p.getZ()); maxZ = Math.max(maxZ, p.getZ());

            boolean supDown = ConstitutiveMaterialDB.isTrueSolidTerrainFoundation(world, p.down(), componentSet);
            boolean supBank = false;
            if (!supDown) {
                for (Direction hd : Direction.Type.HORIZONTAL) {
                    BlockPos side = p.offset(hd);
                    if (ConstitutiveMaterialDB.isTrueSolidTerrainFoundation(world, side, componentSet)
                            && ConstitutiveMaterialDB.isTrueSolidTerrainFoundation(world, side.down(), componentSet)) {
                        supBank = true;
                        break;
                    }
                    BlockPos diagFoot = p.offset(hd).down();
                    if (ConstitutiveMaterialDB.isTrueSolidTerrainFoundation(world, diagFoot, componentSet)
                            && ConstitutiveMaterialDB.isTrueSolidTerrainFoundation(world, side, componentSet)) {
                        supBank = true;
                        break;
                    }
                }
            }
            grounded[i] = supDown || supBank;

            if (windVecMs != null && (Math.abs(windVecMs.x) > 0.5 || Math.abs(windVecMs.z) > 0.5)) {
                double qWindKpa = 0.0006125 * (windVecMs.x * windVecMs.x + windVecMs.z * windVecMs.z);
                extLoadsKn[i * 3]     += qWindKpa * Math.signum(windVecMs.x);
                extLoadsKn[i * 3 + 2] += qWindKpa * Math.signum(windVecMs.z);
            }

            if (blastOrigin != null && blastImpulseKn > 0.0) {
                double dx = (p.getX() + 0.5) - (blastOrigin.getX() + 0.5);
                double dy = (p.getY() + 0.5) - (blastOrigin.getY() + 0.5);
                double dz = (p.getZ() + 0.5) - (blastOrigin.getZ() + 0.5);
                double r2 = dx * dx + dy * dy + dz * dz;
                double r = Math.max(0.75, Math.sqrt(r2));
                double fBlast = blastImpulseKn / (1.0 + 0.35 * r2);
                extLoadsKn[i * 3]     += (dx / r) * fBlast;
                extLoadsKn[i * 3 + 1] += (dy / r) * fBlast * 0.65;
                extLoadsKn[i * 3 + 2] += (dz / r) * fBlast;
            }
        }

        // Couple any Non-Grid Continuous 3D Structural Beams / Inclined Columns touching this structure!
        List<ContinuousBeam> connectedBeams = ContinuousStructuralBeams.findConnectedBeams(componentSet);
        List<ExternalBeamAttachment> beamSpecs = new ArrayList<>(connectedBeams.size());
        for (ContinuousBeam cb : connectedBeams) {
            int nodeA = ContinuousStructuralBeams.findNearestNodeIndex(cb.ax, cb.ay, cb.az, positions, posToIdx);
            int nodeB = ContinuousStructuralBeams.findNearestNodeIndex(cb.bx, cb.by, cb.bz, positions, posToIdx);
            boolean groundA = (nodeA < 0) && ContinuousStructuralBeams.isEndpointGroundedInTerrain(world, cb.ax, cb.ay, cb.az, componentSet);
            boolean groundB = (nodeB < 0) && ContinuousStructuralBeams.isEndpointGroundedInTerrain(world, cb.bx, cb.by, cb.bz, componentSet);
            beamSpecs.add(new ExternalBeamAttachment(cb, nodeA, groundA, nodeB, groundB));
        }

        Box entityScanBox = new Box(minX - 1, minY - 2, minZ - 1, maxX + 2, maxY + 3.0, maxZ + 2);
        for (Entity ent : world.getOtherEntities(null, entityScanBox)) {
            if (!(ent instanceof LivingEntity) || ent.isSpectator()) continue;
            double massKg = (ent instanceof IronGolemEntity) ? 950.0 : ((ent instanceof PlayerEntity) ? 85.0 : 75.0);
            BlockPos under = BlockPos.ofFloored(ent.getX(), ent.getY() - 0.35, ent.getZ());
            Integer idx = posToIdx.get(under);
            if (idx == null) idx = posToIdx.get(under.up());
            if (idx != null) {
                extLoadsKn[idx * 3 + 1] -= (massKg * 9.80665) * 1.0e-3;
            }
        }

        long femStartNs = System.nanoTime();
        FEMSolveReport report = VoxelFrameFEMSolver.solveStructure(positions, states, grounded, extLoadsKn, beamSpecs);
        lastFemSolveMs = Math.round(((System.nanoTime() - femStartNs) * 1.0e-6) * 1000.0) / 1000.0;
        if (positions.size() >= 8 || report.maxStressRatioBeforeCollapse() >= 1.0) {
            lastPeakStressRatio = Math.round(report.maxStressRatioBeforeCollapse() * 1000.0) / 1000.0;
        }

        BlueprintRecord bp = getOrCreateBlueprint(seed);

        // Detach any continuous inclined columns that buckled even if the main structure partially survived
        for (ExternalBeamAttachment eb : beamSpecs) {
            ContinuousBeam cb = eb.beam();
            if (report.buckledBeamIds().contains(cb.id)) {
                ContinuousStructuralBeams.ACTIVE_BEAMS.remove(cb);
                Vec3d mid = cb.sampleDeformedPoint(0.5);
                world.playSound(null, BlockPos.ofFloored(mid.x, mid.y, mid.z),
                        cb.materialState.getSoundGroup().getBreakSound(), SoundCategory.BLOCKS, 1.25f, 0.65f);
                world.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, cb.materialState),
                        mid.x, mid.y, mid.z, 22, 0.35, 0.35, 0.35, 0.08);
                spawnClusterWithCap(RigidBody6DoFDynamics.createFromContinuousBeam(
                        bp.id, cb, new Vector3d(0.0, -0.35, 0.0), new Vector3d(0.25, 0.0, 0.35)));
            }
        }

        // CASE A: Structure SURVIVES -> Apply Smooth Continuous Curvature ("Sürekli Eğrilik") with ZERO Blocks.BARRIER!
        if (report.detachedFragments().isEmpty()) {
            applyOrRestoreSmoothCurvature(world, bp, positions, states, grounded, posToIdx, beamSpecs, report);
            return 0;
        }

        // CASE B: Structure TOPPLES / FRACTURES -> Spawn EACH connected fragment as ONE SINGLE MONOLITHIC 3D RIGID BODY!
        // (ZERO 72-block or 8x8 grid slicing — an intact house ALWAYS topples as ONE whole building!)
        for (int i = 0; i < n; i++) {
            bp.originalStates.putIfAbsent(positions.get(i), states.get(i));
        }

        for (BlockPos fp : report.fracturedFacePositions()) {
            BlockState fst = resolveEffectiveState(world, fp);
            if (!fst.isAir()) {
                world.playSound(null, fp, fst.getSoundGroup().getBreakSound(), SoundCategory.BLOCKS, 1.2f, 0.66f);
                world.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, fst),
                        fp.getX() + 0.5, fp.getY() + 0.5, fp.getZ() + 0.5, 10, 0.25, 0.25, 0.25, 0.06);
            }
        }

        Set<Integer> detachedSet = new HashSet<>();
        int totalDetachedVoxels = 0;
        int spawnedClusters = 0;

        for (DetachedFragment frag : report.detachedFragments()) {
            List<Integer> idxs = frag.nodeIndices();
            if (idxs.isEmpty()) continue;
            totalDetachedVoxels += idxs.size();
            detachedSet.addAll(idxs);

            List<BlockPos> fPos = new ArrayList<>(idxs.size());
            List<BlockState> fSt = new ArrayList<>(idxs.size());
            Set<Integer> fragNodeSet = new HashSet<>(idxs);

            for (int nodeIdx : idxs) {
                BlockPos p = positions.get(nodeIdx);
                ELASTIC_PROXIES.remove(p);
                PLASTIC_RESIDUAL_MAP.remove(p);
                BlockPos above = p.up();
                BlockState aboveSt = world.getBlockState(above);
                if (isNonStructuralAttachment(aboveSt)) {
                    bp.originalStates.putIfAbsent(above, aboveSt);
                    world.setBlockState(above, Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
                }
                world.setBlockState(p, Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
                fPos.add(p);
                fSt.add(states.get(nodeIdx));
            }

            RigidCluster6DoF monoBody = RigidBody6DoFDynamics.createFromWorldVoxels(
                    bp.id, fPos, fSt, frag.initialLinearVel(), frag.initialAngularVel()
            );

            // Any surviving continuous beams attached solely to this toppling building ride with it or detach cleanly!
            for (ExternalBeamAttachment eb : beamSpecs) {
                ContinuousBeam cb = eb.beam();
                if (!ContinuousStructuralBeams.ACTIVE_BEAMS.contains(cb)) continue;
                boolean aIn = eb.nodeA() >= 0 && fragNodeSet.contains(eb.nodeA());
                boolean bIn = eb.nodeB() >= 0 && fragNodeSet.contains(eb.nodeB());
                if (aIn && bIn) {
                    ContinuousStructuralBeams.ACTIVE_BEAMS.remove(cb);
                    monoBody.attachedBeams.add(ContinuousStructuralBeams.toDetachedLocal(cb, monoBody.px, monoBody.py, monoBody.pz));
                } else if (aIn || bIn) {
                    ContinuousStructuralBeams.ACTIVE_BEAMS.remove(cb);
                    spawnClusterWithCap(RigidBody6DoFDynamics.createFromContinuousBeam(
                            bp.id, cb, frag.initialLinearVel(), frag.initialAngularVel()));
                }
            }

            spawnClusterWithCap(monoBody);
            spawnedClusters++;
        }

        // Restore any surviving grounded remnant blocks back to real blocks cleanly
        for (int i = 0; i < n; i++) {
            if (!detachedSet.contains(i)) {
                BlockPos sp = positions.get(i);
                PLASTIC_RESIDUAL_MAP.remove(sp);
                ElasticSagVoxel oldSag = ELASTIC_PROXIES.remove(sp);
                if (oldSag != null && world.getBlockState(sp).isAir()) {
                    restoreBlockSafelyLiftingPlayers(world, sp, oldSag.realState(), Block.NOTIFY_LISTENERS);
                }
            }
        }

        lastDetachedBlocks = totalDetachedVoxels;
        saveBlueprintsToDisk();

        String primaryReason = report.detachedFragments().get(0).failureMode();
        GeoStructuralPhysicsEngine.ACTIVE_ALERTS.removeIf(a -> a.id.startsWith("fem_"));
        GeoStructuralPhysicsEngine.ACTIVE_ALERTS.add(0, new GeoStructuralPhysicsEngine.StructuralAlert(
                "fem_" + seed.getX() + "_" + seed.getZ(),
                primaryReason,
                String.format(Locale.US, "Monolitik 6-DoF Devrilme [%s, σ/σ_allow=%.2f]: %d blok (%d bütün gövde) devrildi — /onar ile geri sar",
                        primaryReason, report.maxStressRatioBeforeCollapse(), totalDetachedVoxels, spawnedClusters),
                seed, 0.95
        ));

        return totalDetachedVoxels;
    }

    /**
     * Smooth Continuous Structural Curvature ("Bloksuz Sürekli Eğrilik"):
     * Replaces integer grid blocks with AIR (ZERO Blocks.BARRIER!) while ContinuousOBBHitboxEngine
     * provides exact curved 3D hitboxes & ProPhysicsRenderer renders a continuous smooth arch
     * where every cross-section translates AND tilts along the exact tangent derivative dw/dx!
     */
    private static void restoreBlockSafelyLiftingPlayers(ServerWorld world, BlockPos p, BlockState realState, int flags) {
        // Lift any player or entity whose feet were resting on the sagged OBB (below p.getY() + 1.0)
        // BEFORE placing the solid 1x1x1 block back, so nobody ever gets buried inside or falls through the floor!
        Box checkBox = new Box(p.getX() - 0.32, p.getY() - 0.45, p.getZ() - 0.32,
                p.getX() + 1.32, p.getY() + 1.04, p.getZ() + 1.32);
        for (Entity ent : world.getOtherEntities(null, checkBox)) {
            if (ent.isSpectator()) continue;
            if (ent.getY() >= p.getY() - 0.45 && ent.getY() < p.getY() + 1.005) {
                double safeY = p.getY() + 1.015;
                if (ent instanceof ServerPlayerEntity sp) {
                    sp.requestTeleport(sp.getX(), safeY, sp.getZ());
                } else {
                    ent.setPosition(ent.getX(), safeY, ent.getZ());
                }
                Vec3d v = ent.getVelocity();
                if (v.y < 0.0) {
                    ent.setVelocity(v.x, 0.0, v.z);
                    ent.velocityModified = true;
                }
                ent.fallDistance = 0.0f;
            }
        }
        world.setBlockState(p, realState, flags);
    }

    private static void capturePreDeformLights(ServerWorld world, BlockPos p, ElasticSagVoxel existing, int[] outBlk, int[] outSky) {
        if (existing != null && existing.faceBlockLight() != null && existing.faceSkyLight() != null
                && existing.faceBlockLight().length == 6 && existing.faceSkyLight().length == 6) {
            System.arraycopy(existing.faceBlockLight(), 0, outBlk, 0, 6);
            System.arraycopy(existing.faceSkyLight(), 0, outSky, 0, 6);
            return;
        }
        Direction[] dirs = Direction.values();
        for (int d = 0; d < 6; d++) {
            BlockPos adj = p.offset(dirs[d]);
            outBlk[d] = world.getLightLevel(LightType.BLOCK, adj);
            outSky[d] = world.getLightLevel(LightType.SKY, adj);
        }
    }

    private static void applyOrRestoreSmoothCurvature(
            ServerWorld world,
            BlueprintRecord bp,
            List<BlockPos> positions,
            List<BlockState> states,
            boolean[] grounded,
            Map<BlockPos, Integer> posToIdx,
            List<ExternalBeamAttachment> beamSpecs,
            FEMSolveReport report
    ) {
        double peakUtil = report.maxStressRatioBeforeCollapse();
        int n = positions.size();
        double[] u = report.nodalDisplacements();

        // Pre-capture exact per-face chunk lighting BEFORE any world.setBlockState(p, AIR) removes roof/wall shadow occlusion!
        int[][] preBlk = new int[n][6];
        int[][] preSky = new int[n][6];
        for (int i = 0; i < n; i++) {
            BlockPos p = positions.get(i);
            capturePreDeformLights(world, p, ELASTIC_PROXIES.get(p), preBlk[i], preSky[i]);
        }

        if (peakUtil < 0.68 || u == null || u.length < n * 6) {
            boolean hasPlasticSet = false;
            for (int i = 0; i < n; i++) {
                double[] res = PLASTIC_RESIDUAL_MAP.get(positions.get(i));
                if (res != null && (Math.abs(res[0]) + Math.abs(res[1]) + Math.abs(res[2])) >= 0.020) {
                    hasPlasticSet = true;
                    break;
                }
            }

            if (hasPlasticSet) {
                // Retain permanent elasto-plastic residual curvature ("kalıcı eğrilik" — house does NOT reset/snap to zero!)
                for (int i = 0; i < n; i++) {
                    BlockPos p = positions.get(i);
                    BlockState st = states.get(i);
                    double[] res = PLASTIC_RESIDUAL_MAP.get(p);
                    if (grounded[i] || res == null || (Math.abs(res[0]) + Math.abs(res[1]) + Math.abs(res[2])) < 0.014) {
                        ElasticSagVoxel prev = ELASTIC_PROXIES.remove(p);
                        if (prev != null && world.getBlockState(p).isAir()) {
                            restoreBlockSafelyLiftingPlayers(world, p, prev.realState(), Block.NOTIFY_LISTENERS);
                        }
                        continue;
                    }
                    bp.originalStates.putIfAbsent(p, st);
                    ELASTIC_PROXIES.put(p, new ElasticSagVoxel(
                            p, st, res[0], res[1], res[2],
                            (float) res[3], (float) res[4], (float) res[5],
                            peakUtil, preBlk[i], preSky[i]));
                    if (!world.getBlockState(p).isAir()) {
                        world.setBlockState(p, Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
                    }
                }
                for (ExternalBeamAttachment eb : beamSpecs) {
                    ContinuousBeam cb = eb.beam();
                    double[] rA = (eb.nodeA() >= 0 && eb.nodeA() < n) ? PLASTIC_RESIDUAL_MAP.get(positions.get(eb.nodeA())) : null;
                    double[] rB = (eb.nodeB() >= 0 && eb.nodeB() < n) ? PLASTIC_RESIDUAL_MAP.get(positions.get(eb.nodeB())) : null;
                    cb.dispAx = rA != null ? rA[0] : 0.0; cb.dispAy = rA != null ? rA[1] : 0.0; cb.dispAz = rA != null ? rA[2] : 0.0;
                    cb.dispBx = rB != null ? rB[0] : 0.0; cb.dispBy = rB != null ? rB[1] : 0.0; cb.dispBz = rB != null ? rB[2] : 0.0;
                    cb.lateralBowM *= 0.55;
                }
                return;
            }

            for (int i = 0; i < n; i++) {
                BlockPos p = positions.get(i);
                ElasticSagVoxel prev = ELASTIC_PROXIES.remove(p);
                if (prev != null && world.getBlockState(p).isAir()) {
                    restoreBlockSafelyLiftingPlayers(world, p, prev.realState(), Block.NOTIFY_LISTENERS);
                }
            }
            for (ExternalBeamAttachment eb : beamSpecs) {
                ContinuousBeam cb = eb.beam();
                cb.dispAx = cb.dispAy = cb.dispAz = 0.0;
                cb.dispBx = cb.dispBy = cb.dispBz = 0.0;
                cb.lateralBowM = 0.0;
            }
            return;
        }

        int minX = Integer.MAX_VALUE, maxX = Integer.MIN_VALUE;
        int minZ = Integer.MAX_VALUE, maxZ = Integer.MIN_VALUE;
        double maxRawDisp = 0.0;
        for (int i = 0; i < n; i++) {
            BlockPos p = positions.get(i);
            minX = Math.min(minX, p.getX()); maxX = Math.max(maxX, p.getX());
            minZ = Math.min(minZ, p.getZ()); maxZ = Math.max(maxZ, p.getZ());
            if (grounded[i]) continue;
            double mag = Math.sqrt(u[i * 6] * u[i * 6] + u[i * 6 + 1] * u[i * 6 + 1] + u[i * 6 + 2] * u[i * 6 + 2]);
            if (mag > maxRawDisp) maxRawDisp = mag;
        }
        if (maxRawDisp < 1.0e-7) return;

        // Scale smooth curvature naturally with both stress ratio AND structural span length!
        double spanM = Math.max(3.0, Math.hypot(maxX - minX + 1, maxZ - minZ + 1));
        double spanScale = MathHelper.clamp(spanM / 7.5, 0.65, 1.85);
        double excess = MathHelper.clamp((peakUtil - 0.68) / 0.32, 0.0, 1.0);
        double targetPeakSagMeters = (0.06 + 0.56 * (excess * 0.45 + excess * excess * 0.55)) * spanScale;
        double dispGain = targetPeakSagMeters / maxRawDisp;

        double[] scaledDx = new double[n];
        double[] scaledDy = new double[n];
        double[] scaledDz = new double[n];
        for (int i = 0; i < n; i++) {
            if (grounded[i]) continue;
            scaledDx[i] = MathHelper.clamp(u[i * 6]     * dispGain, -0.65, 0.65);
            scaledDy[i] = MathHelper.clamp(u[i * 6 + 1] * dispGain, -1.15, 0.45);
            scaledDz[i] = MathHelper.clamp(u[i * 6 + 2] * dispGain, -0.65, 0.65);
        }

        boolean playedCreak = false;

        for (int i = 0; i < n; i++) {
            BlockPos p = positions.get(i);
            BlockState st = states.get(i);
            double dx = scaledDx[i], dy = scaledDy[i], dz = scaledDz[i];

            double slopeX = sampleVerticalSlopeAlongAxis(p, dy, 1, 0, posToIdx, scaledDy);
            double slopeZ = sampleVerticalSlopeAlongAxis(p, dy, 0, 1, posToIdx, scaledDy);
            float rz = (float) MathHelper.clamp(Math.atan(slopeX), -0.38, 0.38);
            float rx = (float) MathHelper.clamp(-Math.atan(slopeZ), -0.38, 0.38);
            float ry = 0.0f;

            Integer floorBelow = posToIdx.get(p.down());
            if (floorBelow != null && Math.abs(rz) > 0.01f) {
                dx -= Math.sin(rz) * 0.12;
            }

            double[] oldRes = PLASTIC_RESIDUAL_MAP.get(p);
            if (oldRes != null && Math.abs(oldRes[1]) > Math.abs(dy)) {
                dx = oldRes[0]; dy = oldRes[1]; dz = oldRes[2];
                rx = (float) oldRes[3]; ry = (float) oldRes[4]; rz = (float) oldRes[5];
            }
            double pFactor = 0.55;
            double candDy = dy * pFactor;
            if (oldRes == null || Math.abs(candDy) > Math.abs(oldRes[1])) {
                PLASTIC_RESIDUAL_MAP.put(p, new double[]{ dx * pFactor, candDy, dz * pFactor, rx * pFactor, ry * pFactor, rz * pFactor });
            }

            double totalMotion = Math.sqrt(dx * dx + dy * dy + dz * dz) + Math.hypot(rx, rz) * 0.5;
            if (grounded[i] || totalMotion < 0.014) {
                ElasticSagVoxel prev = ELASTIC_PROXIES.remove(p);
                if (prev != null && world.getBlockState(p).isAir()) {
                    restoreBlockSafelyLiftingPlayers(world, p, prev.realState(), Block.NOTIFY_LISTENERS);
                }
                continue;
            }

            bp.originalStates.putIfAbsent(p, st);
            ElasticSagVoxel prev = ELASTIC_PROXIES.get(p);
            if (!playedCreak && (prev == null || Math.abs(dy - prev.targetDy) > 0.05) && peakUtil >= 0.55) {
                playedCreak = true;
                boolean wood = st.isIn(BlockTags.PLANKS) || st.isIn(BlockTags.LOGS) || st.isIn(BlockTags.WOODEN_FENCES);
                world.playSound(null, p, wood ? SoundEvents.BLOCK_CHEST_CLOSE : SoundEvents.BLOCK_STONE_STEP,
                        SoundCategory.BLOCKS, 0.9f, wood ? 0.50f : 0.56f);
            }

            ELASTIC_PROXIES.put(p, new ElasticSagVoxel(p, st, dx, dy, dz, rx, ry, rz, peakUtil, preBlk[i], preSky[i]));
            if (!world.getBlockState(p).isAir()) {
                world.setBlockState(p, Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
            }
        }

        // Synchronize Continuous 3D Inclined Columns / Beams with the exact deformed attachment displacements!
        for (ExternalBeamAttachment eb : beamSpecs) {
            ContinuousBeam cb = eb.beam();
            if (eb.nodeA() >= 0 && eb.nodeA() < n) {
                cb.dispAx = scaledDx[eb.nodeA()];
                cb.dispAy = scaledDy[eb.nodeA()];
                cb.dispAz = scaledDz[eb.nodeA()];
            } else {
                cb.dispAx = cb.dispAy = cb.dispAz = 0.0;
            }
            if (eb.nodeB() >= 0 && eb.nodeB() < n) {
                cb.dispBx = scaledDx[eb.nodeB()];
                cb.dispBy = scaledDy[eb.nodeB()];
                cb.dispBz = scaledDz[eb.nodeB()];
            } else {
                cb.dispBx = cb.dispBy = cb.dispBz = 0.0;
            }
            // Subtle realistic Euler compressive mid-span bow when column utilization > 55%
            double uCol = cb.currentUtilization;
            cb.lateralBowM = (uCol > 0.55) ? -0.14 * MathHelper.clamp((uCol - 0.55) / 0.45, 0.0, 1.0) : 0.0;
        }
    }

    private static double sampleVerticalSlopeAlongAxis(
            BlockPos p, double dyCenter, int stepX, int stepZ,
            Map<BlockPos, Integer> posToIdx, double[] scaledDy
    ) {
        Integer iPlus  = posToIdx.get(p.add(stepX, 0, stepZ));
        Integer iMinus = posToIdx.get(p.add(-stepX, 0, -stepZ));
        if (iPlus != null && iMinus != null) {
            return 0.5 * (scaledDy[iPlus] - scaledDy[iMinus]);
        } else if (iPlus != null) {
            return scaledDy[iPlus] - dyCenter;
        } else if (iMinus != null) {
            return dyCenter - scaledDy[iMinus];
        }
        // Check 1 block below (so walls/railings inherit the exact slope of the floor girder beneath them!)
        Integer fPlus  = posToIdx.get(p.add(stepX, -1, stepZ));
        Integer fMinus = posToIdx.get(p.add(-stepX, -1, -stepZ));
        if (fPlus != null && fMinus != null) {
            return 0.5 * (scaledDy[fPlus] - scaledDy[fMinus]);
        }
        return 0.0;
    }

    public static String triggerExplosionWithFEM(ServerWorld world, BlockPos blastPos, double coreRadius, Vector3d windVecMs) {
        ensureLoadedFromDisk();
        world.playSound(null, blastPos, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.BLOCKS, 1.45f, 0.78f);
        world.spawnParticles(ParticleTypes.EXPLOSION_EMITTER,
                blastPos.getX() + 0.5, blastPos.getY() + 0.5, blastPos.getZ() + 0.5, 1, 0.2, 0.2, 0.2, 0.0);

        wakeNearbyRubble(world, blastPos, coreRadius * 2.8);

        Vec3d blastCenter = Vec3d.ofCenter(blastPos);
        for (Entity ent : world.getOtherEntities(null, new Box(blastPos).expand(coreRadius * 2.4))) {
            if (ent instanceof PlayerEntity pe && (pe.isCreative() || pe.isSpectator())) continue;
            double dist = Math.max(1.0, ent.getPos().distanceTo(blastCenter));
            if (dist <= coreRadius * 2.4) {
                Vec3d dir = ent.getPos().subtract(blastCenter).normalize();
                double imp = (2.0 * coreRadius) / (dist * dist * 0.45 + 1.0);
                ent.addVelocity(dir.x * imp, Math.min(1.0, 0.30 + imp * 0.40), dir.z * imp);
                ent.velocityModified = true;
            }
        }

        // Sever any continuous beams caught inside blast core
        for (ContinuousBeam cb : new ArrayList<>(ContinuousStructuralBeams.ACTIVE_BEAMS)) {
            if (cb.sampleDeformedPoint(0.5).distanceTo(blastCenter) <= coreRadius * 1.15) {
                ContinuousStructuralBeams.ACTIVE_BEAMS.remove(cb);
                spawnClusterWithCap(RigidBody6DoFDynamics.createFromContinuousBeam(
                        "blast", cb, new Vector3d(0.0, 2.2, 0.0), new Vector3d(1.5, 0.8, 1.2)));
            }
        }

        BlueprintRecord bp = getOrCreateBlueprint(blastPos);
        int rInt = (int) Math.ceil(coreRadius);
        Set<BlockPos> survivorSeeds = new LinkedHashSet<>();
        List<BlockPos> corePositions = new ArrayList<>();
        List<BlockState> coreStates = new ArrayList<>();

        for (int dx = -rInt - 1; dx <= rInt + 1; dx++) {
            for (int dy = -rInt - 1; dy <= rInt + 1; dy++) {
                for (int dz = -rInt - 1; dz <= rInt + 1; dz++) {
                    BlockPos p = blastPos.add(dx, dy, dz);
                    if (p.getY() < 61 || !world.isChunkLoaded(p.getX() >> 4, p.getZ() >> 4)) continue;

                    BlockState st = resolveEffectiveState(world, p);
                    if (st.isAir() || !st.getFluidState().isEmpty() || isProtectedMetroInfrastructure(p, st)) continue;

                    double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
                    if (d <= coreRadius * 0.88) {
                        bp.originalStates.putIfAbsent(p, st);
                        ELASTIC_PROXIES.remove(p);
                        world.setBlockState(p, Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
                        if (!st.isOf(Blocks.TNT) && !isNonStructuralAttachment(st)) {
                            corePositions.add(p);
                            coreStates.add(st);
                        }
                    } else if (!isNaturalTerrainBlock(st) && !isNonStructuralAttachment(st)) {
                        survivorSeeds.add(p.toImmutable());
                    }
                }
            }
        }

        int launchedCore = 0;
        for (int i = 0; i < corePositions.size(); i += 2) {
            int end = Math.min(corePositions.size(), i + 2);
            List<BlockPos> subP = corePositions.subList(i, end);
            List<BlockState> subS = coreStates.subList(i, end);
            BlockPos ref = subP.get(0);
            double vx = (ref.getX() + 0.5) - (blastPos.getX() + 0.5);
            double vy = (ref.getY() + 0.5) - (blastPos.getY() + 0.5);
            double vz = (ref.getZ() + 0.5) - (blastPos.getZ() + 0.5);
            double len = Math.max(0.6, Math.sqrt(vx * vx + vy * vy + vz * vz));
            double speed = Math.min(9.5, (5.2 * coreRadius) / (len + 0.5));
            Vector3d v0 = new Vector3d((vx / len) * speed, Math.max(1.8, (vy / len) * speed + 2.4), (vz / len) * speed);
            Vector3d w0 = new Vector3d((world.random.nextDouble() - 0.5) * 4.5,
                    (world.random.nextDouble() - 0.5) * 4.5,
                    (world.random.nextDouble() - 0.5) * 4.5);
            spawnClusterWithCap(RigidBody6DoFDynamics.createFromWorldVoxels(bp.id, subP, subS, v0, w0));
            launchedCore += subP.size();
        }

        Set<BlockPos> visited = new HashSet<>();
        double impulseKn = 185.0 * coreRadius;
        int femCollapsed = 0;
        for (BlockPos seed : survivorSeeds) {
            if (!visited.contains(seed)) {
                femCollapsed += evaluateAndCollapseStructure(world, seed, blastPos, impulseKn, windVecMs, visited, false);
            }
        }

        saveBlueprintsToDisk();
        return String.format(Locale.US, "6-DoF FEM Patlama: %d çekirdek + %d yapısal blok devrildi", launchedCore, femCollapsed);
    }

    private static void spawnClusterWithCap(RigidCluster6DoF cluster) {
        while (RigidBody6DoFDynamics.ACTIVE_BODIES.size() >= RigidBody6DoFDynamics.MAX_ACTIVE_BODIES) {
            RigidBody6DoFDynamics.ACTIVE_BODIES.remove(0);
        }
        RigidBody6DoFDynamics.ACTIVE_BODIES.add(cluster);
    }

    /**
     * BARRIER-Free Persistent 3D Rubble:
     * ContinuousOBBHitboxEngine provides exact tilted 3D OBB collision & per-piece breaking
     * directly from `ACTIVE_BODIES` — ZERO `Blocks.BARRIER` cubes are ever placed in the world!
     */
    public static void solidifyBodyInWorld(ServerWorld world, RigidCluster6DoF body) {
        saveBlueprintsToDisk();
    }

    public static void rewindAllBlueprints(ServerWorld world) {
        ensureLoadedFromDisk();
        RigidBody6DoFDynamics.ACTIVE_BODIES.clear();
        ContinuousStructuralBeams.rewindAllDetachedBeams();

        for (BlockPos rp : RUBBLE_BARRIER_OWNER.keySet()) {
            if (world.isChunkLoaded(rp.getX() >> 4, rp.getZ() >> 4) && world.getBlockState(rp).isOf(Blocks.BARRIER)) {
                world.setBlockState(rp, Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
            }
        }
        RUBBLE_BARRIER_OWNER.clear();

        for (Map.Entry<BlockPos, ElasticSagVoxel> e : ELASTIC_PROXIES.entrySet()) {
            BlockPos p = e.getKey();
            if (world.isChunkLoaded(p.getX() >> 4, p.getZ() >> 4)) {
                restoreBlockSafelyLiftingPlayers(world, p, e.getValue().realState(), Block.NOTIFY_ALL);
            }
        }
        ELASTIC_PROXIES.clear();
        PLASTIC_RESIDUAL_MAP.clear();

        for (BlockPos rp : GLOBAL_DEPOSITED_RUBBLE) {
            if (world.isChunkLoaded(rp.getX() >> 4, rp.getZ() >> 4)) {
                restoreWaterOrAirAtRubblePos(world, rp);
            }
        }
        GLOBAL_DEPOSITED_RUBBLE.clear();

        for (BlueprintRecord bp : BLUEPRINTS) {
            for (BlockPos rp : bp.depositedRubble) {
                if (world.isChunkLoaded(rp.getX() >> 4, rp.getZ() >> 4)) {
                    restoreWaterOrAirAtRubblePos(world, rp);
                }
            }
            List<Map.Entry<BlockPos, BlockState>> entries = new ArrayList<>(bp.originalStates.entrySet());
            entries.sort(Comparator.comparingInt(e -> e.getKey().getY()));
            for (Map.Entry<BlockPos, BlockState> e : entries) {
                BlockPos p = e.getKey();
                if (world.isChunkLoaded(p.getX() >> 4, p.getZ() >> 4)) {
                    restoreBlockSafelyLiftingPlayers(world, p, e.getValue(), Block.NOTIFY_ALL);
                }
            }
        }
        BLUEPRINTS.clear();
        saveBlueprintsToDisk();
    }

    /**
     * Repairs all curved/plastically-bent structures, collapsed 3D rigid-body rubble, and detached
     * continuous 3D columns/beams within `radius` meters of `center` (powers `/onar` and `/onar hepsi`!).
     */
    public static synchronized int repairStructuresNear(ServerWorld world, BlockPos center, double radius) {
        ensureLoadedFromDisk();
        double r2 = radius * radius;
        int restoredCount = 0;

        // 1. Remove fallen 3D rigid bodies within radius
        List<RigidCluster6DoF> removedBodies = new ArrayList<>();
        for (RigidCluster6DoF b : RigidBody6DoFDynamics.ACTIVE_BODIES) {
            double dx = b.px - (center.getX() + 0.5);
            double dy = b.py - (center.getY() + 0.5);
            double dz = b.pz - (center.getZ() + 0.5);
            if (dx * dx + dy * dy + dz * dz <= r2) {
                removedBodies.add(b);
                restoredCount += Math.max(1, b.voxels.size());
            }
        }
        RigidBody6DoFDynamics.ACTIVE_BODIES.removeAll(removedBodies);

        // 2. Restore curved / plastically-bent blocks (`ELASTIC_PROXIES` + `PLASTIC_RESIDUAL_MAP`) within radius
        for (Map.Entry<BlockPos, ElasticSagVoxel> e : new ArrayList<>(ELASTIC_PROXIES.entrySet())) {
            BlockPos p = e.getKey();
            if (p.getSquaredDistance(center) <= r2) {
                ELASTIC_PROXIES.remove(p);
                PLASTIC_RESIDUAL_MAP.remove(p);
                if (world.isChunkLoaded(p.getX() >> 4, p.getZ() >> 4)) {
                    restoreBlockSafelyLiftingPlayers(world, p, e.getValue().realState(), Block.NOTIFY_ALL);
                    restoredCount++;
                }
            }
        }
        PLASTIC_RESIDUAL_MAP.keySet().removeIf(p -> p.getSquaredDistance(center) <= r2);

        // 3. Rewind structural blueprints whose origin or blocks lie within radius
        List<BlueprintRecord> rewoundBps = new ArrayList<>();
        for (BlueprintRecord bp : BLUEPRINTS) {
            boolean inRange = false;
            for (BlockPos p : bp.originalStates.keySet()) {
                if (p.getSquaredDistance(center) <= r2) { inRange = true; break; }
            }
            if (inRange) {
                rewoundBps.add(bp);
                for (BlockPos rp : bp.depositedRubble) {
                    if (world.isChunkLoaded(rp.getX() >> 4, rp.getZ() >> 4)) {
                        restoreWaterOrAirAtRubblePos(world, rp);
                    }
                }
                List<Map.Entry<BlockPos, BlockState>> entries = new ArrayList<>(bp.originalStates.entrySet());
                entries.sort(Comparator.comparingInt(e -> e.getKey().getY()));
                for (Map.Entry<BlockPos, BlockState> e : entries) {
                    BlockPos p = e.getKey();
                    if (world.isChunkLoaded(p.getX() >> 4, p.getZ() >> 4)) {
                        restoreBlockSafelyLiftingPlayers(world, p, e.getValue(), Block.NOTIFY_ALL);
                        restoredCount++;
                    }
                }
            }
        }
        BLUEPRINTS.removeAll(rewoundBps);

        // 4. Rewind detached continuous 3D beams/columns within radius
        int beforeBeams = ContinuousStructuralBeams.ACTIVE_BEAMS.size();
        for (ContinuousBeam b : ContinuousStructuralBeams.SNAPSHOT_BEAMS_FOR_REWIND) {
            double mx = 0.5 * (b.ax + b.bx) - (center.getX() + 0.5);
            double my = 0.5 * (b.ay + b.by) - (center.getY() + 0.5);
            double mz = 0.5 * (b.az + b.bz) - (center.getZ() + 0.5);
            if (mx * mx + my * my + mz * mz <= r2) {
                boolean alreadyActive = false;
                for (ContinuousBeam act : ContinuousStructuralBeams.ACTIVE_BEAMS) {
                    if (act.id == b.id) { alreadyActive = true; break; }
                }
                b.dispAx = b.dispAy = b.dispAz = 0.0;
                b.dispBx = b.dispBy = b.dispBz = 0.0;
                b.lateralBowM = 0.0;
                b.currentUtilization = 0.0;
                if (!alreadyActive) {
                    ContinuousStructuralBeams.ACTIVE_BEAMS.add(b);
                }
            }
        }
        restoredCount += Math.max(0, ContinuousStructuralBeams.ACTIVE_BEAMS.size() - beforeBeams);

        if (restoredCount > 0) {
            saveBlueprintsToDisk();
        }
        return restoredCount;
    }

    public static synchronized int clearTestRig(ServerWorld world) {
        RigidBody6DoFDynamics.ACTIVE_BODIES.clear();
        ContinuousStructuralBeams.clearTemporaryTestBeams();
        for (BlockPos rp : new ArrayList<>(RUBBLE_BARRIER_OWNER.keySet())) {
            if (world.isChunkLoaded(rp.getX() >> 4, rp.getZ() >> 4) && world.getBlockState(rp).isOf(Blocks.BARRIER)) {
                world.setBlockState(rp, Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
            }
        }
        RUBBLE_BARRIER_OWNER.clear();
        ELASTIC_PROXIES.clear();
        PLASTIC_RESIDUAL_MAP.clear();

        int count = TEST_RIG_RESTORE_MAP.size();
        List<Map.Entry<BlockPos, BlockState>> list = new ArrayList<>(TEST_RIG_RESTORE_MAP.entrySet());
        for (int i = list.size() - 1; i >= 0; i--) {
            Map.Entry<BlockPos, BlockState> e = list.get(i);
            BlockPos p = e.getKey();
            if (world.isChunkLoaded(p.getX() >> 4, p.getZ() >> 4)) {
                world.setBlockState(p, e.getValue(), Block.NOTIFY_ALL);
            }
        }
        TEST_RIG_RESTORE_MAP.clear();
        BLUEPRINTS.clear();
        GLOBAL_DEPOSITED_RUBBLE.clear();
        saveBlueprintsToDisk();
        return count;
    }

    private static void restoreWaterOrAirAtRubblePos(ServerWorld world, BlockPos rp) {
        int adjWater = 0;
        for (Direction hd : Direction.Type.HORIZONTAL) {
            if (world.getFluidState(rp.offset(hd)).isIn(FluidTags.WATER)) adjWater++;
        }
        if (adjWater >= 2 || world.getFluidState(rp.up()).isIn(FluidTags.WATER)) {
            world.setBlockState(rp, Blocks.WATER.getDefaultState(), Block.NOTIFY_ALL);
        } else {
            world.setBlockState(rp, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);
        }
    }

    private static Path getBlueprintDiskPath() {
        return FabricLoader.getInstance().getGameDir().resolve("arena-physics-blueprints-v2.json");
    }

    public static synchronized void saveBlueprintsToDisk() {
        try {
            JsonArray arr = new JsonArray();
            for (BlueprintRecord bp : BLUEPRINTS) {
                JsonObject obj = new JsonObject();
                obj.addProperty("id", bp.id);
                obj.addProperty("ox", bp.origin.getX());
                obj.addProperty("oy", bp.origin.getY());
                obj.addProperty("oz", bp.origin.getZ());

                JsonArray origArr = new JsonArray();
                for (Map.Entry<BlockPos, BlockState> e : bp.originalStates.entrySet()) {
                    JsonObject bo = new JsonObject();
                    bo.addProperty("x", e.getKey().getX());
                    bo.addProperty("y", e.getKey().getY());
                    bo.addProperty("z", e.getKey().getZ());
                    bo.addProperty("state", ConstitutiveMaterialDB.serializeBlockState(e.getValue()));
                    origArr.add(bo);
                }
                obj.add("originals", origArr);
                arr.add(obj);
            }
            String jsonPayload = new GsonBuilder().create().toJson(arr);
            Path diskPath = getBlueprintDiskPath();
            CompletableFuture.runAsync(() -> {
                try {
                    Files.writeString(diskPath, jsonPayload, StandardCharsets.UTF_8);
                } catch (Throwable ignored) {}
            });
        } catch (Throwable ignored) {}
    }

    public static synchronized void ensureLoadedFromDisk() {
        if (diskLoaded) return;
        diskLoaded = true;
        try {
            Path path = getBlueprintDiskPath();
            if (!Files.exists(path)) return;
            JsonArray arr = JsonParser.parseString(Files.readString(path, StandardCharsets.UTF_8)).getAsJsonArray();
            for (JsonElement el : arr) {
                JsonObject obj = el.getAsJsonObject();
                BlockPos orig = new BlockPos(obj.get("ox").getAsInt(), obj.get("oy").getAsInt(), obj.get("oz").getAsInt());
                BlueprintRecord rec = new BlueprintRecord(obj.get("id").getAsString(), orig);
                if (obj.has("originals")) {
                    for (JsonElement oe : obj.getAsJsonArray("originals")) {
                        JsonObject bo = oe.getAsJsonObject();
                        BlockPos p = new BlockPos(bo.get("x").getAsInt(), bo.get("y").getAsInt(), bo.get("z").getAsInt());
                        rec.originalStates.put(p, ConstitutiveMaterialDB.deserializeBlockState(bo.get("state").getAsString()));
                    }
                }
                BLUEPRINTS.add(rec);
            }
        } catch (Throwable ignored) {}
    }
}

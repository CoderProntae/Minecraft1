package ai.arena.bridge.physics;

import ai.arena.bridge.ArenaContent;
import ai.arena.bridge.map.ArenaMapData;
import ai.arena.bridge.physics.pro.ConstitutiveMaterialDB;
import ai.arena.bridge.physics.pro.ContinuousOBBHitboxEngine;
import ai.arena.bridge.physics.pro.FractureAndSolidifier;
import ai.arena.bridge.physics.pro.RigidBody6DoFDynamics;
import ai.arena.bridge.physics.pro.VerletClothAndWeatherSolver;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.util.ActionResult;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.BedBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.CarpetBlock;
import net.minecraft.block.LanternBlock;
import net.minecraft.block.StairsBlock;
import net.minecraft.block.TorchBlock;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.TntEntity;
import net.minecraft.entity.passive.IronGolemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.Heightmap;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Real-Time 3D Geotechnical, Structural & Progressive Demolition Physics Engine (v7.8.0):
 *
 * 1. Blocksworth-Inspired Multi-Cluster Progressive Building Demolition (Rapier-style 6-DoF):
 *    - Live TNT detonation interceptor on surface crafted structures (up to 84 blocks tall; metro/stations protected).
 *    - 3D Ground-Support Graph BFS + Story Column Buckling check.
 *    - Partitions failing upper stories into 6-DoF CompoundClusterBody chunks with real voxel mass, inertia,
 *      quaternion rotation, progressive floor-by-floor pancake wave, impact fracture into bouncing PhysicsRigidBody
 *      debris, and angle-of-repose solidification into one walkable 3D rubble pile!
 *    - Full pre-collapse StructureBlueprintSnapshot persisted to disk (arena-physics-blueprints.json) for 100% /onar rewind!
 *
 * 2. Terzaghi Rock Arch (Hp <= 18.5m) + Depth-Confined Mohr-Coulomb + Green-Ampt Storm Pore-Water Tunnel Geotechnics:
 *    - Stable dry-weather FoS = 1.72..2.85 even beneath 50m mountains; genuine storm/seismic cracking & spalling.
 *    - Chunk-load-aware pending repair queue so /onar heals unloaded tunnel rings the moment chunks load.
 *
 * 3. EN 14363 / UIC 518 Nadal Wheel-Climb Criterion + ATP Hazard Speed Restriction & Emergency Braking.
 *
 * 4. Safe Dynamic Slab Impact (immune to stairs, underground stations, and cave mobs).
 */
public final class GeoStructuralPhysicsEngine {

    private static final double G = 9.80665;
    private static final int SUBSTEPS = 4; // 4 x 20 Hz = 80 Hz 6-DoF rigid-body contact integration
    private static final int MAX_LIVE_RIGID_BODIES = 180;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static final int RING_MIN_CZ = -2;
    public static final int RING_MAX_CZ = 100;
    public static final int RING_COUNT = RING_MAX_CZ - RING_MIN_CZ + 1;

    public static final int TUNNEL_Z_START = 46;
    public static final int TUNNEL_Z_END   = 1564;

    // ==================== TUNNEL GEOTECHNICAL RING STATE ====================
    public static final class TunnelRingState {
        public final int cz;
        public final int centerZ;
        public volatile double coverDepthM = 16.0;
        public volatile double poreWaterKpa = 0.0;
        public volatile double waterDepthMm = 0.0;  // Flooded trackbed water height Above Top of Rail (mm ATR)
        public volatile double liveBoussinesqKpa = 0.0;
        public volatile double seismicKpa = 0.0;
        public volatile double trainDynamicKpa = 0.0;
        public volatile double factorOfSafety = 2.38;
        public volatile double settlementMm = 0.0;
        public volatile double fatigueDamage = 0.0; // 0.0 .. 1.0
        public volatile int crackStage = 0;         // 0=Intact, 1=Micro-Cracked, 2=Spalling/Collapse
        public volatile boolean emergencyLedActive = false;
        public volatile boolean pendingChunkHeal = false;

        public TunnelRingState(int cz) {
            this.cz = cz;
            this.centerZ = (cz << 4) + 8;
        }
    }

    // ==================== 6-DoF SINGLE-BLOCK RIGID BODY ====================
    public static final class PhysicsRigidBody {
        public final String blueprintId;
        public final BlockState state;
        public final BlockPos originPos;
        public final double massKg;
        public final double invMass;
        public final double invInertia;
        public final double restitution;
        public final double friction;

        public double px, py, pz;
        public double prevPx, prevPy, prevPz;
        public double vx, vy, vz;
        public double wx, wy, wz;
        public final Quaternionf quat = new Quaternionf();
        public final Quaternionf prevQuat = new Quaternionf();

        public int ageTicks = 0;
        public int lowEnergyTicks = 0;
        public boolean sleeping = false;
        public boolean fromSurfaceDemolition = false;

        public PhysicsRigidBody(BlockPos origin, BlockState state, double vx, double vy, double vz, double wx, double wy, double wz) {
            this(null, origin, state, vx, vy, vz, wx, wy, wz);
        }

        public PhysicsRigidBody(String blueprintId, BlockPos origin, BlockState state, double vx, double vy, double vz, double wx, double wy, double wz) {
            this.blueprintId = blueprintId;
            this.originPos = origin.toImmutable();
            this.state = state;
            ConstitutiveMaterialDB.SectionProperties sec = ConstitutiveMaterialDB.computeSection(state);
            this.massKg = sec.massKg();
            this.invMass = 1.0 / Math.max(20.0, this.massKg);
            this.invInertia = 6.0 / Math.max(20.0, this.massKg);
            this.restitution = sec.category().restitution;
            this.friction = sec.category().slidingFriction;

            this.px = origin.getX() + 0.5;
            this.py = origin.getY() + 0.5;
            this.pz = origin.getZ() + 0.5;
            this.prevPx = this.px;
            this.prevPy = this.py;
            this.prevPz = this.pz;
            this.vx = vx;
            this.vy = vy;
            this.vz = vz;
            this.wx = wx;
            this.wy = wy;
            this.wz = wz;
        }
    }

    // ==================== MULTI-BLOCK COMPOUND CLUSTER & TILTING BODY ====================
    public record RelBlock(int dx, int dy, int dz, BlockState state) {}

    public static final class CompoundClusterBody {
        public final String blueprintId;
        public final BlockPos originCenter;
        public final List<RelBlock> blocks;
        public final double massKg;
        public int delayTicks;

        public double px, py, pz;
        public double prevPx, prevPy, prevPz;
        public double vx, vy, vz;
        public double wx, wy, wz;
        public final Quaternionf quat = new Quaternionf();
        public final Quaternionf prevQuat = new Quaternionf();
        public int ageTicks = 0;

        public CompoundClusterBody(String blueprintId, BlockPos originCenter, List<RelBlock> blocks,
                                   int delayTicks, double vx, double vy, double vz, double wx, double wy, double wz) {
            this.blueprintId = blueprintId;
            this.originCenter = originCenter.toImmutable();
            this.blocks = blocks;
            this.massKg = Math.max(200.0, blocks.size() * 1450.0);
            this.delayTicks = delayTicks;
            this.px = originCenter.getX() + 0.5;
            this.py = originCenter.getY() + 0.5;
            this.pz = originCenter.getZ() + 0.5;
            this.prevPx = this.px;
            this.prevPy = this.py;
            this.prevPz = this.pz;
            this.vx = vx; this.vy = vy; this.vz = vz;
            this.wx = wx; this.wy = wy; this.wz = wz;
        }
    }

    public static final class TiltingStructureBody {
        public final String id;
        public final BlockPos hinge;
        public final List<RelBlock> blocks;
        public final double totalMassKg;
        public final double comHeightM;
        public double tiltXRad = 0.0, tiltZRad = 0.0;
        public double prevTiltXRad = 0.0, prevTiltZRad = 0.0;
        public double velXRad = 0.0, velZRad = 0.0;
        public double plasticYieldRadX = 0.018, plasticYieldRadZ = 0.0;
        public int ageTicks = 0;

        public TiltingStructureBody(String id, BlockPos hinge, List<RelBlock> blocks, double totalMassKg, double comHeightM) {
            this.id = id;
            this.hinge = hinge.toImmutable();
            this.blocks = blocks;
            this.totalMassKg = Math.max(500.0, totalMassKg);
            this.comHeightM = Math.max(1.2, comHeightM);
        }
    }

    public static final class StructureBlueprintSnapshot {
        public final String id;
        public final BlockPos center;
        public final Map<BlockPos, BlockState> originalBlocks = new LinkedHashMap<>();
        public final Set<BlockPos> depositedRubble = ConcurrentHashMap.newKeySet();

        public StructureBlueprintSnapshot(String id, BlockPos center) {
            this.id = id;
            this.center = center.toImmutable();
        }
    }

    public static final class StructuralAlert {
        public final String id;
        public final String type;
        public final String summary;
        public final BlockPos pos;
        public final double severity;
        public final long createdMs;

        public StructuralAlert(String id, String type, String summary, BlockPos pos, double severity) {
            this.id = id;
            this.type = type;
            this.summary = summary;
            this.pos = pos.toImmutable();
            this.severity = severity;
            this.createdMs = System.currentTimeMillis();
        }
    }

    // ==================== SHARED LIVE TELEMETRY ====================
    public static final TunnelRingState[] TUNNEL_RINGS = new TunnelRingState[RING_COUNT];
    public static final List<PhysicsRigidBody> RIGID_BODIES = new CopyOnWriteArrayList<>();
    public static final List<CompoundClusterBody> COMPOUND_CLUSTERS = new CopyOnWriteArrayList<>();
    public static final List<TiltingStructureBody> TILTING_STRUCTURES = new CopyOnWriteArrayList<>();
    public static final List<StructureBlueprintSnapshot> SAVED_BLUEPRINTS = new CopyOnWriteArrayList<>();
    public static final List<StructuralAlert> ACTIVE_ALERTS = new CopyOnWriteArrayList<>();

    static {
        for (int i = 0; i < RING_COUNT; i++) {
            TUNNEL_RINGS[i] = new TunnelRingState(RING_MIN_CZ + i);
        }
    }

    public static volatile boolean physicsEnabled = true;
    public static volatile double latestMinTunnelFos = 2.38;
    public static volatile int latestCriticalRingZ = 800;
    public static volatile double latestMaxPoreWaterKpa = 0.0;
    public static volatile double latestMaxWaterDepthMm = 0.0;
    public static volatile double latestNearestColumnDcr = 0.08;
    public static volatile double latestNearestColumnFos = 12.5;
    public static volatile int latestNearestColumnHeight = 0;
    public static volatile double latestSurfaceImpulseKn = 0.0;
    public static volatile double latestNadalYq = 0.16;
    public static volatile boolean elevatorBrakeTripped = false;

    // Client-computed 60 FPS carbody ride comfort metrics
    public static volatile float clientTrainRollDeg = 0.0f;
    public static volatile float clientTrainPitchDeg = 0.0f;
    public static volatile float clientTrainHeaveM = 0.0f;
    public static volatile float clientSperlingWz = 1.45f;

    private static final Map<UUID, Double> PREV_ENTITY_VY = new HashMap<>();
    private static final Map<UUID, Boolean> PREV_ON_GROUND = new HashMap<>();
    private static final Map<Long, Double> SLAB_FATIGUE = new HashMap<>();
    private static final Set<BlockPos> SIMULATED_FLOOD_WATER = ConcurrentHashMap.newKeySet();
    private static final Set<BlockPos> PENDING_FEM_SEEDS = ConcurrentHashMap.newKeySet();
    private static final Map<BlockPos, Integer> DELAYED_PLACEMENT_SEEDS = new ConcurrentHashMap<>();
    private static boolean femCallbacksRegistered = false;
    private static final List<int[]> FORCED_CHUNKS_TO_RELEASE = new ArrayList<>();
    private static int nextStandardizeTunnelCz = 2; // cz=2..98 covers Z=46..1564 progressively
    private static int tickCounter = 0;

    private static void ensureModularFEMHooksBound() {
        if (femCallbacksRegistered) return;
        femCallbacksRegistered = true;
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (physicsEnabled && world instanceof ServerWorld sw && pos.getY() >= 61
                    && !FractureAndSolidifier.isProtectedMetroInfrastructure(pos, state)) {
                PENDING_FEM_SEEDS.addAll(FractureAndSolidifier.handleBlockBreakAndCollectSeeds(sw, pos, state));
            }
        });
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (physicsEnabled && !world.isClient) {
                ItemStack st = player.getStackInHand(hand);
                if (st != null && st.getItem() instanceof BlockItem) {
                    BlockPos target = hitResult.getBlockPos().offset(hitResult.getSide());
                    if (target.getY() >= 61) {
                        DELAYED_PLACEMENT_SEEDS.put(target.toImmutable(), 2);
                    }
                }
            }
            return ActionResult.PASS;
        });
    }

    private GeoStructuralPhysicsEngine() {}

    public static TunnelRingState getRingForZ(double z) {
        int cz = ((int) Math.floor(z)) >> 4;
        int idx = cz - RING_MIN_CZ;
        if (idx < 0 || idx >= RING_COUNT) return null;
        return TUNNEL_RINGS[idx];
    }

    /**
     * O(1) lock-free flooded water depth query (mm Above Top of Rail) for RailPhysicsEngine / MtrVehiclePhysicsMixin.
     */
    public static double getFloodWaterDepthMmAtZ(double z) {
        if (!physicsEnabled) return 0.0;
        TunnelRingState r = getRingForZ(z);
        return (r != null) ? r.waterDepthMm : 0.0;
    }

    /**
     * Maximum flooded water depth (mm ATR) along the train's lookahead braking corridor.
     */
    public static double getMaxFloodWaterAheadMm(double curZ, double dirZ, double lookaheadM) {
        if (!physicsEnabled) return 0.0;
        double maxMm = 0.0;
        for (double d = 0.0; d <= lookaheadM; d += 14.0) {
            TunnelRingState r = getRingForZ(curZ + (dirZ >= 0 ? d : -d));
            if (r != null && r.waterDepthMm > maxMm) {
                maxMm = r.waterDepthMm;
            }
        }
        return maxMm;
    }

    /**
     * Used by RailPhysicsEngine (MtrVehiclePhysicsMixin) to trigger smooth ATP emergency braking
     * 85m ahead of any collapsed tunnel ring!
     */
    public static boolean isCollapsedRingAhead(double curZ, double dirZ, double lookaheadM) {
        if (!physicsEnabled) return false;
        for (double d = 0.0; d <= lookaheadM; d += 14.0) {
            TunnelRingState r = getRingForZ(curZ + (dirZ >= 0 ? d : -d));
            if (r != null && r.crackStage >= 2) {
                return true;
            }
        }
        return false;
    }

    // ==================== MAIN 20 HZ SERVER SOLVER ====================
    public static void onServerTick(MinecraftServer server) {
        if (!physicsEnabled || server == null) return;
        ServerWorld overworld = server.getOverworld();
        if (overworld == null || overworld.getPlayers().isEmpty()) return;
        tickCounter++;

        // Release any temporary chunk tickets from progressive tunnel standardization
        if (!FORCED_CHUNKS_TO_RELEASE.isEmpty()) {
            for (int[] cc : FORCED_CHUNKS_TO_RELEASE) {
                overworld.setChunkForced(cc[0], cc[1], false);
            }
            FORCED_CHUNKS_TO_RELEASE.clear();
        }

        // Progressive 1,519m M1 Tunnel Bore Standardization (Z = 46..1564, 5 chunks/tick => 0 lag!)
        if (nextStandardizeTunnelCz <= 98) {
            if (nextStandardizeTunnelCz == 2) {
                upgradeStationRearSectionsAndYakindaTapes(overworld);
            }
            int n = 0;
            while (nextStandardizeTunnelCz <= 98 && n < 5) {
                standardizeTunnelChunkBore(overworld, nextStandardizeTunnelCz++);
                n++;
            }
        }

        // 1. Heal any pending tunnel rings whose chunks just became loaded!
        if ((tickCounter % 10) == 2) {
            processPendingRingHeals(overworld);
        }

        // 2. Modular 6-DoF FEM Statics, Continuous OBB Hitboxes & Weather/Wind/Snow!
        ensureModularFEMHooksBound();
        VerletClothAndWeatherSolver.tickServerEnvironment(overworld);
        ContinuousOBBHitboxEngine.tickServerEntities(overworld);
        interceptSurfaceTntForDemolition(overworld);
        if (!DELAYED_PLACEMENT_SEEDS.isEmpty()) {
            java.util.Iterator<Map.Entry<BlockPos, Integer>> dit = DELAYED_PLACEMENT_SEEDS.entrySet().iterator();
            while (dit.hasNext()) {
                Map.Entry<BlockPos, Integer> de = dit.next();
                if (de.getValue() <= 1) {
                    dit.remove();
                    PENDING_FEM_SEEDS.add(de.getKey());
                } else {
                    de.setValue(de.getValue() - 1);
                }
            }
        }
        if (!PENDING_FEM_SEEDS.isEmpty()) {
            List<BlockPos> femBatch = new ArrayList<>(PENDING_FEM_SEEDS);
            PENDING_FEM_SEEDS.clear();
            Set<BlockPos> femVis = new HashSet<>();
            org.joml.Vector3d wVec = VerletClothAndWeatherSolver.getCurrentSurfaceWindMs();
            for (BlockPos seed : femBatch) {
                if (!femVis.contains(seed)) {
                    FractureAndSolidifier.evaluateAndCollapseStructure(overworld, seed, null, 0.0, wVec, femVis, true);
                }
            }
        }

        // 3. Step unified 3x3-inertia 6-DoF RigidCluster6DoF + legacy bodies + P-Delta Tilting Structures
        RigidBody6DoFDynamics.tickAll(overworld, 1.0,
                VerletClothAndWeatherSolver.getCurrentSurfaceWindMs(),
                FractureAndSolidifier::solidifyBodyInWorld);
        tickCompoundClusters(overworld);
        tickRigidBodies(overworld);
        tickTiltingStructures(overworld);

        // 4. Safe entity landing impulse (players & iron golems only; stairs & caves protected!)
        tickEntityImpactsAndBoussinesq(overworld);

        // 5. Darcy + Cubic-Law Tunnel Ceiling Dripping & Train-in-Water Bow-Wave Hydrodynamics!
        tickCeilingSeepageDripsAndTrainHydrodynamics(overworld);

        // 6. Every 10 ticks (0.5s): Terzaghi Rock Arch + Depth-Confined Mohr-Coulomb + Flood & Nadal Y/Q Check
        if ((tickCounter % 10) == 0) {
            updateTunnelGeotechnicsAndNadal(overworld);
        }

        // 7. Every 20 ticks (1.0s): Euler/P-Delta column audit around ALL online players (multiplayer-safe!)
        if ((tickCounter % 20) == 5) {
            auditStructuralColumnsAroundPlayers(overworld);
        }

        // 8. Periodic UUID cache cleanup (zero memory leak)
        if ((tickCounter % 300) == 0 && PREV_ENTITY_VY.size() > 64) {
            PREV_ENTITY_VY.clear();
            PREV_ON_GROUND.clear();
        }

        latestSurfaceImpulseKn *= 0.90;
    }

    /**
     * Upgrades South (Z=1593..1612) & North (Z=-28..20) station rear sections and stretches
     * double-ribbon YAKINDA barrier tapes across the future extension alcoves & tail portals!
     */
    private static void upgradeStationRearSectionsAndYakindaTapes(ServerWorld world) {
        int[][] rearChunks = { {-2, -2}, {-1, -2}, {-2, -1}, {-1, -1}, {-2, 0}, {-1, 0}, {-2, 1}, {-1, 1},
                               {-2, 99}, {-1, 99}, {-2, 100}, {-1, 100}, {-2, 101}, {-1, 101} };
        for (int[] cc : rearChunks) {
            if (!world.isChunkLoaded(cc[0], cc[1])) {
                world.setChunkForced(cc[0], cc[1], true);
                FORCED_CHUNKS_TO_RELEASE.add(cc);
            }
            world.getChunk(cc[0], cc[1]);
        }

        BlockState tapeNorth = ArenaContent.YAKINDA_SERIT.getDefaultState().with(ArenaContent.FACING, Direction.NORTH);
        BlockState tapeSouth = ArenaContent.YAKINDA_SERIT.getDefaultState().with(ArenaContent.FACING, Direction.SOUTH);
        BlockState air = Blocks.AIR.getDefaultState();

        // Place real YAKINDA double-ribbon tape across South Future Extension Alcove (Z=1595) & Tail Portal
        for (int x = -25; x <= -23; x++) {
            world.setBlockState(new BlockPos(x, 51, 1595), air, Block.NOTIFY_ALL);
            world.setBlockState(new BlockPos(x, 49, 1595), tapeNorth, Block.NOTIFY_ALL);
        }
        for (int x = -19; x <= -17; x++) {
            BlockPos p = new BlockPos(x, 49, 1595);
            if (!isMtrOrTransitBlock(world.getBlockState(p))) {
                world.setBlockState(p, tapeNorth, Block.NOTIFY_ALL);
            }
        }

        // Place real YAKINDA double-ribbon tape across North Future Extension Alcove (Z=19) & Tail Portal
        for (int x = -25; x <= -23; x++) {
            world.setBlockState(new BlockPos(x, 51, 19), air, Block.NOTIFY_ALL);
            world.setBlockState(new BlockPos(x, 49, 19), tapeSouth, Block.NOTIFY_ALL);
        }
        for (int x = -19; x <= -17; x++) {
            BlockPos p = new BlockPos(x, 49, 19);
            if (!isMtrOrTransitBlock(world.getBlockState(p))) {
                world.setBlockState(p, tapeSouth, Block.NOTIFY_ALL);
            }
        }
    }

    /**
     * Ensures 100% of the M1 tunnel bore (Z = 46 .. 1564) is architecturally uniform:
     * continuous linear ceiling LED rail at (-18, 52, z), 8m Polished Deepslate ribs, and clean Stone Brick walls.
     */
    public static void standardizeTunnelChunkBore(ServerWorld world, int cz) {
        if (!world.isChunkLoaded(-2, cz)) {
            world.setChunkForced(-2, cz, true);
            FORCED_CHUNKS_TO_RELEASE.add(new int[]{-2, cz});
        }
        if (!world.isChunkLoaded(-1, cz)) {
            world.setChunkForced(-1, cz, true);
            FORCED_CHUNKS_TO_RELEASE.add(new int[]{-1, cz});
        }
        world.getChunk(-2, cz);
        world.getChunk(-1, cz);

        int zStart = Math.max(TUNNEL_Z_START, cz << 4);
        int zEnd   = Math.min(TUNNEL_Z_END, (cz << 4) + 15);
        if (zStart > zEnd) return;

        int rIdx = cz - RING_MIN_CZ;
        boolean ringEmg = (rIdx >= 0 && rIdx < RING_COUNT) && TUNNEL_RINGS[rIdx].emergencyLedActive;

        BlockState ceilingLed = ArenaContent.TUNNEL_EMERGENCY_LIGHT.getDefaultState()
                .with(ArenaContent.CEILING, true)
                .with(ArenaContent.FACING, Direction.NORTH)
                .with(ArenaContent.EMERGENCY, ringEmg);
        BlockState stoneBricks = Blocks.STONE_BRICKS.getDefaultState();
        BlockState deepslateRib = Blocks.POLISHED_DEEPSLATE.getDefaultState();
        BlockState polAndesite = Blocks.POLISHED_ANDESITE.getDefaultState();
        BlockState andesite = Blocks.ANDESITE.getDefaultState();
        BlockState air = Blocks.AIR.getDefaultState();

        BlockPos.Mutable mp = new BlockPos.Mutable();
        for (int z = zStart; z <= zEnd; z++) {
            boolean isRib = ((z & 7) == 0);
            BlockState liner = isRib ? deepslateRib : stoneBricks;

            for (int x = -21; x <= -15; x++) {
                BlockState desiredFloor = (x >= -19 && x <= -17) ? andesite : polAndesite;
                BlockState cur = world.getBlockState(mp.set(x, 47, z));
                if (!isMtrOrTransitBlock(cur) && cur != desiredFloor) {
                    world.setBlockState(mp, desiredFloor, Block.NOTIFY_ALL);
                }
            }

            for (int y = 48; y <= 51; y++) {
                for (int x : new int[]{-21, -15}) {
                    BlockState cur = world.getBlockState(mp.set(x, y, z));
                    if (!isMtrOrTransitBlock(cur) && !cur.hasBlockEntity() && cur != liner) {
                        world.setBlockState(mp, liner, Block.NOTIFY_ALL);
                    }
                }
                for (int x = -20; x <= -16; x++) {
                    BlockState cur = world.getBlockState(mp.set(x, y, z));
                    if (isMtrOrTransitBlock(cur) || cur.hasBlockEntity()) continue;
                    if (!cur.isAir() && !cur.getFluidState().isIn(FluidTags.WATER)) {
                        world.setBlockState(mp, air, Block.NOTIFY_ALL);
                    }
                }
            }

            for (int x : new int[]{-21, -20, -16, -15}) {
                BlockState cur = world.getBlockState(mp.set(x, 52, z));
                if (!isMtrOrTransitBlock(cur) && !cur.hasBlockEntity() && cur != liner) {
                    world.setBlockState(mp, liner, Block.NOTIFY_ALL);
                }
            }
            for (int x : new int[]{-19, -17}) {
                BlockState cur = world.getBlockState(mp.set(x, 52, z));
                if (!isMtrOrTransitBlock(cur) && !cur.hasBlockEntity() && !cur.isAir()) {
                    world.setBlockState(mp, air, Block.NOTIFY_ALL);
                }
            }
            BlockState curLed = world.getBlockState(mp.set(-18, 52, z));
            if (curLed != ceilingLed) {
                world.setBlockState(mp, ceilingLed, Block.NOTIFY_ALL);
            }

            for (int x = -21; x <= -15; x++) {
                BlockState cur = world.getBlockState(mp.set(x, 53, z));
                if (!isMtrOrTransitBlock(cur) && !cur.hasBlockEntity() && cur != liner) {
                    world.setBlockState(mp, liner, Block.NOTIFY_ALL);
                }
            }
        }
    }

    private static boolean isMtrOrTransitBlock(BlockState st) {
        if (st == null || st.isAir()) return false;
        String id = Registries.BLOCK.getId(st.getBlock()).toString();
        return id.startsWith("mtr:") || (id.startsWith("arena_ai_bridge:") && !st.isOf(ArenaContent.TUNNEL_EMERGENCY_LIGHT));
    }

    /**
     * Literature-backed Tunnel Crown Darcy + Cubic Fracture Seepage (Schleiss 1997; Liu et al. 2017)
     * and Train-in-Water Bow-Wave Spray & Traction-Motor Immersion Arcing (Kaewunruen 2019; NORAC Rule 117):
     */
    private static void tickCeilingSeepageDripsAndTrainHydrodynamics(ServerWorld world) {
        boolean raining = world.isRaining();
        BlockPos.Mutable mp = new BlockPos.Mutable();

        // 1. Ceiling water dripping inside the tunnel bore
        for (ServerPlayerEntity sp : world.getPlayers()) {
            if (sp.getY() > 58.0) continue;
            int pz = sp.getBlockPos().getZ();
            for (int i = 0; i < 4; i++) {
                int z = pz + world.random.nextInt(49) - 24;
                if (z < TUNNEL_Z_START || z > TUNNEL_Z_END || !world.isChunkLoaded(-2, z >> 4)) continue;
                TunnelRingState ring = getRingForZ(z);
                if (ring == null) continue;

                boolean aquiferAbove = world.getFluidState(mp.set(-18, 54, z)).isIn(FluidTags.WATER)
                        || world.getFluidState(mp.set(-18, 55, z)).isIn(FluidTags.WATER);

                double seepScore = (ring.poreWaterKpa / 55.0)
                        + (ring.crackStage == 1 ? 0.45 : (ring.crackStage >= 2 ? 1.25 : 0.0))
                        + (aquiferAbove ? (raining ? 0.42 : 0.16) : 0.0)
                        + (ring.waterDepthMm > 20.0 ? 0.35 : 0.0);

                if (seepScore > 0.10 && world.random.nextDouble() < Math.min(0.85, seepScore * 0.45)) {
                    double dropX = -19.3 + world.random.nextDouble() * 2.6;
                    double dropY = (Math.abs(dropX - (-17.5)) < 0.45) ? 52.15 : 52.92;
                    world.spawnParticles(ParticleTypes.DRIPPING_WATER, dropX, dropY, z + 0.5, 1, 0.08, 0.0, 0.08, 0.0);
                    if (seepScore > 0.55) {
                        world.spawnParticles(ParticleTypes.FALLING_WATER, dropX, dropY - 0.08, z + 0.5, 2, 0.12, 0.02, 0.12, 0.0);
                    }
                    if (world.random.nextFloat() < 0.07f) {
                        world.playSound(null, mp.set(-18, 49, z),
                                SoundEvents.BLOCK_POINTED_DRIPSTONE_DRIP_WATER, SoundCategory.AMBIENT, 0.45f, 0.9f + world.random.nextFloat() * 0.25f);
                    }
                }
            }
        }

        // 2. Live Train Entering Flooded Track: Bow-Wave Spray + >105mm Traction-Motor Arcing!
        for (ArenaMapData.LiveTrainInfo t : ArenaMapData.getLiveTrains()) {
            TunnelRingState ringHere = getRingForZ(t.z);
            double waterMm = measurePhysicalOrRingWaterMm(world, (int) Math.round(t.x), (int) Math.round(t.y), (int) Math.round(t.z), ringHere);
            if (ringHere != null && waterMm > ringHere.waterDepthMm) {
                ringHere.waterDepthMm = waterMm;
            }
            if (waterMm >= 8.0 && t.speedKmh > 3.0) {
                int splashCount = Math.min(28, (int) Math.round((t.speedKmh / 12.0) * (1.0 + waterMm / 45.0)));
                world.spawnParticles(ParticleTypes.SPLASH, t.x - 0.9, t.y + 0.25, t.z, splashCount, 0.25, 0.18, 1.8, 0.18);
                world.spawnParticles(ParticleTypes.SPLASH, t.x + 0.9, t.y + 0.25, t.z, splashCount, 0.25, 0.18, 1.8, 0.18);
                if (waterMm >= 45.0 && t.speedKmh > 18.0) {
                    world.spawnParticles(ParticleTypes.CLOUD, t.x, t.y + 0.35, t.z, 5, 0.8, 0.2, 1.4, 0.03);
                    if ((tickCounter % 6) == 0) {
                        world.playSound(null, BlockPos.ofFloored(t.x, t.y, t.z),
                                SoundEvents.ENTITY_GENERIC_SPLASH, SoundCategory.BLOCKS, 0.75f, 0.85f);
                    }
                }
                if (waterMm >= 105.0) {
                    world.spawnParticles(ParticleTypes.ELECTRIC_SPARK, t.x, t.y + 0.3, t.z, 10, 0.6, 0.2, 1.2, 0.12);
                    if ((tickCounter % 10) == 0) {
                        world.playSound(null, BlockPos.ofFloored(t.x, t.y, t.z),
                                SoundEvents.BLOCK_REDSTONE_TORCH_BURNOUT, SoundCategory.BLOCKS, 0.70f, 0.75f);
                    }
                }
            }
        }
    }

    private static double measurePhysicalOrRingWaterMm(ServerWorld world, int x, int y, int z, TunnelRingState ring) {
        double mm = (ring != null) ? ring.waterDepthMm : 0.0;
        if (world.isChunkLoaded(x >> 4, z >> 4)) {
            BlockPos.Mutable mp = new BlockPos.Mutable();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = 0; dy <= 1; dy++) {
                    FluidState fs = world.getFluidState(mp.set(x + dx, y + dy, z));
                    if (fs.isIn(FluidTags.WATER)) {
                        mm = Math.max(mm, dy * 250.0 + fs.getLevel() * 32.0);
                    }
                }
            }
        }
        return mm;
    }

    // ==================== 1. ENTITY MASS & SAFE FLOOR IMPACT ====================
    public static double estimateEntityMassKg(LivingEntity e) {
        double base = (e instanceof PlayerEntity) ? 78.0 : (e instanceof IronGolemEntity ? 920.0 : 75.0);
        if (e instanceof PlayerEntity p) {
            double carried = 0.0;
            for (int i = 0; i < p.getInventory().size(); i++) {
                ItemStack st = p.getInventory().getStack(i);
                if (st.isEmpty()) continue;
                Item item = st.getItem();
                double unitKg = 0.35;
                if (item instanceof BlockItem bi) {
                    unitKg = estimateBlockMassKg(bi.getBlock().getDefaultState()) * 0.012;
                } else if (item instanceof ArmorItem) {
                    unitKg = 6.5;
                }
                carried += unitKg * st.getCount();
            }
            return base + Math.min(480.0, carried);
        }
        return base;
    }

    public static double estimateBlockMassKg(BlockState st) {
        if (st == null || st.isAir()) return 50.0;
        Block b = st.getBlock();
        if (b == Blocks.IRON_BLOCK || b == Blocks.ANVIL) return 7850.0;
        if (b == Blocks.GOLD_BLOCK) return 19300.0;
        if (b == Blocks.DEEPSLATE || b == Blocks.POLISHED_DEEPSLATE || b == Blocks.DEEPSLATE_BRICKS) return 2720.0;
        if (b == Blocks.STONE || b == Blocks.STONE_BRICKS || b == Blocks.SMOOTH_STONE || b == Blocks.QUARTZ_BLOCK
                || b == Blocks.SMOOTH_QUARTZ || st.isIn(BlockTags.BASE_STONE_OVERWORLD)) return 2450.0;
        if (st.isIn(BlockTags.LOGS) || st.isIn(BlockTags.PLANKS)) return 680.0;
        if (b == Blocks.GLASS || b == Blocks.TINTED_GLASS) return 2500.0;
        return 1600.0;
    }

    private static boolean isProtectedInfrastructure(BlockPos p, BlockState st) {
        String id = Registries.BLOCK.getId(st.getBlock()).toString();
        if (id.startsWith("mtr:") || id.startsWith("arena_ai_bridge:") || st.isOf(Blocks.BEDROCK) || st.isOf(Blocks.TNT)) {
            return true;
        }
        if (p.getY() < 61) return true; // Protect entire underground M1 tunnel & station caverns
        if (p.getX() >= -48 && p.getX() <= 10 && ((p.getZ() >= -20 && p.getZ() <= 68) || (p.getZ() >= 1548 && p.getZ() <= 1612))) {
            return true; // Protect North & South station complexes
        }
        return false;
    }

    private static boolean isNaturalTerrain(BlockState st) {
        return st.isOf(Blocks.GRASS_BLOCK) || st.isOf(Blocks.DIRT) || st.isOf(Blocks.COARSE_DIRT)
                || st.isOf(Blocks.PODZOL) || st.isOf(Blocks.STONE) || st.isOf(Blocks.DEEPSLATE)
                || st.isOf(Blocks.GRAVEL) || st.isOf(Blocks.SAND) || st.isOf(Blocks.WATER)
                || st.isIn(BlockTags.LEAVES);
    }

    private static boolean isNonStructuralDecor(BlockState st) {
        Block b = st.getBlock();
        return b instanceof CarpetBlock || b instanceof BedBlock || b instanceof LanternBlock
                || b instanceof TorchBlock || st.isIn(BlockTags.FLOWERS) || st.isIn(BlockTags.BANNERS);
    }

    private static void tickEntityImpactsAndBoussinesq(ServerWorld world) {
        for (TunnelRingState r : TUNNEL_RINGS) {
            r.liveBoussinesqKpa *= 0.85;
            r.seismicKpa *= 0.92;
            r.trainDynamicKpa *= 0.85;
        }

        for (ArenaMapData.LiveTrainInfo t : ArenaMapData.getLiveTrains()) {
            TunnelRingState tr = getRingForZ(t.z);
            if (tr != null) {
                double vRatio = Math.max(0.0, t.speedKmh / 80.0);
                double axleDynamicKpa = 12.0 + 14.0 * vRatio * (1.0 + tr.settlementMm / 24.0);
                tr.trainDynamicKpa = Math.max(tr.trainDynamicKpa, axleDynamicKpa);
            }
        }

        List<LivingEntity> tracked = new ArrayList<>(world.getPlayers());
        for (ServerPlayerEntity sp : world.getPlayers()) {
            tracked.addAll(world.getEntitiesByClass(IronGolemEntity.class, sp.getBoundingBox().expand(24.0), Entity::isAlive));
        }

        for (LivingEntity le : tracked) {
            UUID uid = le.getUuid();
            boolean onGroundNow = le.isOnGround();
            boolean wasOnGround = PREV_ON_GROUND.getOrDefault(uid, true);
            PREV_ENTITY_VY.put(uid, le.getVelocity().y);
            PREV_ON_GROUND.put(uid, onGroundNow);

            double massKg = estimateEntityMassKg(le);

            // Boussinesq 3D point-load stress over tunnel crown (-18, 53, z)
            if (Math.abs(le.getX() - (-18.0)) <= 22.0 && le.getY() > 54.0) {
                double zDepth = Math.max(2.5, le.getY() - 53.0);
                double rHoriz = Math.abs(le.getX() - (-18.0));
                double denom = Math.pow(1.0 + (rHoriz / zDepth) * (rHoriz / zDepth), 2.5);
                double boussinesqKpa = ((3.0 * (massKg * G / 1000.0)) / (2.0 * Math.PI * zDepth * zDepth)) / denom;
                TunnelRingState ring = getRingForZ(le.getZ());
                if (ring != null) {
                    ring.liveBoussinesqKpa += boussinesqKpa * 2.5;
                }
            }

            // Require genuine free-fall jump >= 1.20m (walking up/down stairs has fallDistance <= 0.65m!)
            if (!wasOnGround && onGroundNow && le.fallDistance >= 1.20f) {
                double vImpactMps = Math.sqrt(2.0 * G * le.fallDistance);
                double kp = 1.0 + Math.min(5.5, vImpactMps / (G * 0.14));
                double peakForceN = massKg * G * kp;
                double peakForceKn = peakForceN / 1000.0;
                latestSurfaceImpulseKn = Math.max(latestSurfaceImpulseKn, peakForceKn);

                if (Math.abs(le.getX() - (-18.0)) <= 18.0 && le.getY() > 53.0) {
                    TunnelRingState ring = getRingForZ(le.getZ());
                    if (ring != null) {
                        double depth = Math.max(3.0, le.getY() - 53.0);
                        ring.seismicKpa = Math.min(60.0, ring.seismicKpa + (peakForceKn * 9.0) / (depth * depth));
                    }
                }

                BlockPos supportPos = le.getSteppingPos();
                if (supportPos.getY() >= 61) {
                    BlockState slab = world.getBlockState(supportPos);
                    if (!slab.isAir() && !(slab.getBlock() instanceof StairsBlock) && !slab.isIn(BlockTags.STAIRS)
                            && !isProtectedInfrastructure(supportPos, slab) && !isNaturalTerrain(slab)) {
                        evaluateFloorSlabImpactFailure(world, supportPos, slab, peakForceKn);
                    }
                }
            }
        }
    }

    private static void evaluateFloorSlabImpactFailure(ServerWorld world, BlockPos supportPos, BlockState slabState, double peakForceKn) {
        if (!world.getBlockState(supportPos.down(1)).isAir() || !world.getBlockState(supportPos.down(2)).isAir()) return;
        BlockPos.Mutable mp = new BlockPos.Mutable();
        double nearestCol = 9.0;
        for (int dx = -6; dx <= 6; dx++) {
            for (int dz = -6; dz <= 6; dz++) {
                if (!world.getBlockState(mp.set(supportPos.getX() + dx, supportPos.getY() - 1, supportPos.getZ() + dz)).isAir()
                        && !world.getBlockState(mp.set(supportPos.getX() + dx, supportPos.getY() - 2, supportPos.getZ() + dz)).isAir()) {
                    nearestCol = Math.min(nearestCol, Math.hypot(dx, dz));
                }
            }
        }
        double clearSpanM = nearestCol * 2.0;
        if (clearSpanM >= 5.0) {
            boolean wood = slabState.isIn(BlockTags.PLANKS) || slabState.isIn(BlockTags.WOODEN_SLABS);
            double momentCapKnm = wood ? 14.0 : 28.0;
            double appliedMomentKnm = (peakForceKn * clearSpanM) / 4.0;
            if (appliedMomentKnm > momentCapKnm) {
                long k = supportPos.asLong();
                double dmg = SLAB_FATIGUE.getOrDefault(k, 0.0) + 0.45 * (appliedMomentKnm / momentCapKnm);
                SLAB_FATIGUE.put(k, dmg);
                world.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, slabState),
                        supportPos.getX() + 0.5, supportPos.getY() - 0.1, supportPos.getZ() + 0.5,
                        10, 0.25, 0.1, 0.25, 0.04);
                if (dmg >= 1.0) {
                    SLAB_FATIGUE.remove(k);
                    detachBlockAsLiveRigidBody(world, supportPos, 0.0, -0.6, 0.0);
                }
            }
        }
    }

    // ==================== 2. BLOCKSWORTH PROGRESSIVE SKYSCRAPER DEMOLITION ====================
    private static void interceptSurfaceTntForDemolition(ServerWorld world) {
        for (ServerPlayerEntity sp : world.getPlayers()) {
            Box box = sp.getBoundingBox().expand(64.0, 64.0, 64.0);
            for (TntEntity tnt : world.getEntitiesByClass(TntEntity.class, box, Entity::isAlive)) {
                if (tnt.getFuse() <= 2) {
                    BlockPos blastPos = tnt.getBlockPos();
                    if (blastPos.getY() >= 61) {
                        tnt.discard();
                        triggerBlocksworthDemolition(world, blastPos, 4.6);
                    }
                }
            }
        }
    }

    public static String triggerBlocksworthDemolition(ServerWorld world, BlockPos blastPos, double blastRadius) {
        return FractureAndSolidifier.triggerExplosionWithFEM(
                world,
                blastPos,
                blastRadius,
                VerletClothAndWeatherSolver.getCurrentSurfaceWindMs()
        );
    }

    @SuppressWarnings("unused")
    private static String legacyTriggerBlocksworthDemolitionUnused(ServerWorld world, BlockPos blastPos, double blastRadius) {
        world.playSound(null, blastPos, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.BLOCKS, 1.4f, 0.78f);
        world.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, blastPos.getX() + 0.5, blastPos.getY() + 0.5, blastPos.getZ() + 0.5,
                2, 0.5, 0.5, 0.5, 0.0);
        world.spawnParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, blastPos.getX() + 0.5, blastPos.getY() + 1.0, blastPos.getZ() + 0.5,
                28, 1.8, 1.2, 1.8, 0.03);

        StructureBlueprintSnapshot snap = null;
        for (StructureBlueprintSnapshot ex : SAVED_BLUEPRINTS) {
            if (Math.abs(ex.center.getX() - blastPos.getX()) <= 18 && Math.abs(ex.center.getZ() - blastPos.getZ()) <= 18) {
                snap = ex;
                break;
            }
        }

        int minY = Math.max(62, blastPos.getY() - 10);
        int maxY = Math.min(world.getTopY() - 1, blastPos.getY() + 84);
        int rx = 11, rz = 11;

        List<BlockPos> structureBlocks = new ArrayList<>();
        for (int y = minY; y <= maxY; y++) {
            for (int x = blastPos.getX() - rx; x <= blastPos.getX() + rx; x++) {
                for (int z = blastPos.getZ() - rz; z <= blastPos.getZ() + rz; z++) {
                    if (!world.isChunkLoaded(x >> 4, z >> 4)) continue;
                    BlockPos p = new BlockPos(x, y, z);
                    BlockState st = world.getBlockState(p);
                    if (st.isAir() || isProtectedInfrastructure(p, st) || isNaturalTerrain(st) || st.hasBlockEntity()) continue;
                    structureBlocks.add(p);
                }
            }
        }

        if (structureBlocks.isEmpty()) {
            return "Yıkım noktasında yüzey binası bulunamadı (Metro ve yeraltı istasyonları korumalıdır).";
        }

        if (snap == null) {
            snap = new StructureBlueprintSnapshot("bp_" + blastPos.getX() + "_" + blastPos.getZ(), blastPos);
            SAVED_BLUEPRINTS.add(snap);
        }
        for (BlockPos p : structureBlocks) {
            snap.originalBlocks.putIfAbsent(p, world.getBlockState(p));
        }

        // Sympathetic chain-detonation of nearby TNT blocks across floors (supports 25-TNT multi-floor demolition!)
        List<BlockPos> blastCenters = new ArrayList<>();
        blastCenters.add(blastPos);
        for (int x = blastPos.getX() - rx; x <= blastPos.getX() + rx; x++) {
            for (int z = blastPos.getZ() - rz; z <= blastPos.getZ() + rz; z++) {
                for (int y = minY; y <= maxY; y++) {
                    BlockPos p = new BlockPos(x, y, z);
                    if (world.getBlockState(p).isOf(Blocks.TNT)) {
                        world.setBlockState(p, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);
                        blastCenters.add(p);
                    }
                }
            }
        }

        // 1. Blast crater detachment -> radial 6-DoF flying fragments
        Set<BlockPos> remaining = new HashSet<>(structureBlocks);
        for (BlockPos p : structureBlocks) {
            BlockPos nearestBlast = blastPos;
            double bestD2 = p.getSquaredDistance(blastPos);
            for (BlockPos bc : blastCenters) {
                double d2 = p.getSquaredDistance(bc);
                if (d2 < bestD2) { bestD2 = d2; nearestBlast = bc; }
            }
            if (bestD2 <= blastRadius * blastRadius) {
                remaining.remove(p);
                BlockState st = world.getBlockState(p);
                world.setBlockState(p, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);
                if (!isNonStructuralDecor(st) && world.random.nextFloat() < 0.58f) {
                    double d = Math.max(0.8, Math.sqrt(bestD2));
                    double ux = (p.getX() - nearestBlast.getX()) / d;
                    double uy = (p.getY() - nearestBlast.getY() + 0.35) / d;
                    double uz = (p.getZ() - nearestBlast.getZ()) / d;
                    double spd = 9.8 / (1.0 + 0.30 * bestD2);
                    PhysicsRigidBody rb = spawnRigidBodyDirect(world, p, st, ux * spd, Math.max(0.8, uy * spd), uz * spd);
                    rb.fromSurfaceDemolition = true;
                }
            }
        }

        // 2. 3D Ground-Support Graph BFS + Story Column Buckling Threshold (< 48% remaining story area)
        Map<Integer, Integer> countByY = new HashMap<>();
        int actualMinY = Integer.MAX_VALUE, actualMaxY = Integer.MIN_VALUE;
        for (BlockPos p : remaining) {
            countByY.merge(p.getY(), 1, Integer::sum);
            actualMinY = Math.min(actualMinY, p.getY());
            actualMaxY = Math.max(actualMaxY, p.getY());
        }
        int peakFloorArea = 1;
        for (int c : countByY.values()) peakFloorArea = Math.max(peakFloorArea, c);

        int buckleY = Integer.MAX_VALUE;
        for (int y = actualMinY; y <= actualMaxY - 2; y++) {
            if (countByY.getOrDefault(y, 0) < peakFloorArea * 0.48) {
                buckleY = y;
                break;
            }
        }

        Set<BlockPos> grounded = new HashSet<>();
        ArrayDeque<BlockPos> queue = new ArrayDeque<>();
        for (BlockPos p : remaining) {
            if (p.getY() < buckleY) {
                BlockState below = world.getBlockState(p.down());
                if (!below.isAir() && !remaining.contains(p.down())) {
                    grounded.add(p);
                    queue.add(p);
                }
            }
        }
        while (!queue.isEmpty()) {
            BlockPos cur = queue.poll();
            for (Direction dir : Direction.values()) {
                BlockPos nb = cur.offset(dir);
                if (nb.getY() < buckleY && remaining.contains(nb) && grounded.add(nb)) {
                    queue.add(nb);
                }
            }
        }

        // 3. Partition ungrounded/buckled upper stories into 4x4x4 6-DoF CompoundClusterBodies!
        Map<Long, List<BlockPos>> cellMap = new LinkedHashMap<>();
        double eccX = 0.0, eccZ = 0.0;
        int failingBlocks = 0;
        for (BlockPos p : remaining) {
            if (grounded.contains(p)) continue;
            failingBlocks++;
            BlockState st = world.getBlockState(p);
            if (isNonStructuralDecor(st)) {
                world.setBlockState(p, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);
                continue;
            }
            int cx = p.getX() >> 2, cy = p.getY() >> 2, cz = p.getZ() >> 2;
            long cellKey = (((long) cy & 0x3FFL) << 40) | (((long) (cx & 0xFFFFF)) << 20) | (cz & 0xFFFFFL);
            cellMap.computeIfAbsent(cellKey, k -> new ArrayList<>()).add(p);
            eccX += (blastPos.getX() - p.getX());
            eccZ += (blastPos.getZ() - p.getZ());
        }

        if (failingBlocks > 0) {
            double tiltDirX = Math.signum(eccX == 0.0 ? 1.0 : eccX);
            double tiltDirZ = Math.signum(eccZ == 0.0 ? 0.6 : eccZ);
            int baseFailY = (buckleY < Integer.MAX_VALUE) ? buckleY : blastPos.getY();

            for (List<BlockPos> cellBlocks : cellMap.values()) {
                int sx = 0, sy = 0, sz = 0;
                for (BlockPos p : cellBlocks) {
                    sx += p.getX(); sy += p.getY(); sz += p.getZ();
                }
                BlockPos cCenter = new BlockPos(sx / cellBlocks.size(), sy / cellBlocks.size(), sz / cellBlocks.size());
                List<RelBlock> rels = new ArrayList<>(cellBlocks.size());
                for (BlockPos p : cellBlocks) {
                    rels.add(new RelBlock(p.getX() - cCenter.getX(), p.getY() - cCenter.getY(), p.getZ() - cCenter.getZ(), world.getBlockState(p)));
                    world.setBlockState(p, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);
                }
                int delay = Math.max(0, Math.min(24, (cCenter.getY() - baseFailY) / 3));
                double vx = tiltDirX * (0.45 + world.random.nextDouble() * 0.90);
                double vz = tiltDirZ * (0.45 + world.random.nextDouble() * 0.90);
                double wx = (world.random.nextDouble() - 0.35) * 1.10 * tiltDirZ;
                double wy = (world.random.nextDouble() - 0.50) * 0.45;
                double wz = (world.random.nextDouble() - 0.35) * 1.10 * tiltDirX;
                COMPOUND_CLUSTERS.add(new CompoundClusterBody(snap.id, cCenter, rels, delay, vx, -0.35, vz, wx, wy, wz));
            }

            pushAlert(new StructuralAlert(
                    "demolish_" + snap.id,
                    "BUILDING_COLLAPSE",
                    String.format(Locale.US, "Kademeli Bina Yıkımı (%d blok, %d kütle — /onar ile geri sar)", failingBlocks, cellMap.size()),
                    blastPos, 0.92
            ));
            saveBlueprintsToDisk(world.getServer());
        }

        return String.format(Locale.US,
                "Kademeli Yapısal Yıkım Tetiklendi: %d blok / %d rijit kütle çöküyor! (/onar ile 100%% geri sarılır)",
                failingBlocks, cellMap.size());
    }

    private static void tickCompoundClusters(ServerWorld world) {
        if (COMPOUND_CLUSTERS.isEmpty()) return;
        final double dt = 0.05;
        BlockPos.Mutable mp = new BlockPos.Mutable();

        for (CompoundClusterBody cb : COMPOUND_CLUSTERS) {
            cb.prevPx = cb.px; cb.prevPy = cb.py; cb.prevPz = cb.pz;
            cb.prevQuat.set(cb.quat);
            if (cb.delayTicks > 0) {
                cb.delayTicks--;
                continue;
            }
            cb.ageTicks++;
            cb.vy -= G * dt;
            cb.vx *= 0.992;
            cb.vz *= 0.992;
            cb.px += cb.vx * dt;
            cb.py += cb.vy * dt;
            cb.pz += cb.vz * dt;

            float hdt = (float) (0.5 * dt);
            float qx = cb.quat.x, qy = cb.quat.y, qz = cb.quat.z, qw = cb.quat.w;
            float owx = (float) cb.wx, owy = (float) cb.wy, owz = (float) cb.wz;
            cb.quat.set(
                    qx + hdt * (owx * qw + owy * qz - owz * qy),
                    qy + hdt * (owy * qw + owz * qx - owx * qz),
                    qz + hdt * (owz * qw + owx * qy - owy * qx),
                    qw + hdt * (-owx * qx - owy * qy - owz * qz)
            ).normalize();

            int gx = (int) Math.floor(cb.px);
            int gy = (int) Math.floor(cb.py - 1.1);
            int gz = (int) Math.floor(cb.pz);
            boolean hitGround = gy <= world.getBottomY() + 1;
            if (!hitGround && world.isChunkLoaded(gx >> 4, gz >> 4)) {
                BlockState below = world.getBlockState(mp.set(gx, gy, gz));
                if (!below.isAir() && !below.getCollisionShape(world, mp).isEmpty()) {
                    hitGround = true;
                }
            }

            if (hitGround || cb.ageTicks > 110) {
                BlockPos impactPos = BlockPos.ofFloored(cb.px, cb.py, cb.pz);
                world.playSound(null, impactPos, SoundEvents.BLOCK_DEEPSLATE_BRICKS_BREAK, SoundCategory.BLOCKS, 0.85f, 0.65f);
                world.spawnParticles(ParticleTypes.CLOUD, cb.px, cb.py + 0.5, cb.pz, 10, 1.2, 0.4, 1.2, 0.04);

                StructureBlueprintSnapshot snap = findBlueprintById(cb.blueprintId);
                Vector3f rVec = new Vector3f();
                for (RelBlock rb : cb.blocks) {
                    rVec.set(rb.dx(), rb.dy(), rb.dz());
                    cb.quat.transform(rVec);
                    BlockPos worldTarget = BlockPos.ofFloored(cb.px + rVec.x, cb.py + Math.max(0.0f, rVec.y * 0.5f), cb.pz + rVec.z);
                    if (RIGID_BODIES.size() < MAX_LIVE_RIGID_BODIES && world.random.nextFloat() < 0.42f) {
                        double spVx = cb.vx * 0.45 + (world.random.nextDouble() - 0.5) * 3.8;
                        double spVy = Math.min(2.6, Math.abs(cb.vy) * 0.22 + world.random.nextDouble() * 1.4);
                        double spVz = cb.vz * 0.45 + (world.random.nextDouble() - 0.5) * 3.8;
                        PhysicsRigidBody prb = spawnRigidBodyDirect(world, worldTarget, rb.state(), spVx, spVy, spVz);
                        prb.fromSurfaceDemolition = true;
                    } else {
                        depositBlockOntoRubbleMound(world, worldTarget, rb.state(), snap);
                    }
                }
                COMPOUND_CLUSTERS.remove(cb);
            }
        }
    }

    private static StructureBlueprintSnapshot findBlueprintById(String id) {
        if (id == null) return SAVED_BLUEPRINTS.isEmpty() ? null : SAVED_BLUEPRINTS.get(SAVED_BLUEPRINTS.size() - 1);
        for (StructureBlueprintSnapshot s : SAVED_BLUEPRINTS) {
            if (id.equals(s.id)) return s;
        }
        return SAVED_BLUEPRINTS.isEmpty() ? null : SAVED_BLUEPRINTS.get(SAVED_BLUEPRINTS.size() - 1);
    }

    private static void depositBlockOntoRubbleMound(ServerWorld world, BlockPos approx, BlockState st, StructureBlueprintSnapshot snap) {
        if (st == null || st.isAir() || isNonStructuralDecor(st)) return;
        int x = approx.getX(), z = approx.getZ();
        if (!world.isChunkLoaded(x >> 4, z >> 4)) return;
        int y = Math.max(61, approx.getY() - 6);
        BlockPos.Mutable mp = new BlockPos.Mutable();
        while (y > 60 && world.getBlockState(mp.set(x, y - 1, z)).isAir()) y--;
        int guard = 0;
        while (guard++ < 28 && !world.getBlockState(mp.set(x, y, z)).isAir()) {
            int bestNx = x, bestNz = z, lowestY = y;
            for (Direction d : Direction.Type.HORIZONTAL) {
                int nx = x + d.getOffsetX(), nz = z + d.getOffsetZ();
                if (!world.isChunkLoaded(nx >> 4, nz >> 4)) continue;
                if (world.getBlockState(mp.set(nx, y - 1, nz)).isAir()) {
                    bestNx = nx; bestNz = nz; lowestY = y - 1;
                    break;
                }
            }
            if (lowestY < y) {
                x = bestNx; z = bestNz; y = lowestY;
            } else {
                y++;
            }
        }
        BlockPos target = new BlockPos(x, y, z);
        if (isProtectedInfrastructure(target, world.getBlockState(target))) return;
        if (world.getBlockState(target).isAir()) {
            world.setBlockState(target, st, Block.NOTIFY_ALL);
            if (snap != null) snap.depositedRubble.add(target);
        }
    }

    // ==================== 3. TERZAGHI ARCHING + NADAL EN 14363 TUNNEL GEOTECHNICS ====================
    private static void updateTunnelGeotechnicsAndNadal(ServerWorld world) {
        boolean raining = world.isRaining();
        boolean thundering = world.isThundering();
        int rainLvl = raining ? Math.max(1, ArenaContent.rainIntensity) : 0;
        int thunderLvl = thundering ? Math.max(1, ArenaContent.thunderIntensity) : 0;

        double maxUw = 0.0;
        double maxWaterMm = 0.0;
        double minFos = 9.9;
        int critZ = 800;

        for (TunnelRingState ring : TUNNEL_RINGS) {
            boolean isStationBox = (ring.centerZ < TUNNEL_Z_START) || (ring.centerZ > TUNNEL_Z_END);
            boolean chunkLoaded = world.isChunkLoaded(-2, ring.cz);
            if (chunkLoaded) {
                int topY = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, -18, ring.centerZ);
                ring.coverDepthM = Math.max(3.0, topY - 53.0);
            }

            double depthAtten = Math.max(0.28, Math.min(1.30, 14.0 / ring.coverDepthM));
            if (raining || thundering) {
                double targetUw = (13.0 * rainLvl + 10.0 * thunderLvl) * depthAtten;
                ring.poreWaterKpa = ring.poreWaterKpa + (targetUw - ring.poreWaterKpa) * 0.035;
            } else {
                ring.poreWaterKpa *= 0.95;
                if (ring.poreWaterKpa < 0.2) ring.poreWaterKpa = 0.0;
            }
            maxUw = Math.max(maxUw, ring.poreWaterKpa);

            if (isStationBox) {
                ring.factorOfSafety = 2.85;
                continue;
            }

            // Darcy + Cubic Fracture seepage accumulation vs sump pump drainage (mm ATR)
            double inflowMm = (ring.poreWaterKpa > 28.0 && ring.crackStage >= 1)
                    ? ((ring.poreWaterKpa - 28.0) * (ring.crackStage >= 2 ? 0.16 : 0.045))
                    : 0.0;
            double drainMm = (raining || thundering) ? 0.35 : 1.80;
            double seepageMm = Math.max(0.0, Math.min(260.0, ring.waterDepthMm + inflowMm - drainMm));

            // Also sample real physical water blocks placed/leaked on the rails in loaded chunks!
            if (chunkLoaded) {
                double physMm = 0.0;
                BlockPos.Mutable wmp = new BlockPos.Mutable();
                for (int dz = -6; dz <= 6; dz += 3) {
                    for (int dx = -19; dx <= -17; dx++) {
                        for (int dy = 0; dy <= 1; dy++) {
                            FluidState fs = world.getFluidState(wmp.set(dx, 48 + dy, ring.centerZ + dz));
                            if (fs.isIn(FluidTags.WATER)) {
                                physMm = Math.max(physMm, dy * 250.0 + fs.getLevel() * 32.0);
                            }
                        }
                    }
                }
                ring.waterDepthMm = Math.max(seepageMm, physMm);
            } else {
                ring.waterDepthMm = seepageMm;
            }
            maxWaterMm = Math.max(maxWaterMm, ring.waterDepthMm);

            // Subgrade suction loss & ballast softening under flooding (Hasnayn 2016; Kaewunruen 2019)
            if (ring.waterDepthMm >= 40.0) {
                ring.settlementMm = Math.min(42.0, ring.settlementMm + 0.04 * (ring.waterDepthMm / 50.0));
            }

            // Terzaghi Rock Arching Theory: loosening arch height Hp bounded at 18.5m!
            double hpArchM = Math.min(ring.coverDepthM, 18.5);
            double seamWave = 0.88 + 0.14 * Math.sin(ring.centerZ * 0.037) * Math.cos(ring.centerZ * 0.013);
            double staticArchKpa = (18.5 * hpArchM) * 0.24;
            double verticalDemandKpa = staticArchKpa + ring.liveBoussinesqKpa + ring.trainDynamicKpa + ring.seismicKpa;

            double effectiveNormalKpa = Math.max(28.0, 96.0 + 0.42 * staticArchKpa - 1.15 * ring.poreWaterKpa);
            double cohesionKpa = (118.0 * seamWave) * (1.0 - 0.48 * ring.fatigueDamage);
            double shearCapKpa = cohesionKpa + effectiveNormalKpa * Math.tan(Math.toRadians(33.0));

            double fos = shearCapKpa / Math.max(22.0, verticalDemandKpa);
            ring.factorOfSafety = Math.max(0.55, Math.min(3.50, fos));

            if (ring.factorOfSafety < minFos) {
                minFos = ring.factorOfSafety;
                critZ = ring.centerZ;
            }

            if (ring.factorOfSafety < 1.24) {
                ring.fatigueDamage = Math.min(1.0, ring.fatigueDamage + (1.24 - ring.factorOfSafety) * 0.022);
                ring.settlementMm = Math.min(38.0, Math.max(ring.settlementMm, ring.fatigueDamage * 34.0));
            }

            int desiredStage = ring.crackStage;
            if (ring.factorOfSafety < 0.96 || ring.fatigueDamage > 0.88) {
                desiredStage = Math.max(desiredStage, 2);
            } else if (ring.factorOfSafety < 1.22 || ring.fatigueDamage > 0.36) {
                desiredStage = Math.max(desiredStage, 1);
            }

            // Red emergency lights activate STRICTLY on genuinely damaged (stage>=2) or flooded (>=85mm ATR) rings!
            boolean wantEmergency = (desiredStage >= 2) || (ring.waterDepthMm >= 85.0);
            if (wantEmergency != ring.emergencyLedActive) {
                ring.emergencyLedActive = wantEmergency;
                setRingEmergencyLights(world, ring.cz, wantEmergency);
            }
            if (ring.waterDepthMm >= 85.0) {
                pushAlert(new StructuralAlert(
                        "flood_" + ring.cz,
                        "TRACK_FLOOD",
                        String.format(Locale.US, "Ray Su Taşkını Z=%dm (h=%.0fmm — Hidrodinamik Fren!)",
                                ring.centerZ, ring.waterDepthMm),
                        new BlockPos(-18, 48, ring.centerZ), 0.90
                ));
            } else {
                ACTIVE_ALERTS.removeIf(a -> a.id.equals("flood_" + ring.cz));
            }

            if (desiredStage != ring.crackStage) {
                ring.crackStage = desiredStage;
                if (desiredStage >= 2) {
                    if (chunkLoaded) {
                        triggerTunnelCrownSpall(world, ring);
                    }
                    pushAlert(new StructuralAlert(
                            "ring_" + ring.cz,
                            "TUNNEL_COLLAPSE",
                            String.format(Locale.US, "Tünel Z=%dm Kemer Çökmesi (FoS=%.2f, u_w=%.0fkPa)",
                                    ring.centerZ, ring.factorOfSafety, ring.poreWaterKpa),
                            new BlockPos(-18, 52, ring.centerZ), 0.95
                    ));
                } else if (desiredStage == 1) {
                    pushAlert(new StructuralAlert(
                            "ring_" + ring.cz,
                            "TUNNEL_CRACK",
                            String.format(Locale.US, "Tünel Z=%dm Kemer Çatlağı (FoS=%.2f, oturma=%.1fmm)",
                                    ring.centerZ, ring.factorOfSafety, ring.settlementMm),
                            new BlockPos(-18, 52, ring.centerZ), 0.65
                    ));
                }
            }
        }

        // EN 14363 / UIC 518 Nadal Flange-Climb + Ohyama-Chen EHL Adhesion + Archimedes Buoyancy Unloading!
        double tan68 = Math.tan(Math.toRadians(68.0));
        double peakYq = 0.14;
        for (ArenaMapData.LiveTrainInfo t : ArenaMapData.getLiveTrains()) {
            TunnelRingState tr = getRingForZ(t.z);
            double waterMm = (tr != null) ? tr.waterDepthMm : 0.0;
            double vMps = Math.max(0.0, t.speedKmh / 3.6);
            double mu = (waterMm > 2.0 || raining || thundering)
                    ? (0.24 * Math.exp(-0.022 * vMps * Math.sqrt(1.0 + waterMm / 15.0)) + 0.07)
                    : 0.32;
            double nadalLimit = (tan68 - mu) / (1.0 + mu * tan68);
            double buoyUnloading = Math.min(0.28, (waterMm / 450.0) * 0.25);

            double vRatio = Math.max(0.0, t.speedKmh / 80.0);
            double settle = (tr != null) ? tr.settlementMm : 0.0;
            int stage = (tr != null) ? tr.crackStage : 0;
            double baseYq = 0.08 + 0.14 * vRatio * vRatio + 0.014 * settle * vRatio
                    + (stage >= 2 ? 0.88 : (stage == 1 ? 0.28 : 0.0))
                    + (waterMm > 60.0 ? 0.22 * vRatio : 0.0);
            double yq = baseYq / Math.max(0.70, 1.0 - buoyUnloading);
            peakYq = Math.max(peakYq, yq);
            if (tr != null && yq > nadalLimit && t.speedKmh > 28.0 && (stage >= 2 || waterMm >= 115.0)) {
                pushAlert(new StructuralAlert(
                        "nadal_" + tr.cz,
                        "TRAIN_DERAIL_RISK",
                        String.format(Locale.US, "ATP Hidrodinamik/Nadal Fren! Z=%dm Y/Q=%.2f (μ=%.2f, h=%.0fmm)",
                                (int) Math.round(t.z), yq, mu, waterMm),
                        new BlockPos(-18, 49, (int) Math.round(t.z)), 0.96
                ));
            }
        }
        latestNadalYq = peakYq;
        latestMaxPoreWaterKpa = maxUw;
        latestMaxWaterDepthMm = maxWaterMm;
        latestMinTunnelFos = minFos;
        latestCriticalRingZ = critZ;
    }

    public static void onLightningStrike(ServerWorld world, BlockPos strikePos, int thunderIntensity) {
        if (world == null || strikePos == null) return;
        double eWave = 18.0 + thunderIntensity * 9.5;
        for (TunnelRingState ring : TUNNEL_RINGS) {
            double dx = strikePos.getX() - (-18.0);
            double dy = strikePos.getY() - 53.0;
            double dz = strikePos.getZ() - ring.centerZ;
            double r = Math.max(4.0, Math.sqrt(dx * dx + dy * dy + dz * dz));
            if (r < 95.0) {
                double pulseKpa = (eWave * 24.0) / (r * Math.pow(r / 10.0, 0.45));
                ring.seismicKpa = Math.min(72.0, ring.seismicKpa + pulseKpa);
            }
        }
    }

    public static void triggerTunnelCrownSpall(ServerWorld world, TunnelRingState ring) {
        int cz = ring.centerZ;
        int[][] offsets = { {-20, 52, -2}, {-16, 52, 1}, {-19, 53, 0}, {-17, 53, 3} };
        for (int[] off : offsets) {
            BlockPos bp = new BlockPos(off[0], off[1], cz + off[2]);
            if (!world.isChunkLoaded(bp.getX() >> 4, bp.getZ() >> 4)) continue;
            BlockState st = world.getBlockState(bp);
            if (st.isOf(Blocks.STONE_BRICKS) || st.isOf(Blocks.DEEPSLATE_BRICKS) || st.isOf(Blocks.STONE)) {
                detachBlockAsLiveRigidBody(world, bp, (world.random.nextDouble() - 0.5) * 1.4, -0.8, (world.random.nextDouble() - 0.5) * 1.4);
            }
        }
        world.playSound(null, new BlockPos(-18, 51, cz), SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.BLOCKS, 0.65f, 0.55f);
    }

    public static void syncStormEmergencyLights(ServerWorld world, boolean emergency) {
        if (world == null) return;
        // Never activate red emergency lights on undamaged, unflooded tunnel rings!
        for (TunnelRingState r : TUNNEL_RINGS) {
            boolean actuallyHazardous = (r.crackStage >= 2) || (r.waterDepthMm >= 85.0);
            if (r.emergencyLedActive != actuallyHazardous) {
                r.emergencyLedActive = actuallyHazardous;
                setRingEmergencyLights(world, r.cz, actuallyHazardous);
            }
        }
    }

    public static void setRingEmergencyLights(ServerWorld world, int cz, boolean emergency) {
        if (!world.isChunkLoaded(-2, cz) && !world.isChunkLoaded(-1, cz)) return;
        int z0 = cz << 4, z1 = z0 + 15;
        BlockPos.Mutable mp = new BlockPos.Mutable();
        for (int z = z0; z <= z1; z++) {
            for (int y = 48; y <= 56; y++) {
                for (int x = -21; x <= -15; x++) {
                    if (!world.isChunkLoaded(x >> 4, z >> 4)) continue;
                    BlockState st = world.getBlockState(mp.set(x, y, z));
                    if (st.isOf(ArenaContent.TUNNEL_EMERGENCY_LIGHT) && st.get(ArenaContent.EMERGENCY) != emergency) {
                        world.setBlockState(mp, st.with(ArenaContent.EMERGENCY, emergency), Block.NOTIFY_LISTENERS);
                    }
                }
            }
        }
    }

    // ==================== 4. EULER BUCKLING & P-DELTA COLUMN AUDIT ====================
    private static void auditStructuralColumnsAroundPlayers(ServerWorld world) {
        double worstDcr = 0.04;
        double worstFos = 20.0;
        int worstH = 0;
        BlockPos.Mutable mp = new BlockPos.Mutable();

        for (ServerPlayerEntity p : world.getPlayers()) {
            BlockPos center = p.getBlockPos();
            if (center.getY() < 60) continue;

            for (int i = 0; i < 8; i++) {
                int sx = center.getX() + world.random.nextInt(33) - 16;
                int sz = center.getZ() + world.random.nextInt(33) - 16;
                if (!world.isChunkLoaded(sx >> 4, sz >> 4)) continue;
                int topY = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, sx, sz) - 1;
                if (topY < 64) continue;

                BlockState topState = world.getBlockState(mp.set(sx, topY, sz));
                if (isNaturalTerrain(topState) || isProtectedInfrastructure(mp, topState)) continue;

                int colH = 0;
                int slenderY = topY;
                for (int y = topY - 1; y >= Math.max(58, topY - 26); y--) {
                    BlockState bs = world.getBlockState(mp.set(sx, y, sz));
                    if (bs.isAir()) break;
                    boolean freeX = world.getBlockState(mp.set(sx + 1, y, sz)).isAir()
                            && world.getBlockState(mp.set(sx - 1, y, sz)).isAir();
                    boolean freeZ = world.getBlockState(mp.set(sx, y, sz + 1)).isAir()
                            && world.getBlockState(mp.set(sx, y, sz - 1)).isAir();
                    if (freeX || freeZ) {
                        colH++;
                        slenderY = y;
                    } else {
                        break;
                    }
                }

                if (colH >= 5) {
                    boolean wood = topState.isIn(BlockTags.PLANKS) || topState.isIn(BlockTags.LOGS) || topState.isIn(BlockTags.FENCES);
                    double eModPa = wood ? 9.5e9 : 24.0e9;
                    double inertiaM4 = topState.isIn(BlockTags.FENCES) ? 0.0012 : 0.042;
                    double kEff = 1.25;
                    double lEff = kEff * colH;
                    double pCritKn = ((Math.PI * Math.PI * eModPa * inertiaM4) / (lEff * lEff)) / 1000.0;

                    double tribMassKg = 0.0;
                    for (int dx = -2; dx <= 2; dx++) {
                        for (int dz = -2; dz <= 2; dz++) {
                            for (int dy = 0; dy <= 5; dy++) {
                                BlockState us = world.getBlockState(mp.set(sx + dx, slenderY + colH + dy, sz + dz));
                                if (!us.isAir()) tribMassKg += estimateBlockMassKg(us);
                            }
                        }
                    }
                    double axialLoadKn = (tribMassKg * G) / 1000.0;
                    double windShearKn = (world.isThundering() ? 14.0 : (world.isRaining() ? 5.0 : 1.0)) * (colH * 0.35);
                    double dcr = (axialLoadKn / Math.max(15.0, pCritKn)) + (windShearKn * colH) / Math.max(40.0, pCritKn * 0.45);
                    double fos = 1.0 / Math.max(0.05, dcr);

                    if (dcr > worstDcr) {
                        worstDcr = dcr;
                        worstFos = fos;
                        worstH = colH;
                    }
                }
            }
        }

        latestNearestColumnDcr = Math.min(2.5, worstDcr);
        latestNearestColumnFos = Math.min(20.0, worstFos);
        latestNearestColumnHeight = worstH;
    }

    public static void initiateBuildingTilt(ServerWorld world, BlockPos baseHinge, int height) {
        if (TILTING_STRUCTURES.size() >= 3) return;
        for (TiltingStructureBody ex : TILTING_STRUCTURES) {
            if (ex.hinge.isWithinDistance(baseHinge, 8.0)) return;
        }

        List<RelBlock> captured = new ArrayList<>();
        double sumMass = 0.0;
        double sumMy = 0.0;
        int maxCap = 220;

        for (int dy = 0; dy <= Math.min(18, height + 5) && captured.size() < maxCap; dy++) {
            for (int dx = -4; dx <= 4 && captured.size() < maxCap; dx++) {
                for (int dz = -4; dz <= 4 && captured.size() < maxCap; dz++) {
                    BlockPos bp = baseHinge.add(dx, dy, dz);
                    BlockState st = world.getBlockState(bp);
                    if (st.isAir() || st.hasBlockEntity() || isProtectedInfrastructure(bp, st) || isNaturalTerrain(st)) continue;
                    double m = estimateBlockMassKg(st);
                    captured.add(new RelBlock(dx, dy, dz, st));
                    sumMass += m;
                    sumMy += m * (dy + 0.5);
                    world.setBlockState(bp, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);
                }
            }
        }

        if (captured.size() < 6) {
            for (RelBlock rb : captured) {
                world.setBlockState(baseHinge.add(rb.dx(), rb.dy(), rb.dz()), rb.state(), Block.NOTIFY_ALL);
            }
            return;
        }

        double comH = sumMy / Math.max(1.0, sumMass);
        String id = "tilt_" + baseHinge.getX() + "_" + baseHinge.getZ();
        TiltingStructureBody body = new TiltingStructureBody(id, baseHinge, captured, sumMass, comH);
        body.velXRad = 0.035;
        TILTING_STRUCTURES.add(body);

        pushAlert(new StructuralAlert(
                id,
                "BUILDING_TILT",
                String.format(Locale.US, "Bina P-Delta Eğilmesi (%d,%d,%d — %.0f ton)",
                        baseHinge.getX(), baseHinge.getY(), baseHinge.getZ(), sumMass / 1000.0),
                baseHinge, 0.88
        ));
    }

    private static void tickTiltingStructures(ServerWorld world) {
        if (TILTING_STRUCTURES.isEmpty()) return;
        final double dt = 0.05;
        boolean storm = world.isThundering();

        for (TiltingStructureBody b : TILTING_STRUCTURES) {
            b.prevTiltXRad = b.tiltXRad;
            b.prevTiltZRad = b.tiltZRad;
            b.ageTicks++;

            double inertia = b.totalMassKg * (b.comHeightM * b.comHeightM + 1.8);
            double kRot = b.totalMassKg * G * b.comHeightM * 1.42;
            double cDamp = 2.0 * 0.34 * Math.sqrt(kRot * inertia);

            double windMoment = storm ? (b.totalMassKg * 0.42 * (0.7 + 0.3 * Math.sin(b.ageTicks * 0.18))) : 0.0;
            double gravityPDeltaX = b.totalMassKg * G * b.comHeightM * Math.sin(b.tiltXRad);
            double resistX = -kRot * (b.tiltXRad - b.plasticYieldRadX) - cDamp * b.velXRad;
            double alphaX = (gravityPDeltaX + windMoment + resistX) / inertia;

            b.velXRad += alphaX * dt;
            b.tiltXRad = MathHelper.clamp(b.tiltXRad + b.velXRad * dt, -0.42, 0.42);
            if (Math.abs(b.tiltXRad) > Math.abs(b.plasticYieldRadX) + 0.02) {
                b.plasticYieldRadX = b.tiltXRad * 0.58;
            }
        }
    }

    // ==================== 5. 6-DoF QUATERNION RIGID-BODY SOLVER (80 HZ) ====================
    private static PhysicsRigidBody spawnRigidBodyDirect(ServerWorld world, BlockPos pos, BlockState st, double vx, double vy, double vz) {
        if (RIGID_BODIES.size() >= MAX_LIVE_RIGID_BODIES) {
            PhysicsRigidBody oldest = RIGID_BODIES.remove(0);
            if (oldest.fromSurfaceDemolition) {
                depositBlockOntoRubbleMound(world, BlockPos.ofFloored(oldest.px, oldest.py, oldest.pz), oldest.state,
                        SAVED_BLUEPRINTS.isEmpty() ? null : SAVED_BLUEPRINTS.get(SAVED_BLUEPRINTS.size() - 1));
            }
        }
        double wx = (world.random.nextDouble() - 0.5) * 5.6;
        double wy = (world.random.nextDouble() - 0.5) * 4.0;
        double wz = (world.random.nextDouble() - 0.5) * 5.6;
        PhysicsRigidBody rb = new PhysicsRigidBody(pos, st, vx, vy, vz, wx, wy, wz);
        RIGID_BODIES.add(rb);
        return rb;
    }

    public static void detachBlockAsLiveRigidBody(ServerWorld world, BlockPos pos, double vx, double vy, double vz) {
        BlockState st = world.getBlockState(pos);
        if (st.isAir() || st.hasBlockEntity() || st.isOf(Blocks.BEDROCK)) return;
        world.setBlockState(pos, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);
        spawnRigidBodyDirect(world, pos, st, vx, vy, vz);
    }

    private static void tickRigidBodies(ServerWorld world) {
        if (RIGID_BODIES.isEmpty()) return;
        final double dtSub = 0.05 / SUBSTEPS;
        final double[][] unitCorners = {
                {-0.46, -0.46, -0.46}, {0.46, -0.46, -0.46}, {-0.46, 0.46, -0.46}, {0.46, 0.46, -0.46},
                {-0.46, -0.46,  0.46}, {0.46, -0.46,  0.46}, {-0.46, 0.46,  0.46}, {0.46, 0.46,  0.46}
        };
        Vector3f tmp = new Vector3f();
        BlockPos.Mutable mp = new BlockPos.Mutable();

        for (PhysicsRigidBody rb : RIGID_BODIES) {
            rb.prevPx = rb.px;
            rb.prevPy = rb.py;
            rb.prevPz = rb.pz;
            rb.prevQuat.set(rb.quat);
            rb.ageTicks++;

            if (rb.sleeping) {
                if (rb.ageTicks > 24) {
                    RIGID_BODIES.remove(rb);
                    StructureBlueprintSnapshot targetSnap = null;
                    if (rb.blueprintId != null) {
                        for (StructureBlueprintSnapshot s : SAVED_BLUEPRINTS) {
                            if (rb.blueprintId.equals(s.id)) { targetSnap = s; break; }
                        }
                    } else if (rb.fromSurfaceDemolition && !SAVED_BLUEPRINTS.isEmpty()) {
                        targetSnap = SAVED_BLUEPRINTS.get(SAVED_BLUEPRINTS.size() - 1);
                    }
                    BlockState rotState = ConstitutiveMaterialDB.rotateStateByQuaternion(rb.state, rb.quat, false);
                    depositBlockOntoRubbleMound(world, BlockPos.ofFloored(rb.px, rb.py, rb.pz), rotState, targetSnap);
                }
                continue;
            }
            if (!world.isChunkLoaded(((int) Math.floor(rb.px)) >> 4, ((int) Math.floor(rb.pz)) >> 4)) continue;

            boolean hitHardThisTick = false;
            for (int step = 0; step < SUBSTEPS; step++) {
                boolean submerged = world.getFluidState(mp.set((int) Math.floor(rb.px), (int) Math.floor(rb.py), (int) Math.floor(rb.pz))).isIn(FluidTags.WATER);
                double effG = submerged ? (G * (1.0 - 1000.0 / Math.max(400.0, rb.massKg))) : G;
                double linDrag = submerged ? 0.92 : 0.995;
                rb.vy -= effG * dtSub;
                rb.vx *= linDrag;
                rb.vy *= (submerged ? 0.90 : 0.998);
                rb.vz *= linDrag;
                rb.wx *= (submerged ? 0.92 : 0.985);
                rb.wy *= (submerged ? 0.92 : 0.985);
                rb.wz *= (submerged ? 0.92 : 0.985);

                rb.px += rb.vx * dtSub;
                rb.py += rb.vy * dtSub;
                rb.pz += rb.vz * dtSub;

                float hdt = (float) (0.5 * dtSub);
                float qx = rb.quat.x, qy = rb.quat.y, qz = rb.quat.z, qw = rb.quat.w;
                float owx = (float) rb.wx, owy = (float) rb.wy, owz = (float) rb.wz;
                rb.quat.set(
                        qx + hdt * (owx * qw + owy * qz - owz * qy),
                        qy + hdt * (owy * qw + owz * qx - owx * qz),
                        qz + hdt * (owz * qw + owx * qy - owy * qx),
                        qw + hdt * (-owx * qx - owy * qy - owz * qz)
                ).normalize();

                for (double[] c : unitCorners) {
                    tmp.set((float) c[0], (float) c[1], (float) c[2]);
                    rb.quat.transform(tmp);
                    double cx = rb.px + tmp.x;
                    double cy = rb.py + tmp.y;
                    double cz = rb.pz + tmp.z;

                    int bx = (int) Math.floor(cx);
                    int by = (int) Math.floor(cy);
                    int bz = (int) Math.floor(cz);
                    if (!world.isChunkLoaded(bx >> 4, bz >> 4)) continue;
                    BlockState hitState = world.getBlockState(mp.set(bx, by, bz));
                    if (hitState.isAir() || hitState.getCollisionShape(world, mp).isEmpty()) continue;

                    double boxTop = by + hitState.getCollisionShape(world, mp).getMax(Direction.Axis.Y);
                    if (cy > boxTop) continue;

                    double penY = boxTop - cy;
                    double penX0 = cx - bx;
                    double penX1 = (bx + 1.0) - cx;
                    double penZ0 = cz - bz;
                    double penZ1 = (bz + 1.0) - cz;

                    double nx = 0.0, ny = 1.0, nz = 0.0;
                    double minPen = penY;
                    if (penX0 < minPen) { minPen = penX0; nx = -1.0; ny = 0.0; nz = 0.0; }
                    if (penX1 < minPen) { minPen = penX1; nx = 1.0;  ny = 0.0; nz = 0.0; }
                    if (penZ0 < minPen) { minPen = penZ0; nx = 0.0;  ny = 0.0; nz = -1.0; }
                    if (penZ1 < minPen) { minPen = penZ1; nx = 0.0;  ny = 0.0; nz = 1.0; }

                    rb.px += nx * minPen * 0.65;
                    rb.py += ny * minPen * 0.65;
                    rb.pz += nz * minPen * 0.65;

                    double rx = tmp.x, ry = tmp.y, rz = tmp.z;
                    double vpx = rb.vx + (rb.wy * rz - rb.wz * ry);
                    double vpy = rb.vy + (rb.wz * rx - rb.wx * rz);
                    double vpz = rb.vz + (rb.wx * ry - rb.wy * rx);
                    double vn = vpx * nx + vpy * ny + vpz * nz;

                    if (vn < 0.0) {
                        if (vn < -2.6) hitHardThisTick = true;
                        double rcnX = ry * nz - rz * ny;
                        double rcnY = rz * nx - rx * nz;
                        double rcnZ = rx * ny - ry * nx;
                        double angTerm = rb.invInertia * (rcnX * rcnX + rcnY * rcnY + rcnZ * rcnZ);
                        double rest = (-vn < 0.9) ? 0.0 : rb.restitution;
                        double jn = -(1.0 + rest) * vn / (rb.invMass + angTerm);

                        rb.vx += (jn * nx) * rb.invMass;
                        rb.vy += (jn * ny) * rb.invMass;
                        rb.vz += (jn * nz) * rb.invMass;
                        rb.wx += (rcnX * jn) * rb.invInertia;
                        rb.wy += (rcnY * jn) * rb.invInertia;
                        rb.wz += (rcnZ * jn) * rb.invInertia;

                        double tx = vpx - vn * nx, ty = vpy - vn * ny, tz = vpz - vn * nz;
                        double tLen = Math.sqrt(tx * tx + ty * ty + tz * tz);
                        if (tLen > 1e-4) {
                            tx /= tLen; ty /= tLen; tz /= tLen;
                            double jt = -tLen / (rb.invMass + angTerm);
                            double maxJt = rb.friction * jn;
                            jt = MathHelper.clamp(jt, -maxJt, maxJt);
                            rb.vx += (jt * tx) * rb.invMass;
                            rb.vy += (jt * ty) * rb.invMass;
                            rb.vz += (jt * tz) * rb.invMass;
                            rb.wx += ((ry * tz - rz * ty) * jt) * rb.invInertia;
                            rb.wy += ((rz * tx - rx * tz) * jt) * rb.invInertia;
                            rb.wz += ((rx * ty - ry * tx) * jt) * rb.invInertia;
                        }
                    }
                }
            }

            if (hitHardThisTick) {
                BlockPos ip = BlockPos.ofFloored(rb.px, rb.py, rb.pz);
                world.playSound(null, ip, rb.state.getSoundGroup().getFallSound(), SoundCategory.BLOCKS, 0.55f, 0.82f);
            }

            double speedSq = rb.vx * rb.vx + rb.vy * rb.vy + rb.vz * rb.vz;
            double rotSq = rb.wx * rb.wx + rb.wy * rb.wy + rb.wz * rb.wz;
            if (speedSq < 0.003 && rotSq < 0.010) {
                rb.lowEnergyTicks++;
                if (rb.lowEnergyTicks > 14) {
                    rb.vx = rb.vy = rb.vz = 0.0;
                    rb.wx = rb.wy = rb.wz = 0.0;
                    rb.sleeping = true;
                }
            } else {
                rb.lowEnergyTicks = 0;
            }
        }
    }

    // ==================== 6. CHUNK-SAFE REPAIR, DISK PERSISTENCE & API ====================
    private static void processPendingRingHeals(ServerWorld world) {
        for (TunnelRingState ring : TUNNEL_RINGS) {
            if (!ring.pendingChunkHeal) continue;
            if (!world.isChunkLoaded(-2, ring.cz)) continue;
            ring.pendingChunkHeal = false;
            setRingEmergencyLights(world, ring.cz, false);
            int[][] offsets = { {-20, 52, -2}, {-16, 52, 1}, {-19, 53, 0}, {-17, 53, 3} };
            for (int[] off : offsets) {
                BlockPos bp = new BlockPos(off[0], off[1], ring.centerZ + off[2]);
                if (world.getBlockState(bp).isAir()) {
                    world.setBlockState(bp, Blocks.STONE_BRICKS.getDefaultState(), Block.NOTIFY_ALL);
                }
            }
        }
    }

    public static int repairStructuralDamageNear(ServerWorld world, BlockPos center, double radius) {
        int repaired = 0;

        // 0. Rewind modular 6-DoF FEM blueprints & rotated rubble!
        if (!FractureAndSolidifier.BLUEPRINTS.isEmpty() || !FractureAndSolidifier.GLOBAL_DEPOSITED_RUBBLE.isEmpty()
                || !RigidBody6DoFDynamics.ACTIVE_BODIES.isEmpty()) {
            FractureAndSolidifier.rewindAllBlueprints(world);
            ACTIVE_ALERTS.removeIf(a -> a.id.startsWith("fem_"));
            repaired++;
        }

        // 1. Rewind collapsed building blueprints & clear rubble piles within radius!
        COMPOUND_CLUSTERS.removeIf(cb -> cb.originCenter.isWithinDistance(center, radius + 32.0));
        for (StructureBlueprintSnapshot snap : new ArrayList<>(SAVED_BLUEPRINTS)) {
            if (snap.center.isWithinDistance(center, radius + 32.0)) {
                for (BlockPos rp : snap.depositedRubble) {
                    if (world.isChunkLoaded(rp.getX() >> 4, rp.getZ() >> 4)) {
                        world.setBlockState(rp, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);
                    }
                }
                List<Map.Entry<BlockPos, BlockState>> entries = new ArrayList<>(snap.originalBlocks.entrySet());
                entries.sort(Comparator.comparingInt(e -> e.getKey().getY()));
                for (Map.Entry<BlockPos, BlockState> e : entries) {
                    BlockPos p = e.getKey();
                    if (world.isChunkLoaded(p.getX() >> 4, p.getZ() >> 4)) {
                        world.setBlockState(p, e.getValue(), Block.NOTIFY_ALL);
                    }
                }
                SAVED_BLUEPRINTS.remove(snap);
                ACTIVE_ALERTS.removeIf(a -> a.id.equals("demolish_" + snap.id));
                repaired++;
            }
        }

        // 2. Restore single-block rigid bodies to origin
        for (PhysicsRigidBody rb : new ArrayList<>(RIGID_BODIES)) {
            if (rb.originPos.isWithinDistance(center, radius)) {
                if (!rb.fromSurfaceDemolition && world.isChunkLoaded(rb.originPos.getX() >> 4, rb.originPos.getZ() >> 4)
                        && world.getBlockState(rb.originPos).isAir()) {
                    world.setBlockState(rb.originPos, rb.state, Block.NOTIFY_ALL);
                }
                RIGID_BODIES.remove(rb);
                repaired++;
            }
        }

        // 3. Jack tilting buildings upright
        for (TiltingStructureBody tb : new ArrayList<>(TILTING_STRUCTURES)) {
            if (tb.hinge.isWithinDistance(center, radius)) {
                for (RelBlock rel : tb.blocks) {
                    BlockPos bp = tb.hinge.add(rel.dx(), rel.dy(), rel.dz());
                    world.setBlockState(bp, rel.state(), Block.NOTIFY_ALL);
                }
                TILTING_STRUCTURES.remove(tb);
                ACTIVE_ALERTS.removeIf(a -> a.id.equals(tb.id));
                repaired++;
            }
        }

        // 4. Drain simulated flood water & grout/reinforce tunnel rings (queues unloaded chunks automatically!)
        for (BlockPos wp : new ArrayList<>(SIMULATED_FLOOD_WATER)) {
            if (wp.isWithinDistance(center, radius + 24.0)) {
                if (world.isChunkLoaded(wp.getX() >> 4, wp.getZ() >> 4) && world.getBlockState(wp).isOf(Blocks.WATER)) {
                    world.setBlockState(wp, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);
                }
                SIMULATED_FLOOD_WATER.remove(wp);
                repaired++;
            }
        }
        for (TunnelRingState ring : TUNNEL_RINGS) {
            if (Math.abs(ring.centerZ - center.getZ()) <= radius) {
                if (ring.crackStage > 0 || ring.fatigueDamage > 0.05 || ring.emergencyLedActive || ring.waterDepthMm > 1.0) {
                    ring.crackStage = 0;
                    ring.fatigueDamage = 0.0;
                    ring.settlementMm = 0.0;
                    ring.waterDepthMm = 0.0;
                    ring.poreWaterKpa *= 0.25;
                    ring.factorOfSafety = 2.38;
                    ring.emergencyLedActive = false;
                    if (world.isChunkLoaded(-2, ring.cz)) {
                        setRingEmergencyLights(world, ring.cz, false);
                        int[][] offsets = { {-20, 52, -2}, {-16, 52, 1}, {-19, 53, 0}, {-17, 53, 3} };
                        for (int[] off : offsets) {
                            BlockPos bp = new BlockPos(off[0], off[1], ring.centerZ + off[2]);
                            if (world.getBlockState(bp).isAir()) {
                                world.setBlockState(bp, Blocks.STONE_BRICKS.getDefaultState(), Block.NOTIFY_ALL);
                            }
                        }
                    } else {
                        ring.pendingChunkHeal = true;
                    }
                    ACTIVE_ALERTS.removeIf(a -> a.id.equals("ring_" + ring.cz)
                            || a.id.equals("nadal_" + ring.cz)
                            || a.id.equals("flood_" + ring.cz));
                    repaired++;
                }
            }
        }
        if (radius >= 2000.0) {
            ACTIVE_ALERTS.clear();
            latestMinTunnelFos = 2.38;
            latestMaxWaterDepthMm = 0.0;
            nextStandardizeTunnelCz = 2; // Re-verify all 1,519m tunnel LEDs & liner ribs!
        }
        elevatorBrakeTripped = false;
        saveBlueprintsToDisk(world.getServer());
        world.playSound(null, center, SoundEvents.BLOCK_ANVIL_USE, SoundCategory.BLOCKS, 0.65f, 1.15f);
        return repaired;
    }

    public static String simulateScenario(ServerWorld world, BlockPos playerPos, String mode) {
        String m = mode == null ? "" : mode.toLowerCase(Locale.ROOT);
        if (m.contains("yikim") || m.contains("gokdelen") || m.contains("tnt")) {
            return triggerBlocksworthDemolition(world, playerPos, 4.6);
        } else if (m.contains("su") || m.contains("sel") || m.contains("flood")) {
            TunnelRingState r = getRingForZ(playerPos.getZ());
            if (r == null) r = TUNNEL_RINGS[RING_COUNT / 2];
            r.poreWaterKpa = 68.0;
            r.crackStage = Math.max(1, r.crackStage);
            r.waterDepthMm = 115.0;
            r.emergencyLedActive = true;
            setRingEmergencyLights(world, r.cz, true);
            for (int dz = -3; dz <= 3; dz++) {
                for (int x : new int[]{-19, -17}) {
                    BlockPos wp = new BlockPos(x, 48, r.centerZ + dz);
                    if (world.isChunkLoaded(wp.getX() >> 4, wp.getZ() >> 4) && world.getBlockState(wp).isAir()) {
                        world.setBlockState(wp, Blocks.WATER.getDefaultState(), Block.NOTIFY_ALL);
                        SIMULATED_FLOOD_WATER.add(wp);
                    }
                }
            }
            pushAlert(new StructuralAlert("flood_" + r.cz, "TRACK_FLOOD",
                    "Tünel Z=" + r.centerZ + "m Tavan Sızıntısı & Su Taşkını (h=115mm — Hidrodinamik Fren!)",
                    new BlockPos(-18, 48, r.centerZ), 0.92));
            return "Tavan sızıntısı ve ray su taşkını (h=115 mm ATR) tetiklendi (Z=" + r.centerZ + "m) — Tren yaklaşınca pruva dalgası, EHL kayma ve hidrodinamik fren devreye girer! (/onar ile tahliye edilir)";
        } else if (m.contains("cokme") || m.contains("collapse")) {
            TunnelRingState r = getRingForZ(playerPos.getZ());
            if (r == null) r = TUNNEL_RINGS[RING_COUNT / 2];
            r.poreWaterKpa = 92.0;
            r.seismicKpa = 58.0;
            r.fatigueDamage = 0.92;
            r.crackStage = 2;
            r.factorOfSafety = 0.84;
            r.emergencyLedActive = true;
            setRingEmergencyLights(world, r.cz, true);
            triggerTunnelCrownSpall(world, r);
            pushAlert(new StructuralAlert("ring_" + r.cz, "TUNNEL_COLLAPSE",
                    "Tünel Z=" + r.centerZ + "m Kemer Çökmesi (FoS=0.84)", new BlockPos(-18, 52, r.centerZ), 0.96));
            return "Tünel kemer çökmesi tetiklendi (Z=" + r.centerZ + "m) — 6-DoF kaya blokları düşüyor & ATP Acil Fren aktif!";
        } else if (m.contains("catlak") || m.contains("crack")) {
            TunnelRingState r = getRingForZ(playerPos.getZ());
            if (r == null) r = TUNNEL_RINGS[RING_COUNT / 2];
            r.poreWaterKpa = 64.0;
            r.fatigueDamage = 0.48;
            r.settlementMm = 14.5;
            r.crackStage = 1;
            r.factorOfSafety = 1.14;
            pushAlert(new StructuralAlert("ring_" + r.cz, "TUNNEL_CRACK",
                    "Tünel Z=" + r.centerZ + "m Mikro-Çatlak & 14.5mm Oturma", new BlockPos(-18, 52, r.centerZ), 0.65));
            return "Tünel mikro-çatlak ve ray oturması (14.5 mm) oluşturuldu (Z=" + r.centerZ + "m).";
        } else if (m.contains("bina") || m.contains("tilt")) {
            BlockPos hinge = playerPos.add(4, 0, 0);
            initiateBuildingTilt(world, hinge, 8);
            return "P-Delta bina eğilme fiziği başlatıldı.";
        }
        return "Bilinmeyen senaryo: " + mode + " (yikim | su | catlak | cokme | bina)";
    }

    private static File getBlueprintFile() {
        return new File(FabricLoader.getInstance().getGameDir().toFile(), "arena-physics-blueprints.json");
    }

    public static synchronized void saveBlueprintsToDisk(MinecraftServer server) {
        try {
            File f = getBlueprintFile();
            if (SAVED_BLUEPRINTS.isEmpty()) {
                if (f.exists()) f.delete();
                return;
            }
            JsonArray arr = new JsonArray();
            for (StructureBlueprintSnapshot snap : SAVED_BLUEPRINTS) {
                JsonObject o = new JsonObject();
                o.addProperty("id", snap.id);
                o.addProperty("cx", snap.center.getX());
                o.addProperty("cy", snap.center.getY());
                o.addProperty("cz", snap.center.getZ());
                JsonArray orig = new JsonArray();
                for (Map.Entry<BlockPos, BlockState> e : snap.originalBlocks.entrySet()) {
                    JsonObject bo = new JsonObject();
                    bo.addProperty("x", e.getKey().getX());
                    bo.addProperty("y", e.getKey().getY());
                    bo.addProperty("z", e.getKey().getZ());
                    bo.addProperty("b", ConstitutiveMaterialDB.serializeBlockState(e.getValue()));
                    orig.add(bo);
                }
                o.add("orig", orig);
                JsonArray rub = new JsonArray();
                for (BlockPos rp : snap.depositedRubble) {
                    JsonObject ro = new JsonObject();
                    ro.addProperty("x", rp.getX());
                    ro.addProperty("y", rp.getY());
                    ro.addProperty("z", rp.getZ());
                    rub.add(ro);
                }
                o.add("rubble", rub);
                arr.add(o);
            }
            Files.writeString(f.toPath(), GSON.toJson(arr), StandardCharsets.UTF_8);
        } catch (Throwable ignored) {}
    }

    public static synchronized void loadBlueprintsFromDisk(MinecraftServer server) {
        try {
            File f = getBlueprintFile();
            if (!f.exists()) return;
            SAVED_BLUEPRINTS.clear();
            JsonArray arr = JsonParser.parseString(Files.readString(f.toPath(), StandardCharsets.UTF_8)).getAsJsonArray();
            for (JsonElement el : arr) {
                JsonObject o = el.getAsJsonObject();
                StructureBlueprintSnapshot snap = new StructureBlueprintSnapshot(
                        o.get("id").getAsString(),
                        new BlockPos(o.get("cx").getAsInt(), o.get("cy").getAsInt(), o.get("cz").getAsInt())
                );
                for (JsonElement be : o.getAsJsonArray("orig")) {
                    JsonObject bo = be.getAsJsonObject();
                    BlockState fullSt = ConstitutiveMaterialDB.deserializeBlockState(bo.get("b").getAsString());
                    snap.originalBlocks.put(new BlockPos(bo.get("x").getAsInt(), bo.get("y").getAsInt(), bo.get("z").getAsInt()), fullSt);
                }
                for (JsonElement re : o.getAsJsonArray("rubble")) {
                    JsonObject ro = re.getAsJsonObject();
                    snap.depositedRubble.add(new BlockPos(ro.get("x").getAsInt(), ro.get("y").getAsInt(), ro.get("z").getAsInt()));
                }
                SAVED_BLUEPRINTS.add(snap);
            }
        } catch (Throwable ignored) {}
    }

    private static void pushAlert(StructuralAlert alert) {
        ACTIVE_ALERTS.removeIf(a -> a.id.equals(alert.id));
        ACTIVE_ALERTS.add(0, alert);
        while (ACTIVE_ALERTS.size() > 8) {
            ACTIVE_ALERTS.remove(ACTIVE_ALERTS.size() - 1);
        }
    }

    public static JsonObject handleApi(String rawBody, MinecraftServer server) {
        JsonObject inner = new JsonObject();
        try {
            if (rawBody != null && !rawBody.isBlank()) {
                JsonObject root = JsonParser.parseString(rawBody).getAsJsonObject();
                inner = root.has("physics") && root.get("physics").isJsonObject()
                        ? root.getAsJsonObject("physics") : root;
            }
        } catch (Throwable ignored) {}
        return handleApi(inner, server);
    }

    public static JsonObject handleApi(JsonObject body, MinecraftServer server) {
        JsonObject res = new JsonObject();
        String op = (body != null && body.has("op")) ? body.get("op").getAsString() : "radar";

        if ("repair".equalsIgnoreCase(op) && server != null) {
            ServerWorld ow = server.getOverworld();
            int x = body.has("x") ? body.get("x").getAsInt() : -18;
            int y = body.has("y") ? body.get("y").getAsInt() : 52;
            int z = body.has("z") ? body.get("z").getAsInt() : 800;
            double rad = body.has("radius") ? body.get("radius").getAsDouble() : 120.0;
            server.execute(() -> repairStructuralDamageNear(ow, new BlockPos(x, y, z), rad));
            res.addProperty("ok", true);
            res.addProperty("scheduledRepair", true);
            return res;
        }
        if ("demolish".equalsIgnoreCase(op) && server != null) {
            ServerWorld ow = server.getOverworld();
            int x = body.get("x").getAsInt();
            int y = body.get("y").getAsInt();
            int z = body.get("z").getAsInt();
            double rad = body.has("radius") ? body.get("radius").getAsDouble() : 4.6;
            server.execute(() -> triggerBlocksworthDemolition(ow, new BlockPos(x, y, z), rad));
            res.addProperty("ok", true);
            res.addProperty("triggeredDemolition", true);
            return res;
        }
        if ("toggle".equalsIgnoreCase(op) && body.has("enabled")) {
            physicsEnabled = body.get("enabled").getAsBoolean();
        }

        res.addProperty("ok", true);
        res.addProperty("minTunnelFos", Math.round(latestMinTunnelFos * 100.0) / 100.0);
        res.addProperty("criticalRingZ", latestCriticalRingZ);
        res.addProperty("maxPoreWaterKpa", Math.round(latestMaxPoreWaterKpa * 10.0) / 10.0);
        res.addProperty("maxWaterDepthMm", Math.round(latestMaxWaterDepthMm * 10.0) / 10.0);
        res.addProperty("nearestColumnDcr", Math.round(latestNearestColumnDcr * 1000.0) / 1000.0);
        res.addProperty("nearestColumnFos", Math.round(latestNearestColumnFos * 100.0) / 100.0);
        res.addProperty("surfaceImpulseKn", Math.round(latestSurfaceImpulseKn * 10.0) / 10.0);
        res.addProperty("nadalYq", Math.round(latestNadalYq * 100.0) / 100.0);
        res.addProperty("trainRollDeg", Math.round(clientTrainRollDeg * 100.0) / 100.0);
        res.addProperty("sperlingWz", Math.round(clientSperlingWz * 100.0) / 100.0);
        res.addProperty("activeRigidBodies", RIGID_BODIES.size());
        res.addProperty("activeClusters", COMPOUND_CLUSTERS.size());
        res.addProperty("tiltingStructures", TILTING_STRUCTURES.size());
        res.addProperty("elevatorBrakeTripped", elevatorBrakeTripped);

        JsonArray alertsArr = new JsonArray();
        for (StructuralAlert a : ACTIVE_ALERTS) {
            JsonObject ao = new JsonObject();
            ao.addProperty("id", a.id);
            ao.addProperty("type", a.type);
            ao.addProperty("summary", a.summary);
            ao.addProperty("x", a.pos.getX());
            ao.addProperty("y", a.pos.getY());
            ao.addProperty("z", a.pos.getZ());
            ao.addProperty("severity", a.severity);
            alertsArr.add(ao);
        }
        res.add("alerts", alertsArr);
        return res;
    }
}

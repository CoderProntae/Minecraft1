package ai.arena.bridge.board;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Persistent real-time transit & expansion board manager (arena-live-news.json).
 */
public final class ArenaNewsManager {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static class NewsSlide {
        public String id;
        public String category;
        public String line1;
        public String line2;
        public String line3;
        public double mapFocusX = -18.0;
        public double mapFocusZ = 32.0;
        public double mapSpan = 80.0;
        public String overlayKind = "NONE"; // NONE, UNDERGROUND_METRO, SURFACE_BRANCH
        public int accentColor = 0x00A86B;
    }

    public static final List<NewsSlide> SLIDES = new CopyOnWriteArrayList<>();
    public static volatile int slideSeconds = 10;
    private static boolean loaded = false;

    private ArenaNewsManager() {}

    public static File getFile() {
        return new File(FabricLoader.getInstance().getGameDir().toFile(), "arena-live-news.json");
    }

    public static synchronized void ensureLoaded() {
        if (loaded) return;
        loaded = true;
        seedDefaults();
        saveToDisk();
    }

    public static void seedDefaults() {
        SLIDES.clear();

        NewsSlide s1 = new NewsSlide();
        s1.id = "m1_underground_plan";
        s1.category = "M1 YERALTI METRO PROJESİ";
        s1.line1 = "UITP Ağır Raylı Standart";
        s1.line2 = "Yeraltı İstasyon Planı";
        s1.line3 = "Harita Önizlemesi ->";
        s1.mapFocusX = -18.0;
        s1.mapFocusZ = 32.0;
        s1.mapSpan = 72.0;
        s1.overlayKind = "UNDERGROUND_METRO";
        s1.accentColor = 0xE53935;
        SLIDES.add(s1);

        NewsSlide s2 = new NewsSlide();
        s2.id = "b1_surface_plan";
        s2.category = "B1 / T1 YÜZEY HATTI PLANI";
        s2.line1 = "Nehir ve Orman Koridoru";
        s2.line2 = "Kuzey Gar Aktarma Noktası";
        s2.line3 = "Güzergah Haritası ->";
        s2.mapFocusX = 16.0;
        s2.mapFocusZ = 32.0;
        s2.mapSpan = 92.0;
        s2.overlayKind = "SURFACE_BRANCH";
        s2.accentColor = 0x1E88E5;
        SLIDES.add(s2);
    }

    public static synchronized void saveToDisk() {
        try {
            Files.writeString(getFile().toPath(), GSON.toJson(toJson()), StandardCharsets.UTF_8);
        } catch (Throwable ignored) {}
    }

    public static JsonObject toJson() {
        JsonObject root = new JsonObject();
        root.addProperty("ok", true);
        root.addProperty("slideSeconds", slideSeconds);
        JsonArray arr = new JsonArray();
        for (NewsSlide s : SLIDES) {
            JsonObject o = new JsonObject();
            o.addProperty("id", s.id);
            o.addProperty("category", s.category);
            o.addProperty("line1", s.line1);
            o.addProperty("line2", s.line2);
            o.addProperty("line3", s.line3);
            o.addProperty("mapFocusX", s.mapFocusX);
            o.addProperty("mapFocusZ", s.mapFocusZ);
            o.addProperty("mapSpan", s.mapSpan);
            o.addProperty("overlayKind", s.overlayKind);
            o.addProperty("accentColor", String.format("#%06X", s.accentColor & 0xFFFFFF));
            arr.add(o);
        }
        root.add("slides", arr);
        return root;
    }

    public static JsonObject handleApiPost(String body) {
        ensureLoaded();
        try {
            JsonObject req = JsonParser.parseString(body == null || body.isBlank() ? "{}" : body).getAsJsonObject();
            String op = req.has("op") ? req.get("op").getAsString() : "upsert";
            if ("upsert".equalsIgnoreCase(op)) {
                String id = req.has("id") ? req.get("id").getAsString() : ("slide_" + System.currentTimeMillis());
                NewsSlide target = null;
                for (NewsSlide ex : SLIDES) {
                    if (ex.id.equals(id)) { target = ex; break; }
                }
                if (target == null) {
                    target = new NewsSlide();
                    target.id = id;
                    SLIDES.add(target);
                }
                if (req.has("category")) target.category = req.get("category").getAsString();
                if (req.has("line1")) target.line1 = req.get("line1").getAsString();
                if (req.has("line2")) target.line2 = req.get("line2").getAsString();
                if (req.has("line3")) target.line3 = req.get("line3").getAsString();
                if (req.has("mapFocusX")) target.mapFocusX = req.get("mapFocusX").getAsDouble();
                if (req.has("mapFocusZ")) target.mapFocusZ = req.get("mapFocusZ").getAsDouble();
                if (req.has("mapSpan")) target.mapSpan = req.get("mapSpan").getAsDouble();
                if (req.has("overlayKind")) target.overlayKind = req.get("overlayKind").getAsString();
                if (req.has("accentColor")) {
                    try {
                        target.accentColor = Integer.parseInt(req.get("accentColor").getAsString().replace("#", ""), 16) & 0xFFFFFF;
                    } catch (Throwable ignored) {}
                }
                saveToDisk();
            } else if ("remove".equalsIgnoreCase(op) && req.has("id")) {
                String id = req.get("id").getAsString();
                SLIDES.removeIf(s -> s.id.equals(id));
                saveToDisk();
            } else if ("reset".equalsIgnoreCase(op)) {
                seedDefaults();
                saveToDisk();
            }
        } catch (Throwable ignored) {}
        return toJson();
    }
}

package ai.arena.bridge.board;

import ai.arena.bridge.ArenaContent;
import ai.arena.bridge.hotpatch.HotPatchManager;
import ai.arena.bridge.map.ArenaMapData;
import ai.arena.bridge.map.WorldAtlasManager;
import com.google.gson.JsonObject;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.entity.BlockEntityRenderer;
import net.minecraft.client.render.block.entity.BlockEntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.RotationAxis;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

import java.util.List;
import java.util.Locale;

/**
 * Location-aware wall map & real-time kinematic corridor renderer for world_map_board (v7.6.0):
 * - Supports live JVM bytecode hot-swap (HotPatchManager) + instant JSON board overrides (/map_api).
 * - Bezel-safe screen aperture strictly within [-0.430..+0.430] x [-0.376..+0.376] (never clipped by 14.2/1.8 bezel!).
 * - Mode 4: Real-time kinematic corridor diagram (exact trapezoidal physics travel time + live second-by-second ETA).
 */
public class WorldMapBoardRenderer implements BlockEntityRenderer<ArenaContent.MapBoardBlockEntity> {

    // Per-train live velocity tracker (multi-train & multi-board safe!)
    private static final java.util.Map<String, double[]> TRAIN_VZ_TRACKER = new java.util.concurrent.ConcurrentHashMap<>();
    private static volatile double emaVzMps = 0.0;

    public static double getPrimaryTrainVzMps() {
        return emaVzMps;
    }

    public WorldMapBoardRenderer(BlockEntityRendererFactory.Context ctx) {}

    @Override
    public int getRenderDistance() {
        return 96;
    }

    @Override
    public void render(
            ArenaContent.MapBoardBlockEntity entity,
            float tickDelta,
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            int light,
            int overlay
    ) {
        if (entity.getWorld() == null) return;
        if (HotPatchManager.renderWorldMapBoard(entity, tickDelta, matrices, vertexConsumers, light, overlay)) {
            return;
        }
        BlockState state = entity.getCachedState();
        if (!state.isOf(ArenaContent.WORLD_MAP_BOARD)) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        ArenaMapData.ensureLoaded();
        Identifier atlasId = WorldAtlasManager.getAndBindAtlas(mc);

        Direction facing = state.get(ArenaContent.FACING);
        int mode = state.get(ArenaContent.MAP_MODE);
        int fullBright = 0xF000F0;

        matrices.push();
        // Bezel inner aperture of world_map_board.json is Y=[1.8..14.2]/16 => [-0.3875..+0.3875], X=[0.9..15.1]/16 => [-0.443..+0.443].
        // Keep ALL rendered elements strictly inside [-0.430..+0.430] x [-0.376..+0.376] so zero pixels ever touch the frame!
        orientToWallFace(matrices, facing, 0.414f);

        TextRenderer tr = mc.textRenderer;
        if (HotPatchManager.renderCustomPrimitivesIfFullReplace("world_map_board", matrices, vertexConsumers, tr, fullBright)) {
            matrices.pop();
            return;
        }

        float vpL = -0.430f, vpR = 0.430f, vpB = -0.376f, vpT = 0.312f;
        float vpW = vpR - vpL;
        float vpH = vpT - vpB;

        List<ArenaMapData.LiveTrainInfo> trains = ArenaMapData.getLiveTrains();
        updateTrainVelocityTracker(trains);

        if (mode == 4) {
            double boardZ = entity.getPos().getZ() + 0.5;
            renderSchematicDiagram(matrices, vertexConsumers, tr, trains, boardZ, vpL, vpR, vpB, vpT, vpH, fullBright);
            HotPatchManager.renderCustomOverlayPrimitives("world_map_board", matrices, vertexConsumers, tr, fullBright);
            matrices.pop();
            return;
        }

        double centerX = entity.getPos().getX() + 0.5;
        double centerZ = entity.getPos().getZ() + 0.5;
        double halfSpanZ;
        String header;

        switch (mode) {
            case 0 -> {
                halfSpanZ = 52.0;
                header = String.format(Locale.US, "HARİTA 1:1 (%d, %d)", entity.getPos().getX(), entity.getPos().getZ());
            }
            case 1 -> {
                halfSpanZ = 92.0;
                header = String.format(Locale.US, "HARİTA 1:2 (%d, %d)", entity.getPos().getX(), entity.getPos().getZ());
            }
            case 2 -> {
                halfSpanZ = 156.0;
                header = "ÇEVRE HARİTASI 1:3";
            }
            default -> {
                halfSpanZ = 240.0;
                header = "BÖLGE VE SINIR HARİTASI";
            }
        }
        double halfSpanX = Math.min(460.0, halfSpanZ * (vpW / vpH));

        if (atlasId != null) {
            float u0 = clamp01((float) ((centerX - halfSpanX - WorldAtlasManager.ATLAS_MIN_X) / WorldAtlasManager.ATLAS_W));
            float u1 = clamp01((float) ((centerX + halfSpanX - WorldAtlasManager.ATLAS_MIN_X) / WorldAtlasManager.ATLAS_W));
            float v0 = clamp01((float) ((centerZ - halfSpanZ - WorldAtlasManager.ATLAS_MIN_Z) / WorldAtlasManager.ATLAS_H));
            float v1 = clamp01((float) ((centerZ + halfSpanZ - WorldAtlasManager.ATLAS_MIN_Z) / WorldAtlasManager.ATLAS_H));

            VertexConsumer texVc = vertexConsumers.getBuffer(RenderLayer.getEntityCutoutNoCull(atlasId));
            Matrix4f m4 = matrices.peek().getPositionMatrix();
            Matrix3f m3 = matrices.peek().getNormalMatrix();
            texVertex(texVc, m4, m3, vpL, vpB, 0.0f, u0, v1, fullBright);
            texVertex(texVc, m4, m3, vpR, vpB, 0.0f, u1, v1, fullBright);
            texVertex(texVc, m4, m3, vpR, vpT, 0.0f, u1, v0, fullBright);
            texVertex(texVc, m4, m3, vpL, vpT, 0.0f, u0, v0, fullBright);
        }

        VertexConsumer vc = vertexConsumers.getBuffer(RenderLayer.getGui());
        Matrix4f mat = matrices.peek().getPositionMatrix();

        // Bezel-safe header bar [0.312 .. 0.376]
        quad(vc, mat, vpL, 0.315f, vpR, 0.376f, 0.0005f, 0xFF222222);
        quad(vc, mat, vpL, 0.311f, vpR, 0.315f, 0.0008f, 0xFF424242);

        if (mode == 3) {
            float bz = toScreenY(800.0, centerZ, halfSpanZ, vpB, vpT);
            if (bz > vpB && bz < vpT) {
                quad(vc, mat, vpL, bz - 0.004f, vpR, bz + 0.004f, 0.0012f, 0xAAFFA726);
            }
        }

        float trackX = toScreenX(-18.0, centerX, halfSpanX, vpL, vpR);
        if (trackX > vpL + 0.01f && trackX < vpR - 0.01f) {
            float surfN0 = clamp(toScreenY(-10.0, centerZ, halfSpanZ, vpB, vpT), vpB, vpT);
            float surfN1 = clamp(toScreenY(52.0, centerZ, halfSpanZ, vpB, vpT), vpB, vpT);
            if (Math.abs(surfN1 - surfN0) > 0.004f) {
                quad(vc, mat, trackX - 0.007f, Math.min(surfN0, surfN1), trackX + 0.007f, Math.max(surfN0, surfN1), 0.0015f, 0xEE00A86B);
            }
            for (int z = 56; z < 1560; z += 18) {
                float d0 = toScreenY(z, centerZ, halfSpanZ, vpB, vpT);
                float d1 = toScreenY(z + 10, centerZ, halfSpanZ, vpB, vpT);
                if (Math.max(d0, d1) < vpB || Math.min(d0, d1) > vpT) continue;
                quad(vc, mat, trackX - 0.005f, clamp(Math.min(d0, d1), vpB, vpT), trackX + 0.005f, clamp(Math.max(d0, d1), vpB, vpT), 0.0015f, 0xBB00A86B);
            }
        }

        for (ArenaMapData.LiveStationInfo st : ArenaMapData.getLiveStations()) {
            float sx = toScreenX(st.x, centerX, halfSpanX, vpL, vpR);
            float sy = toScreenY(st.z, centerZ, halfSpanZ, vpB, vpT);
            if (sx > vpL + 0.02f && sx < vpR - 0.02f && sy > vpB + 0.02f && sy < vpT - 0.02f) {
                quad(vc, mat, sx - 0.018f, sy - 0.018f, sx + 0.018f, sy + 0.018f, 0.0020f, 0xFFFFFFFF);
                quad(vc, mat, sx - 0.010f, sy - 0.010f, sx + 0.010f, sy + 0.010f, 0.0023f, 0xFF181818);
            }
        }

        for (ArenaMapData.LiveTrainInfo t : trains) {
            float tx = toScreenX(t.x, centerX, halfSpanX, vpL, vpR);
            float ty = toScreenY(t.z, centerZ, halfSpanZ, vpB, vpT);
            if (tx > vpL + 0.015f && tx < vpR - 0.015f && ty > vpB + 0.015f && ty < vpT - 0.015f) {
                int col = 0xFF000000 | (t.color & 0xFFFFFF);
                quad(vc, mat, tx - 0.018f, ty - 0.018f, tx + 0.018f, ty + 0.018f, 0.0026f, 0xFFFFFFFF);
                quad(vc, mat, tx - 0.012f, ty - 0.012f, tx + 0.012f, ty + 0.012f, 0.0029f, col);
            }
        }

        for (PlayerEntity p : entity.getWorld().getPlayers()) {
            float px = toScreenX(p.getX(), centerX, halfSpanX, vpL, vpR);
            float py = toScreenY(p.getZ(), centerZ, halfSpanZ, vpB, vpT);
            if (px > vpL + 0.015f && px < vpR - 0.015f && py > vpB + 0.015f && py < vpT - 0.015f) {
                boolean self = mc.player != null && p.getUuid().equals(mc.player.getUuid());
                quad(vc, mat, px - 0.013f, py - 0.013f, px + 0.013f, py + 0.013f, 0.0031f, 0xFFFFFFFF);
                quad(vc, mat, px - 0.009f, py - 0.009f, px + 0.009f, py + 0.009f, 0.0033f, self ? 0xFF42A5F5 : 0xFFFFCA28);
            }
        }

        float bx = toScreenX(centerX, centerX, halfSpanX, vpL, vpR);
        float by = toScreenY(centerZ, centerZ, halfSpanZ, vpB, vpT);
        quad(vc, mat, bx - 0.014f, by - 0.003f, bx + 0.014f, by + 0.003f, 0.0035f, 0xFFFF5252);
        quad(vc, mat, bx - 0.003f, by - 0.014f, bx + 0.003f, by + 0.014f, 0.0035f, 0xFFFF5252);

        if (tr != null) {
            float hScale = fitScale(tr, header, 0.48f, 0.0031f);
            drawWallText(matrices, vertexConsumers, tr, header, -0.412f, 0.358f, hScale, 0xFFEAEAEA, fullBright);
            if (!trains.isEmpty()) {
                ArenaMapData.LiveTrainInfo t = trains.get(0);
                String ts = t.speedKmh < 1.5
                        ? (t.routeNumber + " | DURAKTA")
                        : String.format(Locale.US, "%s %.0f km/s", t.routeNumber, t.speedKmh);
                drawWallText(matrices, vertexConsumers, tr, ts, 0.095f, 0.357f, 0.0029f, 0xFF81C784, fullBright);
            }
        }

        HotPatchManager.renderCustomOverlayPrimitives("world_map_board", matrices, vertexConsumers, tr, fullBright);
        matrices.pop();
    }

    private static void updateTrainVelocityTracker(List<ArenaMapData.LiveTrainInfo> trains) {
        if (trains == null || trains.isEmpty()) return;
        if (TRAIN_VZ_TRACKER.size() > 24) TRAIN_VZ_TRACKER.clear();
        long now = System.currentTimeMillis();
        ArenaMapData.LiveTrainInfo t = trains.get(0);
        String key = (t.routeNumber == null ? "M1" : t.routeNumber) + "#" + (t.destination == null ? "" : t.destination);
        double[] st = TRAIN_VZ_TRACKER.computeIfAbsent(key, k -> new double[]{ t.z, now, 0.0 });
        double dt = (now - st[1]) / 1000.0;
        if (dt >= 0.12 && dt <= 5.0) {
            double instVz = (t.z - st[0]) / dt;
            st[2] = st[2] * 0.65 + instVz * 0.35;
            st[0] = t.z;
            st[1] = now;
            emaVzMps = st[2];
        } else if (dt > 5.0) {
            st[0] = t.z;
            st[1] = now;
        }
    }

    /**
     * Exact UITP/UIC trapezoidal traction-cruise-braking physics run time (seconds) for distance D (meters).
     */
    public static double computeExactCorridorSeconds(double distMeters, double vMaxKmh) {
        double d = Math.max(1.0, Math.abs(distMeters));
        double vMax = Math.max(2.0, vMaxKmh / 3.6);
        double a = 1.10; // m/s^2 acceleration
        double b = 1.20; // m/s^2 service braking
        double dAcc = 0.5 * vMax * vMax / a;
        double dDec = 0.5 * vMax * vMax / b;
        if (d >= dAcc + dDec) {
            return (vMax / a) + (vMax / b) + ((d - dAcc - dDec) / vMax);
        } else {
            double vPeak = Math.sqrt((2.0 * d) / ((1.0 / a) + (1.0 / b)));
            return vPeak * ((1.0 / a) + (1.0 / b));
        }
    }

    /**
     * Computes live remaining seconds from current train position & speed to targetZ along a 1D corridor.
     */
    public static double computeRemainingSecondsDirect(double currentZ, double targetZ, double speedKmh, double vMaxKmh) {
        double dRem = Math.abs(targetZ - currentZ);
        if (dRem <= 2.5) return 0.0;
        double vNow = Math.max(0.0, speedKmh / 3.6);
        double vMax = Math.max(vNow, Math.max(5.0, vMaxKmh / 3.6));
        double a = 1.10;
        double b = 1.20;
        double dBrakeFromNow = 0.5 * vNow * vNow / b;
        if (dRem <= dBrakeFromNow + 4.0) {
            return Math.max(1.0, (2.0 * dRem) / Math.max(2.2, vNow));
        }
        double dDecFull = 0.5 * vMax * vMax / b;
        if (vNow >= vMax * 0.90) {
            return Math.max(1.0, ((dRem - dDecFull) / vMax) + (vMax / b));
        }
        double tAccRem = (vMax - vNow) / a;
        double dAccRem = 0.5 * (vMax * vMax - vNow * vNow) / a;
        if (dRem >= dAccRem + dDecFull) {
            return tAccRem + ((dRem - dAccRem - dDecFull) / vMax) + (vMax / b);
        }
        double vPeak = Math.sqrt((2.0 * dRem + (vNow * vNow / a)) / ((1.0 / a) + (1.0 / b)));
        return Math.max(1.0, ((vPeak - vNow) / a) + (vPeak / b));
    }

    private static void renderSchematicDiagram(
            MatrixStack matrices,
            VertexConsumerProvider vcp,
            TextRenderer tr,
            List<ArenaMapData.LiveTrainInfo> trains,
            double boardZ,
            float vpL, float vpR, float vpB, float vpT, float vpH,
            int fullBright
    ) {
        VertexConsumer vc = vcp.getBuffer(RenderLayer.getGui());
        Matrix4f mat = matrices.peek().getPositionMatrix();
        // Screen background + bezel-safe header bar [0.315 .. 0.376]
        quad(vc, mat, vpL, vpB, vpR, 0.376f, 0.0f, 0xFF14181D);
        quad(vc, mat, vpL, 0.315f, vpR, 0.376f, 0.0005f, 0xFF20262E);

        int lineColor = (!trains.isEmpty() && trains.get(0).color != 0)
                ? (0xFF000000 | (trains.get(0).color & 0xFFFFFF))
                : 0xFFE53935;
        quad(vc, mat, vpL, 0.310f, vpR, 0.315f, 0.0008f, lineColor);

        List<ArenaMapData.LiveStationInfo> stations = ArenaMapData.getLiveStations();
        int count = stations.size();
        float spineX = -0.27f;
        float topY = vpT - 0.088f;
        float botY = vpB + 0.118f;

        quad(vc, mat, spineX - 0.013f, botY, spineX + 0.013f, topY, 0.0012f, lineColor);

        double minZ = count >= 2 ? stations.get(0).z : 32.0;
        double maxZ = count >= 2 ? stations.get(count - 1).z : 1580.0;
        String northName = count >= 2 ? stations.get(0).name : "Kuzey Orman";
        String southName = count >= 2 ? stations.get(count - 1).name : "Güney Orman";
        if (Math.abs(maxZ - minZ) < 10.0) {
            minZ = 32.0;
            maxZ = 1580.0;
        }

        // Emit ALL RenderLayer.getGui() quads FIRST before calling drawWallText()
        if (count >= 2) {
            for (int i = 0; i < count; i++) {
                ArenaMapData.LiveStationInfo st = stations.get(i);
                float frac = (float) ((st.z - minZ) / (maxZ - minZ));
                float sy = topY + (botY - topY) * frac;
                boolean isHere = Math.abs(st.z - boardZ) < Math.abs((i == 0 ? maxZ : minZ) - boardZ);
                int ringCol = isHere ? 0xFF81C784 : 0xFFFFFFFF;
                quad(vc, mat, spineX - 0.027f, sy - 0.027f, spineX + 0.027f, sy + 0.027f, 0.0018f, ringCol);
                quad(vc, mat, spineX - 0.014f, sy - 0.014f, spineX + 0.014f, sy + 0.014f, 0.0021f, 0xFF14181D);
            }
        } else {
            for (float sy : new float[]{topY, botY}) {
                quad(vc, mat, spineX - 0.027f, sy - 0.027f, spineX + 0.027f, sy + 0.027f, 0.0018f, 0xFFFFFFFF);
                quad(vc, mat, spineX - 0.014f, sy - 0.014f, spineX + 0.014f, sy + 0.014f, 0.0021f, 0xFF14181D);
            }
        }

        double corridorMeters = Math.abs(maxZ - minZ);
        double corridorVmaxKmh = 80.0;
        if (!trains.isEmpty() && trains.get(0).speedKmh > corridorVmaxKmh + 2.0) {
            corridorVmaxKmh = Math.round(trains.get(0).speedKmh);
        }
        double exactCorridorSec = computeExactCorridorSeconds(corridorMeters, corridorVmaxKmh);

        boolean boardAtSouth = Math.abs(boardZ - maxZ) <= Math.abs(boardZ - minZ);
        double hereZ = boardAtSouth ? maxZ : minZ;
        double otherZ = boardAtSouth ? minZ : maxZ;
        String hereName = boardAtSouth ? southName : northName;
        String otherName = boardAtSouth ? northName : southName;

        String status = String.format(Locale.US, "M1 • Net Sefer: %.1f sn • Peron: 20 sn", exactCorridorSec);
        if (!trains.isEmpty()) {
            ArenaMapData.LiveTrainInfo t = trains.get(0);
            double frac = Math.max(0.0, Math.min(1.0, (t.z - minZ) / (maxZ - minZ)));
            float ty = (float) (topY + (botY - topY) * frac);
            quad(vc, mat, spineX - 0.024f, ty - 0.019f, spineX + 0.024f, ty + 0.019f, 0.0026f, 0xFFFFFFFF);
            quad(vc, mat, spineX - 0.018f, ty - 0.013f, spineX + 0.018f, ty + 0.013f, 0.0029f, 0xFFFFCA28);

            double dHere = Math.abs(t.z - hereZ);
            double dOther = Math.abs(t.z - otherZ);
            if (dHere <= 18.0 && t.speedKmh < 1.5) {
                status = String.format(Locale.US, "%s • BU İSTASYONDA (Kapılar Açık)", t.routeNumber);
            } else if (dOther <= 18.0 && t.speedKmh < 1.5) {
                int etaBack = (int) Math.round(12.0 + exactCorridorSec);
                status = String.format(Locale.US, "%s %s peronunda • Buraya: %d sn", t.routeNumber, otherName, etaBack);
            } else {
                // Determine travel direction from live velocity vector + MTR nextStation
                Boolean headingSouth = null;
                if (Math.abs(emaVzMps) > 0.35) {
                    headingSouth = emaVzMps > 0.0;
                } else if (!t.nextStation.isBlank()) {
                    String ns = t.nextStation.toLowerCase(Locale.ROOT);
                    if (ns.contains("güney") || ns.contains("guney")) headingSouth = true;
                    else if (ns.contains("kuzey")) headingSouth = false;
                }
                boolean towardHere = (headingSouth != null) ? (headingSouth == boardAtSouth) : (dHere < dOther);
                if (towardHere) {
                    int etaSec = (int) Math.max(1L, Math.round(computeRemainingSecondsDirect(t.z, hereZ, t.speedKmh, corridorVmaxKmh)));
                    status = String.format(Locale.US, "%s → %s • %.0f km/s • Varış: %d sn",
                            t.routeNumber, hereName, t.speedKmh, etaSec);
                } else {
                    double etaOther = computeRemainingSecondsDirect(t.z, otherZ, t.speedKmh, corridorVmaxKmh);
                    int totalHereSec = (int) Math.round(etaOther + 20.0 + exactCorridorSec);
                    status = String.format(Locale.US, "%s → %s (%.0f sn) • Buraya: %d sn",
                            t.routeNumber, otherName, etaOther, totalHereSec);
                }
            }
        }

        JsonObject ov = HotPatchManager.getBoardOverride();
        String diagTitle = (!trains.isEmpty() ? trains.get(0).routeNumber : "M1") + " CANLI HAT DİYAGRAMI";
        if (ov != null) {
            if (ov.has("diagTitle")) diagTitle = ov.get("diagTitle").getAsString();
            if (ov.has("statusText")) status = ov.get("statusText").getAsString();
        }

        // Draw ALL text overlays strictly AFTER all GUI quads
        if (tr != null) {
            if (count >= 2) {
                for (int i = 0; i < count; i++) {
                    ArenaMapData.LiveStationInfo st = stations.get(i);
                    float frac = (float) ((st.z - minZ) / (maxZ - minZ));
                    float sy = topY + (botY - topY) * frac;
                    boolean isHere = Math.abs(st.z - boardZ) < Math.abs((i == 0 ? maxZ : minZ) - boardZ);
                    String stLabel = isHere ? (st.name + " (Buradasın)") : st.name;
                    float stScale = fitScale(tr, stLabel, 0.64f, 0.0033f);
                    drawWallText(matrices, vcp, tr, stLabel, spineX + 0.046f, sy + 0.020f, stScale,
                            isHere ? 0xFFA5D6A7 : 0xFFFFFFFF, fullBright);
                    String sub = String.format(Locale.US, "Yeraltı Metro • Z=%d m", (int) Math.round(st.z));
                    drawWallText(matrices, vcp, tr, sub, spineX + 0.046f, sy - 0.012f, 0.0025f, 0xFF90A4AE, fullBright);

                    if (i + 1 < count) {
                        ArenaMapData.LiveStationInfo next = stations.get(i + 1);
                        double segM = Math.abs(next.z - st.z);
                        double segSec = computeExactCorridorSeconds(segM, corridorVmaxKmh);
                        float nextFrac = (float) ((next.z - minZ) / (maxZ - minZ));
                        float midY = topY + (botY - topY) * ((frac + nextFrac) * 0.5f);
                        String segInfo = String.format(Locale.US, "%.2f km (%.0f m) • %.1f sn (%.0f km/s)",
                                segM / 1000.0, segM, segSec, corridorVmaxKmh);
                        float segScale = fitScale(tr, segInfo, 0.64f, 0.0026f);
                        drawWallText(matrices, vcp, tr, segInfo, spineX + 0.046f, midY + 0.008f, segScale, 0xFF81C784, fullBright);
                    }
                }
            } else {
                drawWallText(matrices, vcp, tr, northName, spineX + 0.046f, topY + 0.014f, 0.0033f, 0xFFFFFFFF, fullBright);
                String segInfo = String.format(Locale.US, "%.2f km (%.0f m) • %.1f sn (%.0f km/s)",
                        corridorMeters / 1000.0, corridorMeters, exactCorridorSec, corridorVmaxKmh);
                drawWallText(matrices, vcp, tr, segInfo, spineX + 0.046f, (topY + botY) * 0.5f,
                        fitScale(tr, segInfo, 0.64f, 0.0026f), 0xFF81C784, fullBright);
                drawWallText(matrices, vcp, tr, southName, spineX + 0.046f, botY + 0.014f, 0.0033f, 0xFFFFFFFF, fullBright);
            }

            float titleScale = fitScale(tr, diagTitle, 0.80f, 0.0031f);
            drawWallText(matrices, vcp, tr, diagTitle, -0.412f, 0.358f, titleScale, 0xFFF5F5F5, fullBright);

            float statusScale = fitScale(tr, status, 0.81f, 0.0028f);
            drawWallText(matrices, vcp, tr, status, -0.412f, vpB + 0.042f, statusScale, 0xFFFFD54F, fullBright);
        }
    }

    static float fitScale(TextRenderer tr, String text, float maxWorldWidth, float preferredScale) {
        if (tr == null || text == null || text.isEmpty()) return preferredScale;
        int px = tr.getWidth(text);
        if (px <= 0) return preferredScale;
        return Math.min(preferredScale, maxWorldWidth / (float) px);
    }

    static void orientToWallFace(MatrixStack matrices, Direction facing, float depthOffset) {
        matrices.translate(0.5, 0.5, 0.5);
        float yaw = switch (facing) {
            case SOUTH -> 0f;
            case NORTH -> 180f;
            case EAST -> 90f;
            case WEST -> -90f;
            default -> 0f;
        };
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(yaw));
        matrices.translate(0.0, 0.0, -depthOffset);
    }

    static void texVertex(VertexConsumer vc, Matrix4f m4, Matrix3f m3, float x, float y, float z, float u, float v, int light) {
        vc.vertex(m4, x, y, z)
                .color(255, 255, 255, 255)
                .texture(u, v)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(light)
                .normal(m3, 0f, 0f, 1f)
                .next();
    }

    static float toScreenX(double wx, double cx, double halfSpanX, float vpL, float vpR) {
        float norm = (float) ((wx - (cx - halfSpanX)) / (halfSpanX * 2.0));
        return vpL + norm * (vpR - vpL);
    }

    static float toScreenY(double wz, double cz, double halfSpanZ, float vpB, float vpT) {
        float norm = (float) ((wz - (cz - halfSpanZ)) / (halfSpanZ * 2.0));
        return vpT - norm * (vpT - vpB);
    }

    static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    static float clamp01(float v) {
        return Math.max(0.0f, Math.min(1.0f, v));
    }

    static void quad(VertexConsumer vc, Matrix4f mat, float x1, float y1, float x2, float y2, float z, int argb) {
        int a = (argb >>> 24) & 0xFF;
        int r = (argb >>> 16) & 0xFF;
        int g = (argb >>> 8) & 0xFF;
        int b = argb & 0xFF;
        vc.vertex(mat, x1, y1, z).color(r, g, b, a).next();
        vc.vertex(mat, x2, y1, z).color(r, g, b, a).next();
        vc.vertex(mat, x2, y2, z).color(r, g, b, a).next();
        vc.vertex(mat, x1, y2, z).color(r, g, b, a).next();
    }

    static void drawWallText(
            MatrixStack matrices,
            VertexConsumerProvider vcp,
            TextRenderer tr,
            String text,
            float x,
            float y,
            float scale,
            int color,
            int light
    ) {
        matrices.push();
        matrices.translate(x, y, 0.0045f);
        matrices.scale(scale, -scale, scale);
        tr.draw(
                text,
                0f,
                0f,
                color,
                false,
                matrices.peek().getPositionMatrix(),
                vcp,
                TextRenderer.TextLayerType.POLYGON_OFFSET,
                0,
                light
        );
        matrices.pop();
    }
}

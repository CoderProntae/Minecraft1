package ai.arena.bridge.board;

import ai.arena.bridge.ArenaContent;
import net.minecraft.block.BlockState;
import net.minecraft.block.enums.DoubleBlockHalf;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.entity.BlockEntityRenderer;
import net.minecraft.client.render.block.entity.BlockEntityRendererFactory;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.RotationAxis;

/**
 * Pure 3D Minecraft Item Showcase Renderer for the 2-Block Vending Machine (v7.5.0):
 * - Renders 9 real 3D Minecraft items resting directly on the 3 stainless-steel shelves
 *   inside vending_machine_upper.json (x = 5.2..14.4, y = 1.0 / 5.0 / 9.0, z = 3.6..9.5).
 * - Zero procedural colored quads.
 */
public final class MetroFurnitureRenderers {

    private static final ItemStack[] DISPLAY_STACKS = {
            new ItemStack(Items.APPLE),
            new ItemStack(Items.BREAD),
            new ItemStack(Items.COOKIE),
            new ItemStack(Items.SWEET_BERRIES),
            new ItemStack(Items.GOLDEN_CARROT),
            new ItemStack(Items.POTION),
            new ItemStack(Items.HONEY_BOTTLE),
            new ItemStack(Items.BAKED_POTATO),
            new ItemStack(Items.GLOW_BERRIES)
    };

    private MetroFurnitureRenderers() {}

    public static class VendingMachineRenderer implements BlockEntityRenderer<ArenaContent.VendingMachineBlockEntity> {
        public VendingMachineRenderer(BlockEntityRendererFactory.Context ctx) {}

        @Override
        public void render(
                ArenaContent.VendingMachineBlockEntity entity, float tickDelta, MatrixStack matrices,
                VertexConsumerProvider vertexConsumers, int light, int overlay
        ) {
            if (entity.getWorld() == null) return;
            if (ai.arena.bridge.hotpatch.HotPatchManager.renderVendingMachine(entity, tickDelta, matrices, vertexConsumers, light, overlay)) {
                return;
            }
            BlockState state = entity.getCachedState();
            if (!state.isOf(ArenaContent.VENDING_MACHINE) || state.get(ArenaContent.HALF) != DoubleBlockHalf.UPPER) {
                return;
            }
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc == null || mc.player == null) return;
            if (mc.player.squaredDistanceTo(
                    entity.getPos().getX() + 0.5, entity.getPos().getY() + 0.5, entity.getPos().getZ() + 0.5
            ) > 26.0 * 26.0) {
                return;
            }

            Direction facing = state.get(ArenaContent.FACING);
            // Exact match to blockstates/vending_machine.json clockwise Y rotations:
            // north: y=0 -> 0°, east: y=90 CW -> -90°, south: y=180 -> 180°, west: y=270 CW -> +90°
            float rotDeg = switch (facing) {
                case EAST -> -90f;
                case SOUTH -> 180f;
                case WEST -> 90f;
                default -> 0f;
            };

            matrices.push();
            matrices.translate(0.5, 0.5, 0.5);
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(rotDeg));
            matrices.translate(-0.5, -0.5, -0.5);

            // Showcase interior bright LED light (block=14, sky=12)
            int showcaseLight = (12 << 20) | (14 << 4);

            // 3 physical shelves at y_model = 1.0, 5.0, 9.0 -> item centers at y = 0.16, 0.41, 0.66
            // Showcase window spans x_model = 5.2..14.4 -> 3 columns at x = 0.43, 0.61, 0.79, depth z = 0.37
            float[] shelfY = { 0.66f, 0.41f, 0.16f };
            float[] colX   = { 0.79f, 0.61f, 0.43f };

            int idx = 0;
            for (float sy : shelfY) {
                for (float cx : colX) {
                    matrices.push();
                    matrices.translate(cx, sy, 0.37f);
                    // Face outward toward -Z (North front of model)
                    matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180f));
                    matrices.scale(0.19f, 0.19f, 0.19f);
                    mc.getItemRenderer().renderItem(
                            DISPLAY_STACKS[idx % DISPLAY_STACKS.length],
                            ModelTransformationMode.FIXED,
                            showcaseLight,
                            OverlayTexture.DEFAULT_UV,
                            matrices,
                            vertexConsumers,
                            entity.getWorld(),
                            idx
                    );
                    matrices.pop();
                    idx++;
                }
            }

            matrices.pop();
        }
    }
}

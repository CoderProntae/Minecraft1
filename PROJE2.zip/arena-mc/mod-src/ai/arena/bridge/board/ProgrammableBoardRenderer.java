package ai.arena.bridge.board;

import ai.arena.bridge.ArenaContent;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.entity.BlockEntityRenderer;
import net.minecraft.client.render.block.entity.BlockEntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Direction;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

import java.util.List;

/**
 * MTR-Authentic PIDS & Transit Board Renderer (1x1 up to 8x4 meters):
 * Neutral brushed-silver aluminum housing (#DCDFE0), matte black dot-matrix display (#0A0A0A),
 * MTR amber/orange (#FF9900) & crisp white typography — zero futuristic blue styling.
 */
public class ProgrammableBoardRenderer implements BlockEntityRenderer<ArenaContent.ProgrammableBoardBlockEntity> {

    private static final Identifier BOARD_ATLAS = new Identifier("arena_ai_bridge", "textures/gui/board_ui_atlas.png");

    public ProgrammableBoardRenderer(BlockEntityRendererFactory.Context ctx) {}

    @Override
    public int getRenderDistance() {
        return 144;
    }

    @Override
    public boolean rendersOutsideBoundingBox(ArenaContent.ProgrammableBoardBlockEntity blockEntity) {
        return true;
    }

    @Override
    public void render(
            ArenaContent.ProgrammableBoardBlockEntity entity,
            float tickDelta,
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            int light,
            int overlay
    ) {
        if (entity.getWorld() == null) return;
        BlockState state = entity.getCachedState();
        if (!state.isOf(ArenaContent.PROGRAMMABLE_BOARD)) return;

        ProgrammableBoardManager.BoardSpec spec = ProgrammableBoardManager.resolve(entity.boardId);
        int wBlocks = entity.customWidth > 0 ? entity.customWidth : spec.widthBlocks;
        int hBlocks = entity.customHeight > 0 ? entity.customHeight : spec.heightBlocks;
        String theme = (entity.customTheme != null && !entity.customTheme.isBlank()) ? entity.customTheme : spec.theme;

        Direction facing = state.get(ArenaContent.FACING);
        ArenaContent.BoardMount mount = state.get(ArenaContent.BOARD_MOUNT);

        float depthFromCenter;
        float zBack;
        float yB;
        float totalW;
        float totalH;
        switch (mount) {
            case STAND -> {
                depthFromCenter = -0.12f;
                zBack = -0.24f;
                yB = -0.165f;
                totalW = Math.max(0.96f, wBlocks - 0.04f);
                totalH = Math.max(0.685f, hBlocks - 0.16f);
            }
            case POSTER -> {
                depthFromCenter = -0.13f;
                zBack = -0.26f;
                yB = -0.418f;
                totalW = Math.max(0.96f, wBlocks - 0.04f);
                totalH = Math.max(0.935f, hBlocks - 0.06f);
            }
            case GANTRY -> {
                depthFromCenter = 0.09f;
                zBack = -0.135f;
                yB = -0.45f;
                totalW = Math.max(0.985f, wBlocks - 0.015f);
                totalH = Math.max(0.90f, hBlocks - 0.08f);
            }
            default -> {
                depthFromCenter = 0.365f;
                zBack = -0.135f;
                yB = -0.465f;
                totalW = Math.max(0.985f, wBlocks - 0.015f);
                totalH = Math.max(0.95f, hBlocks - 0.05f);
            }
        }
        float xL = -totalW * 0.5f;
        float xR =  totalW * 0.5f;
        float yT = yB + totalH;

        float qU0, qV0;
        int tagIdx;
        int tagTextCol, titleCol, bodyCol, activeBodyCol, doneBodyCol, footerCol;
        switch (theme) {
            case "highway_green" -> {
                qU0 = 128f / 256f; qV0 = 0f; tagIdx = 1;
                tagTextCol = 0xFFFFFFFF; titleCol = 0xFFFFFFFF;
                bodyCol = 0xFFF5FFF8; activeBodyCol = 0xFFFFE082; doneBodyCol = 0xFFFFFFFF;
                footerCol = 0xFFC8E6C9;
            }
            case "highway_blue", "poster_light" -> {
                qU0 = 0f; qV0 = 96f / 256f; tagIdx = 3;
                tagTextCol = 0xFFFFFFFF; titleCol = 0xFFF5F5F5;
                bodyCol = 0xFF1E2022; activeBodyCol = 0xFFB71C1C; doneBodyCol = 0xFF1B5E20;
                footerCol = 0xFF54585C;
            }
            case "warning_amber" -> {
                qU0 = 128f / 256f; qV0 = 96f / 256f; tagIdx = 2;
                tagTextCol = 0xFF141414; titleCol = 0xFFFFCA28;
                bodyCol = 0xFFF5F5F5; activeBodyCol = 0xFFFFB300; doneBodyCol = 0xFF81C784;
                footerCol = 0xFFFFB300;
            }
            default -> {
                qU0 = 0f; qV0 = 0f; tagIdx = 0;
                tagTextCol = 0xFF111111; titleCol = 0xFFFFA726;
                bodyCol = 0xFFF2F2F2; activeBodyCol = 0xFFFFAB00; doneBodyCol = 0xFFA5D6A7;
                footerCol = 0xFF9E9E9E;
            }
        }
        float qU1 = qU0 + (128f / 256f);
        float qV1 = qV0 + (96f / 256f);

        int fullBright = 0xF000F0;
        MinecraftClient mc = MinecraftClient.getInstance();
        TextRenderer tr = mc.textRenderer;

        matrices.push();
        WorldMapBoardRenderer.orientToWallFace(matrices, facing, depthFromCenter);

        VertexConsumer vc = vertexConsumers.getBuffer(RenderLayer.getEntityCutoutNoCull(BOARD_ATLAS));
        Matrix4f mat = matrices.peek().getPositionMatrix();
        Matrix3f nrm = matrices.peek().getNormalMatrix();

        float zFront = 0.0f;
        float mU0 = 192f / 256f, mV0 = 192f / 256f, mU1 = 1.0f, mV1 = 1.0f;

        emitTexQuad(vc, mat, nrm, xR, yB, zBack, xL, yB, zBack, xL, yT, zBack, xR, yT, zBack, mU0, mV1, mU1, mV0, light, 0, 0, -1);
        emitTexQuad(vc, mat, nrm, xL, yT, zBack, xR, yT, zBack, xR, yT, zFront, xL, yT, zFront, mU0, mV0, mU1, mV0 + 0.08f, light, 0, 1, 0);
        emitTexQuad(vc, mat, nrm, xL, yB, zFront, xR, yB, zFront, xR, yB, zBack, xL, yB, zBack, mU0, mV0, mU1, mV0 + 0.08f, light, 0, -1, 0);
        emitTexQuad(vc, mat, nrm, xL, yB, zBack, xL, yB, zFront, xL, yT, zFront, xL, yT, zBack, mU0, mV0, mU0 + 0.08f, mV1, light, -1, 0, 0);
        emitTexQuad(vc, mat, nrm, xR, yB, zFront, xR, yB, zBack, xR, yT, zBack, xR, yT, zFront, mU0, mV0, mU0 + 0.08f, mV1, light, 1, 0, 0);

        boolean emissiveFace = !"highway_blue".equals(theme) && !"poster_light".equals(theme);
        int faceLight = emissiveFace ? fullBright : Math.max(light, 0xD000D0);
        emitTexQuad(vc, mat, nrm,
                xL, yB, 0.002f, xR, yB, 0.002f, xR, yT, 0.002f, xL, yT, 0.002f,
                qU0, qV1, qU1, qV0, faceLight, 0, 0, 1);

        float padX = totalW * (8.5f / 128f);
        float hdrTop = yT - totalH * (6.5f / 96f);
        float hdrBot = yT - totalH * (22.5f / 96f);
        float hdrH   = hdrTop - hdrBot;

        String badgeText = sanitizeBoardText((spec.badge == null || spec.badge.isBlank()) ? "M1" : spec.badge);
        float tagH = hdrH * 0.76f;
        float tagW = Math.min(totalW * 0.24f, Math.max(tagH * 2.2f, 0.24f));
        float tagY0 = hdrBot + (hdrH - tagH) * 0.5f;
        emitTexQuad(vc, mat, nrm,
                xL + padX, tagY0, 0.004f, xL + padX + tagW, tagY0, 0.004f,
                xL + padX + tagW, tagY0 + tagH, 0.004f, xL + padX, tagY0 + tagH, 0.004f,
                (tagIdx * 48f) / 256f, 232f / 256f, (tagIdx * 48f + 46f) / 256f, 216f / 256f, fullBright, 0, 0, 1);

        List<String> lines = spec.lines;
        int nLines = (lines == null) ? 0 : Math.min(4, lines.size());
        float[] bandTop96 = {25f, 40f, 55f, 70f};
        float[] bandBot96 = {39f, 54f, 69f, 82f};
        boolean showStatusIcons = !"highway_green".equals(theme);
        float iconSize = totalH * (9.5f / 96f);

        if (showStatusIcons) {
            for (int i = 0; i < nLines; i++) {
                int iconIdx = detectStatusIcon(lines.get(i));
                float rTop = yT - totalH * (bandTop96[i] / 96f);
                float rBot = yT - totalH * (bandBot96[i] / 96f);
                float rMid = (rTop + rBot) * 0.5f;
                float ix0 = xL + padX;
                float iy0 = rMid - iconSize * 0.5f;
                emitTexQuad(vc, mat, nrm,
                        ix0, iy0, 0.004f, ix0 + iconSize, iy0, 0.004f,
                        ix0 + iconSize, iy0 + iconSize, 0.004f, ix0, iy0 + iconSize, 0.004f,
                        (iconIdx * 16f) / 256f, 208f / 256f, (iconIdx * 16f + 16f) / 256f, 192f / 256f,
                        fullBright, 0, 0, 1);
            }
        }

        if (tr != null) {
            float headerScaleY = Math.min((tagH * 0.62f) / 8.0f, totalW / 145.0f);
            drawMtrText(matrices, vertexConsumers, tr, badgeText,
                    xL + padX + tagW * 0.5f, tagY0 + tagH * 0.5f, tagW * 0.88f, headerScaleY,
                    tagTextCol, true, fullBright);

            String cleanTitle = sanitizeBoardText(spec.title);
            float titleX = xL + padX + tagW + totalW * 0.025f;
            float titleMaxW = (xR - padX) - titleX;
            drawMtrText(matrices, vertexConsumers, tr, cleanTitle,
                    titleX, tagY0 + tagH * 0.5f, titleMaxW, headerScaleY * 1.04f,
                    titleCol, false, fullBright);

            float rowBandH = totalH * (13.5f / 96f);
            float uniformRowScaleY = Math.min((rowBandH * 0.56f) / 8.0f, totalW / 170.0f);
            for (int i = 0; i < nLines; i++) {
                String raw = lines.get(i);
                String cleanLine = sanitizeBoardText(raw);
                int iconIdx = detectStatusIcon(raw);
                int rowCol = (iconIdx == 0) ? doneBodyCol : ((iconIdx == 1 || iconIdx == 3) ? activeBodyCol : bodyCol);

                float rTop = yT - totalH * (bandTop96[i] / 96f);
                float rBot = yT - totalH * (bandBot96[i] / 96f);
                float rMid = (rTop + rBot) * 0.5f;
                float textX = showStatusIcons ? (xL + padX + iconSize + totalW * 0.02f) : (xL + padX * 1.15f);
                float maxLineW = (xR - padX) - textX;
                drawMtrText(matrices, vertexConsumers, tr, cleanLine,
                        textX, rMid, maxLineW, uniformRowScaleY, rowCol, false, fullBright);
            }

            String cleanFooter = sanitizeBoardText(spec.footer);
            if (!cleanFooter.isEmpty()) {
                float fTop = yT - totalH * (83f / 96f);
                float fBot = yT - totalH * (91f / 96f);
                float footerScaleY = Math.min(((fTop - fBot) * 0.68f) / 8.0f, uniformRowScaleY * 0.78f);
                drawMtrText(matrices, vertexConsumers, tr, cleanFooter + "  |  Sag Tik: Duzenle",
                        0.0f, (fTop + fBot) * 0.5f, totalW - padX * 2.1f, footerScaleY,
                        footerCol, true, fullBright);
            }
        }

        matrices.pop();
    }

    private static String sanitizeBoardText(String raw) {
        if (raw == null) return "";
        return raw.replace("[✓]", "").replace("[→]", "").replace("[•]", "")
                .replace("⚠", "").replace("◈", "").replace("●", "")
                .replace("•", "-").replace("↓", "v").replace("↗", ">")
                .replaceAll("\\s{2,}", " ").trim();
    }

    private static int detectStatusIcon(String raw) {
        if (raw == null) return 2;
        if (raw.contains("✓")) return 0;
        if (raw.contains("⚠")) return 3;
        if (raw.contains("→")) return 1;
        return 2;
    }

    private static void emitTexQuad(VertexConsumer vc, Matrix4f mat, Matrix3f nrm,
                                    float x0, float y0, float z0, float x1, float y1, float z1,
                                    float x2, float y2, float z2, float x3, float y3, float z3,
                                    float u0, float v0, float u1, float v1,
                                    int light, float nx, float ny, float nz) {
        vc.vertex(mat, x0, y0, z0).color(255, 255, 255, 255).texture(u0, v0).overlay(OverlayTexture.DEFAULT_UV).light(light).normal(nrm, nx, ny, nz).next();
        vc.vertex(mat, x1, y1, z1).color(255, 255, 255, 255).texture(u1, v0).overlay(OverlayTexture.DEFAULT_UV).light(light).normal(nrm, nx, ny, nz).next();
        vc.vertex(mat, x2, y2, z2).color(255, 255, 255, 255).texture(u1, v1).overlay(OverlayTexture.DEFAULT_UV).light(light).normal(nrm, nx, ny, nz).next();
        vc.vertex(mat, x3, y3, z3).color(255, 255, 255, 255).texture(u0, v1).overlay(OverlayTexture.DEFAULT_UV).light(light).normal(nrm, nx, ny, nz).next();
    }

    private static void drawMtrText(MatrixStack matrices, VertexConsumerProvider vcp, TextRenderer tr,
                                    String text, float anchorX, float centerY, float maxWorldW, float fixedScaleY,
                                    int color, boolean centered, int light) {
        if (text == null || text.isEmpty() || maxWorldW <= 0.02f || fixedScaleY <= 0.0001f) return;
        int pxW = Math.max(1, tr.getWidth(text));
        float naturalW = pxW * fixedScaleY;
        float scaleX = (naturalW > maxWorldW) ? (maxWorldW / pxW) : fixedScaleY;

        matrices.push();
        matrices.translate(anchorX, centerY + (3.6f * fixedScaleY), 0.007f);
        matrices.scale(scaleX, -fixedScaleY, fixedScaleY);
        float drawX = centered ? (-pxW * 0.5f) : 0.0f;
        tr.draw(text, drawX, 0.0f, color, false, matrices.peek().getPositionMatrix(), vcp,
                TextRenderer.TextLayerType.NORMAL, 0, light);
        matrices.pop();
    }
}

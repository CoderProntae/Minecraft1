package ai.arena.bridge.board;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Live API-Driven Multi-Scale Board, Stand, Poster & Highway Gantry Registry (v7.7.0):
 * Persists to arena-programmable-boards.json and updates live at 60 FPS via POST /api/map {"board": ...}.
 */
public final class ProgrammableBoardManager {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static final class BoardSpec {
        public String id = "default";
        public int widthBlocks = 2;
        public int heightBlocks = 1;
        public String theme = "roadmap"; // roadmap, highway_green, highway_blue, warning_amber, poster
        public String badge = "PLAN";
        public String title = "ALTYAPI VE ULAŞIM PLANI";
        public List<String> lines = new ArrayList<>();
        public String footer = "ArenaAI Canlı Mühendislik Panosu";
    }

    public static final Map<String, BoardSpec> BOARDS = new ConcurrentHashMap<>();
    private static boolean loaded = false;

    private ProgrammableBoardManager() {}

    public static File getFile() {
        return new File(FabricLoader.getInstance().getGameDir().toFile(), "arena-programmable-boards.json");
    }

    public static synchronized void ensureLoaded() {
        if (loaded) return;
        loaded = true;
        File f = getFile();
        if (f.exists()) {
            try {
                JsonObject root = JsonParser.parseString(Files.readString(f.toPath(), StandardCharsets.UTF_8)).getAsJsonObject();
                if (root.has("boards") && root.get("boards").isJsonArray()) {
                    for (JsonElement el : root.getAsJsonArray("boards")) {
                        BoardSpec bs = fromJson(el.getAsJsonObject());
                        BOARDS.put(bs.id, bs);
                    }
                }
            } catch (Throwable ignored) {}
        }
        if (!BOARDS.containsKey("default")) {
            seedDefaults();
            saveToDisk();
        }
    }

    public static void seedDefaults() {
        BoardSpec def = new BoardSpec();
        def.id = "default";
        def.widthBlocks = 2;
        def.heightBlocks = 2;
        def.theme = "roadmap";
        def.badge = "PLANLAR";
        def.title = "YÜZEY HATTI & ULAŞIM PLANLARI";
        def.lines.add("[✓] M1 Kuzey-Güney Orman Ana Hat (80 km/s)");
        def.lines.add("[→] M1-Yüzey Şube Hattı & Orman Viyadüğü");
        def.lines.add("[→] İstasyon Meydanı Aktarma & Yeni Asansör");
        def.lines.add("[•] O-7 Kuzey Orman Otoyolu & Dev Tabelalar");
        def.footer = "Yüzey Hattı & Altyapı Master Planı";
        BOARDS.put(def.id, def);

        BoardSpec hwy = new BoardSpec();
        hwy.id = "otoban_ornek";
        hwy.widthBlocks = 5;
        hwy.heightBlocks = 2;
        hwy.theme = "highway_green";
        hwy.badge = "O-7";
        hwy.title = "KUZEY ORMAN OTOYOLU";
        hwy.lines.add("↓ ↓   Kuzey Orman Merkez    1.5 km");
        hwy.lines.add("↗     Güney Gar / Metro P+R  400 m");
        hwy.footer = "Azami Hız: 120 km/s • Şerit Yönlendirme";
        BOARDS.put(hwy.id, hwy);
    }

    public static BoardSpec resolve(String boardId) {
        ensureLoaded();
        if (boardId != null && !boardId.isBlank() && BOARDS.containsKey(boardId)) {
            return BOARDS.get(boardId);
        }
        return BOARDS.getOrDefault("default", new BoardSpec());
    }

    private static BoardSpec fromJson(JsonObject o) {
        BoardSpec b = new BoardSpec();
        if (o.has("id")) b.id = o.get("id").getAsString();
        if (o.has("width")) b.widthBlocks = Math.max(1, Math.min(8, o.get("width").getAsInt()));
        if (o.has("height")) b.heightBlocks = Math.max(1, Math.min(4, o.get("height").getAsInt()));
        if (o.has("theme")) b.theme = o.get("theme").getAsString();
        if (o.has("badge")) b.badge = o.get("badge").getAsString();
        if (o.has("title")) b.title = o.get("title").getAsString();
        if (o.has("footer")) b.footer = o.get("footer").getAsString();
        if (o.has("lines") && o.get("lines").isJsonArray()) {
            b.lines.clear();
            for (JsonElement le : o.getAsJsonArray("lines")) {
                b.lines.add(le.getAsString());
            }
        }
        return b;
    }

    public static synchronized void saveToDisk() {
        try {
            Files.writeString(getFile().toPath(), GSON.toJson(toJson()), StandardCharsets.UTF_8);
        } catch (Throwable ignored) {}
    }

    public static JsonObject toJson() {
        JsonObject root = new JsonObject();
        root.addProperty("ok", true);
        JsonArray arr = new JsonArray();
        for (BoardSpec b : BOARDS.values()) {
            JsonObject o = new JsonObject();
            o.addProperty("id", b.id);
            o.addProperty("width", b.widthBlocks);
            o.addProperty("height", b.heightBlocks);
            o.addProperty("theme", b.theme);
            o.addProperty("badge", b.badge);
            o.addProperty("title", b.title);
            o.addProperty("footer", b.footer);
            JsonArray la = new JsonArray();
            for (String s : b.lines) la.add(s);
            o.add("lines", la);
            arr.add(o);
        }
        root.add("boards", arr);
        return root;
    }

    public static JsonObject handleApi(String bodyStr) {
        ensureLoaded();
        try {
            if (bodyStr == null || bodyStr.isBlank()) return toJson();
            JsonObject req = JsonParser.parseString(bodyStr).getAsJsonObject();
            if (req.has("board") && req.get("board").isJsonObject()) {
                req = req.getAsJsonObject("board");
            }
            String op = req.has("op") ? req.get("op").getAsString() : "upsert";
            if ("upsert".equalsIgnoreCase(op)) {
                String id = req.has("id") ? req.get("id").getAsString() : "default";
                BoardSpec existing = BOARDS.getOrDefault(id, new BoardSpec());
                existing.id = id;
                if (req.has("width")) existing.widthBlocks = Math.max(1, Math.min(8, req.get("width").getAsInt()));
                if (req.has("height")) existing.heightBlocks = Math.max(1, Math.min(4, req.get("height").getAsInt()));
                if (req.has("theme")) existing.theme = req.get("theme").getAsString();
                if (req.has("badge")) existing.badge = req.get("badge").getAsString();
                if (req.has("title")) existing.title = req.get("title").getAsString();
                if (req.has("footer")) existing.footer = req.get("footer").getAsString();
                if (req.has("lines") && req.get("lines").isJsonArray()) {
                    existing.lines.clear();
                    for (JsonElement le : req.getAsJsonArray("lines")) {
                        existing.lines.add(le.getAsString());
                    }
                }
                BOARDS.put(id, existing);
                saveToDisk();
            } else if ("remove".equalsIgnoreCase(op) && req.has("id")) {
                BOARDS.remove(req.get("id").getAsString());
                saveToDisk();
            } else if ("reset".equalsIgnoreCase(op)) {
                BOARDS.clear();
                seedDefaults();
                saveToDisk();
            }
        } catch (Throwable ignored) {}
        return toJson();
    }
}

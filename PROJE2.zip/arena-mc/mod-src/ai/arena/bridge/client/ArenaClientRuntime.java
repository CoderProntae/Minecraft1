package ai.arena.bridge.client;

import ai.arena.bridge.ArenaContent;
import ai.arena.bridge.audio.LocalTtsManager;
import ai.arena.bridge.board.MetroFurnitureRenderers;
import ai.arena.bridge.board.TransitNewsBoardRenderer;
import ai.arena.bridge.board.WorldMapBoardRenderer;
import ai.arena.bridge.map.ArenaMapData;
import ai.arena.bridge.map.ArenaMapScreen;
import ai.arena.bridge.map.WorldAtlasManager;
import ai.arena.bridge.transit.UitpSystemType;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.BlockEntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.util.InputUtil;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Clean client runtime (v7.1.0):
 * - Registers 3D block entity renderers (WorldMapBoard, TransitNewsBoard, TunnelLightRenderer).
 * - Renders ONLY the optional N-key minimap on HUD (zero clutter banners or overlays).
 * - Natural atmospheric storm fog & wind-angled outdoor rain.
 * - Real-time 3D Spatial + Reverb Station & Onboard Metro Announcements ("Gelecek istasyon...").
 */
public final class ArenaClientRuntime {

    public static volatile boolean weatherGraphicsEnabled = true;

    private static KeyBinding openMapKey;
    private static KeyBinding toggleMinimapKey;
    private static KeyBinding toggleRadarKey;
    private static boolean initialized = false;
    private static int clientTicks = 0;
    private static float smoothStormFactor = 0.0f;
    private static final Random RNG = new Random();

    // Per-train station dwell & approaching-station announcement state
    private static final Map<String, Long> DWELLING_AT_STATION_ID = new HashMap<>();
    private static final Map<String, Long> LAST_ORIGIN_STATION_ID = new HashMap<>();
    private static final Map<String, String> APPROACH_ANNOUNCED_TARGET = new HashMap<>();
    private static long lastVoiceTriggerMs = 0L;
    private static float tunnelEmergencyBlend = 0.0f;
    private static long lastLightmapFrameNs = 0L;
    private static boolean wasTunnelEmergencyLightmapActive = false;
    private static java.lang.reflect.Field ltmTextureField = null;
    private static java.lang.reflect.Field ltmDirtyField = null;
    private static boolean ltmFieldsResolved = false;

    private ArenaClientRuntime() {}

    public static synchronized void initClient() {
        if (initialized) return;
        initialized = true;

        try {
            net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap.INSTANCE.putBlock(
                    ArenaContent.VENDING_MACHINE, RenderLayer.getTranslucent()
            );
            net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap.INSTANCE.putBlock(
                    ArenaContent.SAFETY_CABINET, RenderLayer.getTranslucent()
            );
            net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap.INSTANCE.putBlock(
                    ArenaContent.HIZMET_DISI_SERIT, RenderLayer.getCutout()
            );
            net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap.INSTANCE.putBlock(
                    ArenaContent.YAKINDA_SERIT, RenderLayer.getCutout()
            );
        } catch (Throwable ignored) {
            try {
                for (java.lang.reflect.Field f : RenderLayers.class.getDeclaredFields()) {
                    if (Map.class.isAssignableFrom(f.getType())) {
                        f.setAccessible(true);
                        Map<?, ?> m = (Map<?, ?>) f.get(null);
                        if (m != null && (m.containsKey(Blocks.GLASS) || m.containsKey(Blocks.TINTED_GLASS))) {
                            @SuppressWarnings("unchecked")
                            Map<Block, RenderLayer> blockLayers = (Map<Block, RenderLayer>) m;
                            blockLayers.put(ArenaContent.VENDING_MACHINE, RenderLayer.getTranslucent());
                            blockLayers.put(ArenaContent.SAFETY_CABINET, RenderLayer.getTranslucent());
                            break;
                        }
                    }
                }
            } catch (Throwable ignored2) {}
        }

        BlockEntityRendererRegistry.register(ArenaContent.MAP_BOARD_BE_TYPE, WorldMapBoardRenderer::new);
        BlockEntityRendererRegistry.register(ArenaContent.NEWS_BOARD_BE_TYPE, TransitNewsBoardRenderer::new);
        BlockEntityRendererRegistry.register(ArenaContent.VENDING_BE_TYPE, MetroFurnitureRenderers.VendingMachineRenderer::new);
        BlockEntityRendererRegistry.register(ArenaContent.PROGRAMMABLE_BOARD_BE_TYPE, ai.arena.bridge.board.ProgrammableBoardRenderer::new);

        openMapKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.arena_ai_bridge.open_map",
                InputUtil.Type.KEYSYM,
                InputUtil.GLFW_KEY_M,
                "category.arena_ai_bridge"
        ));
        toggleMinimapKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.arena_ai_bridge.toggle_minimap",
                InputUtil.Type.KEYSYM,
                InputUtil.GLFW_KEY_N,
                "category.arena_ai_bridge"
        ));
        toggleRadarKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.arena_ai_bridge.toggle_radar",
                InputUtil.Type.KEYSYM,
                InputUtil.GLFW_KEY_R,
                "category.arena_ai_bridge"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            ai.arena.bridge.hotpatch.HotPatchManager.onClientTick(client);
            LiveRigidBodyRenderer.tickEmergencyAlarmAudio(client);
            onClientTick(client);
        });

        WorldRenderEvents.START.register(ctx -> {
            applyDynamicTunnelEmergencyLighting(MinecraftClient.getInstance(), ctx.tickDelta());
            LiveRigidBodyRenderer.applyTrainCarbodySway(ctx);

            if (weatherGraphicsEnabled && smoothStormFactor > 0.02f) {
                float baseEnd = RenderSystem.getShaderFogEnd();
                if (baseEnd > 48.0f) {
                    float factor = 1.0f - 0.36f * smoothStormFactor;
                    RenderSystem.setShaderFogEnd(Math.max(56.0f, baseEnd * factor));
                    RenderSystem.setShaderFogStart(Math.max(12.0f, RenderSystem.getShaderFogStart() * factor));
                }
            }
        });

        WorldRenderEvents.AFTER_ENTITIES.register(LiveRigidBodyRenderer::renderWorldBodies);

        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc == null || mc.player == null || mc.world == null || mc.options.hudHidden) return;
            if (ArenaMapData.minimapEnabled && mc.currentScreen == null) {
                ArenaMapScreen.renderMiniMap(drawContext, drawContext.getScaledWindowWidth() - 96, 8, 88);
            }
            if (LiveRigidBodyRenderer.radarOpen && mc.currentScreen == null) {
                LiveRigidBodyRenderer.renderGeotechnicalRadarHud(drawContext);
            }
        });
    }

    private static void onClientTick(MinecraftClient mc) {
        while (openMapKey.wasPressed()) {
            if (mc.currentScreen instanceof ArenaMapScreen) {
                mc.setScreen(null);
            } else {
                mc.setScreen(new ArenaMapScreen(0));
            }
        }
        while (toggleMinimapKey.wasPressed()) {
            ArenaMapData.minimapEnabled = !ArenaMapData.minimapEnabled;
            if (mc.player != null) {
                mc.player.sendMessage(Text.literal(
                        ArenaMapData.minimapEnabled ? "Mini harita açıldı." : "Mini harita kapatıldı."
                ).formatted(Formatting.GRAY), true);
            }
        }

        while (toggleRadarKey.wasPressed()) {
            LiveRigidBodyRenderer.radarOpen = !LiveRigidBodyRenderer.radarOpen;
            if (mc.player != null) {
                mc.player.sendMessage(Text.literal(
                        LiveRigidBodyRenderer.radarOpen ? "Jeoteknik ve Yapısal Radar açıldı." : "Jeoteknik ve Yapısal Radar kapatıldı."
                ).formatted(Formatting.AQUA), true);
            }
        }
        if (mc.player == null || mc.world == null) return;
        clientTicks++;
        ArenaMapData.ensureLoaded();
        WorldAtlasManager.tickIncrementalScan(mc);

        // 1. Natural storm atmosphere & outdoor wind-angled rain
        float rainGrad = mc.world.getRainGradient(1.0f);
        float thunderGrad = mc.world.getThunderGradient(1.0f);
        float targetStorm = Math.min(1.0f, rainGrad * 0.55f + thunderGrad * 0.45f);
        smoothStormFactor += (targetStorm - smoothStormFactor) * 0.05f;

        if (weatherGraphicsEnabled && rainGrad > 0.25f && mc.player.getY() >= 58.0) {
            BlockPos eye = mc.player.getBlockPos().up();
            if (mc.world.isSkyVisible(eye)) {
                int count = thunderGrad > 0.3f ? 10 : 5;
                for (int i = 0; i < count; i++) {
                    double px = mc.player.getX() + (RNG.nextDouble() - 0.5) * 26.0;
                    double pz = mc.player.getZ() + (RNG.nextDouble() - 0.5) * 26.0;
                    int topY = mc.world.getTopY(Heightmap.Type.MOTION_BLOCKING, (int) Math.floor(px), (int) Math.floor(pz));
                    if (Math.abs(topY - mc.player.getY()) <= 16.0) {
                        mc.world.addParticle(ParticleTypes.RAIN, px, topY + 6.0 + RNG.nextDouble() * 5.0, pz, 0.14, -0.85, 0.06);
                        if (thunderGrad > 0.3f && (i & 3) == 0) {
                            mc.world.addParticle(ParticleTypes.SPLASH, px, topY + 0.05, pz, 0.04, 0.08, 0.02);
                        }
                    }
                }
            }
        }

        // 2. Dynamic 3D Spatial + Reverb MTR Station & Onboard Announcements (Every 5 ticks)
        if (clientTicks % 5 != 0) return;

        List<ArenaMapData.LiveTrainInfo> trains = ArenaMapData.getLiveTrains();
        List<ArenaMapData.LiveStationInfo> stations = ArenaMapData.getLiveStations();
        if (trains.isEmpty() || stations.isEmpty()) return;

        long now = System.currentTimeMillis();
        double px = mc.player.getX();
        double py = mc.player.getY();
        double pz = mc.player.getZ();

        int idx = 0;
        for (ArenaMapData.LiveTrainInfo t : trains) {
            String key = t.routeNumber + "#" + (idx++);
            ArenaMapData.LiveStationInfo stoppedStation = null;
            if (t.speedKmh < 1.8) {
                for (ArenaMapData.LiveStationInfo st : stations) {
                    double ds = Math.sqrt(sq(t.x - st.x) + sq(t.y - st.y) + sq(t.z - st.z));
                    if (ds <= 28.0) {
                        stoppedStation = st;
                        break;
                    }
                }
            }

            Long prevStationId = DWELLING_AT_STATION_ID.get(key);
            double distToTrain = Math.sqrt(sq(px - t.x) + sq(py - t.y) + sq(pz - t.z));
            boolean onboard = distToTrain <= 9.5;
            boolean inTunnel = t.y < 59.0 || !mc.world.isSkyVisible(BlockPos.ofFloored(t.x, t.y + 2.0, t.z));
            String spokenLine = UitpSystemType.toSpokenTurkishTitle(t.routeNumber, t.routeName);

            if (stoppedStation != null) {
                if (prevStationId == null || prevStationId != stoppedStation.id) {
                    DWELLING_AT_STATION_ID.put(key, stoppedStation.id);
                    LAST_ORIGIN_STATION_ID.put(key, stoppedStation.id);
                    APPROACH_ANNOUNCED_TARGET.remove(key);

                    String stClean = cleanStationName(stoppedStation.name);
                    double distToSt = Math.sqrt(sq(px - stoppedStation.x) + sq(py - stoppedStation.y) + sq(pz - stoppedStation.z));

                    if (now - lastVoiceTriggerMs > 8_500L) {
                        if (onboard) {
                            lastVoiceTriggerMs = now;
                            LocalTtsManager.speakTrainCabin(
                                    stClean + " istasyonuna ulaştık. İnecek yolcularımızın hazırlanması rica olunur.",
                                    "arr_onboard",
                                    t.routeNumber,
                                    0.95f,
                                    inTunnel,
                                    false
                            );
                        } else if (distToSt <= 72.0) {
                            lastVoiceTriggerMs = now;
                            boolean stUnderground = stoppedStation.y < 59.0
                                    || !mc.world.isSkyVisible(BlockPos.ofFloored(stoppedStation.x, stoppedStation.y + 3.0, stoppedStation.z));
                            LocalTtsManager.speakStationSpeaker(
                                    "Sayın yolcularımız, " + spokenLine + " perona yanaşmıştır. Lütfen sarı çizgiyi geçmeyiniz.",
                                    "arr_platform",
                                    stoppedStation.x,
                                    stoppedStation.y + 3.5,
                                    stoppedStation.z,
                                    0.96f,
                                    stUnderground,
                                    false
                            );
                        }
                    }
                }
            } else if (prevStationId != null && t.speedKmh > 3.5) {
                // Train just departed platform!
                DWELLING_AT_STATION_ID.remove(key);
                String targetName = resolveUpcomingStationName(t, stations, LAST_ORIGIN_STATION_ID.get(key));

                if (onboard && now - lastVoiceTriggerMs > 7_500L) {
                    lastVoiceTriggerMs = now;
                    String msg = targetName.isEmpty()
                            ? ("Sayın yolcularımız, " + spokenLine + " seferimiz hareket etmiştir.")
                            : ("Sayın yolcularımız, " + spokenLine + " seferimiz hareket etmiştir. Gelecek istasyon, " + targetName + ".");
                    LocalTtsManager.speakTrainCabin(msg, "dep_onboard", t.routeNumber, 0.95f, inTunnel, false);
                } else if (!onboard) {
                    // Bystander on platform hears station departure PA, which fades if they walk/ride away!
                    ArenaMapData.LiveStationInfo depSt = findStationById(stations, prevStationId);
                    if (depSt != null) {
                        double distToDep = Math.sqrt(sq(px - depSt.x) + sq(py - depSt.y) + sq(pz - depSt.z));
                        if (distToDep <= 65.0 && now - lastVoiceTriggerMs > 10_000L) {
                            lastVoiceTriggerMs = now;
                            boolean stUnder = depSt.y < 59.0;
                            LocalTtsManager.speakStationSpeaker(
                                    spokenLine + " perondan ayrılmaktadır. Lütfen emniyet çizgisinin gerisinde durunuz.",
                                    "dep_platform",
                                    depSt.x, depSt.y + 3.5, depSt.z,
                                    0.90f, stUnder, false
                            );
                        }
                    }
                }
            } else if (onboard && t.speedKmh > 8.0) {
                // Mid-tunnel / Approaching next station announcement (~120m..310m before arrival!)
                ArenaMapData.LiveStationInfo upcomingSt = resolveUpcomingStation(t, stations, LAST_ORIGIN_STATION_ID.get(key));
                if (upcomingSt != null) {
                    double distToUpcoming = Math.sqrt(sq(t.x - upcomingSt.x) + sq(t.y - upcomingSt.y) + sq(t.z - upcomingSt.z));
                    String targetKey = Long.toString(upcomingSt.id);
                    if (distToUpcoming <= 310.0 && distToUpcoming >= 105.0
                            && !targetKey.equals(APPROACH_ANNOUNCED_TARGET.get(key))
                            && now - lastVoiceTriggerMs > 9_000L) {
                        APPROACH_ANNOUNCED_TARGET.put(key, targetKey);
                        lastVoiceTriggerMs = now;
                        String stClean = cleanStationName(upcomingSt.name);
                        LocalTtsManager.speakTrainCabin(
                                "Gelecek istasyon, " + stClean + ". Kapıların açılacağı tarafa dikkat ediniz.",
                                "approach_onboard",
                                t.routeNumber,
                                0.95f,
                                inTunnel,
                                false
                        );
                    }
                }
            }
        }
    }

    private static ArenaMapData.LiveStationInfo findStationById(List<ArenaMapData.LiveStationInfo> stations, Long id) {
        if (id == null) return null;
        for (ArenaMapData.LiveStationInfo st : stations) {
            if (st.id == id) return st;
        }
        return null;
    }

    private static ArenaMapData.LiveStationInfo resolveUpcomingStation(
            ArenaMapData.LiveTrainInfo t,
            List<ArenaMapData.LiveStationInfo> stations,
            Long originId
    ) {
        String rawTarget = !t.nextStation.isEmpty() ? t.nextStation : t.destination;
        if (!rawTarget.isEmpty()) {
            String clean = cleanStationName(rawTarget);
            for (ArenaMapData.LiveStationInfo st : stations) {
                if (cleanStationName(st.name).equalsIgnoreCase(clean)) return st;
            }
        }
        // Fallback: closest station along heading that isn't the station we just departed
        ArenaMapData.LiveStationInfo best = null;
        double bestDist = Double.MAX_VALUE;
        for (ArenaMapData.LiveStationInfo st : stations) {
            if (originId != null && st.id == originId) continue;
            double d = Math.sqrt(sq(t.x - st.x) + sq(t.y - st.y) + sq(t.z - st.z));
            if (d < bestDist) {
                bestDist = d;
                best = st;
            }
        }
        return best;
    }

    private static String resolveUpcomingStationName(
            ArenaMapData.LiveTrainInfo t,
            List<ArenaMapData.LiveStationInfo> stations,
            Long originId
    ) {
        ArenaMapData.LiveStationInfo st = resolveUpcomingStation(t, stations, originId);
        if (st != null) return cleanStationName(st.name);
        return cleanStationName(!t.nextStation.isEmpty() ? t.nextStation : t.destination);
    }

    private static String cleanStationName(String raw) {
        if (raw == null) return "";
        int pipe = raw.indexOf('|');
        String base = (pipe >= 0 ? raw.substring(0, pipe) : raw).trim();
        return base;
    }

    private static double sq(double v) {
        return v * v;
    }

    /**
     * Real-time GPU LightmapTextureManager Dynamic Red/Darkness Tunnel Lighting (0.004ms, ZERO BlockEntities, ZERO chunk rebuilds!):
     * - When thundering inside a tunnel equipped with tunnel_emergency_light:
     *   * Blink ON: bathes all skyLight==0 block-lit walls, ceiling, rails, and the white LED diffuser in vivid crimson red!
     *   * Blink OFF: plunges skyLight==0 block-lit surfaces into authentic emergency darkness (zero white light bleed!).
     */
    private static void applyDynamicTunnelEmergencyLighting(MinecraftClient mc, float tickDelta) {
        if (mc == null || mc.gameRenderer == null || mc.world == null || mc.player == null) return;

        long nowNs = System.nanoTime();
        float dt = (lastLightmapFrameNs == 0L) ? 0.016f : Math.min(0.10f, (nowNs - lastLightmapFrameNs) * 1e-9f);
        lastLightmapFrameNs = nowNs;

        // Trigger red/darkness lightmap ONLY around structurally cracked/collapsing enclosed tunnel sectors (EMERGENCY == true)!
        float spatialTarget = 0.0f;
        if (mc.player.getY() < 58.0) {
            Vec3d cam = mc.gameRenderer.getCamera().getPos();
            int cx = (int) Math.floor(cam.x);
            int cy = (int) Math.floor(cam.y);
            int cz = (int) Math.floor(cam.z);
            BlockPos.Mutable mp = new BlockPos.Mutable();
            int skyHere = mc.world.getLightLevel(net.minecraft.world.LightType.SKY, mp.set(cx, cy, cz));
            boolean inStationBox = (cz >= 16 && cz <= 48) || (cz >= 1564 && cz <= 1596);
            if (skyHere <= 2 && !inStationBox) {
                double minDistSq = Double.MAX_VALUE;
                for (int dx = -5; dx <= 5; dx++) {
                    for (int dz = -10; dz <= 10; dz++) {
                        for (int dy = -1; dy <= 5; dy++) {
                            int bx = cx + dx, by = cy + dy, bz = cz + dz;
                            net.minecraft.block.BlockState st = mc.world.getBlockState(mp.set(bx, by, bz));
                            if (st.isOf(ArenaContent.TUNNEL_EMERGENCY_LIGHT) && st.get(ArenaContent.EMERGENCY)) {
                                double d2 = cam.squaredDistanceTo(bx + 0.5, by + 0.5, bz + 0.5);
                                if (d2 < minDistSq) minDistSq = d2;
                            }
                        }
                    }
                }
                if (minDistSq < Double.MAX_VALUE) {
                    double dist = Math.sqrt(minDistSq);
                    // Strictly local to the damaged/flooded ring itself (<= 7.5m) so undamaged sectors stay crisp white!
                    if (dist <= 4.0) {
                        spatialTarget = 0.85f;
                    } else if (dist < 7.5) {
                        spatialTarget = (float) (0.85 * (7.5 - dist) / 3.5);
                    }
                }
            }
        }

        tunnelEmergencyBlend += (spatialTarget - tunnelEmergencyBlend) * Math.min(1.0f, dt * 8.0f);
        if (tunnelEmergencyBlend < 0.003f && !wasTunnelEmergencyLightmapActive) {
            tunnelEmergencyBlend = 0.0f;
            return;
        }

        try {
            LightmapTextureManager ltm = mc.gameRenderer.getLightmapTextureManager();
            if (!ltmFieldsResolved) {
                ltmFieldsResolved = true;
                for (java.lang.reflect.Field f : LightmapTextureManager.class.getDeclaredFields()) {
                    if (f.getType() == NativeImageBackedTexture.class) {
                        f.setAccessible(true);
                        ltmTextureField = f;
                    } else if (f.getType() == boolean.class) {
                        f.setAccessible(true);
                        ltmDirtyField = f;
                    }
                }
            }
            if (ltmTextureField == null || ltmDirtyField == null) return;

            // ALWAYS compute fresh vanilla lightmap first so sky=1..5 transitions never accumulate stale red!
            ltmDirtyField.setBoolean(ltm, true);
            ltm.update(tickDelta);

            if (tunnelEmergencyBlend < 0.003f) {
                tunnelEmergencyBlend = 0.0f;
                wasTunnelEmergencyLightmapActive = false;
                return;
            }

            wasTunnelEmergencyLightmapActive = true;
            NativeImageBackedTexture tex = (NativeImageBackedTexture) ltmTextureField.get(ltm);
            if (tex == null || tex.getImage() == null) return;
            NativeImage img = tex.getImage();

            // Locked 100% to led_red_emergency.png.mcmeta (frametime: 10 => 20 ticks cycle: 0..10 ON, 10..20 OFF)
            float phase = (((mc.world.getTime() % 20L) + tickDelta) / 20.0f);
            float pulse;
            if (phase < 0.06f) {
                pulse = phase / 0.06f;
            } else if (phase < 0.46f) {
                pulse = 1.0f;
            } else if (phase < 0.54f) {
                pulse = 1.0f - (phase - 0.46f) / 0.08f;
            } else {
                pulse = 0.0f;
            }

            for (int sky = 0; sky <= 6; sky++) {
                float underground = Math.max(0.0f, 1.0f - (sky / 5.5f));
                float w = tunnelEmergencyBlend * underground;
                if (w <= 0.001f) continue;

                for (int block = 0; block < 16; block++) {
                    int cur = img.getColor(block, sky);
                    int vr = cur & 0xFF;
                    int vg = (cur >>> 8) & 0xFF;
                    int vb = (cur >>> 16) & 0xFF;

                    float normB = block / 15.0f;
                    float curved = normB * normB;

                    // Pulse ON = vivid crimson (255, 10, 9); Pulse OFF = dark tunnel ember (16, 2, 2) — NEVER white!
                    float er = 5.0f + 11.0f * normB + pulse * (239.0f * curved);
                    float eg = 1.0f + pulse * (9.0f * curved);
                    float eb = 1.0f + pulse * (8.0f * curved);

                    int ri = Math.min(255, Math.max(0, Math.round(vr + (er - vr) * w)));
                    int gi = Math.min(255, Math.max(0, Math.round(vg + (eg - vg) * w)));
                    int bi = Math.min(255, Math.max(0, Math.round(vb + (eb - vb) * w)));
                    img.setColor(block, sky, 0xFF000000 | (bi << 16) | (gi << 8) | ri);
                }
            }
            tex.upload();
        } catch (Throwable ignored) {}
    }
}

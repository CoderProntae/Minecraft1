package ai.arena.bridge.client;

import ai.arena.bridge.ArenaContent;
import ai.arena.bridge.board.WorldMapBoardRenderer;
import ai.arena.bridge.map.ArenaMapData;
import ai.arena.bridge.map.ArenaMapScreen;
import ai.arena.bridge.physics.GeoStructuralPhysicsEngine;
import ai.arena.bridge.transit.RegionPolicyEngine;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Custom Pixel-Art Textured Minecraft GUI Screens for Vending Machine & Info Kiosk (v7.8.0):
 * - VendingScreen: 3x3 9-Item Interactive Showcase Grid synced 1-to-1 with the 9 3D items rendered
 *   inside vending_machine_upper.json, using silent Fabric C2S networking (zero chat spam!) + OLED toast.
 * - InfoKioskScreen: Real-time M1 train position/speed/ETA telemetry, Tunnel Geotechnical FoS & SCADA status,
 *   live Orman Kart wallet balance, and instant Map / Top-Up / Close controls.
 */
public final class MetroScreens {

    private static final Identifier VENDING_GUI_TEX = new Identifier(ArenaContent.MOD_ID, "textures/gui/vending_gui.png");
    private static final Identifier KIOSK_GUI_TEX   = new Identifier(ArenaContent.MOD_ID, "textures/gui/kiosk_gui.png");

    private MetroScreens() {}

    public static void openVendingScreen(BlockPos pos) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc != null) {
            mc.setScreen(new VendingScreen(pos));
        }
    }

    public static void openInfoKioskScreen(BlockPos pos) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc != null) {
            mc.setScreen(new InfoKioskScreen(pos));
        }
    }

    public static void sendVendingActionSilent(int op, int itemIndex, BlockPos pos) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.player == null) return;
        mc.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, 1.05f));
        if (ClientPlayNetworking.canSend(ArenaContent.VENDING_ACTION_PACKET)) {
            PacketByteBuf buf = PacketByteBufs.create();
            buf.writeByte(op); // 0 = buy itemIndex, 1 = topup emerald (+10), 2 = topup gold (+5)
            buf.writeVarInt(itemIndex);
            buf.writeBlockPos(pos);
            ClientPlayNetworking.send(ArenaContent.VENDING_ACTION_PACKET, buf);
        } else if (mc.player.networkHandler != null) {
            if (op == 0) {
                mc.player.networkHandler.sendCommand("otomat al " + itemIndex + " " + pos.getX() + " " + pos.getY() + " " + pos.getZ());
            } else {
                mc.player.networkHandler.sendCommand(op == 1 ? "otomat yukle zumrut" : "otomat yukle altin");
            }
        }
    }

    private record SpriteRect(int x, int y, int w, int h, Runnable action, boolean enabled, int style, String label) {
        boolean contains(double mx, double my) {
            return mx >= x && mx < x + w && my >= y && my < y + h;
        }
    }

    public static class VendingScreen extends Screen {
        // Exact 9 items matching MetroFurnitureRenderers.DISPLAY_STACKS (3x3 shelves!)
        public static final Item[] ITEMS = {
                Items.APPLE, Items.BREAD, Items.COOKIE,
                Items.SWEET_BERRIES, Items.GOLDEN_CARROT, Items.POTION,
                Items.HONEY_BOTTLE, Items.BAKED_POTATO, Items.GLOW_BERRIES
        };
        public static final String[] SHORT_NAMES = {
                "Elma", "Sandviç", "Kurabiye",
                "Böğürtlen", "AltınHavuç", "Soğuk Su",
                "OrmanBalı", "Kumpir", "IşıltıMeyve"
        };
        public static final String[] FULL_NAMES = {
                "Taze Orman Elması", "Sıcak Sandviç Ekmeği", "Metro Kurabiyesi",
                "Yaban Böğürtlen Paketi", "Altın Havuç Enerji", "Soğuk Kaynak Suyu",
                "Süzme Orman Balı", "Fırınlanmış Sıcak Kumpir", "Işıltılı Mağara Meyvesi"
        };
        public static final int[] BASE_PRICES = {
                4, 4, 4,
                4, 6, 3,
                7, 5, 5
        };

        private static final int BG_W = 236;
        private static final int BG_H = 196;

        private final BlockPos machinePos;
        private final List<SpriteRect> topupButtons = new ArrayList<>();
        private int guiX;
        private int guiY;
        private String toastText = "Ürüne tıklayarak anında satın alabilirsiniz.";
        private int toastColor = 0x94A3B8;
        private long toastExpireMs = 0L;

        public VendingScreen(BlockPos pos) {
            super(Text.literal("Metro İkram Otomatı"));
            this.machinePos = pos;
        }

        @Override
        protected void init() {
            this.guiX = (this.width - BG_W) / 2;
            this.guiY = (this.height - BG_H) / 2;
            rebuildTopupButtons();
        }

        private void setToast(String msg, int color) {
            this.toastText = msg;
            this.toastColor = color;
            this.toastExpireMs = System.currentTimeMillis() + 3600L;
        }

        private void rebuildTopupButtons() {
            topupButtons.clear();
            topupButtons.add(new SpriteRect(guiX + 12, guiY + 168, 86, 16, () -> {
                sendVendingActionSilent(1, 0, machinePos);
                setToast("Zümrüt ile +10 TL bakiye yükleme isteği gönderildi.", 0x55FFAA);
            }, true, 1, "+10 TL (Zümrüt)"));
            topupButtons.add(new SpriteRect(guiX + 102, guiY + 168, 86, 16, () -> {
                sendVendingActionSilent(2, 0, machinePos);
                setToast("Altın ile +5 TL bakiye yükleme isteği gönderildi.", 0xFFE066);
            }, true, 1, "+5 TL (Altın)"));
            topupButtons.add(new SpriteRect(guiX + 192, guiY + 168, 32, 16, this::close, true, 1, "Çık"));
        }

        @Override
        public void render(DrawContext context, int mouseX, int mouseY, float delta) {
            this.renderBackground(context, mouseX, mouseY, delta);
            MinecraftClient mc = MinecraftClient.getInstance();
            int bal = (mc != null && mc.world != null && mc.player != null)
                    ? ArenaContent.getPlayerMtrBalance(mc.world.getScoreboard(), mc.player) : 0;
            int disc = (mc != null && mc.world != null && mc.player != null)
                    ? RegionPolicyEngine.getBestShopDiscountPct(mc.world, machinePos, mc.player) : 0;
            boolean creative = (mc != null && mc.player != null && mc.player.getAbilities().creativeMode);

            // 1. Custom 236x196 Beveled MTR Dark-Titanium 3x3 Showcase Container
            context.drawTexture(VENDING_GUI_TEX, guiX, guiY, 0, 0, BG_W, BG_H, 256, 256);

            // 2. Header text & live Orman Kart balance
            context.drawTextWithShadow(this.textRenderer,
                    Text.literal("METRO OTOMAT • 9 ÜRÜN").formatted(Formatting.AQUA, Formatting.BOLD),
                    guiX + 14, guiY + 12, 0xFFFFFF);
            String balStr = "Bakiye: " + bal + " TL" + (disc > 0 ? " (-%" + disc + ")" : "");
            int balW = this.textRenderer.getWidth(balStr);
            context.drawTextWithShadow(this.textRenderer, balStr, guiX + BG_W - 14 - balW, guiY + 12,
                    disc > 0 ? 0x55FFAA : 0xFFE066);

            // 3. 3x3 Product Cards (each 68 x 36 at x = guiX + 13 + col*71, y = guiY + 35 + row*38)
            ItemStack hoveredStack = null;
            int hoveredIdx = -1;
            for (int i = 0; i < ITEMS.length; i++) {
                int row = i / 3;
                int col = i % 3;
                int cx = guiX + 13 + col * 71;
                int cy = guiY + 35 + row * 38;

                int price = (mc != null && mc.world != null && mc.player != null)
                        ? RegionPolicyEngine.computeShopPrice(mc.world, machinePos, mc.player, BASE_PRICES[i])
                        : BASE_PRICES[i];
                boolean canAfford = creative || bal >= price;
                boolean hov = mouseX >= cx && mouseX < cx + 68 && mouseY >= cy && mouseY < cy + 36;

                if (!canAfford) {
                    context.drawTexture(VENDING_GUI_TEX, cx, cy, 70, 200, 68, 36, 256, 256);
                } else if (hov) {
                    context.drawTexture(VENDING_GUI_TEX, cx, cy, 0, 200, 68, 36, 256, 256);
                }

                ItemStack stack = new ItemStack(ITEMS[i]);
                context.drawItem(stack, cx + 4, cy + 10);
                if (hov) {
                    hoveredStack = stack;
                    hoveredIdx = i;
                }

                // Compact crisp title + price badge
                context.drawTextWithShadow(this.textRenderer, SHORT_NAMES[i], cx + 24, cy + 7,
                        canAfford ? (hov ? 0xFFFFFF : 0xE2E8F0) : 0x788290);
                String pStr = price + " TL";
                int pw = this.textRenderer.getWidth(pStr);
                context.drawTextWithShadow(this.textRenderer, pStr, cx + 44 - pw / 2, cy + 23,
                        canAfford ? 0x6EE7B7 : 0xF87171);
            }

            // 4. OLED Status Toast Line (y = guiY + 158)
            String activeToast = (System.currentTimeMillis() < toastExpireMs || toastExpireMs == 0L)
                    ? toastText
                    : "Ürüne tıklayarak anında satın alabilirsiniz.";
            int activeCol = (System.currentTimeMillis() < toastExpireMs) ? toastColor : 0x94A3B8;
            context.drawTextWithShadow(this.textRenderer, activeToast, guiX + 13, guiY + 158, activeCol);

            // 5. Bottom Wallet Top-Up & Close Buttons
            for (SpriteRect b : topupButtons) {
                boolean hov = b.contains(mouseX, mouseY);
                if (b.w() >= 80) {
                    context.drawTexture(VENDING_GUI_TEX, b.x(), b.y(), hov ? 88 : 0, 238, 86, 16, 256, 256);
                } else {
                    context.fill(b.x(), b.y(), b.x() + b.w(), b.y() + b.h(), hov ? 0xFF475569 : 0xFF334155);
                }
                int tw = this.textRenderer.getWidth(b.label());
                context.drawTextWithShadow(this.textRenderer, b.label(), b.x() + (b.w() - tw) / 2, b.y() + 4,
                        hov ? 0xFFFFCC : 0xF8FAFC);
            }

            if (hoveredStack != null && hoveredIdx >= 0) {
                int price = (mc != null && mc.world != null && mc.player != null)
                        ? RegionPolicyEngine.computeShopPrice(mc.world, machinePos, mc.player, BASE_PRICES[hoveredIdx])
                        : BASE_PRICES[hoveredIdx];
                List<Text> tip = new ArrayList<>();
                tip.add(Text.literal(FULL_NAMES[hoveredIdx]).formatted(Formatting.AQUA, Formatting.BOLD));
                tip.add(Text.literal("Fiyat: " + price + " TL" + (disc > 0 ? " (%" + disc + " Bölge İndirimi)" : ""))
                        .formatted(Formatting.GREEN));
                tip.add(Text.literal("Satın almak için sol tıklayın").formatted(Formatting.GRAY));
                context.drawTooltip(this.textRenderer, tip, mouseX, mouseY);
            }
        }

        @Override
        public boolean mouseClicked(double mouseX, double mouseY, int button) {
            if (button == 0) {
                MinecraftClient mc = MinecraftClient.getInstance();
                int bal = (mc != null && mc.world != null && mc.player != null)
                        ? ArenaContent.getPlayerMtrBalance(mc.world.getScoreboard(), mc.player) : 0;
                boolean creative = (mc != null && mc.player != null && mc.player.getAbilities().creativeMode);

                for (int i = 0; i < ITEMS.length; i++) {
                    int row = i / 3;
                    int col = i % 3;
                    int cx = guiX + 13 + col * 71;
                    int cy = guiY + 35 + row * 38;
                    if (mouseX >= cx && mouseX < cx + 68 && mouseY >= cy && mouseY < cy + 36) {
                        int price = (mc != null && mc.world != null && mc.player != null)
                                ? RegionPolicyEngine.computeShopPrice(mc.world, machinePos, mc.player, BASE_PRICES[i])
                                : BASE_PRICES[i];
                        if (!creative && bal < price) {
                            if (mc != null) {
                                mc.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.BLOCK_NOTE_BLOCK_BASS.value(), 0.75f));
                            }
                            setToast("✗ Yetersiz bakiye! Gerekli: " + price + " TL (Mevcut: " + bal + " TL)", 0xF87171);
                        } else {
                            sendVendingActionSilent(0, i, machinePos);
                            setToast("✓ " + FULL_NAMES[i] + " verildi (-" + price + " TL)", 0x4ADE80);
                        }
                        return true;
                    }
                }

                for (SpriteRect b : topupButtons) {
                    if (b.enabled() && b.contains(mouseX, mouseY)) {
                        b.action().run();
                        return true;
                    }
                }
            }
            return super.mouseClicked(mouseX, mouseY, button);
        }

        @Override
        public boolean shouldPause() {
            return false;
        }
    }

    public static class InfoKioskScreen extends Screen {
        private static final int BG_W = 236;
        private static final int BG_H = 186;

        private final BlockPos kioskPos;
        private final List<SpriteRect> actionButtons = new ArrayList<>();
        private int guiX;
        private int guiY;

        public InfoKioskScreen(BlockPos pos) {
            super(Text.literal("Yolcu Bilgi Terminali"));
            this.kioskPos = pos;
        }

        @Override
        protected void init() {
            this.guiX = (this.width - BG_W) / 2;
            this.guiY = (this.height - BG_H) / 2;
            actionButtons.clear();
            actionButtons.add(new SpriteRect(guiX + 12, guiY + 160, 70, 16, () -> {
                MinecraftClient mc = MinecraftClient.getInstance();
                if (mc != null) mc.setScreen(new ArenaMapScreen(0));
            }, true, 0, "Harita (M)"));
            actionButtons.add(new SpriteRect(guiX + 84, guiY + 160, 70, 16, () -> {
                sendVendingActionSilent(1, 0, kioskPos);
            }, true, 2, "+10 TL Yükle"));
            actionButtons.add(new SpriteRect(guiX + 156, guiY + 160, 68, 16, this::close, true, 0, "Kapat"));
        }

        @Override
        public void render(DrawContext context, int mouseX, int mouseY, float delta) {
            this.renderBackground(context, mouseX, mouseY, delta);
            MinecraftClient mc = MinecraftClient.getInstance();
            int bal = (mc != null && mc.world != null && mc.player != null)
                    ? ArenaContent.getPlayerMtrBalance(mc.world.getScoreboard(), mc.player) : 0;
            String reg = (mc != null && mc.world != null)
                    ? RegionPolicyEngine.getPrimaryRegionDisplay(mc.world, kioskPos) : "Standart Bölge";
            boolean freeTransit = (mc != null && mc.world != null && mc.player != null)
                    ? RegionPolicyEngine.hasFreeTransitInRegion(mc.world, kioskPos, mc.player) : false;

            context.drawTexture(KIOSK_GUI_TEX, guiX, guiY, 0, 0, BG_W, BG_H, 256, 256);

            // Header & Wallet
            context.drawTextWithShadow(this.textRenderer,
                    Text.literal("M1 YOLCU BİLGİ & TELEMETRİ").formatted(Formatting.AQUA, Formatting.BOLD),
                    guiX + 14, guiY + 13, 0xFFFFFF);
            String balTxt = bal + " TL";
            context.drawTextWithShadow(this.textRenderer, balTxt,
                    guiX + BG_W - 14 - this.textRenderer.getWidth(balTxt), guiY + 13, 0xFFE066);

            // Card 1: Live M1 Train Telemetry & ETA (y = guiY + 37..73)
            List<ArenaMapData.LiveTrainInfo> trains = ArenaMapData.getLiveTrains();
            boolean atSouth = Math.abs(kioskPos.getZ() - 1580) < Math.abs(kioskPos.getZ() - 32);
            double hereZ = atSouth ? 1580.0 : 32.0;
            String hereName = atSouth ? "Güney Orman" : "Kuzey Orman";
            if (!trains.isEmpty()) {
                ArenaMapData.LiveTrainInfo t = trains.get(0);
                double dHere = Math.abs(t.z - hereZ);
                String line1;
                String line2;
                if (dHere <= 18.0 && t.speedKmh < 1.5) {
                    line1 = String.format(Locale.US, "Canlı Tren: %s • PERONDA (Kapılar Açık)", t.routeNumber);
                    line2 = String.format(Locale.US, "Konum: Z=%.0fm • Hız: 0 km/s • %s", t.z, hereName);
                } else {
                    double vz = WorldMapBoardRenderer.getPrimaryTrainVzMps();
                    boolean towardHere = Math.abs(vz) > 0.3 ? ((vz > 0) == atSouth) : (dHere < 774.0);
                    int etaSec = (int) Math.max(1L, Math.round(
                            WorldMapBoardRenderer.computeRemainingSecondsDirect(t.z, hereZ, t.speedKmh, Math.max(80.0, t.speedKmh))
                    ));
                    if (!towardHere) {
                        double otherZ = atSouth ? 32.0 : 1580.0;
                        etaSec = (int) Math.round(
                                WorldMapBoardRenderer.computeRemainingSecondsDirect(t.z, otherZ, t.speedKmh, 80.0)
                                + 20.0 + WorldMapBoardRenderer.computeExactCorridorSeconds(1548.0, 80.0)
                        );
                    }
                    line1 = String.format(Locale.US, "Canlı Tren: %s • Hız: %.0f km/s (Z=%.0fm)", t.routeNumber, t.speedKmh, t.z);
                    line2 = String.format(Locale.US, "%s Tahmini Varış: %d sn (%s)",
                            hereName, etaSec, towardHere ? "Yaklaşıyor" : "Dönüş Seferi");
                }
                context.drawTextWithShadow(this.textRenderer, line1, guiX + 20, guiY + 43, 0x7DD3FC);
                context.drawTextWithShadow(this.textRenderer, line2, guiX + 20, guiY + 57, 0x4ADE80);
            } else {
                context.drawTextWithShadow(this.textRenderer, "Hat: M1 Orman Metrosu (Kuzey <-> Güney)", guiX + 20, guiY + 43, 0x7DD3FC);
                context.drawTextWithShadow(this.textRenderer, "Durum: Otomatik Sefer • Tasarım Hızı: 80 km/s", guiX + 20, guiY + 57, 0xCBD5E1);
            }

            // Card 2: Live Tunnel Geotechnical FoS & SCADA Safety Status (y = guiY + 76..112)
            double minFos = GeoStructuralPhysicsEngine.latestMinTunnelFos;
            double maxUw = GeoStructuralPhysicsEngine.latestMaxPoreWaterKpa;
            int alerts = GeoStructuralPhysicsEngine.ACTIVE_ALERTS.size();
            String scadaBadge = (alerts == 0 && minFos >= 1.35)
                    ? "TÜM HAT GÜVENLİ (YEŞİL)"
                    : (minFos >= 1.02 ? "SARI SİSMİK İZLEME" : "ACİL FREN / KIRMIZI ALARM");
            int scadaCol = (alerts == 0 && minFos >= 1.35) ? 0x4ADE80 : (minFos >= 1.02 ? 0xFACC15 : 0xF87171);
            context.drawTextWithShadow(this.textRenderer, "SCADA Durumu: " + scadaBadge, guiX + 20, guiY + 82, scadaCol);
            context.drawTextWithShadow(this.textRenderer,
                    String.format(Locale.US, "Tünel Min FoS: %.2f • Boşluk Suyu: %.1f kPa", minFos, maxUw),
                    guiX + 20, guiY + 96, 0xCBD5E1);

            // Card 3: Regional Tariff & Orman Kart Wallet (y = guiY + 115..149)
            context.drawTextWithShadow(this.textRenderer, "Bölge: " + reg, guiX + 20, guiY + 121, 0xE2E8F0);
            context.drawTextWithShadow(this.textRenderer,
                    freeTransit ? "Tarife: Bölge Kartı ile ÜCRETSİZ GEÇİŞ" : "Tarife: Orman Kart Otomatik Geçiş",
                    guiX + 20, guiY + 134, freeTransit ? 0x6EE7B7 : 0xFDE047);

            // Bottom Action Buttons
            for (SpriteRect b : actionButtons) {
                boolean hov = b.contains(mouseX, mouseY);
                int u = b.style() == 2 ? (hov ? 72 : 144) : (hov ? 72 : 0);
                context.drawTexture(KIOSK_GUI_TEX, b.x(), b.y(), u, 192, Math.min(70, b.w()), 16, 256, 256);
                int tw = this.textRenderer.getWidth(b.label());
                context.drawTextWithShadow(this.textRenderer, b.label(), b.x() + (b.w() - tw) / 2, b.y() + 4,
                        hov ? 0xFFFFCC : 0xF8FAFC);
            }
        }

        @Override
        public boolean mouseClicked(double mouseX, double mouseY, int button) {
            if (button == 0) {
                for (SpriteRect b : actionButtons) {
                    if (b.enabled() && b.contains(mouseX, mouseY)) {
                        b.action().run();
                        return true;
                    }
                }
            }
            return super.mouseClicked(mouseX, mouseY, button);
        }

        @Override
        public boolean shouldPause() {
            return false;
        }
    }
}

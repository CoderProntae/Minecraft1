package ai.arena.bridge.transit;

import ai.arena.bridge.ArenaContent;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.BiomeTags;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Open-ended, zero-enum Data-Driven Region & Card Discount Engine (v7.3.0):
 * - NO hardcoded FOREST/CITY enum! Unlimited custom regions can be defined in-game (/bolge tanimla ...)
 *   or in arena-regions.json with arbitrary string IDs ("orman", "merkez", "sahil", "kampus", "sanayi", ...).
 * - If no explicit custom region polygon/box covers (x, z), automatically derives natural biome tags from the
 *   surface biome above (x, z) (#minecraft:is_forest / #is_taiga / #is_jungle -> "orman", etc.).
 * - Every transit card (Orman Kart or any minted /kart custom card) carries NBT rules:
 *     arena_region: String (e.g. "orman")
 *     arena_ticket_discount: int 0..100 (Orman Kart default: 100% -> free transit ticket ONLY in "orman" regions!)
 *     arena_shop_discount: int 0..90 (Orman Kart default: 50% -> half-price shops/vending ONLY in "orman" regions; NEVER free!)
 */
public final class RegionPolicyEngine {

    public static final class RegionBox {
        public String id;
        public String displayName;
        public int minX;
        public int maxX;
        public int minZ;
        public int maxZ;

        public boolean contains(int x, int z) {
            return x >= Math.min(minX, maxX) && x <= Math.max(minX, maxX)
                    && z >= Math.min(minZ, maxZ) && z <= Math.max(minZ, maxZ);
        }
    }

    public static final class CardBenefit {
        public final String cardName;
        public final String regionId;
        public final int ticketDiscountPct;
        public final int shopDiscountPct;

        public CardBenefit(String cardName, String regionId, int ticketDiscountPct, int shopDiscountPct) {
            this.cardName = cardName;
            this.regionId = normalizeId(regionId);
            this.ticketDiscountPct = Math.max(0, Math.min(100, ticketDiscountPct));
            this.shopDiscountPct = Math.max(0, Math.min(90, shopDiscountPct)); // Never 100% free on shops!
        }
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final List<RegionBox> EXPLICIT_REGIONS = new ArrayList<>();
    private static boolean loaded = false;

    private RegionPolicyEngine() {}

    public static File getConfigFile() {
        return new File(FabricLoader.getInstance().getGameDir().toFile(), "arena-regions.json");
    }

    public static String normalizeId(String raw) {
        if (raw == null || raw.isBlank()) return "genel";
        return raw.trim().toLowerCase(Locale.ROOT)
                .replace('ı', 'i')
                .replace('ğ', 'g')
                .replace('ü', 'u')
                .replace('ş', 's')
                .replace('ö', 'o')
                .replace('ç', 'c');
    }

    public static synchronized void ensureLoaded() {
        if (loaded) return;
        loaded = true;
        EXPLICIT_REGIONS.clear();
        File f = getConfigFile();
        if (!f.exists()) {
            save();
            return;
        }
        try {
            String raw = Files.readString(f.toPath(), StandardCharsets.UTF_8);
            JsonObject root = JsonParser.parseString(raw).getAsJsonObject();
            if (root.has("regions") && root.get("regions").isJsonArray()) {
                for (JsonElement el : root.getAsJsonArray("regions")) {
                    JsonObject o = el.getAsJsonObject();
                    RegionBox rb = new RegionBox();
                    rb.id = normalizeId(o.has("id") ? o.get("id").getAsString() : "genel");
                    rb.displayName = o.has("displayName") ? o.get("displayName").getAsString() : rb.id;
                    rb.minX = o.get("minX").getAsInt();
                    rb.maxX = o.get("maxX").getAsInt();
                    rb.minZ = o.get("minZ").getAsInt();
                    rb.maxZ = o.get("maxZ").getAsInt();
                    EXPLICIT_REGIONS.add(rb);
                }
            }
        } catch (Throwable ignored) {}
    }

    public static synchronized void save() {
        try {
            JsonObject root = new JsonObject();
            JsonArray arr = new JsonArray();
            for (RegionBox rb : EXPLICIT_REGIONS) {
                JsonObject o = new JsonObject();
                o.addProperty("id", rb.id);
                o.addProperty("displayName", rb.displayName);
                o.addProperty("minX", rb.minX);
                o.addProperty("maxX", rb.maxX);
                o.addProperty("minZ", rb.minZ);
                o.addProperty("maxZ", rb.maxZ);
                arr.add(o);
            }
            root.add("regions", arr);
            Files.writeString(getConfigFile().toPath(), GSON.toJson(root), StandardCharsets.UTF_8);
        } catch (Throwable ignored) {}
    }

    public static synchronized void defineOrUpdateRegion(String id, String displayName, int x1, int z1, int x2, int z2) {
        ensureLoaded();
        String norm = normalizeId(id);
        EXPLICIT_REGIONS.removeIf(r -> r.id.equals(norm)
                && r.minX == Math.min(x1, x2) && r.maxX == Math.max(x1, x2)
                && r.minZ == Math.min(z1, z2) && r.maxZ == Math.max(z1, z2));
        RegionBox rb = new RegionBox();
        rb.id = norm;
        rb.displayName = (displayName == null || displayName.isBlank()) ? norm.toUpperCase(Locale.ROOT) : displayName.trim();
        rb.minX = Math.min(x1, x2);
        rb.maxX = Math.max(x1, x2);
        rb.minZ = Math.min(z1, z2);
        rb.maxZ = Math.max(z1, z2);
        EXPLICIT_REGIONS.add(rb);
        save();
    }

    public static synchronized boolean removeRegionById(String id) {
        ensureLoaded();
        String norm = normalizeId(id);
        boolean removed = EXPLICIT_REGIONS.removeIf(r -> r.id.equals(norm));
        if (removed) save();
        return removed;
    }

    public static synchronized List<RegionBox> getExplicitRegions() {
        ensureLoaded();
        return new ArrayList<>(EXPLICIT_REGIONS);
    }

    /**
     * Returns all active region IDs at (world, pos):
     * - If explicit regions cover (x, z), ONLY those explicit region IDs apply (so a "sehir"/"merkez" district
     *   built over cleared forest is strictly "sehir"/"merkez", NOT "orman"!).
     * - Otherwise, derives natural biome region tags from the surface biome above (x, z).
     */
    public static Set<String> getActiveRegionIds(World world, BlockPos pos) {
        ensureLoaded();
        Set<String> tags = new LinkedHashSet<>();
        if (pos == null) {
            tags.add("genel");
            return tags;
        }
        int x = pos.getX();
        int z = pos.getZ();

        synchronized (RegionPolicyEngine.class) {
            for (RegionBox rb : EXPLICIT_REGIONS) {
                if (rb.contains(x, z)) {
                    tags.add(rb.id);
                }
            }
        }
        if (!tags.isEmpty()) return tags;

        if (world != null) {
            try {
                BlockPos surfaceProbe = new BlockPos(x, 68, z);
                RegistryEntry<Biome> biome = world.getBiome(surfaceProbe);
                if (biome.isIn(BiomeTags.IS_FOREST) || biome.isIn(BiomeTags.IS_TAIGA) || biome.isIn(BiomeTags.IS_JUNGLE)) {
                    tags.add("orman");
                } else if (biome.isIn(BiomeTags.IS_BEACH) || biome.isIn(BiomeTags.IS_OCEAN) || biome.isIn(BiomeTags.IS_RIVER)) {
                    tags.add("sahil");
                } else if (biome.isIn(BiomeTags.IS_MOUNTAIN) || biome.isIn(BiomeTags.IS_HILL)) {
                    tags.add("dag");
                }
            } catch (Throwable ignored) {}
        }

        if (tags.isEmpty()) tags.add("genel");
        return tags;
    }

    public static String getPrimaryRegionDisplay(World world, BlockPos pos) {
        ensureLoaded();
        if (pos != null) {
            synchronized (RegionPolicyEngine.class) {
                for (RegionBox rb : EXPLICIT_REGIONS) {
                    if (rb.contains(pos.getX(), pos.getZ())) {
                        return rb.displayName;
                    }
                }
            }
        }
        Set<String> ids = getActiveRegionIds(world, pos);
        String first = ids.iterator().next();
        return switch (first) {
            case "orman" -> "Orman Bölgesi";
            case "sahil" -> "Sahil Bölgesi";
            case "dag" -> "Dağ Bölgesi";
            default -> first.substring(0, 1).toUpperCase(Locale.ROOT) + first.substring(1) + " Bölgesi";
        };
    }

    public static CardBenefit readCardBenefit(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.isOf(ArenaContent.ORMAN_KART)) return null;
        NbtCompound nbt = stack.getNbt();
        String region = "orman";
        int ticketDisc = 100; // Orman Kart default: free transit ticket ONLY in "orman" region
        int shopDisc = 50;    // Orman Kart default: 50% shop/vending discount ONLY in "orman" region (never free!)
        String name = stack.getName().getString();
        if (nbt != null) {
            if (nbt.contains("arena_region")) region = nbt.getString("arena_region");
            if (nbt.contains("arena_ticket_discount")) ticketDisc = nbt.getInt("arena_ticket_discount");
            if (nbt.contains("arena_shop_discount")) shopDisc = nbt.getInt("arena_shop_discount");
        }
        return new CardBenefit(name, region, ticketDisc, shopDisc);
    }

    public static ItemStack createCustomRegionalCard(String regionId, int ticketDiscountPct, int shopDiscountPct, String displayName) {
        ItemStack stack = new ItemStack(ArenaContent.ORMAN_KART, 1);
        NbtCompound nbt = stack.getOrCreateNbt();
        String norm = normalizeId(regionId);
        nbt.putString("arena_region", norm);
        nbt.putInt("arena_ticket_discount", Math.max(0, Math.min(100, ticketDiscountPct)));
        nbt.putInt("arena_shop_discount", Math.max(0, Math.min(90, shopDiscountPct)));
        if (displayName != null && !displayName.isBlank()) {
            stack.setCustomName(Text.literal(displayName.trim()).formatted(Formatting.AQUA));
        }
        return stack;
    }

    public static List<CardBenefit> getPlayerCards(PlayerEntity player) {
        List<CardBenefit> out = new ArrayList<>();
        if (player == null) return out;
        for (int i = 0; i < player.getInventory().size(); i++) {
            CardBenefit cb = readCardBenefit(player.getInventory().getStack(i));
            if (cb != null) out.add(cb);
        }
        return out;
    }

    /**
     * Returns true ONLY if the player holds a regional transit card whose region matches the station's active region
     * AND grants 100% free ticket entry in that region!
     * (e.g. Orman Kart grants free transit ONLY in "orman" stations; in future "sehir"/"merkez" stations it returns FALSE!)
     */
    public static boolean hasFreeTransitInRegion(World world, BlockPos pos, PlayerEntity player) {
        if (player == null) return false;
        Set<String> activeRegions = getActiveRegionIds(world, pos);
        for (CardBenefit cb : getPlayerCards(player)) {
            if (activeRegions.contains(cb.regionId) && cb.ticketDiscountPct >= 100) {
                return true;
            }
        }
        return false;
    }

    public static int getBestShopDiscountPct(World world, BlockPos pos, PlayerEntity player) {
        if (player == null) return 0;
        Set<String> activeRegions = getActiveRegionIds(world, pos);
        int best = 0;
        for (CardBenefit cb : getPlayerCards(player)) {
            if (activeRegions.contains(cb.regionId) && cb.shopDiscountPct > best) {
                best = cb.shopDiscountPct;
            }
        }
        return Math.min(90, best);
    }

    /**
     * Computes final shop/vending price at (world, pos) for player.
     * NEVER returns 0 (always >= 1 TL) — regional cards ONLY discount shop items in their matching region!
     */
    public static int computeShopPrice(World world, BlockPos pos, PlayerEntity player, int basePrice) {
        int safeBase = Math.max(2, basePrice);
        int discPct = getBestShopDiscountPct(world, pos, player);
        if (discPct <= 0) return safeBase;
        int discounted = Math.round(safeBase * (100 - discPct) / 100.0f);
        return Math.max(1, discounted);
    }
}

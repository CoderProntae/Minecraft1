package ai.arena.bridge.transit;

import ai.arena.bridge.audio.SpatialAudioEngine;
import ai.arena.bridge.world.WorldContextAnalyzer;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.MinecraftClient;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.server.world.ServerWorld;
import org.mtr.core.Main;
import org.mtr.core.data.Data;
import org.mtr.core.data.Depot;
import org.mtr.core.data.Platform;
import org.mtr.core.data.Position;
import org.mtr.core.data.Rail;
import org.mtr.core.data.Route;
import org.mtr.core.data.RoutePlatformData;
import org.mtr.core.data.Siding;
import org.mtr.core.data.Station;
import org.mtr.core.data.TransportMode;
import org.mtr.core.data.VehicleCar;
import org.mtr.core.generated.data.RailSchema;
import org.mtr.core.operation.UpdateDataRequest;
import org.mtr.core.simulation.Simulator;
import org.mtr.core.tool.Angle;
import org.mtr.libraries.it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.mtr.libraries.it.unimi.dsi.fastutil.objects.ObjectImmutableList;
import org.mtr.mod.Init;
import org.mtr.mod.client.CustomResourceLoader;
import org.mtr.mod.client.MinecraftClientData;
import org.mtr.mod.packet.PacketUpdateData;
import org.mtr.mod.resource.VehicleResource;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.SourceDataLine;
import java.io.ByteArrayInputStream;
import java.lang.reflect.Field;
import java.util.Base64;
import java.util.Iterator;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Clean MTR 4.0.5 integration layer:
 * - Enforces full passenger dwell times on all sidings (zero schedule-deviation dwell skipping).
 * - Configures UITP & UIC classified transit lines (YHT, M, B, HRS, T, MR, F, TF).
 * - Exposes structured station, platform, siding, route, and depot telemetry.
 */
public final class MtrBridgeHelper {

    private static final ExecutorService SPEAKER_EXEC = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "Arena-PA-Speaker");
        t.setDaemon(true);
        return t;
    });
    private static volatile SourceDataLine activeAudioLine = null;
    private static Field mainFieldCache = null;
    private static Field simulatorsFieldCache = null;

    private MtrBridgeHelper() {}

    @SuppressWarnings("unchecked")
    public static Simulator getOverworldSimulator() {
        try {
            if (mainFieldCache == null) {
                Field f = Init.class.getDeclaredField("main");
                f.setAccessible(true);
                mainFieldCache = f;
            }
            Main main = (Main) mainFieldCache.get(null);
            if (main == null) return null;
            if (simulatorsFieldCache == null) {
                Field sf = Main.class.getDeclaredField("simulators");
                sf.setAccessible(true);
                simulatorsFieldCache = sf;
            }
            ObjectImmutableList<Simulator> sims = (ObjectImmutableList<Simulator>) simulatorsFieldCache.get(main);
            if (sims == null || sims.isEmpty()) return null;
            for (Simulator s : sims) {
                if (s.dimension != null && s.dimension.contains("overworld")) return s;
            }
            return sims.get(0);
        } catch (Throwable ignored) {
            return null;
        }
    }

    /**
     * Automatically keeps all MTR sidings configured so delayed vehicles NEVER cut platform dwell time short.
     */
    public static void enforceGuaranteedStationDwell() {
        Simulator sim = getOverworldSimulator();
        if (sim == null) return;
        try {
            for (Siding s : sim.sidings) {
                if (s.getDelayedVehicleReduceDwellTimePercentage() != 0) {
                    s.setDelayedVehicleReduceDwellTimePercentage(0);
                }
                if (s.getEarlyVehicleIncreaseDwellTime()) {
                    s.setEarlyVehicleIncreaseDwellTime(false);
                }
            }
            for (Platform p : sim.platforms) {
                if (p.getDwellTime() < 18000L) {
                    p.setDwellTime(20000L);
                }
            }
        } catch (Throwable ignored) {}
    }

    public static void playWavRaw(byte[] wavBytes, float volume, boolean interrupt) {
        SpatialAudioEngine.playSpatialWav(wavBytes, SpatialAudioEngine.SoundSourceSpec.self(volume), interrupt);
    }

    /**
     * Caps overly fast running-line rails (e.g. 200 km/h) down to maxKmh (80 km/h)
     * so Minecraft 1.20.4 streams chunks smoothly and onboard station announcements play on time!
     * Returns number of rails updated, or -1 if simulator is not loaded yet.
     */
    @SuppressWarnings("unchecked")
    public static int ensureSmoothRailSpeeds(ServerWorld overworld, long maxKmh) {
        Simulator sim = getOverworldSimulator();
        if (sim == null || overworld == null || sim.rails.isEmpty()) return -1;
        try {
            Field fPos1 = RailSchema.class.getDeclaredField("position1");
            Field fAng1 = RailSchema.class.getDeclaredField("angle1");
            Field fPos2 = RailSchema.class.getDeclaredField("position2");
            Field fAng2 = RailSchema.class.getDeclaredField("angle2");
            Field fShape = RailSchema.class.getDeclaredField("shape");
            Field fVertR = RailSchema.class.getDeclaredField("verticalRadius");
            Field fStyles = RailSchema.class.getDeclaredField("styles");
            Field fSpd1 = RailSchema.class.getDeclaredField("speedLimit1");
            Field fSpd2 = RailSchema.class.getDeclaredField("speedLimit2");
            Field fAcc = RailSchema.class.getDeclaredField("canAccelerate");
            Field fRem = RailSchema.class.getDeclaredField("canConnectRemotely");
            Field fSig = RailSchema.class.getDeclaredField("canHaveSignal");
            Field fMode = RailSchema.class.getDeclaredField("transportMode");

            fPos1.setAccessible(true); fAng1.setAccessible(true);
            fPos2.setAccessible(true); fAng2.setAccessible(true);
            fShape.setAccessible(true); fVertR.setAccessible(true);
            fStyles.setAccessible(true); fSpd1.setAccessible(true); fSpd2.setAccessible(true);
            fAcc.setAccessible(true); fRem.setAccessible(true);
            fSig.setAccessible(true); fMode.setAccessible(true);

            org.mtr.mapping.holder.ServerWorld mtrWorld =
                    (org.mtr.mapping.holder.ServerWorld) org.mtr.mapping.holder.ServerWorld.class
                            .getConstructors()[0].newInstance(overworld);

            ObjectArrayList<Rail> snapshot = new ObjectArrayList<>(sim.rails);
            int updated = 0;

            for (Rail r : snapshot) {
                if (r.isPlatform() || r.isSiding() || r.canTurnBack()) continue;
                long s1 = fSpd1.getLong(r);
                long s2 = fSpd2.getLong(r);
                if (s1 <= maxKmh && s2 <= maxKmh) continue;

                long ns1 = s1 > maxKmh ? maxKmh : s1;
                long ns2 = s2 > maxKmh ? maxKmh : s2;
                ObjectArrayList<String> origStyles = (ObjectArrayList<String>) fStyles.get(r);
                ObjectArrayList<String> stylesCopy = origStyles != null ? new ObjectArrayList<>(origStyles) : new ObjectArrayList<>();

                Rail capped = Rail.newRail(
                        (Position) fPos1.get(r),
                        (Angle) fAng1.get(r),
                        (Position) fPos2.get(r),
                        (Angle) fAng2.get(r),
                        (Rail.Shape) fShape.get(r),
                        fVertR.getDouble(r),
                        stylesCopy,
                        ns1,
                        ns2,
                        false,
                        false,
                        fAcc.getBoolean(r),
                        fRem.getBoolean(r),
                        fSig.getBoolean(r),
                        (TransportMode) fMode.get(r)
                );
                capped.copySignalColors(r);
                PacketUpdateData.sendDirectlyToServerRail(mtrWorld, capped);
                updated++;
            }

            if (updated > 0 && !sim.depots.isEmpty()) {
                Depot.generateDepots(sim, new ObjectArrayList<>(sim.depots));
            }
            return updated;
        } catch (Throwable ignored) {
            return -1;
        }
    }

    public static JsonObject playWav(String bodyStr) {
        JsonObject out = new JsonObject();
        try {
            JsonObject req = JsonParser.parseString(bodyStr).getAsJsonObject();
            String b64 = req.get("wavBase64").getAsString();
            float vol = req.has("volume") ? req.get("volume").getAsFloat() : 0.95f;
            boolean intr = req.has("interrupt") && req.get("interrupt").getAsBoolean();
            byte[] decoded = Base64.getDecoder().decode(b64);
            if (req.has("sourceX") && req.has("sourceY") && req.has("sourceZ")) {
                boolean under = req.has("underground") && req.get("underground").getAsBoolean();
                SpatialAudioEngine.playSpatialWav(
                        decoded,
                        SpatialAudioEngine.SoundSourceSpec.station(
                                req.get("sourceX").getAsDouble(),
                                req.get("sourceY").getAsDouble(),
                                req.get("sourceZ").getAsDouble(),
                                vol,
                                under
                        ),
                        intr
                );
            } else if (req.has("routeNumber")) {
                boolean inTunnel = !req.has("inTunnel") || req.get("inTunnel").getAsBoolean();
                SpatialAudioEngine.playSpatialWav(
                        decoded,
                        SpatialAudioEngine.SoundSourceSpec.trainCabin(req.get("routeNumber").getAsString(), vol, inTunnel),
                        intr
                );
            } else {
                playWavRaw(decoded, vol, intr);
            }
            out.addProperty("ok", true);
        } catch (Throwable t) {
            out.addProperty("ok", false);
            out.addProperty("error", t.toString());
        }
        return out;
    }

    public static JsonObject getMtrState() {
        JsonObject res = new JsonObject();
        Simulator sim = getOverworldSimulator();
        if (sim == null) {
            res.addProperty("ok", false);
            res.addProperty("error", "simulator_unavailable");
            return res;
        }
        res.addProperty("ok", true);

        JsonArray stArr = new JsonArray();
        for (Station s : sim.stations) {
            JsonObject o = new JsonObject();
            o.addProperty("id", Long.toString(s.getId()));
            o.addProperty("hexId", String.format("%016X", s.getId()));
            o.addProperty("name", s.getName());
            o.addProperty("color", s.getColor());
            o.addProperty("minX", s.getMinX());
            o.addProperty("maxX", s.getMaxX());
            o.addProperty("minZ", s.getMinZ());
            o.addProperty("maxZ", s.getMaxZ());
            stArr.add(o);
        }
        res.add("stations", stArr);

        JsonArray plArr = new JsonArray();
        for (Platform p : sim.platforms) {
            JsonObject o = new JsonObject();
            o.addProperty("id", Long.toString(p.getId()));
            o.addProperty("name", p.getName());
            o.addProperty("dwellMillis", p.getDwellTime());
            o.addProperty("midX", p.getMidPosition().getX());
            o.addProperty("midY", p.getMidPosition().getY());
            o.addProperty("midZ", p.getMidPosition().getZ());
            plArr.add(o);
        }
        res.add("platforms", plArr);

        JsonArray sdArr = new JsonArray();
        for (Siding s : sim.sidings) {
            JsonObject o = new JsonObject();
            o.addProperty("id", Long.toString(s.getId()));
            o.addProperty("name", s.getName());
            o.addProperty("railLength", Math.round(s.getRailLength()));
            o.addProperty("maxVehicles", s.getMaxVehicles());
            o.addProperty("reduceDwellPct", s.getDelayedVehicleReduceDwellTimePercentage());
            o.addProperty("midX", s.getMidPosition().getX());
            o.addProperty("midY", s.getMidPosition().getY());
            o.addProperty("midZ", s.getMidPosition().getZ());
            JsonArray cars = new JsonArray();
            for (VehicleCar c : s.getVehicleCars()) cars.add(c.getVehicleId());
            o.add("cars", cars);
            sdArr.add(o);
        }
        res.add("sidings", sdArr);

        JsonArray rtArr = new JsonArray();
        for (Route r : sim.routes) {
            JsonObject o = new JsonObject();
            o.addProperty("id", Long.toString(r.getId()));
            o.addProperty("name", r.getName());
            o.addProperty("routeNumber", r.getRouteNumber());
            o.addProperty("uitpSystem", UitpSystemType.fromRouteCodeOrType(r.getRouteNumber()).name());
            o.addProperty("color", r.getColor());
            JsonArray pids = new JsonArray();
            for (RoutePlatformData rpd : r.getRoutePlatforms()) {
                Platform p = rpd.getPlatform();
                if (p != null) pids.add(Long.toString(p.getId()));
            }
            o.add("platformIds", pids);
            rtArr.add(o);
        }
        res.add("routes", rtArr);

        JsonArray dpArr = new JsonArray();
        for (Depot d : sim.depots) {
            JsonObject o = new JsonObject();
            o.addProperty("id", Long.toString(d.getId()));
            o.addProperty("name", d.getName());
            o.addProperty("repeatInfinitely", d.getRepeatInfinitely());
            dpArr.add(o);
        }
        res.add("depots", dpArr);

        return res;
    }

    private static VehicleCar buildVehicleCar(TransportMode mode, String vehicleId) {
        AtomicReference<VehicleResource> found = new AtomicReference<>(null);
        try {
            CustomResourceLoader.getVehicleById(mode, vehicleId, pair -> {
                if (pair != null && pair.left() != null) found.set(pair.left());
            });
        } catch (Throwable ignored) {}
        VehicleResource vr = found.get();
        if (vr != null) {
            return new VehicleCar(
                    vehicleId,
                    vr.getLength(),
                    vr.getWidth(),
                    vr.getBogie1Position(),
                    vr.getBogie2Position(),
                    vr.getCouplingPadding1(),
                    vr.getCouplingPadding2()
            );
        }
        return new VehicleCar(vehicleId, 16.0, 2.5, -5.0, 5.0, 0.5, 0.5);
    }

    public static JsonObject handleMtrControl(String bodyStr) {
        JsonObject out = new JsonObject();
        Simulator sim = getOverworldSimulator();
        MinecraftClient mc = MinecraftClient.getInstance();
        IntegratedServer server = mc != null ? mc.getServer() : null;
        if (sim == null || server == null) {
            out.addProperty("ok", false);
            out.addProperty("error", "simulator_or_server_unavailable");
            return out;
        }

        try {
            JsonObject req = (bodyStr != null && !bodyStr.isBlank())
                    ? JsonParser.parseString(bodyStr).getAsJsonObject()
                    : new JsonObject();
            String op = req.has("op") ? req.get("op").getAsString()
                    : (req.has("action") ? req.get("action").getAsString() : "auto_setup_express");

            CompletableFuture<JsonObject> fut = new CompletableFuture<>();
            server.execute(() -> {
                JsonObject res = new JsonObject();
                try {
                    Data data = MinecraftClientData.getInstance();
                    UpdateDataRequest updateReq = new UpdateDataRequest(sim);

                    if ("enforce_dwell".equalsIgnoreCase(op)) {
                        long dwell = req.has("dwellMillis") ? req.get("dwellMillis").getAsLong() : 20000L;
                        for (Platform p : sim.platforms) {
                            p.setDwellTime(dwell);
                            updateReq.addPlatform(p);
                        }
                        for (Siding s : sim.sidings) {
                            s.setDelayedVehicleReduceDwellTimePercentage(0);
                            s.setEarlyVehicleIncreaseDwellTime(false);
                            updateReq.addSiding(s);
                        }
                        updateReq.update();
                        res.addProperty("ok", true);
                        res.addProperty("dwellMillis", dwell);
                        fut.complete(res);
                        return;
                    }

                    if ("analyze_physics".equalsIgnoreCase(op) || "sync_physics".equalsIgnoreCase(op)) {
                        RailPhysicsEngine.CorridorPhysicsDecision decision;
                        if (req.has("corridorMeters")) {
                            boolean tun = !req.has("mostlyTunnel") || req.get("mostlyTunnel").getAsBoolean();
                            decision = RailPhysicsEngine.evaluateCorridorPhysics(req.get("corridorMeters").getAsDouble(), tun);
                        } else {
                            boolean autoClass = !"analyze_only".equalsIgnoreCase(op);
                            decision = RailPhysicsEngine.synchronizeSimulatorWithRealPhysics(server.getOverworld(), autoClass);
                        }
                        if (decision == null) {
                            res.addProperty("ok", false);
                            res.addProperty("error", "physics_simulator_unavailable");
                        } else {
                            res = RailPhysicsEngine.toJson(decision);
                        }
                        fut.complete(res);
                        return;
                    }

                    if ("generate_depots".equalsIgnoreCase(op)) {
                        int purged = WorldContextAnalyzer.purgeOrphanMtrRails(server.getOverworld(), sim);
                        ObjectArrayList<Depot> all = new ObjectArrayList<>(sim.depots);
                        Depot.generateDepots(sim, all);
                        res.addProperty("ok", true);
                        res.addProperty("count", all.size());
                        res.addProperty("purgedOrphanRailNodes", purged);
                        fut.complete(res);
                        return;
                    }

                    if ("clean_orphan_rails".equalsIgnoreCase(op)) {
                        int purged = WorldContextAnalyzer.purgeOrphanMtrRails(server.getOverworld(), sim);
                        res.addProperty("ok", true);
                        res.addProperty("purgedOrphanRailNodes", purged);
                        fut.complete(res);
                        return;
                    }

                    if ("world_audit".equalsIgnoreCase(op)) {
                        int cx = req.has("x") ? req.get("x").getAsInt() : -27;
                        int cz = req.has("z") ? req.get("z").getAsInt() : 25;
                        int rad = req.has("radius") ? req.get("radius").getAsInt() : 28;
                        boolean doPurge = !req.has("purge") || req.get("purge").getAsBoolean();
                        int purged = doPurge ? WorldContextAnalyzer.purgeOrphanMtrRails(server.getOverworld(), sim) : 0;
                        JsonObject audit = WorldContextAnalyzer.auditSurfaceSite(server.getOverworld(), cx, cz, rad);
                        audit.addProperty("purgedOrphanRailNodes", purged);
                        fut.complete(audit);
                        return;
                    }

                    if ("heal_world".equalsIgnoreCase(op)) {
                        fut.complete(WorldContextAnalyzer.healWorldOnServerStart(server.getOverworld()));
                        return;
                    }

                    if ("self_test".equalsIgnoreCase(op)) {
                        int x1 = req.has("x1") ? req.get("x1").getAsInt() : -36;
                        int y1 = req.has("y1") ? req.get("y1").getAsInt() : 47;
                        int z1 = req.has("z1") ? req.get("z1").getAsInt() : 16;
                        int x2 = req.has("x2") ? req.get("x2").getAsInt() : -14;
                        int y2 = req.has("y2") ? req.get("y2").getAsInt() : 72;
                        int z2 = req.has("z2") ? req.get("z2").getAsInt() : 46;
                        boolean autoFix = !req.has("autoFix") || req.get("autoFix").getAsBoolean();
                        JsonObject report = WorldContextAnalyzer.validateAndHealStructure(
                                server.getOverworld(), x1, y1, z1, x2, y2, z2, autoFix
                        );
                        fut.complete(report);
                        return;
                    }

                    // Always purge any orphaned MTR rail nodes whose physical mtr:rail block was broken/filled
                    int autoPurgedOrphans = WorldContextAnalyzer.purgeOrphanMtrRails(server.getOverworld(), sim);
                    res.addProperty("purgedOrphanRailNodes", autoPurgedOrphans);

                    Platform northPlat = null;
                    Platform southPlat = null;
                    for (Platform p : sim.platforms) {
                        long mz = p.getMidPosition().getZ();
                        long my = p.getMidPosition().getY();
                        if (mz >= 0 && mz <= 80 && Math.abs(p.getMidPosition().getX() - (-18)) <= 8) {
                            if (northPlat == null || my < northPlat.getMidPosition().getY()) northPlat = p;
                        } else if (mz >= 1500 && mz <= 1650 && Math.abs(p.getMidPosition().getX() - (-18)) <= 8) {
                            if (southPlat == null || my < southPlat.getMidPosition().getY()) southPlat = p;
                        }
                    }
                    Siding northSiding = null;
                    for (Siding s : sim.sidings) {
                        long mz = s.getMidPosition().getZ();
                        long my = s.getMidPosition().getY();
                        if (mz >= -30 && mz <= 30 && Math.abs(s.getMidPosition().getX() - (-18)) <= 8) {
                            if (northSiding == null || my < northSiding.getMidPosition().getY()) northSiding = s;
                        }
                    }

                    // Cleanly delete any orphaned old surface platforms/sidings above y=56 when underground y=48 exists!
                    org.mtr.core.operation.DeleteDataRequest delReq = new org.mtr.core.operation.DeleteDataRequest();
                    boolean hasOrphans = false;
                    if (northPlat != null && northPlat.getMidPosition().getY() <= 55) {
                        for (Platform p : sim.platforms) {
                            if (p.getId() != northPlat.getId() && (southPlat == null || p.getId() != southPlat.getId())
                                    && p.getMidPosition().getY() > 56) {
                                delReq.addPlatformId(p.getId());
                                hasOrphans = true;
                            }
                        }
                    }
                    if (northSiding != null && northSiding.getMidPosition().getY() <= 55) {
                        for (Siding s : sim.sidings) {
                            if (s.getId() != northSiding.getId() && s.getMidPosition().getY() > 56) {
                                delReq.addSidingId(s.getId());
                                hasOrphans = true;
                            }
                        }
                    }
                    if (hasOrphans) {
                        delReq.delete(sim);
                    }

                    if (northPlat == null || southPlat == null || northSiding == null) {
                        res.addProperty("ok", false);
                        res.addProperty("error", "missing_saved_rails");
                        fut.complete(res);
                        return;
                    }

                    // Measure exact inter-station corridor length & run ODE traction/braking physics calculator!
                    double pdx = southPlat.getMidPosition().getX() - northPlat.getMidPosition().getX();
                    double pdy = southPlat.getMidPosition().getY() - northPlat.getMidPosition().getY();
                    double pdz = southPlat.getMidPosition().getZ() - northPlat.getMidPosition().getZ();
                    double corridorDistM = Math.sqrt(pdx * pdx + pdy * pdy + pdz * pdz);
                    RailPhysicsEngine.CorridorPhysicsDecision physDecision =
                            RailPhysicsEngine.evaluateCorridorPhysics(corridorDistM, true);

                    boolean forceManualClass = req.has("forceOverridePhysics") && req.get("forceOverridePhysics").getAsBoolean();
                    UitpSystemType uitp = forceManualClass && (req.has("uitpType") || req.has("routeNumber"))
                            ? UitpSystemType.fromRouteCodeOrType(req.has("uitpType") ? req.get("uitpType").getAsString() : req.get("routeNumber").getAsString())
                            : physDecision.recommendedSpec.systemType;

                    RailPhysicsEngine.RollingStockPhysics activeSpec = RailPhysicsEngine.getSpecForSystem(uitp);

                    String northName = req.has("northStationName") ? req.get("northStationName").getAsString()
                            : (req.has("northName") ? req.get("northName").getAsString() : "Kuzey Orman");
                    String southName = req.has("southStationName") ? req.get("southStationName").getAsString()
                            : (req.has("southName") ? req.get("southName").getAsString() : "Güney Orman");
                    String routeNumber = forceManualClass && req.has("routeNumber")
                            ? req.get("routeNumber").getAsString()
                            : (uitp.prefix + "1");
                    String routeName = forceManualClass && req.has("routeName")
                            ? req.get("routeName").getAsString()
                            : ("Orman " + uitp.spokenPrefixTr);
                    String trainId = req.has("trainId") ? req.get("trainId").getAsString() : "sp1900_mini_cab_3";
                    long dwellMs = req.has("dwellMillis") ? req.get("dwellMillis").getAsLong() : 20000L;
                    int freqPerHour = req.has("frequencyPerHour") ? req.get("frequencyPerHour").getAsInt() : 20;

                    Station nSt = null;
                    Station sSt = null;
                    org.mtr.core.operation.DeleteDataRequest stDel = new org.mtr.core.operation.DeleteDataRequest();
                    boolean dupStations = false;
                    for (Station st : sim.stations) {
                        long cz = (st.getMinZ() + st.getMaxZ()) / 2;
                        if (cz >= 0 && cz <= 80) {
                            if (nSt == null) nSt = st;
                            else { stDel.addStationId(st.getId()); dupStations = true; }
                        } else if (cz >= 1500 && cz <= 1650) {
                            if (sSt == null) sSt = st;
                            else { stDel.addStationId(st.getId()); dupStations = true; }
                        }
                    }
                    if (dupStations) stDel.delete(sim);
                    if (nSt == null) nSt = new Station(data);
                    nSt.setName(northName);
                    nSt.setColor(0x1E8449);
                    nSt.setCorners(new Position(-32, 42, 16), new Position(-12, 75, 48));
                    updateReq.addStation(nSt);

                    if (sSt == null) sSt = new Station(data);
                    sSt.setName(southName);
                    sSt.setColor(0x117A65);
                    sSt.setCorners(new Position(-32, 42, 1564), new Position(-12, 84, 1596));
                    updateReq.addStation(sSt);

                    northPlat.setName("1");
                    northPlat.setDwellTime(dwellMs);
                    updateReq.addPlatform(northPlat);

                    southPlat.setName("1");
                    southPlat.setDwellTime(dwellMs);
                    updateReq.addPlatform(southPlat);

                    ObjectArrayList<VehicleCar> cars = new ObjectArrayList<>();
                    if (req.has("cars") && req.get("cars").isJsonArray()) {
                        for (JsonElement ce : req.getAsJsonArray("cars")) {
                            cars.add(buildVehicleCar(uitp.mtrTransportMode, ce.getAsString()));
                        }
                    } else {
                        cars.add(buildVehicleCar(uitp.mtrTransportMode, trainId));
                    }
                    northSiding.setName(routeNumber + " Depo");
                    northSiding.setVehicleCars(cars);
                    northSiding.setUnlimitedVehicles(false);
                    northSiding.setMaxVehicles(1);
                    northSiding.setIsManual(false);
                    northSiding.setAcceleration(Math.max(Siding.MIN_ACCELERATION, activeSpec.maxStartAccelMps2 * 0.88 * 1.0E-6));
                    northSiding.setDeceleration(Math.max(Siding.MIN_ACCELERATION, activeSpec.serviceBrakeMps2 * 1.0E-6));
                    northSiding.setDelayedVehicleSpeedIncreasePercentage(0);
                    northSiding.setDelayedVehicleReduceDwellTimePercentage(0);
                    northSiding.setEarlyVehicleIncreaseDwellTime(false);
                    updateReq.addSiding(northSiding);

                    Route routeNS = null;
                    Route routeSN = null;
                    Iterator<Route> rit = sim.routes.iterator();
                    if (rit.hasNext()) routeNS = rit.next();
                    if (rit.hasNext()) routeSN = rit.next();
                    if (routeNS == null) routeNS = new Route(uitp.mtrTransportMode, data);
                    if (routeSN == null || routeSN.getId() == routeNS.getId()) {
                        routeSN = new Route(uitp.mtrTransportMode, data);
                    }

                    int routeColor = req.has("color") ? req.get("color").getAsInt() : uitp.defaultColor;
                    routeNS.setName(routeName);
                    routeNS.setRouteNumber(routeNumber);
                    routeNS.setColor(routeColor);
                    routeNS.setRouteType(uitp.mtrRouteType);
                    routeNS.setHidden(false);
                    routeNS.getRoutePlatforms().clear();
                    routeNS.getRoutePlatforms().add(new RoutePlatformData(northPlat.getId()));
                    routeNS.getRoutePlatforms().add(new RoutePlatformData(southPlat.getId()));
                    updateReq.addRoute(routeNS);

                    routeSN.setName(routeName);
                    routeSN.setRouteNumber(routeNumber);
                    routeSN.setColor(routeColor);
                    routeSN.setRouteType(uitp.mtrRouteType);
                    routeSN.setHidden(false);
                    routeSN.getRoutePlatforms().clear();
                    routeSN.getRoutePlatforms().add(new RoutePlatformData(southPlat.getId()));
                    routeSN.getRoutePlatforms().add(new RoutePlatformData(northPlat.getId()));
                    updateReq.addRoute(routeSN);

                    Depot depot = sim.depots.isEmpty() ? new Depot(uitp.mtrTransportMode, data) : sim.depots.iterator().next();
                    depot.setName(routeNumber + " Merkez Deposu");
                    depot.setCorners(new Position(-26, 42, -38), new Position(-10, 74, 15));
                    depot.setUseRealTime(false);
                    depot.setRepeatInfinitely(true);
                    for (int h = 0; h < 24; h++) depot.setFrequency(h, freqPerHour);
                    depot.getRouteIds().clear();
                    depot.getRouteIds().add(routeNS.getId());
                    depot.getRouteIds().add(routeSN.getId());
                    updateReq.addDepot(depot);

                    updateReq.update();

                    long targetLineSpeed = Math.min(RailPhysicsEngine.chunkSafeMaxSpeedKmh,
                            forceManualClass ? Math.round(activeSpec.designSpeedKmh) : physDecision.recommendedLineSpeedKmh);
                    RailPhysicsEngine.applyCorridorRailSpeedLimit(server.getOverworld(), sim, targetLineSpeed);

                    ObjectArrayList<Depot> toGen = new ObjectArrayList<>();
                    toGen.add(depot);
                    Depot.generateDepots(sim, toGen);

                    res.addProperty("ok", true);
                    res.addProperty("route", routeNumber + " " + routeName);
                    res.addProperty("uitpSystem", uitp.name());
                    res.addProperty("corridorMeters", Math.round(corridorDistM));
                    res.addProperty("physicsSpeedKmh", targetLineSpeed);
                    res.addProperty("referenceTrain", activeSpec.referenceModel);
                    res.addProperty("dwellMillis", dwellMs);
                    res.addProperty("reduceDwellPct", 0);
                    fut.complete(res);
                } catch (Throwable t) {
                    res.addProperty("ok", false);
                    res.addProperty("error", t.toString());
                    fut.complete(res);
                }
            });
            return fut.get(8, TimeUnit.SECONDS);
        } catch (Throwable t) {
            out.addProperty("ok", false);
            out.addProperty("error", t.toString());
            return out;
        }
    }
}

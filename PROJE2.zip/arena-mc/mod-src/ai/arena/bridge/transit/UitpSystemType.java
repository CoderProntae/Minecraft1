package ai.arena.bridge.transit;

import org.mtr.core.data.RouteType;
import org.mtr.core.data.TransportMode;

import java.util.Locale;

/**
 * Official UITP (International Association of Public Transport) &
 * UIC (International Union of Railways) transit system classification.
 */
public enum UitpSystemType {
    YHT("YHT", "Yüksek Hızlı Tren", "Y H T", TransportMode.TRAIN, RouteType.HIGH_SPEED, 0x00A86B, false),
    BOLGESEL("R", "Bölgesel Ekspres Tren", "Bölgesel Tren", TransportMode.TRAIN, RouteType.NORMAL, 0x3949AB, false),
    BANLIYO("B", "Banliyö Treni (Yüzey Bölgesel Hat)", "Banliyö", TransportMode.TRAIN, RouteType.NORMAL, 0x1E88E5, false),
    METRO("M", "Metro (Tam Ayrılmış Yeraltı Ağır Raylı)", "Metro", TransportMode.TRAIN, RouteType.NORMAL, 0xE53935, true),
    HRS("HRS", "Hafif Raylı Sistem", "Hafif Raylı Sistem", TransportMode.TRAIN, RouteType.LIGHT_RAIL, 0xFB8C00, false),
    TRAMVAY("T", "Tramvay (Yüzey Cadde/Kıyı Hattı)", "Tramvay", TransportMode.TRAIN, RouteType.LIGHT_RAIL, 0x43A047, false),
    MONORAY("MR", "Monoray (Yükseltilmiş Tek Ray)", "Monoray", TransportMode.TRAIN, RouteType.LIGHT_RAIL, 0x8E24AA, false),
    FUNIKULER("F", "Füniküler (Eğimli Yamaç Hattı)", "Füniküler", TransportMode.TRAIN, RouteType.NORMAL, 0x6D4C41, true),
    TELEFERIK("TF", "Teleferik (Hava Hattı)", "Teleferik", TransportMode.CABLE_CAR, RouteType.NORMAL, 0x00ACC1, false);

    public final String prefix;
    public final String displayNameTr;
    public final String spokenPrefixTr;
    public final TransportMode mtrTransportMode;
    public final RouteType mtrRouteType;
    public final int defaultColor;
    public final boolean requiresUndergroundStations;

    UitpSystemType(
            String prefix,
            String displayNameTr,
            String spokenPrefixTr,
            TransportMode mtrTransportMode,
            RouteType mtrRouteType,
            int defaultColor,
            boolean requiresUndergroundStations
    ) {
        this.prefix = prefix;
        this.displayNameTr = displayNameTr;
        this.spokenPrefixTr = spokenPrefixTr;
        this.mtrTransportMode = mtrTransportMode;
        this.mtrRouteType = mtrRouteType;
        this.defaultColor = defaultColor;
        this.requiresUndergroundStations = requiresUndergroundStations;
    }

    public static UitpSystemType fromRouteCodeOrType(String codeOrName) {
        if (codeOrName == null || codeOrName.isBlank()) return YHT;
        String u = codeOrName.trim().toUpperCase(Locale.ROOT);
        if (u.startsWith("YHT") || u.equals("HIGH_SPEED") || u.equals("HSR")) return YHT;
        if (u.startsWith("BOL") || u.startsWith("REG") || u.startsWith("R")) return BOLGESEL;
        if (u.startsWith("HRS") || u.equals("LRT") || u.equals("LIGHT_RAIL")) return HRS;
        if (u.startsWith("MR") || u.startsWith("MONOR")) return MONORAY;
        if (u.startsWith("TF") || u.startsWith("TELEF") || u.equals("CABLE_CAR")) return TELEFERIK;
        if (u.startsWith("METRO") || (u.startsWith("M") && !u.startsWith("MR"))) return METRO;
        if (u.startsWith("BAN") || u.startsWith("B")) return BANLIYO;
        if (u.startsWith("TRAM") || u.startsWith("T")) return TRAMVAY;
        if (u.startsWith("FUN") || u.startsWith("F")) return FUNIKULER;
        return YHT;
    }

    public static String toSpokenTurkishTitle(String routeNumber, String routeName) {
        String code = (routeNumber == null || routeNumber.isBlank()) ? "YHT-1" : routeNumber.trim();
        UitpSystemType sys = fromRouteCodeOrType(code);
        String digits = code.toUpperCase(Locale.ROOT)
                .replace(sys.prefix, "")
                .replace("-", "")
                .trim();
        String spokenNum = switch (digits) {
            case "", "1" -> "Bir";
            case "2" -> "İki";
            case "3" -> "Üç";
            case "4" -> "Dört";
            case "5" -> "Beş";
            case "6" -> "Altı";
            case "7" -> "Yedi";
            case "8" -> "Sekiz";
            case "9" -> "Dokuz";
            case "10" -> "On";
            default -> digits;
        };
        if (sys == YHT) {
            return "Y H T " + spokenNum + " Yüksek Hızlı Tren";
        }
        return sys.spokenPrefixTr + " " + spokenNum;
    }
}

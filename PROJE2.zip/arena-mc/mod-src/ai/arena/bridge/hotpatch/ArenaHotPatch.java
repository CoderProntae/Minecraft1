package ai.arena.bridge.hotpatch;

import com.google.gson.JsonObject;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.server.MinecraftServer;

/**
 * Live JVM Hot-Swap Extension Contract (v7.6.0):
 * Implementations can be compiled & remapped externally and injected over HTTP (/hotpatch or /map_api)
 * into a running Minecraft 1.20.4 session with ZERO client/world restarts.
 */
public interface ArenaHotPatch {

    default String getPatchId() {
        return "live-patch";
    }

    default boolean renderWorldMapBoard(
            BlockEntity entity,
            float tickDelta,
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            int light,
            int overlay
    ) {
        return false;
    }

    default boolean renderNewsBoard(
            BlockEntity entity,
            float tickDelta,
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            int light,
            int overlay
    ) {
        return false;
    }

    default boolean renderVendingMachine(
            BlockEntity entity,
            float tickDelta,
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            int light,
            int overlay
    ) {
        return false;
    }

    default void onClientTick(MinecraftClient client) {}

    default void onServerTick(MinecraftServer server) {}

    default JsonObject invoke(MinecraftClient client, MinecraftServer server, JsonObject payload) {
        JsonObject res = new JsonObject();
        res.addProperty("ok", true);
        res.addProperty("patchId", getPatchId());
        return res;
    }
}

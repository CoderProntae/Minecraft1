package ai.arena.bridge;

import ai.arena.bridge.audio.LocalTtsManager;
import ai.arena.bridge.board.ArenaNewsManager;
import ai.arena.bridge.client.ArenaClientRuntime;
import ai.arena.bridge.map.ArenaMapData;
import ai.arena.bridge.transit.MtrBridgeHelper;
import ai.arena.bridge.world.WorldContextAnalyzer;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.fabricmc.loader.api.metadata.ModMetadata;
import net.minecraft.block.BedBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.CampfireBlock;
import net.minecraft.block.CarpetBlock;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.FallingBlock;
import net.minecraft.block.LanternBlock;
import net.minecraft.block.LeavesBlock;
import net.minecraft.block.LecternBlock;
import net.minecraft.block.PlantBlock;
import net.minecraft.block.SignBlock;
import net.minecraft.block.TorchBlock;
import net.minecraft.block.VineBlock;
import net.minecraft.block.WallSignBlock;
import net.minecraft.block.WallTorchBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.util.ScreenshotRecorder;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.command.argument.BlockArgumentParser;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtIo;
import net.minecraft.nbt.NbtSizeTracker;
import net.minecraft.registry.Registries;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.property.Property;
import net.minecraft.structure.StructurePlacementData;
import net.minecraft.structure.StructureTemplate;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.EmptyBlockView;
import net.minecraft.world.GameMode;
import net.minecraft.world.Heightmap;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.Base64;
import java.util.Optional;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

public class ArenaAiMod implements ClientModInitializer {
    private static final int BRIDGE_PORT = 25580;
    private static final Gson GSON = new Gson();
    private static final Deque<WorldSnapshot> UNDO_STACK = new ArrayDeque<>();
    private static volatile String lastAnnouncedWorld = "";

    private static class WorldSnapshot {
        final ServerWorld world;
        final Map<BlockPos, BlockState> blocks;
        WorldSnapshot(ServerWorld world, Map<BlockPos, BlockState> blocks) {
            this.world = world;
            this.blocks = blocks;
        }
    }

    private static class PlannedBlock {
        final BlockPos pos;
        final BlockState state;
        final String rawSpec;
        final boolean onlyAir;
        final int pass; // 1 = structural, 2 = standing attachment, 3 = hanging attachment

        PlannedBlock(BlockPos pos, BlockState state, String rawSpec, boolean onlyAir, int pass) {
            this.pos = pos;
            this.state = state;
            this.rawSpec = rawSpec;
            this.onlyAir = onlyAir;
            this.pass = pass;
        }
    }

    @Override
    public void onInitializeClient() {
        try {
            ArenaClientRuntime.initClient();
        } catch (Throwable t) {
            t.printStackTrace();
        }

        Thread httpThread = new Thread(this::runHttpServer, "ArenaAI-HttpBridge");
        httpThread.setDaemon(true);
        httpThread.start();

        Thread watcherThread = new Thread(this::runWorldWatcher, "ArenaAI-WorldWatcher");
        watcherThread.setDaemon(true);
        watcherThread.start();
    }

    private void runWorldWatcher() {
        while (true) {
            try {
                Thread.sleep(1500);
                MinecraftClient client = MinecraftClient.getInstance();
                if (client == null) continue;
                IntegratedServer server = client.getServer();
                ClientPlayerEntity player = client.player;
                if (server != null && player != null) {
                    server.execute(() -> {
                        try {
                            if (!server.isRemote()) {
                                int freePort = findFreePort();
                                GameMode gm = GameMode.SURVIVAL;
                                List<ServerPlayerEntity> players = server.getPlayerManager().getPlayerList();
                                if (!players.isEmpty()) {
                                    gm = players.get(0).interactionManager.getGameMode();
                                }
                                server.openToLan(gm, true, freePort);
                            }
                            server.setOnlineMode(false);
                            String key = server.getSaveProperties().getLevelName() + ":" + server.getServerPort();
                            if (!key.equals(lastAnnouncedWorld)) {
                                lastAnnouncedWorld = key;
                                boolean mtr = FabricLoader.getInstance().isModLoaded("mtr");
                                server.getPlayerManager().broadcast(
                                    Text.literal("§8[§7Avrasya Ulaşım v7.0§8] §7Köprü hazır (LAN: " + server.getServerPort() + ")"),
                                    false
                                );
                            }
                        } catch (Throwable ignored) {}
                    });
                } else {
                    lastAnnouncedWorld = "";
                }
            } catch (Throwable ignored) {}
        }
    }

    private static int findFreePort() {
        try (ServerSocket ss = new ServerSocket(0)) {
            return ss.getLocalPort();
        } catch (Exception e) {
            return 25565;
        }
    }

    private void runHttpServer() {
        while (true) {
            try (ServerSocket serverSocket = new ServerSocket()) {
                serverSocket.setReuseAddress(true);
                serverSocket.bind(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), BRIDGE_PORT), 50);
                while (true) {
                    final Socket sock = serverSocket.accept();
                    Thread t = new Thread(() -> handleClient(sock), "ArenaAI-Req");
                    t.setDaemon(true);
                    t.start();
                }
            } catch (Throwable e) {
                try { Thread.sleep(2000); } catch (InterruptedException ignored) {}
            }
        }
    }

    private void handleClient(Socket sock) {
        try (Socket s = sock) {
            s.setSoTimeout(15000);
            InputStream in = new BufferedInputStream(s.getInputStream());
            OutputStream out = s.getOutputStream();

            String requestLine = readLine(in);
            if (requestLine == null || requestLine.isEmpty()) return;
            String[] parts = requestLine.split(" ");
            if (parts.length < 2) return;
            String method = parts[0].toUpperCase();
            String fullPath = parts[1];
            String path = fullPath;
            String query = "";
            int qIdx = fullPath.indexOf('?');
            if (qIdx >= 0) {
                path = fullPath.substring(0, qIdx);
                query = fullPath.substring(qIdx + 1);
            }

            int contentLength = 0;
            while (true) {
                String header = readLine(in);
                if (header == null || header.isEmpty()) break;
                int colon = header.indexOf(':');
                if (colon > 0) {
                    String hName = header.substring(0, colon).trim().toLowerCase();
                    String hVal = header.substring(colon + 1).trim();
                    if ("content-length".equals(hName)) {
                        contentLength = Integer.parseInt(hVal);
                    }
                }
            }

            byte[] bodyBytes = new byte[contentLength];
            int readTotal = 0;
            while (readTotal < contentLength) {
                int r = in.read(bodyBytes, readTotal, contentLength - readTotal);
                if (r < 0) break;
                readTotal += r;
            }
            String bodyStr = new String(bodyBytes, 0, readTotal, StandardCharsets.UTF_8);

            if ("OPTIONS".equals(method)) {
                writeResponse(out, 200, "application/json", "{\"ok\":true}".getBytes(StandardCharsets.UTF_8));
                return;
            }

            switch (path) {
                case "/ping": {
                    JsonObject res = new JsonObject();
                    res.addProperty("ok", true);
                    res.addProperty("mod", "arena_ai_bridge");
                    res.addProperty("version", "7.8.0");
                    res.addProperty("ttsBackend", LocalTtsManager.getBackendStatus());
                    res.addProperty("mtrLoaded", FabricLoader.getInstance().isModLoaded("mtr"));
                    writeJson(out, 200, res);
                    break;
                }
                case "/status":
                    writeJson(out, 200, handleStatus());
                    break;
                case "/mods":
                    writeJson(out, 200, handleMods());
                    break;
                case "/registry":
                    writeJson(out, 200, handleRegistry(parseQuery(query)));
                    break;
                case "/state_map":
                    writeJson(out, 200, handleStateMap());
                    break;
                case "/world_audit":
                    writeJson(out, 200, handleWorldAudit(parseQuery(query)));
                    break;
                case "/mtr_proxy":
                    writeJson(out, 200, handleMtrProxy(parseQuery(query), method, bodyStr));
                    break;
                case "/screenshot": {
                    byte[] png = handleScreenshot();
                    if (png != null) {
                        writeResponse(out, 200, "image/png", png);
                    } else {
                        JsonObject err = new JsonObject();
                        err.addProperty("ok", false);
                        err.addProperty("error", "not_in_world_or_framebuffer_unavailable");
                        writeJson(out, 503, err);
                    }
                    break;
                }
                case "/bot_vision": {
                    byte[] png = handleBotVision(parseQuery(query));
                    if (png != null) {
                        writeResponse(out, 200, "image/png", png);
                    } else {
                        JsonObject err = new JsonObject();
                        err.addProperty("ok", false);
                        err.addProperty("error", "bot_not_in_client_render_range_or_unavailable");
                        writeJson(out, 503, err);
                    }
                    break;
                }
                case "/scan":
                    writeJson(out, 200, handleScan(parseQuery(query)));
                    break;
                case "/scan3d":
                    writeJson(out, 200, handleScan3d(parseQuery(query)));
                    break;
                case "/templates":
                    writeJson(out, 200, handleTemplates(parseQuery(query)));
                    break;
                case "/place_nbt":
                    writeJson(out, 200, handlePlaceNbt(bodyStr));
                    break;
                case "/save_nbt":
                    writeJson(out, 200, handleSaveNbt(bodyStr));
                    break;
                case "/place_real":
                    writeJson(out, 200, handlePlaceReal(bodyStr));
                    break;
                case "/break_real":
                    writeJson(out, 200, handleBreakReal(bodyStr));
                    break;
                case "/actionbar":
                    writeJson(out, 200, handleActionbar(bodyStr));
                    break;
                case "/chat":
                    writeJson(out, 200, handleChat(bodyStr));
                    break;
                case "/command":
                    writeJson(out, 200, handleCommand(bodyStr));
                    break;
                case "/build":
                    writeJson(out, 200, handleBuild(bodyStr));
                    break;
                case "/clean_floating":
                    writeJson(out, 200, handleCleanFloating(bodyStr));
                    break;
                case "/interact":
                    writeJson(out, 200, handleInteract(bodyStr));
                    break;
                case "/play_wav":
                    writeJson(out, 200, MtrBridgeHelper.playWav(bodyStr));
                    break;
                case "/mtr_state":
                    if (!FabricLoader.getInstance().isModLoaded("mtr")) {
                        JsonObject e = new JsonObject(); e.addProperty("ok", false); e.addProperty("error", "mtr_not_loaded");
                        writeJson(out, 503, e);
                    } else {
                        writeJson(out, 200, MtrBridgeHelper.getMtrState());
                    }
                    break;
                case "/mtr_control":
                    if (!FabricLoader.getInstance().isModLoaded("mtr")) {
                        JsonObject e = new JsonObject(); e.addProperty("ok", false); e.addProperty("error", "mtr_not_loaded");
                        writeJson(out, 503, e);
                    } else {
                        writeJson(out, 200, MtrBridgeHelper.handleMtrControl(bodyStr));
                    }
                    break;
                case "/map_api":
                    writeJson(out, 200, ArenaMapData.handleMapApi(method, bodyStr));
                    break;
                case "/hotpatch":
                    writeJson(out, 200, ai.arena.bridge.hotpatch.HotPatchManager.handleHttp(method, bodyStr));
                    break;
                case "/news": {
                    ArenaNewsManager.ensureLoaded();
                    if ("POST".equalsIgnoreCase(method)) {
                        writeJson(out, 200, ArenaNewsManager.handleApiPost(bodyStr));
                    } else {
                        writeJson(out, 200, ArenaNewsManager.toJson());
                    }
                    break;
                }
                case "/local_tts": {
                    JsonObject res = new JsonObject();
                    try {
                        JsonObject req = (bodyStr != null && !bodyStr.isBlank()) ? JsonParser.parseString(bodyStr).getAsJsonObject() : new JsonObject();
                        String txt = req.has("text") ? req.get("text").getAsString() : "";
                        String chime = req.has("chime") ? req.get("chime").getAsString() : "station";
                        boolean intr = req.has("interrupt") && req.get("interrupt").getAsBoolean();
                        if (!txt.isBlank()) {
                            LocalTtsManager.speakAsync(txt, chime, 0.95f, intr);
                        }
                        res.addProperty("ok", true);
                        res.addProperty("localReady", LocalTtsManager.isLocalReady());
                        res.addProperty("backend", LocalTtsManager.getBackendStatus());
                    } catch (Throwable t) {
                        res.addProperty("ok", false);
                        res.addProperty("error", t.toString());
                    }
                    writeJson(out, 200, res);
                    break;
                }
                case "/balance": {
                    JsonObject res = new JsonObject();
                    try {
                        JsonObject req = (bodyStr != null && !bodyStr.isBlank()) ? JsonParser.parseString(bodyStr).getAsJsonObject() : new JsonObject();
                        int amount = req.has("amount") ? req.get("amount").getAsInt() : 0;
                        String targetPlayer = req.has("player") ? req.get("player").getAsString() : "";
                        MinecraftClient mc = MinecraftClient.getInstance();
                        IntegratedServer srv = mc != null ? mc.getServer() : null;
                        if (srv != null) {
                            String pName = !targetPlayer.isBlank() ? targetPlayer : (mc.player != null ? mc.player.getNameForScoreboard() : "ilkan");
                            srv.execute(() -> ArenaContent.setPlayerMtrBalance(srv, pName, amount));
                            res.addProperty("ok", true);
                            res.addProperty("player", pName);
                            res.addProperty("amount", amount);
                        } else {
                            res.addProperty("ok", false);
                            res.addProperty("error", "no_integrated_server");
                        }
                    } catch (Throwable t) {
                        res.addProperty("ok", false);
                        res.addProperty("error", t.toString());
                    }
                    writeJson(out, 200, res);
                    break;
                }
                case "/weather_gfx": {
                    JsonObject res = new JsonObject();
                    if (bodyStr != null && !bodyStr.isBlank()) {
                        JsonObject req = JsonParser.parseString(bodyStr).getAsJsonObject();
                        if (req.has("enabled")) ArenaClientRuntime.weatherGraphicsEnabled = req.get("enabled").getAsBoolean();
                        if (req.has("mode") || req.has("intensity")) {
                            String mode = req.has("mode") ? req.get("mode").getAsString() : "thunder";
                            int intensity = req.has("intensity") ? req.get("intensity").getAsInt() : 1;
                            MinecraftClient mc = MinecraftClient.getInstance();
                            IntegratedServer srv = mc != null ? mc.getServer() : null;
                            if (srv != null) {
                                int thunderLvl = req.has("thunderIntensity") ? req.get("thunderIntensity").getAsInt() : intensity;
                                srv.execute(() -> ArenaContent.applyServerWeather(srv.getOverworld(), mode, intensity, thunderLvl));
                            }
                        }
                    }
                    res.addProperty("ok", true);
                    res.addProperty("enabled", ArenaClientRuntime.weatherGraphicsEnabled);
                    res.addProperty("rainIntensity", ArenaContent.rainIntensity);
                    res.addProperty("thunderIntensity", ArenaContent.thunderIntensity);
                    writeJson(out, 200, res);
                    break;
                }
                case "/undo":
                    writeJson(out, 200, handleUndo());
                    break;
                default: {
                    JsonObject err = new JsonObject();
                    err.addProperty("ok", false);
                    err.addProperty("error", "not_found");
                    writeJson(out, 404, err);
                }
            }
        } catch (Throwable ignored) {}
    }

    private static int getMtrPort() {
        if (!FabricLoader.getInstance().isModLoaded("mtr")) return -1;
        try {
            Class<?> initCls = Class.forName("org.mtr.mod.Init");
            Object p = initCls.getMethod("getServerPort").invoke(null);
            return p instanceof Integer ? (Integer) p : -1;
        } catch (Throwable t) {
            return -1;
        }
    }

    private JsonObject handleMtrProxy(Map<String, String> q, String method, String bodyStr) {
        JsonObject res = new JsonObject();
        int port = getMtrPort();
        if (port <= 0) {
            res.addProperty("ok", false);
            res.addProperty("error", "mtr_not_running_or_no_port");
            return res;
        }
        String subPath = q.getOrDefault("path", "/mtr/api/map/stations-and-routes?dimension=0");
        if (!subPath.startsWith("/")) subPath = "/" + subPath;
        try {
            java.net.URL url = new java.net.URL("http://127.0.0.1:" + port + subPath);
            java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(3000);
            conn.setReadTimeout(6000);
            conn.setRequestMethod(bodyStr != null && !bodyStr.isEmpty() ? "POST" : "GET");
            if (bodyStr != null && !bodyStr.isEmpty()) {
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(bodyStr.getBytes(StandardCharsets.UTF_8));
                }
            }
            int code = conn.getResponseCode();
            InputStream is = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
            String respText = is != null ? new String(is.readAllBytes(), StandardCharsets.UTF_8) : "";
            res.addProperty("ok", code >= 200 && code < 300);
            res.addProperty("mtrPort", port);
            res.addProperty("status", code);
            try {
                res.add("data", JsonParser.parseString(respText));
            } catch (Throwable parseErr) {
                res.addProperty("raw", respText);
            }
            return res;
        } catch (Throwable t) {
            res.addProperty("ok", false);
            res.addProperty("mtrPort", port);
            res.addProperty("error", t.toString());
            return res;
        }
    }

    // ==================== MOD & REGISTRY INTROSPECTION (MTR + ALL FABRIC MODS) ====================
    private JsonObject handleMods() {
        JsonObject res = new JsonObject();
        res.addProperty("ok", true);
        res.addProperty("mtrLoaded", FabricLoader.getInstance().isModLoaded("mtr"));
        res.addProperty("mtrPort", getMtrPort());
        JsonArray arr = new JsonArray();
        for (ModContainer mc : FabricLoader.getInstance().getAllMods()) {
            ModMetadata meta = mc.getMetadata();
            String id = meta.getId();
            if (id.startsWith("fabric-") && !id.equals("fabric-api")) continue;
            if (id.equals("java") || id.equals("minecraft") || id.equals("mixinextras")) continue;
            JsonObject m = new JsonObject();
            m.addProperty("id", id);
            m.addProperty("name", meta.getName());
            m.addProperty("version", meta.getVersion().getFriendlyString());
            arr.add(m);
        }
        res.add("mods", arr);
        return res;
    }

    private JsonObject handleRegistry(Map<String, String> q) {
        String nsFilter = q.getOrDefault("ns", "").trim().toLowerCase();
        String queryStr = q.getOrDefault("q", "").trim().toLowerCase();
        String type = q.getOrDefault("type", "block").trim().toLowerCase();
        int limit = Math.min(500, Math.max(1, parseInt(q.get("limit"), 150)));

        JsonObject res = new JsonObject();
        res.addProperty("ok", true);
        res.addProperty("type", type);
        JsonArray results = new JsonArray();

        if ("item".equals(type)) {
            for (Identifier id : Registries.ITEM.getIds()) {
                if (!nsFilter.isEmpty() && !id.getNamespace().equalsIgnoreCase(nsFilter)) continue;
                if (!queryStr.isEmpty() && !id.toString().toLowerCase().contains(queryStr)) continue;
                Item item = Registries.ITEM.get(id);
                JsonObject o = new JsonObject();
                o.addProperty("id", id.toString());
                o.addProperty("maxCount", item.getMaxCount());
                results.add(o);
                if (results.size() >= limit) break;
            }
        } else if ("entity".equals(type)) {
            for (Identifier id : Registries.ENTITY_TYPE.getIds()) {
                if (!nsFilter.isEmpty() && !id.getNamespace().equalsIgnoreCase(nsFilter)) continue;
                if (!queryStr.isEmpty() && !id.toString().toLowerCase().contains(queryStr)) continue;
                JsonObject o = new JsonObject();
                o.addProperty("id", id.toString());
                results.add(o);
                if (results.size() >= limit) break;
            }
        } else {
            for (Identifier id : Registries.BLOCK.getIds()) {
                if (!nsFilter.isEmpty() && !id.getNamespace().equalsIgnoreCase(nsFilter)) continue;
                if (!queryStr.isEmpty() && !id.toString().toLowerCase().contains(queryStr)) continue;
                Block b = Registries.BLOCK.get(id);
                BlockState def = b.getDefaultState();
                JsonObject o = new JsonObject();
                o.addProperty("id", id.toString());
                boolean hasCol = false;
                try {
                    hasCol = !def.getCollisionShape(EmptyBlockView.INSTANCE, BlockPos.ORIGIN).isEmpty();
                } catch (Throwable ignored) {
                    hasCol = def.isOpaque();
                }
                o.addProperty("solid", hasCol);

                Collection<Property<?>> props = b.getStateManager().getProperties();
                if (!props.isEmpty()) {
                    JsonObject pMap = new JsonObject();
                    for (Property<?> prop : props) {
                        JsonArray vals = new JsonArray();
                        for (Comparable<?> val : prop.getValues()) {
                            vals.add(propName(prop, val));
                        }
                        pMap.add(prop.getName(), vals);
                    }
                    o.add("properties", pMap);
                }
                results.add(o);
                if (results.size() >= limit) break;
            }
        }

        res.addProperty("count", results.size());
        res.add("entries", results);
        return res;
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static String propName(Property prop, Comparable val) {
        return prop.name(val);
    }

    private JsonObject handleStateMap() {
        JsonObject res = new JsonObject();
        res.addProperty("ok", true);
        JsonArray blocks = new JsonArray();
        for (Identifier id : Registries.BLOCK.getIds()) {
            if ("minecraft".equals(id.getNamespace())) continue;
            Block b = Registries.BLOCK.get(id);
            int minId = Integer.MAX_VALUE;
            int maxId = Integer.MIN_VALUE;
            for (BlockState st : b.getStateManager().getStates()) {
                int raw = Block.STATE_IDS.getRawId(st);
                if (raw >= 0) {
                    if (raw < minId) minId = raw;
                    if (raw > maxId) maxId = raw;
                }
            }
            if (minId <= maxId) {
                boolean solid = false;
                try {
                    solid = !b.getDefaultState().getCollisionShape(EmptyBlockView.INSTANCE, BlockPos.ORIGIN).isEmpty();
                } catch (Throwable ignored) {
                    solid = b.getDefaultState().isOpaque();
                }
                JsonObject bo = new JsonObject();
                bo.addProperty("rawBlockId", Registries.BLOCK.getRawId(b));
                bo.addProperty("id", id.toString());
                bo.addProperty("minStateId", minId);
                bo.addProperty("maxStateId", maxId);
                bo.addProperty("solid", solid);
                blocks.add(bo);
            }
        }

        JsonArray items = new JsonArray();
        for (Identifier id : Registries.ITEM.getIds()) {
            if ("minecraft".equals(id.getNamespace())) continue;
            Item it = Registries.ITEM.get(id);
            JsonObject io = new JsonObject();
            io.addProperty("rawId", Registries.ITEM.getRawId(it));
            io.addProperty("id", id.toString());
            io.addProperty("maxCount", it.getMaxCount());
            items.add(io);
        }

        res.add("moddedBlocks", blocks);
        res.add("moddedItems", items);
        return res;
    }

    // ==================== STATUS & SCREENSHOT ====================
    private JsonObject handleStatus() throws Exception {
        MinecraftClient client = MinecraftClient.getInstance();
        JsonObject root = new JsonObject();
        root.addProperty("ok", true);
        root.addProperty("modActive", true);
        root.addProperty("modVersion", "7.8.0");
        root.addProperty("ttsBackend", LocalTtsManager.getBackendStatus());
        int curBal = (client != null && client.world != null && client.player != null)
                ? ArenaContent.getPlayerMtrBalance(client.world.getScoreboard(), client.player) : 0;
        boolean hasCard = (client != null && client.player != null) && ArenaContent.playerHasOrmanKart(client.player);
        root.addProperty("mtrBalance", curBal);
        root.addProperty("hasOrmanKart", hasCard);
        root.addProperty("mtrLoaded", FabricLoader.getInstance().isModLoaded("mtr"));

        if (client == null || client.player == null || client.world == null) {
            root.addProperty("inWorld", false);
            return root;
        }

        IntegratedServer server = client.getServer();
        CompletableFuture<JsonObject> fut = new CompletableFuture<>();

        Runnable collectClient = () -> {
            try {
                ClientPlayerEntity p = client.player;
                if (p == null) {
                    root.addProperty("inWorld", false);
                    fut.complete(root);
                    return;
                }
                root.addProperty("inWorld", true);
                root.addProperty("lanOpen", server != null && server.isRemote());
                root.addProperty("lanPort", server != null ? server.getServerPort() : -1);
                root.addProperty("undoCount", UNDO_STACK.size());

                JsonObject pObj = new JsonObject();
                pObj.addProperty("name", p.getNameForScoreboard());
                pObj.addProperty("x", round2(p.getPos().x));
                pObj.addProperty("y", round2(p.getPos().y));
                pObj.addProperty("z", round2(p.getPos().z));
                pObj.addProperty("blockX", p.getBlockPos().getX());
                pObj.addProperty("blockY", p.getBlockPos().getY());
                pObj.addProperty("blockZ", p.getBlockPos().getZ());
                pObj.addProperty("yaw", round2(p.getYaw()));
                pObj.addProperty("pitch", round2(p.getPitch()));
                pObj.addProperty("health", round2(p.getHealth()));
                pObj.addProperty("food", p.getHungerManager().getFoodLevel());
                pObj.addProperty("dimension", client.world.getRegistryKey().getValue().toString());

                ItemStack main = p.getMainHandStack();
                ItemStack off = p.getOffHandStack();
                pObj.addProperty("mainHand", Registries.ITEM.getId(main.getItem()).toString());
                pObj.addProperty("mainHandCount", main.getCount());
                pObj.addProperty("offHand", Registries.ITEM.getId(off.getItem()).toString());

                JsonArray hotbar = new JsonArray();
                for (int i = 0; i < 9; i++) {
                    ItemStack st = p.getInventory().getStack(i);
                    if (!st.isEmpty()) {
                        JsonObject it = new JsonObject();
                        it.addProperty("slot", i);
                        it.addProperty("id", Registries.ITEM.getId(st.getItem()).toString());
                        it.addProperty("count", st.getCount());
                        hotbar.add(it);
                    }
                }
                pObj.add("hotbar", hotbar);
                root.add("player", pObj);

                HitResult hit = p.raycast(24.0, 0.0f, false);
                JsonObject target = new JsonObject();
                if (hit != null && hit.getType() == HitResult.Type.BLOCK && hit instanceof BlockHitResult bhr) {
                    BlockPos bp = bhr.getBlockPos();
                    BlockState bs = client.world.getBlockState(bp);
                    target.addProperty("hit", true);
                    target.addProperty("x", bp.getX());
                    target.addProperty("y", bp.getY());
                    target.addProperty("z", bp.getZ());
                    target.addProperty("side", bhr.getSide().getName());
                    target.addProperty("block", formatBlockStateString(bs));
                } else {
                    target.addProperty("hit", false);
                }
                root.add("targetBlock", target);
                root.add("nearbyEntities", new JsonArray());
                fut.complete(root);
            } catch (Throwable t) {
                root.addProperty("error", t.toString());
                fut.complete(root);
            }
        };

        client.execute(collectClient);
        return fut.get(4, TimeUnit.SECONDS);
    }

    private JsonObject handleWorldAudit(Map<String, String> q) {
        JsonObject err = new JsonObject();
        MinecraftClient client = MinecraftClient.getInstance();
        IntegratedServer server = client != null ? client.getServer() : null;
        if (server == null) {
            err.addProperty("ok", false);
            err.addProperty("error", "server_unavailable");
            return err;
        }
        int cx = parseIntSafe(q.get("x"), client.player != null ? client.player.getBlockX() : -27);
        int cz = parseIntSafe(q.get("z"), client.player != null ? client.player.getBlockZ() : 25);
        int radius = parseIntSafe(q.get("radius"), 24);
        boolean purgeRails = "1".equals(q.get("purge")) || "true".equalsIgnoreCase(q.get("purge"));

        CompletableFuture<JsonObject> fut = new CompletableFuture<>();
        server.execute(() -> {
            try {
                ServerWorld ow = server.getOverworld();
                int purged = 0;
                if (purgeRails && FabricLoader.getInstance().isModLoaded("mtr")) {
                    purged = WorldContextAnalyzer.purgeOrphanMtrRails(ow, MtrBridgeHelper.getOverworldSimulator());
                }
                JsonObject res = WorldContextAnalyzer.auditSurfaceSite(ow, cx, cz, radius);
                res.addProperty("purgedOrphanRailNodes", purged);
                fut.complete(res);
            } catch (Throwable t) {
                JsonObject ex = new JsonObject();
                ex.addProperty("ok", false);
                ex.addProperty("error", t.toString());
                fut.complete(ex);
            }
        });
        try {
            return fut.get(4, TimeUnit.SECONDS);
        } catch (Throwable t) {
            err.addProperty("ok", false);
            err.addProperty("error", t.toString());
            return err;
        }
    }

    private static int parseIntSafe(String s, int def) {
        if (s == null || s.isBlank()) return def;
        try {
            return Integer.parseInt(s.trim());
        } catch (Throwable ignored) {
            return def;
        }
    }

    private byte[] handleScreenshot() throws Exception {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.player == null || client.getFramebuffer() == null) return null;
        // v7.3.0 Zero-Lag Screenshot: ONLY copy raw NativeImage buffer on render thread (~1.5ms),
        // then run expensive PNG compression OFF-THREAD on this HTTP worker thread!
        CompletableFuture<NativeImage> fut = new CompletableFuture<>();
        client.execute(() -> {
            try {
                fut.complete(ScreenshotRecorder.takeScreenshot(client.getFramebuffer()));
            } catch (Throwable t) {
                fut.complete(null);
            }
        });
        NativeImage raw = fut.get(5, TimeUnit.SECONDS);
        if (raw == null) return null;
        try (NativeImage owned = raw) {
            return owned.getBytes();
        }
    }

    // ==================== ARENAAI FIRST-PERSON CAMERA EYE (ZERO FLICKER ON HOST MONITOR!) ====================
    private byte[] handleBotVision(Map<String, String> q) throws Exception {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.world == null || client.getFramebuffer() == null) return null;

        String botName = q.getOrDefault("bot", "ArenaAI");
        Float reqYaw = q.containsKey("yaw") ? Float.parseFloat(q.get("yaw")) : null;
        Float reqPitch = q.containsKey("pitch") ? Float.parseFloat(q.get("pitch")) : null;
        Double lookX = q.containsKey("lookX") ? Double.parseDouble(q.get("lookX")) : null;
        Double lookY = q.containsKey("lookY") ? Double.parseDouble(q.get("lookY")) : null;
        Double lookZ = q.containsKey("lookZ") ? Double.parseDouble(q.get("lookZ")) : null;

        // Also update server-side ArenaAI head orientation so ilkan physically sees ArenaAI looking there!
        IntegratedServer server = client.getServer();
        if (server != null && (reqYaw != null || lookX != null)) {
            server.execute(() -> {
                ServerPlayerEntity sp = getExactServerPlayer(server, botName);
                if (sp != null) {
                    float yw = reqYaw != null ? reqYaw : sp.getYaw();
                    float pt = reqPitch != null ? reqPitch : sp.getPitch();
                    if (lookX != null && lookY != null && lookZ != null) {
                        double dx = lookX - sp.getX();
                        double dy = lookY - (sp.getY() + sp.getStandingEyeHeight());
                        double dz = lookZ - sp.getZ();
                        double h = Math.sqrt(dx * dx + dz * dz);
                        yw = (float) (Math.toDegrees(Math.atan2(-dx, dz)));
                        pt = (float) (-Math.toDegrees(Math.atan2(dy, h)));
                    }
                    sp.setYaw(yw);
                    sp.setHeadYaw(yw);
                    sp.setBodyYaw(yw);
                    sp.setPitch(pt);
                }
            });
        }

        CompletableFuture<NativeImage> fut = new CompletableFuture<>();
        client.execute(() -> {
            Entity prevCam = client.getCameraEntity();
            try {
                AbstractClientPlayerEntity botEnt = null;
                for (AbstractClientPlayerEntity pe : client.world.getPlayers()) {
                    if (pe.getNameForScoreboard().equalsIgnoreCase(botName)) {
                        botEnt = pe;
                        break;
                    }
                }
                if (botEnt == null) {
                    fut.complete(null);
                    return;
                }

                float origYaw = botEnt.getYaw(), origPrevYaw = botEnt.prevYaw;
                float origHead = botEnt.headYaw, origPrevHead = botEnt.prevHeadYaw;
                float origPitch = botEnt.getPitch(), origPrevPitch = botEnt.prevPitch;

                float useYaw = origYaw;
                float usePitch = origPitch;
                if (lookX != null && lookY != null && lookZ != null) {
                    double dx = lookX - botEnt.getX();
                    double dy = lookY - (botEnt.getY() + botEnt.getStandingEyeHeight());
                    double dz = lookZ - botEnt.getZ();
                    double h = Math.sqrt(dx * dx + dz * dz);
                    useYaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
                    usePitch = (float) (-Math.toDegrees(Math.atan2(dy, h)));
                } else {
                    if (reqYaw != null) useYaw = reqYaw;
                    if (reqPitch != null) usePitch = reqPitch;
                }

                botEnt.setYaw(useYaw);
                botEnt.prevYaw = useYaw;
                botEnt.headYaw = useYaw;
                botEnt.prevHeadYaw = useYaw;
                botEnt.setPitch(usePitch);
                botEnt.prevPitch = usePitch;

                client.setCameraEntity(botEnt);
                client.getFramebuffer().beginWrite(true);
                client.gameRenderer.renderWorld(1.0f, System.nanoTime(), new MatrixStack());

                fut.complete(ScreenshotRecorder.takeScreenshot(client.getFramebuffer()));
            } catch (Throwable t) {
                fut.complete(null);
            } finally {
                if (prevCam != null) {
                    client.setCameraEntity(prevCam);
                }
            }
        });
        NativeImage raw = fut.get(5, TimeUnit.SECONDS);
        if (raw == null) return null;
        try (NativeImage owned = raw) {
            return owned.getBytes();
        }
    }

    // ==================== TRUE PLAYER RIGHT-CLICK PLACEMENT & BREAKING ENGINE ====================
    private static ServerPlayerEntity getExactServerPlayer(IntegratedServer server, String name) {
        for (ServerPlayerEntity sp : server.getPlayerManager().getPlayerList()) {
            if (sp.getNameForScoreboard().equalsIgnoreCase(name)) return sp;
        }
        return null;
    }

    private static float yawFromLookString(String look, float fallback) {
        if (look == null || look.isEmpty()) return fallback;
        switch (look.toLowerCase()) {
            case "north": return 180.0f;
            case "south": return 0.0f;
            case "west":  return 90.0f;
            case "east":  return -90.0f;
            default:
                try { return Float.parseFloat(look); } catch (Exception e) { return fallback; }
        }
    }

    private JsonObject handlePlaceReal(String body) throws Exception {
        JsonObject req = JsonParser.parseString(body).getAsJsonObject();
        JsonArray steps = req.has("steps") ? req.getAsJsonArray("steps") : new JsonArray();
        String actorName = req.has("actor") ? req.get("actor").getAsString() : "ArenaAI";
        boolean recordUndo = !req.has("recordUndo") || req.get("recordUndo").getAsBoolean();

        MinecraftClient client = MinecraftClient.getInstance();
        JsonObject res = new JsonObject();
        if (client == null || client.getServer() == null) {
            res.addProperty("ok", false);
            res.addProperty("error", "not_in_world");
            return res;
        }
        IntegratedServer server = client.getServer();
        CompletableFuture<JsonObject> fut = new CompletableFuture<>();

        server.execute(() -> {
            try {
                ServerPlayerEntity actor = getExactServerPlayer(server, actorName);
                if (actor == null) actor = getServerPlayer(server, actorName);
                if (actor == null) {
                    res.addProperty("ok", false);
                    res.addProperty("error", "actor_not_found");
                    fut.complete(res);
                    return;
                }
                ServerWorld sw = actor.getServerWorld();
                Map<BlockPos, BlockState> prior = new LinkedHashMap<>();
                JsonArray results = new JsonArray();
                JsonArray failed = new JsonArray();
                int placedCount = 0;

                boolean wasSneaking = actor.isSneaking();

                for (JsonElement el : steps) {
                    JsonObject st = el.getAsJsonObject();
                    int tx = st.get("x").getAsInt();
                    int ty = st.get("y").getAsInt();
                    int tz = st.get("z").getAsInt();
                    BlockPos targetPos = new BlockPos(tx, ty, tz);

                    String itemStr = st.get("item").getAsString();
                    if (!itemStr.contains(":")) itemStr = "minecraft:" + itemStr;
                    Identifier iid = new Identifier(itemStr);
                    if (!Registries.ITEM.containsId(iid)) {
                        JsonObject f = new JsonObject();
                        f.addProperty("x", tx); f.addProperty("y", ty); f.addProperty("z", tz);
                        f.addProperty("error", "unknown_item:" + itemStr);
                        failed.add(f);
                        continue;
                    }
                    Item item = Registries.ITEM.get(iid);

                    boolean replaceExisting = st.has("replace") && st.get("replace").getAsBoolean();
                    BlockState existingTarget = sw.getBlockState(targetPos);
                    if (!existingTarget.isAir() && !existingTarget.isReplaceable()) {
                        if (replaceExisting) {
                            prior.putIfAbsent(targetPos.toImmutable(), existingTarget);
                            sw.setBlockState(targetPos, Blocks.AIR.getDefaultState(), 3);
                        } else {
                            continue;
                        }
                    }

                    // Determine player look direction (crucial for stairs, doors, chests, MTR platforms/PIDS/ticket barriers!)
                    String lookStr = st.has("look") ? st.get("look").getAsString() : "";
                    String half = st.has("half") ? st.get("half").getAsString().toLowerCase() : "bottom";
                    boolean sneak = !st.has("sneak") || st.get("sneak").getAsBoolean();

                    float yaw = yawFromLookString(lookStr, actor.getYaw());
                    float pitch = "top".equals(half) ? -35.0f : 25.0f;
                    if (st.has("pitch")) pitch = st.get("pitch").getAsFloat();

                    // Move ArenaAI cleanly 2.5 blocks behind its look vector so ArenaAI's hitbox NEVER overlaps targetPos
                    // AND ilkan physically sees ArenaAI standing right beside the block looking straight at it!
                    double rad = Math.toRadians(yaw);
                    double lookDx = -Math.sin(rad);
                    double lookDz = Math.cos(rad);
                    double standX = (tx + 0.5) - lookDx * 2.4;
                    double standZ = (tz + 0.5) - lookDz * 2.4;
                    double standY = ty;
                    // Keep ArenaAI standing on nearby solid ground if within 2 blocks vertically
                    for (int dy = 1; dy >= -2; dy--) {
                        BlockPos gp = BlockPos.ofFloored(standX, ty + dy - 1, standZ);
                        BlockPos fp = gp.up();
                        if (!sw.getBlockState(gp).isAir() && sw.getBlockState(fp).isAir() && sw.getBlockState(fp.up()).isAir()) {
                            standY = fp.getY();
                            break;
                        }
                    }
                    if (actor.getNameForScoreboard().equalsIgnoreCase("ArenaAI")) {
                        actor.requestTeleport(standX, standY, standZ);
                    }
                    actor.setYaw(yaw);
                    actor.setHeadYaw(yaw);
                    actor.setBodyYaw(yaw);
                    actor.setPitch(pitch);
                    actor.setSneaking(sneak);

                    // Find real support block & face to right-click against (just like a real player!)
                    BlockPos clickPos = null;
                    Direction clickFace = null;

                    if (st.has("against")) {
                        Direction againstDir = Direction.byName(st.get("against").getAsString().toLowerCase());
                        if (againstDir != null) {
                            BlockPos cand = targetPos.offset(againstDir);
                            if (!sw.getBlockState(cand).isAir()) {
                                clickPos = cand;
                                clickFace = againstDir.getOpposite();
                            }
                        }
                    }

                    if (clickPos == null) {
                        Direction[] searchOrder = "top".equals(half)
                                ? new Direction[]{Direction.UP, Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST, Direction.DOWN}
                                : new Direction[]{Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST, Direction.UP};
                        for (Direction d : searchOrder) {
                            BlockPos np = targetPos.offset(d);
                            BlockState nbs = sw.getBlockState(np);
                            if (!nbs.isAir() && !nbs.isReplaceable()) {
                                clickPos = np;
                                clickFace = d.getOpposite();
                                break;
                            }
                        }
                    }

                    if (clickPos == null) {
                        JsonObject f = new JsonObject();
                        f.addProperty("x", tx); f.addProperty("y", ty); f.addProperty("z", tz);
                        f.addProperty("item", itemStr);
                        f.addProperty("error", "no_adjacent_support_block_to_click");
                        failed.add(f);
                        continue;
                    }

                    // Snapshot target + 6 neighbors (captures multi-block doors, beds, MTR PIDS, MTR ticket machines!)
                    prior.putIfAbsent(targetPos.toImmutable(), sw.getBlockState(targetPos));
                    for (Direction d : Direction.values()) {
                        BlockPos np = targetPos.offset(d);
                        prior.putIfAbsent(np.toImmutable(), sw.getBlockState(np));
                    }

                    // Compute exact hit vector on clickFace (controls slab/stair top vs bottom!)
                    double hitX = clickPos.getX() + 0.5 + clickFace.getOffsetX() * 0.5;
                    double hitY = clickPos.getY() + 0.5 + clickFace.getOffsetY() * 0.5;
                    double hitZ = clickPos.getZ() + 0.5 + clickFace.getOffsetZ() * 0.5;
                    if (clickFace.getAxis().isHorizontal()) {
                        hitY = targetPos.getY() + ("top".equals(half) ? 0.82 : 0.18);
                    }

                    ItemStack stack = new ItemStack(item, 64);
                    actor.setStackInHand(Hand.MAIN_HAND, stack);
                    actor.swingHand(Hand.MAIN_HAND, true);

                    BlockHitResult bhr = new BlockHitResult(new Vec3d(hitX, hitY, hitZ), clickFace, clickPos, false);
                    ActionResult ar = actor.interactionManager.interactBlock(actor, sw, stack, Hand.MAIN_HAND, bhr);

                    BlockState afterState = sw.getBlockState(targetPos);
                    if (!afterState.isAir()) {
                        placedCount++;
                        if (results.size() < 40) {
                            JsonObject rObj = new JsonObject();
                            rObj.addProperty("x", tx); rObj.addProperty("y", ty); rObj.addProperty("z", tz);
                            rObj.addProperty("state", formatBlockStateString(afterState));
                            results.add(rObj);
                        }
                    } else {
                        if (failed.size() < 25) {
                            JsonObject f = new JsonObject();
                            f.addProperty("x", tx); f.addProperty("y", ty); f.addProperty("z", tz);
                            f.addProperty("item", itemStr);
                            f.addProperty("actionResult", ar.name());
                            f.addProperty("error", "placement_rejected_by_game");
                            failed.add(f);
                        }
                    }
                }

                actor.setSneaking(wasSneaking);

                if (recordUndo && !prior.isEmpty()) {
                    while (UNDO_STACK.size() >= 30) UNDO_STACK.removeLast();
                    UNDO_STACK.push(new WorldSnapshot(sw, prior));
                }

                res.addProperty("ok", true);
                res.addProperty("placedCount", placedCount);
                res.addProperty("undoCount", UNDO_STACK.size());
                res.add("placedSample", results);
                res.add("failed", failed);
                fut.complete(res);
            } catch (Throwable t) {
                res.addProperty("ok", false);
                res.addProperty("error", t.toString());
                fut.complete(res);
            }
        });
        return fut.get(20, TimeUnit.SECONDS);
    }

    private JsonObject handleBreakReal(String body) throws Exception {
        JsonObject req = JsonParser.parseString(body).getAsJsonObject();
        String actorName = req.has("actor") ? req.get("actor").getAsString() : "ArenaAI";
        boolean leavesOnly = req.has("leavesOnly") && req.get("leavesOnly").getAsBoolean();

        MinecraftClient client = MinecraftClient.getInstance();
        JsonObject res = new JsonObject();
        if (client == null || client.getServer() == null) {
            res.addProperty("ok", false);
            res.addProperty("error", "not_in_world");
            return res;
        }
        IntegratedServer server = client.getServer();
        CompletableFuture<JsonObject> fut = new CompletableFuture<>();

        server.execute(() -> {
            try {
                ServerPlayerEntity actor = getExactServerPlayer(server, actorName);
                if (actor == null) actor = getServerPlayer(server, actorName);
                ServerWorld sw = actor.getServerWorld();
                Map<BlockPos, BlockState> prior = new LinkedHashMap<>();
                List<BlockPos> targets = new ArrayList<>();

                if (req.has("positions")) {
                    for (JsonElement el : req.getAsJsonArray("positions")) {
                        JsonObject o = el.getAsJsonObject();
                        targets.add(new BlockPos(o.get("x").getAsInt(), o.get("y").getAsInt(), o.get("z").getAsInt()));
                    }
                } else if (req.has("x1")) {
                    int minX = Math.min(req.get("x1").getAsInt(), req.get("x2").getAsInt());
                    int maxX = Math.max(req.get("x1").getAsInt(), req.get("x2").getAsInt());
                    int minY = Math.min(req.get("y1").getAsInt(), req.get("y2").getAsInt());
                    int maxY = Math.max(req.get("y1").getAsInt(), req.get("y2").getAsInt());
                    int minZ = Math.min(req.get("z1").getAsInt(), req.get("z2").getAsInt());
                    int maxZ = Math.max(req.get("z1").getAsInt(), req.get("z2").getAsInt());
                    for (int x = minX; x <= maxX; x++) {
                        for (int y = minY; y <= maxY; y++) {
                            for (int z = minZ; z <= maxZ; z++) {
                                targets.add(new BlockPos(x, y, z));
                            }
                        }
                    }
                }

                int broken = 0;
                for (BlockPos bp : targets) {
                    BlockState bs = sw.getBlockState(bp);
                    if (bs.isAir()) continue;
                    if (leavesOnly && !(bs.getBlock() instanceof LeavesBlock || bs.getBlock() instanceof VineBlock || bs.getBlock() instanceof PlantBlock)) {
                        continue;
                    }
                    prior.putIfAbsent(bp.toImmutable(), bs);
                    actor.swingHand(Hand.MAIN_HAND, true);
                    sw.breakBlock(bp, false, actor);
                    broken++;
                }

                if (!prior.isEmpty()) {
                    while (UNDO_STACK.size() >= 30) UNDO_STACK.removeLast();
                    UNDO_STACK.push(new WorldSnapshot(sw, prior));
                }

                res.addProperty("ok", true);
                res.addProperty("brokenCount", broken);
                fut.complete(res);
            } catch (Throwable t) {
                res.addProperty("ok", false);
                res.addProperty("error", t.toString());
                fut.complete(res);
            }
        });
        return fut.get(15, TimeUnit.SECONDS);
    }

    // ==================== NATIVE MINECRAFT .NBT STRUCTURE TEMPLATE ENGINE ====================
    private JsonObject handleTemplates(Map<String, String> q) throws Exception {
        String filter = q.getOrDefault("q", "").toLowerCase();
        int limit = Math.min(200, Math.max(1, parseInt(q.get("limit"), 80)));
        MinecraftClient client = MinecraftClient.getInstance();
        JsonObject res = new JsonObject();
        if (client == null || client.getServer() == null) {
            res.addProperty("ok", false);
            res.addProperty("error", "not_in_world");
            return res;
        }
        IntegratedServer server = client.getServer();
        CompletableFuture<JsonObject> fut = new CompletableFuture<>();
        server.execute(() -> {
            try {
                JsonArray arr = new JsonArray();
                server.getStructureTemplateManager().streamTemplates()
                        .filter(id -> filter.isEmpty() || id.toString().toLowerCase().contains(filter))
                        .limit(limit)
                        .forEach(id -> arr.add(id.toString()));
                res.addProperty("ok", true);
                res.addProperty("count", arr.size());
                res.add("templates", arr);
                fut.complete(res);
            } catch (Throwable t) {
                res.addProperty("ok", false);
                res.addProperty("error", t.toString());
                fut.complete(res);
            }
        });
        return fut.get(8, TimeUnit.SECONDS);
    }

    private JsonObject handlePlaceNbt(String body) throws Exception {
        JsonObject req = JsonParser.parseString(body).getAsJsonObject();
        int x = req.get("x").getAsInt();
        int y = req.get("y").getAsInt();
        int z = req.get("z").getAsInt();
        String rotStr = req.has("rotation") ? req.get("rotation").getAsString().toUpperCase() : "NONE";
        boolean groundFoundation = !req.has("groundFoundation") || req.get("groundFoundation").getAsBoolean();

        MinecraftClient client = MinecraftClient.getInstance();
        JsonObject res = new JsonObject();
        if (client == null || client.getServer() == null || client.player == null) {
            res.addProperty("ok", false);
            res.addProperty("error", "not_in_world");
            return res;
        }
        IntegratedServer server = client.getServer();
        String pName = client.player.getNameForScoreboard();
        CompletableFuture<JsonObject> fut = new CompletableFuture<>();

        server.execute(() -> {
            try {
                ServerWorld sw = getPlayerServerWorld(server, pName);
                StructureTemplate tpl = null;

                if (req.has("b64") && !req.get("b64").getAsString().isEmpty()) {
                    byte[] raw = Base64.getDecoder().decode(req.get("b64").getAsString());
                    NbtCompound nbt = NbtIo.readCompressed(new ByteArrayInputStream(raw), NbtSizeTracker.ofUnlimitedBytes());
                    tpl = sw.getStructureTemplateManager().createTemplate(nbt);
                } else if (req.has("id")) {
                    String idStr = req.get("id").getAsString();
                    if (!idStr.contains(":")) idStr = "minecraft:" + idStr;
                    Optional<StructureTemplate> opt = sw.getStructureTemplateManager().getTemplate(new Identifier(idStr));
                    if (opt.isPresent()) tpl = opt.get();
                }

                if (tpl == null) {
                    res.addProperty("ok", false);
                    res.addProperty("error", "template_not_found");
                    fut.complete(res);
                    return;
                }

                BlockRotation rot = BlockRotation.NONE;
                if ("90".equals(rotStr) || "CLOCKWISE_90".equals(rotStr)) rot = BlockRotation.CLOCKWISE_90;
                else if ("180".equals(rotStr) || "CLOCKWISE_180".equals(rotStr)) rot = BlockRotation.CLOCKWISE_180;
                else if ("270".equals(rotStr) || "COUNTERCLOCKWISE_90".equals(rotStr)) rot = BlockRotation.COUNTERCLOCKWISE_90;

                StructurePlacementData placement = new StructurePlacementData()
                        .setRotation(rot)
                        .setMirror(BlockMirror.NONE)
                        .setIgnoreEntities(false);

                Vec3i sz = tpl.getRotatedSize(rot);
                BlockPos origin = new BlockPos(x, y, z);

                // Record undo snapshot across bounding box before placing template!
                Map<BlockPos, BlockState> prior = new LinkedHashMap<>();
                int minX = Math.min(x, x + sz.getX()), maxX = Math.max(x, x + sz.getX());
                int minZ = Math.min(z, z + sz.getZ()), maxZ = Math.max(z, z + sz.getZ());
                for (int bx = minX - 1; bx <= maxX + 1; bx++) {
                    for (int bz = minZ - 1; bz <= maxZ + 1; bz++) {
                        for (int by = Math.max(sw.getBottomY(), y - 12); by <= y + sz.getY() + 2; by++) {
                            BlockPos p = new BlockPos(bx, by, bz);
                            prior.put(p, sw.getBlockState(p));
                        }
                    }
                }

                boolean ok = tpl.place(sw, origin, origin, placement, sw.getRandom(), 2);

                // Remove any structure_block or jigsaw markers inside placed template
                for (int bx = minX; bx <= maxX; bx++) {
                    for (int bz = minZ; bz <= maxZ; bz++) {
                        for (int by = y; by <= y + sz.getY(); by++) {
                            BlockPos p = new BlockPos(bx, by, bz);
                            Block b = sw.getBlockState(p).getBlock();
                            if (b == Blocks.JIGSAW || b == Blocks.STRUCTURE_BLOCK || b == Blocks.STRUCTURE_VOID) {
                                sw.setBlockState(p, Blocks.AIR.getDefaultState(), 3);
                            }
                        }
                    }
                }

                // Auto-ground solid bottom blocks of template downward so slopes never leave corners floating!
                if (groundFoundation) {
                    for (int bx = minX; bx <= maxX; bx++) {
                        for (int bz = minZ; bz <= maxZ; bz++) {
                            BlockPos bottomPos = new BlockPos(bx, y, bz);
                            BlockState bottomBs = sw.getBlockState(bottomPos);
                            if (isGroundTerrain(sw, bottomPos, bottomBs)) {
                                BlockState fillMat = Blocks.COBBLESTONE.getDefaultState();
                                BlockPos.Mutable cur = bottomPos.down().mutableCopy();
                                int steps = 0;
                                while (cur.getY() > sw.getBottomY() && steps < 16 && !isGroundTerrain(sw, cur, sw.getBlockState(cur))) {
                                    sw.setBlockState(cur, fillMat, 3);
                                    cur.move(Direction.DOWN);
                                    steps++;
                                }
                            }
                        }
                    }
                }

                while (UNDO_STACK.size() >= 30) UNDO_STACK.removeLast();
                UNDO_STACK.push(new WorldSnapshot(sw, prior));

                res.addProperty("ok", ok);
                res.addProperty("sizeX", sz.getX());
                res.addProperty("sizeY", sz.getY());
                res.addProperty("sizeZ", sz.getZ());
                fut.complete(res);
            } catch (Throwable t) {
                res.addProperty("ok", false);
                res.addProperty("error", t.toString());
                fut.complete(res);
            }
        });
        return fut.get(20, TimeUnit.SECONDS);
    }

    private JsonObject handleSaveNbt(String body) throws Exception {
        JsonObject req = JsonParser.parseString(body).getAsJsonObject();
        int x1 = req.get("x1").getAsInt(), y1 = req.get("y1").getAsInt(), z1 = req.get("z1").getAsInt();
        int x2 = req.get("x2").getAsInt(), y2 = req.get("y2").getAsInt(), z2 = req.get("z2").getAsInt();
        int minX = Math.min(x1, x2), minY = Math.min(y1, y2), minZ = Math.min(z1, z2);
        int sizeX = Math.abs(x2 - x1) + 1, sizeY = Math.abs(y2 - y1) + 1, sizeZ = Math.abs(z2 - z1) + 1;

        MinecraftClient client = MinecraftClient.getInstance();
        JsonObject res = new JsonObject();
        if (client == null || client.getServer() == null || client.player == null) {
            res.addProperty("ok", false);
            res.addProperty("error", "not_in_world");
            return res;
        }
        IntegratedServer server = client.getServer();
        String pName = client.player.getNameForScoreboard();
        CompletableFuture<JsonObject> fut = new CompletableFuture<>();
        server.execute(() -> {
            try {
                ServerWorld sw = getPlayerServerWorld(server, pName);
                StructureTemplate tpl = new StructureTemplate();
                tpl.saveFromWorld(sw, new BlockPos(minX, minY, minZ), new Vec3i(sizeX, sizeY, sizeZ), false, Blocks.STRUCTURE_VOID);
                NbtCompound nbt = tpl.writeNbt(new NbtCompound());
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                NbtIo.writeCompressed(nbt, bos);
                res.addProperty("ok", true);
                res.addProperty("sizeX", sizeX);
                res.addProperty("sizeY", sizeY);
                res.addProperty("sizeZ", sizeZ);
                res.addProperty("b64", Base64.getEncoder().encodeToString(bos.toByteArray()));
                fut.complete(res);
            } catch (Throwable t) {
                res.addProperty("ok", false);
                res.addProperty("error", t.toString());
                fut.complete(res);
            }
        });
        return fut.get(15, TimeUnit.SECONDS);
    }

    // ==================== 2D + CANOPY SCAN & TRUE 3D VOXEL SCAN ====================
    private JsonObject handleScan(Map<String, String> q) throws Exception {
        MinecraftClient client = MinecraftClient.getInstance();
        JsonObject res = new JsonObject();
        if (client == null || client.getServer() == null || client.player == null) {
            res.addProperty("ok", false);
            res.addProperty("error", "not_in_singleplayer_world");
            return res;
        }
        IntegratedServer server = client.getServer();
        String pName = client.player.getNameForScoreboard();
        int cx = parseInt(q.get("x"), client.player.getBlockPos().getX());
        int cz = parseInt(q.get("z"), client.player.getBlockPos().getZ());
        int r = Math.min(36, Math.max(1, parseInt(q.get("r"), 12)));
        int step = Math.max(1, parseInt(q.get("step"), 1));

        CompletableFuture<JsonObject> fut = new CompletableFuture<>();
        server.execute(() -> {
            try {
                ServerWorld sw = getPlayerServerWorld(server, pName);
                res.addProperty("ok", true);
                res.addProperty("cx", cx);
                res.addProperty("cz", cz);
                res.addProperty("r", r);
                res.addProperty("step", step);
                JsonArray rows = new JsonArray();
                for (int dz = -r; dz <= r; dz += step) {
                    JsonArray row = new JsonArray();
                    for (int dx = -r; dx <= r; dx += step) {
                        int x = cx + dx;
                        int z = cz + dz;
                        int topY = sw.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z) - 1;
                        int canopyY = sw.getTopY(Heightmap.Type.MOTION_BLOCKING, x, z) - 1;
                        BlockState bs = sw.getBlockState(new BlockPos(x, topY, z));
                        Identifier bid = Registries.BLOCK.getId(bs.getBlock());
                        JsonObject cell = new JsonObject();
                        cell.addProperty("x", x);
                        cell.addProperty("y", topY);
                        if (canopyY > topY) cell.addProperty("canopyY", canopyY);
                        cell.addProperty("z", z);
                        cell.addProperty("b", "minecraft".equals(bid.getNamespace()) ? bid.getPath() : bid.toString());
                        row.add(cell);
                    }
                    rows.add(row);
                }
                res.add("grid", rows);
                fut.complete(res);
            } catch (Throwable t) {
                res.addProperty("ok", false);
                res.addProperty("error", t.toString());
                fut.complete(res);
            }
        });
        return fut.get(6, TimeUnit.SECONDS);
    }

    private JsonObject handleScan3d(Map<String, String> q) throws Exception {
        MinecraftClient client = MinecraftClient.getInstance();
        JsonObject res = new JsonObject();
        if (client == null || client.getServer() == null || client.player == null) {
            res.addProperty("ok", false);
            res.addProperty("error", "not_in_singleplayer_world");
            return res;
        }
        IntegratedServer server = client.getServer();
        String pName = client.player.getNameForScoreboard();
        BlockPos pp = client.player.getBlockPos();

        int x1 = parseInt(q.get("x1"), pp.getX() - 8);
        int y1 = parseInt(q.get("y1"), pp.getY() - 4);
        int z1 = parseInt(q.get("z1"), pp.getZ() - 8);
        int x2 = parseInt(q.get("x2"), pp.getX() + 8);
        int y2 = parseInt(q.get("y2"), pp.getY() + 12);
        int z2 = parseInt(q.get("z2"), pp.getZ() + 8);

        int minX = Math.min(x1, x2), maxX = Math.min(minX + 48, Math.max(x1, x2));
        int minY = Math.min(y1, y2), maxY = Math.min(minY + 48, Math.max(y1, y2));
        int minZ = Math.min(z1, z2), maxZ = Math.min(minZ + 48, Math.max(z1, z2));

        CompletableFuture<JsonObject> fut = new CompletableFuture<>();
        server.execute(() -> {
            try {
                ServerWorld sw = getPlayerServerWorld(server, pName);
                Map<String, Integer> paletteIndex = new LinkedHashMap<>();
                JsonArray palette = new JsonArray();
                JsonArray voxels = new JsonArray();

                BlockPos.Mutable mpos = new BlockPos.Mutable();
                for (int y = minY; y <= maxY; y++) {
                    for (int x = minX; x <= maxX; x++) {
                        for (int z = minZ; z <= maxZ; z++) {
                            mpos.set(x, y, z);
                            BlockState bs = sw.getBlockState(mpos);
                            if (bs.isAir()) continue;
                            String spec = formatBlockStateString(bs);
                            Integer idx = paletteIndex.get(spec);
                            if (idx == null) {
                                idx = palette.size();
                                paletteIndex.put(spec, idx);
                                palette.add(spec);
                            }
                            JsonArray v = new JsonArray();
                            v.add(x);
                            v.add(y);
                            v.add(z);
                            v.add(idx);
                            voxels.add(v);
                        }
                    }
                }

                res.addProperty("ok", true);
                res.addProperty("minX", minX); res.addProperty("maxX", maxX);
                res.addProperty("minY", minY); res.addProperty("maxY", maxY);
                res.addProperty("minZ", minZ); res.addProperty("maxZ", maxZ);
                res.add("palette", palette);
                res.add("voxels", voxels);
                fut.complete(res);
            } catch (Throwable t) {
                res.addProperty("ok", false);
                res.addProperty("error", t.toString());
                fut.complete(res);
            }
        });
        return fut.get(8, TimeUnit.SECONDS);
    }

    // ==================== PHYSICS-VERIFIED ZERO-FLOAT BUILD ENGINE ====================
    private static int classifyPass(BlockState st, String rawSpec) {
        Block b = st.getBlock();
        String lower = rawSpec.toLowerCase();
        if (b instanceof LanternBlock && st.contains(LanternBlock.HANGING) && st.get(LanternBlock.HANGING)) {
            return 3; // Hanging from ceiling -> top-down after ceiling & chains!
        }
        if (lower.contains("chain") || lower.contains("weeping_vines") || lower.contains("cave_vines") || lower.contains("hanging_sign") || lower.contains("pids")) {
            return 3;
        }
        if (b instanceof LanternBlock || b instanceof TorchBlock || b instanceof WallTorchBlock
                || b instanceof DoorBlock || b instanceof BedBlock || b instanceof SignBlock
                || b instanceof WallSignBlock || b instanceof LecternBlock || b instanceof CarpetBlock
                || b instanceof PlantBlock || b instanceof VineBlock || b instanceof CampfireBlock
                || lower.contains("rail") || lower.contains("button") || lower.contains("lever")
                || lower.contains("pressure_plate") || lower.contains("banner") || lower.contains("ticket_barrier")) {
            return 2; // Standing/wall attachment -> bottom-up after walls & floors!
        }
        return 1; // Solid / structural
    }

    private static boolean isGroundTerrain(ServerWorld sw, BlockPos pos, BlockState bs) {
        if (bs.isAir() || !bs.getFluidState().isEmpty()) return false;
        Block b = bs.getBlock();
        if (b instanceof LeavesBlock || b instanceof PlantBlock || b instanceof VineBlock || b instanceof CarpetBlock || b instanceof TorchBlock) {
            return false;
        }
        String path = Registries.BLOCK.getId(b).getPath();
        if (path.contains("snow") && !path.equals("snow_block")) return false;
        return !bs.getCollisionShape(sw, pos).isEmpty();
    }

    private JsonObject handleBuild(String body) throws Exception {
        JsonObject req = JsonParser.parseString(body).getAsJsonObject();
        JsonArray ops = req.has("ops") ? req.getAsJsonArray("ops") : new JsonArray();
        boolean recordUndo = !req.has("recordUndo") || req.get("recordUndo").getAsBoolean();
        boolean strictPhysics = !req.has("strictPhysics") || req.get("strictPhysics").getAsBoolean();
        boolean autoConnect = !req.has("autoConnect") || req.get("autoConnect").getAsBoolean();
        boolean cleanFloating = !req.has("cleanFloating") || req.get("cleanFloating").getAsBoolean();

        MinecraftClient client = MinecraftClient.getInstance();
        JsonObject res = new JsonObject();
        if (client == null || client.getServer() == null || client.player == null) {
            res.addProperty("ok", false);
            res.addProperty("error", "not_in_world");
            return res;
        }
        IntegratedServer server = client.getServer();
        String pName = client.player.getNameForScoreboard();
        CompletableFuture<JsonObject> fut = new CompletableFuture<>();

        server.execute(() -> {
            try {
                ServerWorld sw = getPlayerServerWorld(server, pName);
                Map<BlockPos, BlockState> prior = new LinkedHashMap<>();
                Map<BlockPos, PlannedBlock> plannedMap = new LinkedHashMap<>();
                List<PlannedBlock> foundations = new ArrayList<>();
                JsonArray errors = new JsonArray();
                JsonArray physicsRejected = new JsonArray();

                int bMinX = Integer.MAX_VALUE, bMaxX = Integer.MIN_VALUE;
                int bMinY = Integer.MAX_VALUE, bMaxY = Integer.MIN_VALUE;
                int bMinZ = Integer.MAX_VALUE, bMaxZ = Integer.MIN_VALUE;

                for (JsonElement el : ops) {
                    JsonObject opObj = el.getAsJsonObject();
                    String op = opObj.has("op") ? opObj.get("op").getAsString() : "set";
                    String blockStr = opObj.has("block") ? opObj.get("block").getAsString() : "minecraft:stone";
                    if (!blockStr.contains(":")) blockStr = "minecraft:" + blockStr;

                    BlockState state;
                    try {
                        state = BlockArgumentParser.block(Registries.BLOCK.getReadOnlyWrapper(), blockStr, false).blockState();
                    } catch (Throwable pe) {
                        if (errors.size() < 15) errors.add("Invalid block '" + blockStr + "': " + pe.getMessage());
                        continue;
                    }

                    boolean onlyAir = opObj.has("onlyAir") && opObj.get("onlyAir").getAsBoolean();
                    boolean hollow = opObj.has("hollow") && opObj.get("hollow").getAsBoolean();
                    int pass = classifyPass(state, blockStr);

                    if ("foundation".equals(op)) {
                        int x = opObj.get("x").getAsInt();
                        int y = opObj.get("y").getAsInt();
                        int z = opObj.get("z").getAsInt();
                        foundations.add(new PlannedBlock(new BlockPos(x, y, z), state, blockStr, onlyAir, 0));
                        continue;
                    }

                    List<BlockPos> targets = new ArrayList<>();
                    if ("set".equals(op)) {
                        targets.add(new BlockPos(opObj.get("x").getAsInt(), opObj.get("y").getAsInt(), opObj.get("z").getAsInt()));
                    } else if ("fill".equals(op)) {
                        int x1 = opObj.get("x1").getAsInt(), y1 = opObj.get("y1").getAsInt(), z1 = opObj.get("z1").getAsInt();
                        int x2 = opObj.get("x2").getAsInt(), y2 = opObj.get("y2").getAsInt(), z2 = opObj.get("z2").getAsInt();
                        int minX = Math.min(x1, x2), maxX = Math.max(x1, x2);
                        int minY = Math.min(y1, y2), maxY = Math.max(y1, y2);
                        int minZ = Math.min(z1, z2), maxZ = Math.max(z1, z2);
                        for (int x = minX; x <= maxX; x++) {
                            for (int y = minY; y <= maxY; y++) {
                                for (int z = minZ; z <= maxZ; z++) {
                                    if (hollow && x > minX && x < maxX && y > minY && y < maxY && z > minZ && z < maxZ) continue;
                                    targets.add(new BlockPos(x, y, z));
                                }
                            }
                        }
                    } else if ("cylinder".equals(op)) {
                        int cx = opObj.get("cx").getAsInt(), baseY = opObj.get("y").getAsInt(), cz = opObj.get("cz").getAsInt();
                        int radius = opObj.get("radius").getAsInt();
                        int height = opObj.has("height") ? opObj.get("height").getAsInt() : 1;
                        double rSq = (radius + 0.35) * (radius + 0.35);
                        double innerSq = (radius - 0.65) * (radius - 0.65);
                        for (int dy = 0; dy < height; dy++) {
                            for (int dx = -radius; dx <= radius; dx++) {
                                for (int dz = -radius; dz <= radius; dz++) {
                                    double d = dx * dx + dz * dz;
                                    if (d <= rSq && (!hollow || d >= innerSq)) {
                                        targets.add(new BlockPos(cx + dx, baseY + dy, cz + dz));
                                    }
                                }
                            }
                        }
                    } else if ("sphere".equals(op)) {
                        int cx = opObj.get("cx").getAsInt(), cy = opObj.get("cy").getAsInt(), cz = opObj.get("cz").getAsInt();
                        int radius = opObj.get("radius").getAsInt();
                        double rSq = (radius + 0.35) * (radius + 0.35);
                        double innerSq = (radius - 0.65) * (radius - 0.65);
                        for (int dx = -radius; dx <= radius; dx++) {
                            for (int dy = -radius; dy <= radius; dy++) {
                                for (int dz = -radius; dz <= radius; dz++) {
                                    double d = dx * dx + dy * dy + dz * dz;
                                    if (d <= rSq && (!hollow || d >= innerSq)) {
                                        targets.add(new BlockPos(cx + dx, cy + dy, cz + dz));
                                    }
                                }
                            }
                        }
                    } else if ("line".equals(op)) {
                        int x1 = opObj.get("x1").getAsInt(), y1 = opObj.get("y1").getAsInt(), z1 = opObj.get("z1").getAsInt();
                        int x2 = opObj.get("x2").getAsInt(), y2 = opObj.get("y2").getAsInt(), z2 = opObj.get("z2").getAsInt();
                        int steps = Math.max(1, Math.max(Math.abs(x2 - x1), Math.max(Math.abs(y2 - y1), Math.abs(z2 - z1))));
                        for (int i = 0; i <= steps; i++) {
                            int x = (int) Math.round(x1 + (x2 - x1) * (i / (double) steps));
                            int y = (int) Math.round(y1 + (y2 - y1) * (i / (double) steps));
                            int z = (int) Math.round(z1 + (z2 - z1) * (i / (double) steps));
                            targets.add(new BlockPos(x, y, z));
                        }
                    }

                    for (BlockPos bp : targets) {
                        if (onlyAir && plannedMap.containsKey(bp)) continue;
                        plannedMap.put(bp, new PlannedBlock(bp, state, blockStr, onlyAir, pass));
                        if (bp.getX() < bMinX) bMinX = bp.getX();
                        if (bp.getX() > bMaxX) bMaxX = bp.getX();
                        if (bp.getY() < bMinY) bMinY = bp.getY();
                        if (bp.getY() > bMaxY) bMaxY = bp.getY();
                        if (bp.getZ() < bMinZ) bMinZ = bp.getZ();
                        if (bp.getZ() > bMaxZ) bMaxZ = bp.getZ();
                    }
                }

                int placed = 0;
                int autoConnected = 0;
                int autoChained = 0;

                // PASS 0: Automatic Grounded Foundations (walks down until true solid terrain!)
                for (PlannedBlock f : foundations) {
                    BlockPos.Mutable cur = f.pos.mutableCopy();
                    int safety = 0;
                    while (cur.getY() > sw.getBottomY() && safety < 48) {
                        BlockState existing = sw.getBlockState(cur);
                        if (safety > 0 && isGroundTerrain(sw, cur, existing)) break;
                        if (placeRawTracked(sw, cur.toImmutable(), f.state, false, prior)) placed++;
                        if (cur.getX() < bMinX) bMinX = cur.getX();
                        if (cur.getX() > bMaxX) bMaxX = cur.getX();
                        if (cur.getY() < bMinY) bMinY = cur.getY();
                        if (cur.getY() > bMaxY) bMaxY = cur.getY();
                        if (cur.getZ() < bMinZ) bMinZ = cur.getZ();
                        if (cur.getZ() > bMaxZ) bMaxZ = cur.getZ();
                        cur.move(Direction.DOWN);
                        safety++;
                    }
                }

                // Order planned blocks: Pass 1 (y asc) -> Pass 2 (y asc) -> Pass 3 (y desc so chains attach to ceilings first!)
                List<PlannedBlock> ordered = new ArrayList<>(plannedMap.values());
                ordered.sort((a, b) -> {
                    if (a.pass != b.pass) return Integer.compare(a.pass, b.pass);
                    if (a.pass == 3) return Integer.compare(b.pos.getY(), a.pos.getY());
                    return Integer.compare(a.pos.getY(), b.pos.getY());
                });

                List<PlannedBlock> actuallyPlaced = new ArrayList<>();

                for (PlannedBlock pb : ordered) {
                    BlockPos pos = pb.pos;
                    BlockState targetState = pb.state;

                    if (pb.onlyAir && !sw.getBlockState(pos).isAir()) continue;

                    // Auto-repair hanging lanterns with a 1-2 block ceiling gap using Chains!
                    if (strictPhysics && targetState.getBlock() instanceof LanternBlock
                            && targetState.contains(LanternBlock.HANGING) && targetState.get(LanternBlock.HANGING)) {
                        if (!targetState.canPlaceAt(sw, pos)) {
                            BlockPos up1 = pos.up();
                            BlockPos up2 = pos.up(2);
                            if (sw.getBlockState(up1).isAir() && !sw.getBlockState(up2).isAir()
                                    && Blocks.CHAIN.getDefaultState().canPlaceAt(sw, up1)) {
                                placeRawTracked(sw, up1, Blocks.CHAIN.getDefaultState(), false, prior);
                                autoChained++;
                            }
                        }
                    }

                    // Strict Anti-Float Physics Validation!
                    if (strictPhysics && !targetState.isAir()) {
                        String rejectReason = checkPhysicsSupport(sw, pos, targetState, pb.rawSpec);
                        if (rejectReason != null) {
                            if (physicsRejected.size() < 25) {
                                JsonObject rj = new JsonObject();
                                rj.addProperty("x", pos.getX());
                                rj.addProperty("y", pos.getY());
                                rj.addProperty("z", pos.getZ());
                                rj.addProperty("block", pb.rawSpec);
                                rj.addProperty("reason", rejectReason);
                                physicsRejected.add(rj);
                            }
                            continue;
                        }
                    }

                    if (placeRawTracked(sw, pos, targetState, false, prior)) {
                        placed++;
                        actuallyPlaced.add(pb);
                    }
                }

                // Native Minecraft Neighbor Auto-Connection (Fences, Panes, Walls, Stairs, Doors, MTR Platforms/APGs!)
                if (autoConnect) {
                    for (PlannedBlock pb : actuallyPlaced) {
                        if (pb.state.isAir()) continue;
                        // Only auto-connect if user didn't explicitly lock every state or if block supports neighbor shapes
                        BlockState cur = sw.getBlockState(pb.pos);
                        if (!cur.isAir()) {
                            BlockState connected = Block.postProcessState(cur, sw, pb.pos);
                            if (!connected.equals(cur) && connected.canPlaceAt(sw, pb.pos)) {
                                sw.setBlockState(pb.pos, connected, 3);
                                autoConnected++;
                            }
                            for (Direction dir : Direction.values()) {
                                BlockPos np = pb.pos.offset(dir);
                                BlockState ns = sw.getBlockState(np);
                                if (!ns.isAir()) {
                                    BlockState nConn = ns.getStateForNeighborUpdate(dir.getOpposite(), sw.getBlockState(pb.pos), sw, np, pb.pos);
                                    if (!nConn.equals(ns) && nConn.canPlaceAt(sw, np)) {
                                        prior.putIfAbsent(np.toImmutable(), ns);
                                        sw.setBlockState(np, nConn, 3);
                                    }
                                }
                            }
                        }
                    }
                }

                // Automatic Floating Canopy & Illegal Block Cleanup in Modified Region!
                int cleanedFloating = 0;
                if (cleanFloating && bMinX <= bMaxX) {
                    cleanedFloating = sweepFloatingBlocks(
                        sw,
                        bMinX - 3, Math.max(sw.getBottomY() + 1, bMinY - 2), bMinZ - 3,
                        bMaxX + 3, Math.min(sw.getTopY() - 1, bMaxY + 18), bMaxZ + 3,
                        prior
                    );
                }

                if (recordUndo && !prior.isEmpty()) {
                    while (UNDO_STACK.size() >= 30) UNDO_STACK.removeLast();
                    UNDO_STACK.push(new WorldSnapshot(sw, prior));
                }

                res.addProperty("ok", true);
                res.addProperty("changedBlocks", placed);
                res.addProperty("autoConnected", autoConnected);
                res.addProperty("autoChained", autoChained);
                res.addProperty("cleanedFloating", cleanedFloating);
                res.addProperty("undoCount", UNDO_STACK.size());
                res.add("physicsRejected", physicsRejected);
                res.add("errors", errors);
                fut.complete(res);
            } catch (Throwable t) {
                res.addProperty("ok", false);
                res.addProperty("error", t.toString());
                fut.complete(res);
            }
        });
        return fut.get(20, TimeUnit.SECONDS);
    }

    private static String checkPhysicsSupport(ServerWorld sw, BlockPos pos, BlockState targetState, String rawSpec) {
        Block b = targetState.getBlock();
        // Door upper half is placed right after lower half (Pass 2 sorted y asc), so lower half is already in sw!
        if (!targetState.canPlaceAt(sw, pos)) {
            return "canPlaceAt_false_missing_support";
        }
        // Standing furniture/gravity blocks must NOT sit over open air!
        if (b instanceof FallingBlock || b instanceof CampfireBlock || b instanceof LecternBlock
                || b instanceof BedBlock || (b instanceof LanternBlock && (!targetState.contains(LanternBlock.HANGING) || !targetState.get(LanternBlock.HANGING)))) {
            BlockState below = sw.getBlockState(pos.down());
            if (below.isAir() || !below.getFluidState().isEmpty()) {
                // Campfires on roofs/chimneys sit on bricks/hay, never air
                return "standing_block_over_air";
            }
        }
        return null;
    }

    // ==================== 3D FLOATING TREE & BROKEN SUPPORT CLEANER ====================
    private JsonObject handleCleanFloating(String body) throws Exception {
        JsonObject req = (body == null || body.isEmpty()) ? new JsonObject() : JsonParser.parseString(body).getAsJsonObject();
        MinecraftClient client = MinecraftClient.getInstance();
        JsonObject res = new JsonObject();
        if (client == null || client.getServer() == null || client.player == null) {
            res.addProperty("ok", false);
            res.addProperty("error", "not_in_world");
            return res;
        }
        IntegratedServer server = client.getServer();
        String pName = client.player.getNameForScoreboard();
        BlockPos pp = client.player.getBlockPos();

        int r = Math.min(90, Math.max(4, req.has("r") ? req.get("r").getAsInt() : 32));
        int cx = req.has("x") ? req.get("x").getAsInt() : pp.getX();
        int cz = req.has("z") ? req.get("z").getAsInt() : pp.getZ();
        int minX = req.has("x1") ? Math.min(req.get("x1").getAsInt(), req.get("x2").getAsInt()) : (cx - r);
        int maxX = req.has("x2") ? Math.max(req.get("x1").getAsInt(), req.get("x2").getAsInt()) : (cx + r);
        int minZ = req.has("z1") ? Math.min(req.get("z1").getAsInt(), req.get("z2").getAsInt()) : (cz - r);
        int maxZ = req.has("z2") ? Math.max(req.get("z1").getAsInt(), req.get("z2").getAsInt()) : (cz + r);
        int minY = req.has("y1") ? req.get("y1").getAsInt() : 58;
        int maxY = req.has("y2") ? req.get("y2").getAsInt() : 125;

        CompletableFuture<JsonObject> fut = new CompletableFuture<>();
        server.execute(() -> {
            try {
                ServerWorld sw = getPlayerServerWorld(server, pName);
                Map<BlockPos, BlockState> prior = new LinkedHashMap<>();
                int cleaned = sweepFloatingBlocks(sw, minX, minY, minZ, maxX, maxY, maxZ, prior);

                // Clean dropped item entities in box too so broken floating blocks leave zero litter
                int itemsCleared = 0;
                for (Entity e : sw.getEntitiesByClass(ItemEntity.class, new Box(minX, minY, minZ, maxX + 1, maxY + 1, maxZ + 1), ent -> true)) {
                    e.discard();
                    itemsCleared++;
                }

                if (!prior.isEmpty()) {
                    while (UNDO_STACK.size() >= 30) UNDO_STACK.removeLast();
                    UNDO_STACK.push(new WorldSnapshot(sw, prior));
                }
                res.addProperty("ok", true);
                res.addProperty("cleanedFloating", cleaned);
                res.addProperty("itemsCleared", itemsCleared);
                fut.complete(res);
            } catch (Throwable t) {
                res.addProperty("ok", false);
                res.addProperty("error", t.toString());
                fut.complete(res);
            }
        });
        return fut.get(20, TimeUnit.SECONDS);
    }

    private static boolean isTreeComponent(BlockState bs) {
        if (bs.isAir()) return false;
        Block b = bs.getBlock();
        if (b instanceof LeavesBlock || b instanceof VineBlock) return true;
        String path = Registries.BLOCK.getId(b).getPath();
        return path.endsWith("_log") || path.endsWith("_wood") || path.endsWith("_leaves")
                || path.equals("mangrove_roots") || path.equals("bee_nest") || path.equals("shroomlight");
    }

    private int sweepFloatingBlocks(ServerWorld sw, int minX, int minY, int minZ, int maxX, int maxY, int maxZ, Map<BlockPos, BlockState> prior) {
        int removed = 0;

        // 1. First pass: fix or remove any block in box that violates Minecraft's own canPlaceAt (e.g. floating lanterns, floating torches, floating vines/plants)
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int y = maxY; y >= minY; y--) {
            for (int x = minX; x <= maxX; x++) {
                for (int z = minZ; z <= maxZ; z++) {
                    m.set(x, y, z);
                    BlockState bs = sw.getBlockState(m);
                    if (bs.isAir()) continue;
                    if (!bs.canPlaceAt(sw, m)) {
                        // If it's a hanging lantern 1-2 blocks below a ceiling, auto-chain it instead of deleting!
                        if (bs.getBlock() instanceof LanternBlock && bs.contains(LanternBlock.HANGING) && bs.get(LanternBlock.HANGING)) {
                            BlockPos up1 = m.up();
                            BlockPos up2 = m.up(2);
                            if (sw.getBlockState(up1).isAir() && !sw.getBlockState(up2).isAir()
                                    && Blocks.CHAIN.getDefaultState().canPlaceAt(sw, up1)) {
                                placeRawTracked(sw, up1, Blocks.CHAIN.getDefaultState(), false, prior);
                                continue;
                            }
                        }
                        if (placeRawTracked(sw, m.toImmutable(), Blocks.AIR.getDefaultState(), false, prior)) {
                            removed++;
                        }
                    }
                }
            }
        }

        // 2. Second pass: 3D Ground-Reachability Flood-Fill for severed floating tree trunks & canopies!
        // Expand search collar by 6 blocks horizontally so trees whose trunks stand just outside the box aren't mistaken for floating!
        int cMinX = minX - 6, cMaxX = maxX + 6;
        int cMinZ = minZ - 6, cMaxZ = maxZ + 6;
        int cMinY = Math.max(sw.getBottomY() + 1, minY - 4);

        Set<Long> treeSet = new HashSet<>();
        Set<Long> grounded = new HashSet<>();
        ArrayDeque<BlockPos> queue = new ArrayDeque<>();

        for (int y = cMinY; y <= maxY; y++) {
            for (int x = cMinX; x <= cMaxX; x++) {
                for (int z = cMinZ; z <= cMaxZ; z++) {
                    m.set(x, y, z);
                    BlockState bs = sw.getBlockState(m);
                    if (!isTreeComponent(bs)) continue;
                    long key = m.asLong();
                    treeSet.add(key);

                    // Is this tree block directly touching non-tree solid ground/structure, or on the outer collar boundary?
                    boolean touchesAnchor = (x == cMinX || x == cMaxX || z == cMinZ || z == cMaxZ || y == cMinY);
                    if (!touchesAnchor) {
                        for (Direction d : Direction.values()) {
                            BlockPos np = m.offset(d);
                            BlockState nbs = sw.getBlockState(np);
                            if (!nbs.isAir() && nbs.getFluidState().isEmpty() && !isTreeComponent(nbs)) {
                                touchesAnchor = true;
                                break;
                            }
                        }
                    }
                    if (touchesAnchor) {
                        grounded.add(key);
                        queue.add(m.toImmutable());
                    }
                }
            }
        }

        // 26-way 3D connectivity (diagonal branches & canopy leaves in Minecraft connect across corners!)
        while (!queue.isEmpty()) {
            BlockPos cur = queue.poll();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dy == 0 && dz == 0) continue;
                        BlockPos np = cur.add(dx, dy, dz);
                        long nKey = np.asLong();
                        if (treeSet.contains(nKey) && grounded.add(nKey)) {
                            queue.add(np);
                        }
                    }
                }
            }
        }

        // Remove only ungrounded (truly mid-air floating!) tree blocks inside the target box
        for (long key : treeSet) {
            if (grounded.contains(key)) continue;
            BlockPos pos = BlockPos.fromLong(key);
            if (pos.getX() >= minX && pos.getX() <= maxX && pos.getZ() >= minZ && pos.getZ() <= maxZ && pos.getY() >= minY && pos.getY() <= maxY) {
                if (placeRawTracked(sw, pos, Blocks.AIR.getDefaultState(), false, prior)) {
                    removed++;
                }
            }
        }

        return removed;
    }

    // ==================== SERVER-SIDE BLOCK / MODDED ITEM INTERACTION (MTR RAIL NODES ETC.) ====================
    private JsonObject handleInteract(String body) throws Exception {
        JsonObject req = JsonParser.parseString(body).getAsJsonObject();
        int x = req.get("x").getAsInt();
        int y = req.get("y").getAsInt();
        int z = req.get("z").getAsInt();
        String sideStr = req.has("side") ? req.get("side").getAsString().toLowerCase() : "up";
        String itemStr = req.has("item") ? req.get("item").getAsString() : "";
        String actorName = req.has("actor") ? req.get("actor").getAsString() : "ArenaAI";

        MinecraftClient client = MinecraftClient.getInstance();
        JsonObject res = new JsonObject();
        if (client == null || client.getServer() == null) {
            res.addProperty("ok", false);
            res.addProperty("error", "not_in_world");
            return res;
        }
        IntegratedServer server = client.getServer();
        CompletableFuture<JsonObject> fut = new CompletableFuture<>();
        server.execute(() -> {
            try {
                ServerPlayerEntity actor = getServerPlayer(server, actorName);
                if (actor == null) {
                    res.addProperty("ok", false);
                    res.addProperty("error", "no_player_actor");
                    fut.complete(res);
                    return;
                }
                ServerWorld sw = actor.getServerWorld();
                if (!itemStr.isEmpty()) {
                    Identifier iid = new Identifier(itemStr.contains(":") ? itemStr : ("minecraft:" + itemStr));
                    if (Registries.ITEM.containsId(iid)) {
                        Item it = Registries.ITEM.get(iid);
                        ItemStack cur = actor.getMainHandStack();
                        if (!cur.isOf(it)) {
                            actor.setStackInHand(Hand.MAIN_HAND, new ItemStack(it, 1));
                        }
                    }
                }
                Direction side = Direction.byName(sideStr);
                if (side == null) side = Direction.UP;
                BlockPos bp = new BlockPos(x, y, z);
                BlockHitResult bhr = new BlockHitResult(Vec3d.ofCenter(bp), side, bp, false);
                ActionResult ar = actor.interactionManager.interactBlock(actor, sw, actor.getMainHandStack(), Hand.MAIN_HAND, bhr);
                res.addProperty("ok", true);
                res.addProperty("result", ar.name());
                res.addProperty("heldItem", Registries.ITEM.getId(actor.getMainHandStack().getItem()).toString());
                fut.complete(res);
            } catch (Throwable t) {
                res.addProperty("ok", false);
                res.addProperty("error", t.toString());
                fut.complete(res);
            }
        });
        return fut.get(6, TimeUnit.SECONDS);
    }

    // ==================== ACTIONBAR / CHAT / COMMAND / UNDO ====================
    private JsonObject handleActionbar(String body) {
        JsonObject req = JsonParser.parseString(body).getAsJsonObject();
        String text = req.has("text") ? req.get("text").getAsString() : "";
        MinecraftClient client = MinecraftClient.getInstance();
        if (client != null && client.inGameHud != null) {
            client.execute(() -> client.inGameHud.setOverlayMessage(Text.literal(text), false));
        }
        JsonObject res = new JsonObject();
        res.addProperty("ok", true);
        return res;
    }

    private JsonObject handleChat(String body) {
        JsonObject req = JsonParser.parseString(body).getAsJsonObject();
        String text = req.has("text") ? req.get("text").getAsString() : "";
        MinecraftClient client = MinecraftClient.getInstance();
        if (client != null && client.getServer() != null) {
            IntegratedServer server = client.getServer();
            server.execute(() -> server.getPlayerManager().broadcast(Text.literal(text), false));
        }
        JsonObject res = new JsonObject();
        res.addProperty("ok", true);
        return res;
    }

    private JsonObject handleCommand(String body) throws Exception {
        JsonObject req = JsonParser.parseString(body).getAsJsonObject();
        String cmd = req.has("command") ? req.get("command").getAsString() : "";
        boolean silent = !req.has("silent") || req.get("silent").getAsBoolean();
        MinecraftClient client = MinecraftClient.getInstance();
        JsonObject res = new JsonObject();
        if (client == null || client.getServer() == null) {
            res.addProperty("ok", false);
            res.addProperty("error", "no_server");
            return res;
        }
        IntegratedServer server = client.getServer();
        String pName = client.player != null ? client.player.getNameForScoreboard() : "";
        CompletableFuture<JsonObject> fut = new CompletableFuture<>();
        server.execute(() -> {
            try {
                ServerPlayerEntity sp = getServerPlayer(server, pName);
                ServerCommandSource src = sp != null ? sp.getCommandSource().withLevel(4) : server.getCommandSource().withLevel(4);
                if (silent) src = src.withSilent();
                String clean = cmd.startsWith("/") ? cmd.substring(1) : cmd;
                server.getCommandManager().executeWithPrefix(src, clean);
                res.addProperty("ok", true);
                fut.complete(res);
            } catch (Throwable t) {
                res.addProperty("ok", false);
                res.addProperty("error", t.toString());
                fut.complete(res);
            }
        });
        return fut.get(5, TimeUnit.SECONDS);
    }

    private boolean placeRawTracked(ServerWorld sw, BlockPos pos, BlockState newState, boolean onlyAir, Map<BlockPos, BlockState> prior) {
        BlockState oldState = sw.getBlockState(pos);
        if (onlyAir && !oldState.isAir()) return false;
        if (oldState.equals(newState)) return false;
        BlockPos imm = pos.toImmutable();
        prior.putIfAbsent(imm, oldState);
        sw.setBlockState(imm, newState, 3);
        return true;
    }

    private JsonObject handleUndo() throws Exception {
        MinecraftClient client = MinecraftClient.getInstance();
        JsonObject res = new JsonObject();
        if (client == null || client.getServer() == null) {
            res.addProperty("ok", false);
            res.addProperty("error", "not_in_world");
            return res;
        }
        if (UNDO_STACK.isEmpty()) {
            res.addProperty("ok", false);
            res.addProperty("error", "nothing_to_undo");
            return res;
        }
        IntegratedServer server = client.getServer();
        CompletableFuture<JsonObject> fut = new CompletableFuture<>();
        server.execute(() -> {
            WorldSnapshot snap = UNDO_STACK.pop();
            int restored = 0;
            for (Map.Entry<BlockPos, BlockState> e : snap.blocks.entrySet()) {
                snap.world.setBlockState(e.getKey(), e.getValue(), 3);
                restored++;
            }
            res.addProperty("ok", true);
            res.addProperty("restoredBlocks", restored);
            res.addProperty("undoCount", UNDO_STACK.size());
            fut.complete(res);
        });
        return fut.get(10, TimeUnit.SECONDS);
    }

    // ==================== HELPERS ====================
    @SuppressWarnings({"unchecked", "rawtypes"})
    private static String formatBlockStateString(BlockState bs) {
        Identifier id = Registries.BLOCK.getId(bs.getBlock());
        String base = id.toString();
        Map<Property<?>, Comparable<?>> entries = bs.getEntries();
        if (entries.isEmpty()) return base;
        StringBuilder sb = new StringBuilder(base).append('[');
        boolean first = true;
        for (Map.Entry<Property<?>, Comparable<?>> e : entries.entrySet()) {
            if (!first) sb.append(',');
            first = false;
            Property p = e.getKey();
            sb.append(p.getName()).append('=').append(p.name(e.getValue()));
        }
        sb.append(']');
        return sb.toString();
    }

    private static ServerPlayerEntity getServerPlayer(IntegratedServer server, String name) {
        for (ServerPlayerEntity sp : server.getPlayerManager().getPlayerList()) {
            if (sp.getNameForScoreboard().equals(name)) return sp;
        }
        List<ServerPlayerEntity> list = server.getPlayerManager().getPlayerList();
        return list.isEmpty() ? null : list.get(0);
    }

    private static ServerWorld getPlayerServerWorld(IntegratedServer server, String name) {
        ServerPlayerEntity sp = getServerPlayer(server, name);
        if (sp != null) return server.getWorld(sp.getWorld().getRegistryKey());
        return server.getOverworld();
    }

    private static Map<String, String> parseQuery(String query) {
        Map<String, String> map = new HashMap<>();
        if (query == null || query.isEmpty()) return map;
        for (String pair : query.split("&")) {
            int eq = pair.indexOf('=');
            if (eq > 0) {
                map.put(
                    URLDecoder.decode(pair.substring(0, eq), StandardCharsets.UTF_8),
                    URLDecoder.decode(pair.substring(eq + 1), StandardCharsets.UTF_8)
                );
            }
        }
        return map;
    }

    private static int parseInt(String s, int def) {
        try { return s == null ? def : Integer.parseInt(s); } catch (Exception e) { return def; }
    }

    private static double round2(double v) {
        return Math.round(v * 100.0) / 100.0;
    }

    private static String readLine(InputStream in) throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        int prev = -1;
        while (true) {
            int b = in.read();
            if (b < 0) return bos.size() == 0 ? null : bos.toString(StandardCharsets.UTF_8);
            if (b == '\n') {
                byte[] arr = bos.toByteArray();
                int len = (prev == '\r' && arr.length > 0) ? arr.length - 1 : arr.length;
                return new String(arr, 0, len, StandardCharsets.UTF_8);
            }
            bos.write(b);
            prev = b;
        }
    }

    private static void writeJson(OutputStream out, int code, JsonObject obj) throws Exception {
        writeResponse(out, code, "application/json; charset=utf-8", GSON.toJson(obj).getBytes(StandardCharsets.UTF_8));
    }

    private static void writeResponse(OutputStream out, int code, String contentType, byte[] body) throws Exception {
        String status = code == 200 ? "OK" : (code == 404 ? "Not Found" : "Error");
        String headers = "HTTP/1.1 " + code + " " + status + "\r\n" +
                "Content-Type: " + contentType + "\r\n" +
                "Content-Length: " + body.length + "\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Connection: close\r\n\r\n";
        out.write(headers.getBytes(StandardCharsets.UTF_8));
        out.write(body);
        out.flush();
    }
}

package ai.arena.bridge.audio;

import ai.arena.bridge.map.ArenaMapData;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.SourceDataLine;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Real-time 3D Spatial & Acoustic Reverb Audio Engine:
 * 1. Applies physical multi-tap acoustic reverb (underground tunnel / covered station echo) to 16-bit PCM.
 * 2. Updates volume (distance attenuation / rise) and stereo balance 25 times per second DURING playback,
 *    so as a train moves away from a station speaker (or away from a bystander), the voice naturally fades!
 */
public final class SpatialAudioEngine {

    public enum AnchorType {
        SELF_UI,          // Turnstile alert right in front of player (no fade, minimal room reflection)
        STATION_SPEAKER,  // Fixed 3D world coordinates (fades as train/player moves away, rises as approaching!)
        TRAIN_CABIN       // Attached to live moving MTR train (stays clear onboard, fades if heard from outside!)
    }

    public static final class SoundSourceSpec {
        public final AnchorType type;
        public final double worldX;
        public final double worldY;
        public final double worldZ;
        public final String routeNumber;
        public final float baseVolume;
        public final boolean tunnelReverb;

        private SoundSourceSpec(AnchorType type, double x, double y, double z, String routeNumber, float vol, boolean tunnelReverb) {
            this.type = type;
            this.worldX = x;
            this.worldY = y;
            this.worldZ = z;
            this.routeNumber = routeNumber;
            this.baseVolume = vol;
            this.tunnelReverb = tunnelReverb;
        }

        public static SoundSourceSpec self(float vol) {
            return new SoundSourceSpec(AnchorType.SELF_UI, 0, 0, 0, "", vol, false);
        }

        public static SoundSourceSpec station(double x, double y, double z, float vol, boolean underground) {
            return new SoundSourceSpec(AnchorType.STATION_SPEAKER, x, y, z, "", vol, underground);
        }

        public static SoundSourceSpec trainCabin(String routeNumber, float vol, boolean inTunnel) {
            return new SoundSourceSpec(AnchorType.TRAIN_CABIN, 0, 0, 0, routeNumber == null ? "" : routeNumber, vol, inTunnel);
        }
    }

    private static final ExecutorService AUDIO_EXEC = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "Arena-3D-SpatialAudio");
        t.setDaemon(true);
        return t;
    });

    private static volatile SourceDataLine currentLine = null;
    private static volatile boolean cancelRequested = false;

    private SpatialAudioEngine() {}

    public static void playSpatialWav(byte[] wavBytes, SoundSourceSpec spec, boolean interrupt) {
        if (wavBytes == null || wavBytes.length < 64) return;
        if (interrupt) {
            cancelRequested = true;
            SourceDataLine active = currentLine;
            if (active != null) {
                try { active.stop(); active.flush(); } catch (Throwable ignored) {}
            }
        }

        AUDIO_EXEC.submit(() -> {
            cancelRequested = false;
            try (AudioInputStream rawIn = AudioSystem.getAudioInputStream(new ByteArrayInputStream(wavBytes))) {
                AudioFormat srcFmt = rawIn.getFormat();
                float sampleRate = srcFmt.getSampleRate() > 0 ? srcFmt.getSampleRate() : 24000f;

                // Convert to stereo 16-bit little-endian PCM so both reverb DSP and real-time stereo panning work everywhere!
                AudioFormat targetFmt = new AudioFormat(
                        AudioFormat.Encoding.PCM_SIGNED,
                        sampleRate,
                        16,
                        2,
                        4,
                        sampleRate,
                        false
                );

                byte[] rawMonoOrStereo = readAllBytes(rawIn);
                short[] monoSamples = decodeToMono16(rawMonoOrStereo, srcFmt);

                // Determine acoustic environment (underground tunnel vs covered station canopy vs cabin)
                boolean inEnclosedSpace = spec.tunnelReverb || isListenerInEnclosedOrUnderground();
                short[] wetSamples = applyMultiTapReverb(monoSamples, (int) sampleRate, spec.type, inEnclosedSpace);

                DataLine.Info info = new DataLine.Info(SourceDataLine.class, targetFmt);
                try (SourceDataLine line = (SourceDataLine) AudioSystem.getLine(info)) {
                    currentLine = line;
                    line.open(targetFmt, 8192);
                    FloatControl gainCtrl = line.isControlSupported(FloatControl.Type.MASTER_GAIN)
                            ? (FloatControl) line.getControl(FloatControl.Type.MASTER_GAIN) : null;

                    line.start();

                    // Stream in ~40ms slices, updating 3D distance attenuation + stereo L/R ear pan LIVE!
                    int sliceFrames = Math.max(512, ((int) sampleRate) / 25);
                    byte[] outBuf = new byte[sliceFrames * 4];
                    float smoothLeft = 0.8f;
                    float smoothRight = 0.8f;

                    for (int offset = 0; offset < wetSamples.length && !cancelRequested; offset += sliceFrames) {
                        int count = Math.min(sliceFrames, wetSamples.length - offset);
                        float[] lr = computeLive3DGains(spec);
                        float targetL = lr[0];
                        float targetR = lr[1];

                        if (gainCtrl != null) {
                            float peak = Math.max(0.002f, Math.max(targetL, targetR));
                            float db = (float) (20.0 * Math.log10(Math.min(1.0f, peak)));
                            gainCtrl.setValue(Math.max(gainCtrl.getMinimum(), Math.min(gainCtrl.getMaximum(), db)));
                            // Normalize per-ear relative ratio
                            targetL = targetL / peak;
                            targetR = targetR / peak;
                        }

                        int bi = 0;
                        for (int i = 0; i < count; i++) {
                            smoothLeft += (targetL - smoothLeft) * 0.004f;
                            smoothRight += (targetR - smoothRight) * 0.004f;
                            short s = wetSamples[offset + i];
                            int lVal = Math.max(-32767, Math.min(32767, Math.round(s * smoothLeft)));
                            int rVal = Math.max(-32767, Math.min(32767, Math.round(s * smoothRight)));
                            outBuf[bi++] = (byte) (lVal & 0xFF);
                            outBuf[bi++] = (byte) ((lVal >> 8) & 0xFF);
                            outBuf[bi++] = (byte) (rVal & 0xFF);
                            outBuf[bi++] = (byte) ((rVal >> 8) & 0xFF);
                        }
                        line.write(outBuf, 0, bi);
                    }
                    if (!cancelRequested) {
                        line.drain();
                    }
                } finally {
                    currentLine = null;
                }
            } catch (Throwable ignored) {}
        });
    }

    private static float[] computeLive3DGains(SoundSourceSpec spec) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc != null && mc.isPaused()) {
            return new float[]{0.0001f, 0.0001f};
        }
        float mcMasterVol = 1.0f;
        if (mc != null && mc.options != null) {
            mcMasterVol = mc.options.getSoundVolume(net.minecraft.sound.SoundCategory.MASTER);
            if (mcMasterVol <= 0.002f) {
                return new float[]{0.0001f, 0.0001f};
            }
        }
        if (mc == null || mc.player == null || spec.type == AnchorType.SELF_UI) {
            float g = Math.max(0.001f, Math.min(1.0f, spec.baseVolume * mcMasterVol));
            return new float[]{g, g};
        }

        double px = mc.player.getX();
        double py = mc.player.getY();
        double pz = mc.player.getZ();

        double sx = spec.worldX;
        double sy = spec.worldY;
        double sz = spec.worldZ;

        if (spec.type == AnchorType.TRAIN_CABIN) {
            List<ArenaMapData.LiveTrainInfo> trains = ArenaMapData.getLiveTrains();
            ArenaMapData.LiveTrainInfo matched = null;
            for (ArenaMapData.LiveTrainInfo t : trains) {
                if (spec.routeNumber.isEmpty() || spec.routeNumber.equalsIgnoreCase(t.routeNumber)) {
                    matched = t;
                    break;
                }
            }
            if (matched == null && !trains.isEmpty()) matched = trains.get(0);
            if (matched != null) {
                sx = matched.x;
                sy = matched.y;
                sz = matched.z;
                double distToCar = Math.sqrt(sq(px - sx) + sq(py - sy) + sq(pz - sz));
                // Inside the train car: consistent crisp cabin PA!
                if (distToCar <= 9.5) {
                    float g = Math.max(0.001f, Math.min(1.0f, spec.baseVolume * mcMasterVol));
                    return new float[]{g, g};
                }
            } else {
                float g = Math.max(0.001f, spec.baseVolume * mcMasterVol);
                return new float[]{g, g};
            }
        }

        double dx = sx - px;
        double dy = sy - py;
        double dz = sz - pz;
        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);

        // Realistic inverse-distance acoustic rolloff: full within 6m, smooth decay out to 75m!
        float atten;
        if (dist <= 6.0) {
            atten = 1.0f;
        } else if (dist >= 80.0) {
            atten = 0.004f;
        } else {
            double norm = (dist - 6.0) / 74.0;
            atten = (float) (Math.pow(1.0 - norm, 2.15) * (6.0 / (6.0 + 0.14 * (dist - 6.0))));
        }
        float master = Math.max(0.0005f, Math.min(1.0f, spec.baseVolume * atten * mcMasterVol));

        // Stereo ear panning from player's head yaw
        double yawRad = Math.toRadians(mc.player.getYaw());
        // Player right-ear unit vector in Minecraft coordinates: (-cos(yaw), 0, -sin(yaw))
        double rightX = -Math.cos(yawRad);
        double rightZ = -Math.sin(yawRad);
        double horizDist = Math.hypot(dx, dz);
        float pan = 0.0f;
        if (horizDist > 1.5) {
            pan = (float) (((dx / horizDist) * rightX + (dz / horizDist) * rightZ) * 0.42);
        }

        float left = Math.max(0.003f, Math.min(1.0f, master * (1.0f - pan)));
        float right = Math.max(0.003f, Math.min(1.0f, master * (1.0f + pan)));
        return new float[]{left, right};
    }

    private static boolean isListenerInEnclosedOrUnderground() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.player == null || mc.world == null) return false;
        BlockPos eye = mc.player.getBlockPos().up();
        return mc.player.getY() < 59.0 || !mc.world.isSkyVisible(eye);
    }

    /**
     * Multi-tap acoustic hall / underground tunnel echo & reverb DSP.
     */
    private static short[] applyMultiTapReverb(short[] dry, int sampleRate, AnchorType type, boolean enclosed) {
        if (dry.length == 0 || type == AnchorType.SELF_UI) return dry;

        // Tail length: ~0.45s for underground tunnel / station canopy, ~0.22s for onboard cabin
        int tailSamples = (type == AnchorType.STATION_SPEAKER && enclosed)
                ? (sampleRate * 48 / 100)
                : (sampleRate * 24 / 100);

        int[] tapDelaysMs;
        float[] tapGains;

        if (type == AnchorType.STATION_SPEAKER && enclosed) {
            // Underground metro / covered concourse PA echo!
            tapDelaysMs = new int[]{47, 93, 149, 217, 305, 410};
            tapGains    = new float[]{0.30f, 0.22f, 0.16f, 0.11f, 0.075f, 0.045f};
        } else if (type == AnchorType.STATION_SPEAKER) {
            // Open-air forest station platform speaker echo
            tapDelaysMs = new int[]{61, 134, 225};
            tapGains    = new float[]{0.20f, 0.12f, 0.06f};
        } else {
            // Inside train cabin + tunnel wall reflection
            tapDelaysMs = enclosed ? new int[]{29, 67, 118} : new int[]{24, 55};
            tapGains    = enclosed ? new float[]{0.18f, 0.11f, 0.06f} : new float[]{0.11f, 0.05f};
        }

        short[] out = new short[dry.length + tailSamples];
        float lowPassState = 0.0f;

        for (int i = 0; i < out.length; i++) {
            float sample = (i < dry.length) ? dry[i] * 0.86f : 0.0f;
            float wet = 0.0f;
            for (int t = 0; t < tapDelaysMs.length; t++) {
                int delayIdx = i - (sampleRate * tapDelaysMs[t] / 1000);
                if (delayIdx >= 0 && delayIdx < dry.length) {
                    wet += dry[delayIdx] * tapGains[t];
                }
            }
            // Warm acoustic damping on reflections so echo sounds natural and never harsh/metallic
            lowPassState = lowPassState * 0.42f + wet * 0.58f;
            int mixed = Math.round(sample + lowPassState);
            out[i] = (short) Math.max(-32767, Math.min(32767, mixed));
        }
        return out;
    }

    private static short[] decodeToMono16(byte[] bytes, AudioFormat fmt) {
        int channels = Math.max(1, fmt.getChannels());
        int bits = fmt.getSampleSizeInBits();
        boolean bigEndian = fmt.isBigEndian();

        if (bits == 16) {
            int frameSize = 2 * channels;
            int frames = bytes.length / frameSize;
            short[] out = new short[frames];
            for (int f = 0; f < frames; f++) {
                int sum = 0;
                for (int c = 0; c < channels; c++) {
                    int idx = f * frameSize + c * 2;
                    short s = bigEndian
                            ? (short) (((bytes[idx] & 0xFF) << 8) | (bytes[idx + 1] & 0xFF))
                            : (short) (((bytes[idx + 1] & 0xFF) << 8) | (bytes[idx] & 0xFF));
                    sum += s;
                }
                out[f] = (short) (sum / channels);
            }
            return out;
        }
        return new short[0];
    }

    private static byte[] readAllBytes(AudioInputStream in) throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int r;
        while ((r = in.read(buf)) != -1) {
            bos.write(buf, 0, r);
        }
        return bos.toByteArray();
    }

    private static double sq(double v) {
        return v * v;
    }
}

package ai.arena.bridge.audio;

import net.fabricmc.loader.api.FabricLoader;

import java.io.File;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Function;

/**
 * Local DirectML GPU / RAM Turkish neural TTS engine (EMA Lightning ONNX).
 * Synthesizes speech asynchronously on a daemon worker and streams into SpatialAudioEngine
 * for 3D live distance attenuation, stereo panning, and underground/station acoustic reverb.
 */
public final class LocalTtsManager {

    private static final ExecutorService SYNTH_WORKER = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "Arena-DirectML-TTS");
        t.setDaemon(true);
        return t;
    });

    private static volatile Function<String[], byte[]> runner = null;
    private static volatile String backendStatus = "not_loaded";
    private static volatile boolean initStarted = false;
    private static volatile long lastQueuedAtMs = 0L;

    private LocalTtsManager() {}

    public static File getTtsRootDir() {
        return new File(FabricLoader.getInstance().getGameDir().toFile(), "arena-tts");
    }

    public static File getModelDir() {
        return new File(getTtsRootDir(), "models");
    }

    public static String getBackendStatus() {
        return backendStatus;
    }

    public static boolean isLocalReady() {
        ensureInitializedAsync();
        return runner != null;
    }

    public static void ensureInitializedAsync() {
        if (initStarted) return;
        initStarted = true;
        SYNTH_WORKER.submit(() -> {
            try {
                File root = getTtsRootDir();
                File jarFile = new File(root, "arena-onnx-directml.jar");
                File modelDir = getModelDir();
                if (!jarFile.exists() || !new File(modelDir, "sound.onnx").exists()) {
                    backendStatus = "missing_local_files";
                    return;
                }
                URLClassLoader cl = new URLClassLoader(
                        new URL[]{ jarFile.toURI().toURL() },
                        LocalTtsManager.class.getClassLoader()
                );
                Class<?> cls = Class.forName("ai.arena.tts.LocalEmaRunner", true, cl);
                @SuppressWarnings("unchecked")
                Function<String[], byte[]> fn = (Function<String[], byte[]>) cls.getDeclaredConstructor().newInstance();
                byte[] st = fn.apply(new String[]{ modelDir.getAbsolutePath(), "__status__" });
                backendStatus = st != null ? new String(st, StandardCharsets.UTF_8) : "ready";
                runner = fn;
            } catch (Throwable t) {
                backendStatus = "init_error:" + t.getClass().getSimpleName();
            }
        });
    }

    public static void speakAsync(String text, String chimeMode, float volume, boolean interrupt) {
        speakSpatial(text, chimeMode, SpatialAudioEngine.SoundSourceSpec.self(volume), interrupt);
    }

    public static void speakStationSpeaker(String text, String chimeMode, double sx, double sy, double sz, float baseVol, boolean underground, boolean interrupt) {
        speakSpatial(text, chimeMode, SpatialAudioEngine.SoundSourceSpec.station(sx, sy, sz, baseVol, underground), interrupt);
    }

    public static void speakTrainCabin(String text, String chimeMode, String routeNumber, float baseVol, boolean inTunnel, boolean interrupt) {
        speakSpatial(text, chimeMode, SpatialAudioEngine.SoundSourceSpec.trainCabin(routeNumber, baseVol, inTunnel), interrupt);
    }

    public static void speakSpatial(String text, String chimeMode, SpatialAudioEngine.SoundSourceSpec spec, boolean interrupt) {
        if (text == null || text.isBlank()) return;
        long now = System.currentTimeMillis();
        if (!interrupt && (now - lastQueuedAtMs) < 2200L) {
            return;
        }
        lastQueuedAtMs = now;
        ensureInitializedAsync();
        SYNTH_WORKER.submit(() -> {
            try {
                Function<String[], byte[]> fn = runner;
                if (fn == null) return;
                byte[] wav = fn.apply(new String[]{
                        getModelDir().getAbsolutePath(),
                        text,
                        chimeMode != null ? chimeMode : "station",
                        "1.0"
                });
                if (wav != null && wav.length > 100) {
                    SpatialAudioEngine.playSpatialWav(wav, spec, interrupt);
                }
            } catch (Throwable ignored) {}
        });
    }
}

package ai.arena.bridge.map;

import com.mojang.blaze3d.platform.GlStateManager;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.MapColor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;

import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Zero-Stutter Persistent World Terrain Atlas (v7.4.0):
 * - Completely pauses surface chunk scanning & GPU uploads while riding vehicles, moving fast, or underground (y < 57).
 * - Uses 16x16 OpenGL sub-rectangle uploads (1 KB via glTexSubImage2D) instead of full 8.4 MB texture uploads!
 */
public final class WorldAtlasManager {

    public static final int ATLAS_MIN_X = -512;
    public static final int ATLAS_MIN_Z = -192;
    public static final int ATLAS_W = 1024;
    public static final int ATLAS_H = 2048;

    private static NativeImageBackedTexture atlasTexture = null;
    private static Identifier atlasTextureId = null;
    private static final Set<Long> SCANNED_CHUNKS = new HashSet<>();
    private static int spiralCursor = 0;
    private static int tickDivider = 0;
    private static int lastPlayerChunkX = Integer.MIN_VALUE;
    private static int lastPlayerChunkZ = Integer.MIN_VALUE;
    private static long lastCurrentChunkRefreshMs = 0L;
    private static boolean dirtySinceSave = false;
    private static long lastDiskSaveMs = System.currentTimeMillis();
    private static final AtomicBoolean ASYNC_SAVE_RUNNING = new AtomicBoolean(false);

    private WorldAtlasManager() {}

    public static File getCacheFile() {
        return new File(FabricLoader.getInstance().getGameDir().toFile(), "arena-world-atlas.png");
    }

    private static int argbToAbgr(int a, int r, int g, int b) {
        return ((a & 0xFF) << 24) | ((b & 0xFF) << 16) | ((g & 0xFF) << 8) | (r & 0xFF);
    }

    public static Identifier getAndBindAtlas(MinecraftClient mc) {
        ensureInitialized(mc);
        if (atlasTexture != null) {
            atlasTexture.bindTexture();
            atlasTexture.setFilter(false, false);
            GlStateManager._texParameter(3553, 10242, 33071);
            GlStateManager._texParameter(3553, 10243, 33071);
        }
        return atlasTextureId;
    }

    public static void ensureInitialized(MinecraftClient mc) {
        if (atlasTexture != null || mc == null) return;

        NativeImage loaded = null;
        File cache = getCacheFile();
        if (cache.exists()) {
            try (InputStream in = Files.newInputStream(cache.toPath())) {
                NativeImage img = NativeImage.read(in);
                if (img.getWidth() == ATLAS_W && img.getHeight() == ATLAS_H) {
                    loaded = img;
                } else {
                    img.close();
                }
            } catch (Throwable ignored) {}
        }

        if (loaded != null) {
            atlasTexture = new NativeImageBackedTexture(loaded);
        } else {
            atlasTexture = new NativeImageBackedTexture(ATLAS_W, ATLAS_H, false);
            NativeImage img = atlasTexture.getImage();
            if (img != null) {
                int base = argbToAbgr(255, 24, 24, 24);
                int grid = argbToAbgr(255, 30, 30, 30);
                for (int z = 0; z < ATLAS_H; z++) {
                    boolean gz = (z & 63) == 0;
                    for (int x = 0; x < ATLAS_W; x++) {
                        img.setColor(x, z, (gz || ((x & 63) == 0)) ? grid : base);
                    }
                }
                atlasTexture.upload();
            }
        }
        atlasTextureId = mc.getTextureManager().registerDynamicTexture("arena_world_atlas_v7", atlasTexture);
    }

    public static void scanImmediateRadius(ClientWorld world, int centerChunkX, int centerChunkZ, int radiusChunks) {
        if (world == null || atlasTexture == null || atlasTexture.getImage() == null) return;
        int clampedR = Math.min(2, radiusChunks);
        for (int dx = -clampedR; dx <= clampedR; dx++) {
            for (int dz = -clampedR; dz <= clampedR; dz++) {
                rasterizeAndUploadSubChunk(world, centerChunkX + dx, centerChunkZ + dz);
            }
        }
    }

    public static void tickIncrementalScan(MinecraftClient mc) {
        if (mc == null || mc.world == null || mc.player == null) return;
        if ((++tickDivider % 20) != 0) return;

        // ZERO STUTTER DURING METRO RIDES OR UNDERGROUND EXPLORATION:
        // Never scan surface heightmaps or upload atlas data while underground or moving fast!
        if (mc.player.getY() < 57.0 || mc.player.hasVehicle()) return;
        if (mc.player.getVelocity().horizontalLengthSquared() > 0.035) return;

        ensureInitialized(mc);
        if (atlasTexture == null || atlasTexture.getImage() == null) return;

        long now = System.currentTimeMillis();
        int pcx = mc.player.getBlockX() >> 4;
        int pcz = mc.player.getBlockZ() >> 4;

        if (pcx != lastPlayerChunkX || pcz != lastPlayerChunkZ || (now - lastCurrentChunkRefreshMs) > 15_000L) {
            lastPlayerChunkX = pcx;
            lastPlayerChunkZ = pcz;
            lastCurrentChunkRefreshMs = now;
            rasterizeAndUploadSubChunk(mc.world, pcx, pcz);
        }

        for (int tries = 0; tries < 12; tries++) {
            spiralCursor = (spiralCursor + 1) % 289;
            int ox = (spiralCursor % 17) - 8;
            int oz = (spiralCursor / 17) - 8;
            int cx = pcx + ox;
            int cz = pcz + oz;
            long key = (((long) cx) << 32) ^ (cz & 0xFFFFFFFFL);
            if (SCANNED_CHUNKS.contains(key)) continue;
            if (rasterizeAndUploadSubChunk(mc.world, cx, cz)) {
                SCANNED_CHUNKS.add(key);
                break;
            }
        }

        if (dirtySinceSave && (now - lastDiskSaveMs) > 120_000L && ASYNC_SAVE_RUNNING.compareAndSet(false, true)) {
            dirtySinceSave = false;
            lastDiskSaveMs = now;
            try {
                NativeImage src = atlasTexture.getImage();
                if (src != null) {
                    NativeImage copy = new NativeImage(ATLAS_W, ATLAS_H, false);
                    copy.copyFrom(src);
                    File target = getCacheFile();
                    CompletableFuture.runAsync(() -> {
                        try (NativeImage owned = copy) {
                            owned.writeTo(target);
                        } catch (Throwable ignored) {
                        } finally {
                            ASYNC_SAVE_RUNNING.set(false);
                        }
                    });
                } else {
                    ASYNC_SAVE_RUNNING.set(false);
                }
            } catch (Throwable t) {
                ASYNC_SAVE_RUNNING.set(false);
            }
        }
    }

    private static boolean rasterizeAndUploadSubChunk(ClientWorld world, int cx, int cz) {
        if (!world.getChunkManager().isChunkLoaded(cx, cz)) return false;
        int wx0 = cx << 4;
        int wz0 = cz << 4;
        if (wx0 < ATLAS_MIN_X || wx0 + 16 > ATLAS_MIN_X + ATLAS_W) return false;
        if (wz0 < ATLAS_MIN_Z || wz0 + 16 > ATLAS_MIN_Z + ATLAS_H) return false;

        NativeImage img = atlasTexture.getImage();
        if (img == null) return false;
        BlockPos.Mutable mpos = new BlockPos.Mutable();

        int ax0 = wx0 - ATLAS_MIN_X;
        int az0 = wz0 - ATLAS_MIN_Z;

        for (int lx = 0; lx < 16; lx++) {
            int wx = wx0 + lx;
            int ax = ax0 + lx;
            for (int lz = 0; lz < 16; lz++) {
                int wz = wz0 + lz;
                int az = az0 + lz;
                int topY = world.getTopY(Heightmap.Type.WORLD_SURFACE, wx, wz) - 1;
                if (topY < world.getBottomY()) continue;

                mpos.set(wx, topY, wz);
                BlockState bs = world.getBlockState(mpos);
                int rgb = bs.getMapColor(world, mpos).color;
                if (rgb == 0) {
                    mpos.set(wx, Math.max(world.getBottomY(), topY - 1), wz);
                    rgb = world.getBlockState(mpos).getMapColor(world, mpos).color;
                }
                if (rgb == 0) rgb = MapColor.STONE_GRAY.color;

                int r = (rgb >> 16) & 0xFF;
                int g = (rgb >> 8) & 0xFF;
                int b = rgb & 0xFF;

                int northY = world.getTopY(Heightmap.Type.WORLD_SURFACE, wx, wz - 1) - 1;
                float shade = 1.0f;
                if (bs.isOf(Blocks.WATER)) {
                    shade = 0.92f;
                } else if (topY > northY) {
                    shade = 1.12f;
                } else if (topY < northY) {
                    shade = 0.84f;
                }

                r = Math.min(255, Math.max(0, Math.round(r * shade)));
                g = Math.min(255, Math.max(0, Math.round(g * shade)));
                b = Math.min(255, Math.max(0, Math.round(b * shade)));

                img.setColor(ax, az, argbToAbgr(255, r, g, b));
            }
        }

        // Upload ONLY this 16x16 chunk tile (1 KB!) instead of the entire 8.4 MB texture!
        atlasTexture.bindTexture();
        img.upload(0, ax0, az0, ax0, az0, 16, 16, false, false, false, false);
        dirtySinceSave = true;
        return true;
    }
}

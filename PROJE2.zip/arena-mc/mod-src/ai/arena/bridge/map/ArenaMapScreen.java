package ai.arena.bridge.map;

import ai.arena.bridge.transit.UitpSystemType;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;

import java.util.List;
import java.util.Locale;

/**
 * Clean MTR-grade interactive transit map (M key) & toggleable corner minimap (N key).
 * - Uses WorldAtlasManager (GL_NEAREST + GL_CLAMP_TO_EDGE).
 * - Distinguishes surface segments (solid) from underground tunnel segments (dashed).
 * - Multiplayer-aware player markers and non-overlapping station/vehicle labels.
 */
public class ArenaMapScreen extends Screen {

    private int activeTab = 0; // 0 = Ulaşım & Arazi, 1 = Bölge Sınırları, 2 = UITP/UIC Sınıfları
    private double centerX = -18.0;
    private double centerZ = 32.0;
    private double scale = 2.0;
    private boolean followTrain = false;
    private boolean dragging = false;

    public ArenaMapScreen(int initialMode) {
        super(Text.literal("Avrasya Ulaşım Ağ Haritası"));
        ArenaMapData.ensureLoaded();
        this.activeTab = (initialMode == 3) ? 1 : 0;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc != null && mc.player != null) {
            this.centerX = Math.round(mc.player.getX());
            this.centerZ = Math.round(mc.player.getZ());
            if (mc.world != null) {
                WorldAtlasManager.ensureInitialized(mc);
                WorldAtlasManager.scanImmediateRadius(mc.world, mc.player.getBlockX() >> 4, mc.player.getBlockZ() >> 4, 3);
            }
        }
    }

    public static void openClientScreen(int mode) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc != null) {
            mc.execute(() -> mc.setScreen(new ArenaMapScreen(mode)));
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            if (mouseY <= 32) {
                // Top bar buttons
                int bx = 12;
                String[] tabs = {"Ulaşım Ağı", "Bölge Sınırları", "UITP / UIC Rehberi", "Tren Takibi", "Kuzey Gar", "Güney Gar"};
                for (int i = 0; i < tabs.length; i++) {
                    int bw = this.textRenderer.getWidth(tabs[i]) + 16;
                    if (mouseX >= bx && mouseX <= bx + bw && mouseY >= 6 && mouseY <= 26) {
                        if (i <= 2) {
                            this.activeTab = i;
                        } else if (i == 3) {
                            this.followTrain = !this.followTrain;
                        } else if (i == 4) {
                            this.followTrain = false;
                            this.centerX = -18.0;
                            this.centerZ = 32.0;
                            this.scale = 2.2;
                        } else {
                            this.followTrain = false;
                            this.centerX = -18.0;
                            this.centerZ = 1580.0;
                            this.scale = 2.2;
                        }
                        return true;
                    }
                    bx += bw + 6;
                }
            } else if (mouseY < this.height - 24) {
                this.dragging = true;
                this.followTrain = false;
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0) this.dragging = false;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (this.dragging && button == 0) {
            this.centerX -= deltaX / this.scale;
            this.centerZ -= deltaY / this.scale;
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        double factor = verticalAmount > 0 ? 1.22 : (1.0 / 1.22);
        this.scale = Math.max(0.22, Math.min(10.0, this.scale * factor));
        return true;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null) return;

        List<ArenaMapData.LiveTrainInfo> trains = ArenaMapData.getLiveTrains();
        if (this.followTrain && !trains.isEmpty()) {
            this.centerX = trains.get(0).x;
            this.centerZ = trains.get(0).z;
        }

        // Matte MTR graphite frame
        ctx.fill(0, 0, this.width, this.height, 0xFF141414);

        int vpLeft = 10;
        int vpTop = 34;
        int vpW = this.width - 20;
        int vpH = this.height - 60;

        renderMapViewport(ctx, mc, vpLeft, vpTop, vpW, vpH, this.centerX, this.centerZ, this.scale, true, this.activeTab == 1, trains);

        // Top MTR Header Bar
        ctx.fill(0, 0, this.width, 32, 0xFF1E1E1E);
        ctx.fill(0, 31, this.width, 32, 0xFF333333);

        int bx = 12;
        String[] tabs = {"Ulaşım Ağı", "Bölge Sınırları", "UITP / UIC Rehberi", "Tren Takibi", "Kuzey Gar", "Güney Gar"};
        for (int i = 0; i < tabs.length; i++) {
            int bw = this.textRenderer.getWidth(tabs[i]) + 16;
            boolean active = (i <= 2 && this.activeTab == i) || (i == 3 && this.followTrain);
            ctx.fill(bx, 6, bx + bw, 26, active ? 0xFF2E7D32 : 0xFF2A2A2A);
            ctx.drawBorder(bx, 6, bw, 20, active ? 0xFF66BB6A : 0xFF3E3E3E);
            ctx.drawText(this.textRenderer, tabs[i], bx + 8, 12, 0xFFF2F2F2, false);
            bx += bw + 6;
        }

        // Optional UITP & UIC Classification Reference Drawer
        if (this.activeTab == 2) {
            int pw = 310;
            int ph = 196;
            int px = this.width - pw - 20;
            int py = vpTop + 10;
            ctx.fill(px, py, px + pw, py + ph, 0xEE1A1A1A);
            ctx.drawBorder(px, py, pw, ph, 0xFF3C3C3C);
            ctx.drawText(this.textRenderer, "UITP & UIC Standart Hat Sınıfları", px + 10, py + 8, 0xFFFFFFFF, false);
            ctx.fill(px + 8, py + 20, px + pw - 8, py + 21, 0xFF333333);

            int ry = py + 27;
            for (UitpSystemType sys : UitpSystemType.values()) {
                int col = 0xFF000000 | sys.defaultColor;
                ctx.fill(px + 10, ry, px + 42, ry + 13, col);
                drawScaledText(ctx, this.textRenderer, sys.prefix, px + 14, ry + 3, 0.85f, 0xFFFFFFFF);
                drawScaledText(ctx, this.textRenderer, sys.displayNameTr, px + 50, ry + 3, 0.85f, 0xFFE0E0E0);
                ry += 20;
            }
        }

        // Bottom Status Bar
        ctx.fill(0, this.height - 24, this.width, this.height, 0xFF1E1E1E);
        ctx.fill(0, this.height - 24, this.width, this.height - 23, 0xFF333333);
        double hoverWX = this.centerX + (mouseX - (vpLeft + vpW * 0.5)) / this.scale;
        double hoverWZ = this.centerZ + (mouseY - (vpTop + vpH * 0.5)) / this.scale;
        String footer = String.format(Locale.US, "İmleç: X=%.0f, Z=%.0f  |  Yakınlaştırma: %.2fx  |  Düz Çizgi: Yüzey Hattı, Kesikli: Yeraltı Tüneli",
                hoverWX, hoverWZ, this.scale);
        ctx.drawText(this.textRenderer, footer, 12, this.height - 16, 0xFFBDBDBD, false);
    }

    public static void renderMiniMap(DrawContext ctx, int x, int y, int size) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.player == null || mc.world == null) return;

        ctx.fill(x - 2, y - 2, x + size + 2, y + size + 2, 0xEE181818);
        ctx.drawBorder(x - 2, y - 2, size + 4, size + 4, 0xFF3A3A3A);

        List<ArenaMapData.LiveTrainInfo> trains = ArenaMapData.getLiveTrains();
        renderMapViewport(ctx, mc, x, y, size, size, mc.player.getX(), mc.player.getZ(), 0.72, false, false, trains);
    }

    private static void renderMapViewport(
            DrawContext ctx,
            MinecraftClient mc,
            int left,
            int top,
            int w,
            int h,
            double cx,
            double cz,
            double sc,
            boolean fullLabels,
            boolean showBorders,
            List<ArenaMapData.LiveTrainInfo> trains
    ) {
        ctx.enableScissor(left, top, left + w, top + h);
        ctx.fill(left, top, left + w, top + h, 0xFF181818);

        // 1. Blit Crisp World Terrain Atlas ONLY inside valid world bounds (clamped, zero repeat!)
        Identifier atlasId = WorldAtlasManager.getAndBindAtlas(mc);
        if (atlasId != null) {
            double worldLeft = cx - (w * 0.5) / sc;
            double worldRight = cx + (w * 0.5) / sc;
            double worldTop = cz - (h * 0.5) / sc;
            double worldBot = cz + (h * 0.5) / sc;

            double clW0 = Math.max(WorldAtlasManager.ATLAS_MIN_X, worldLeft);
            double clW1 = Math.min(WorldAtlasManager.ATLAS_MIN_X + WorldAtlasManager.ATLAS_W, worldRight);
            double clZ0 = Math.max(WorldAtlasManager.ATLAS_MIN_Z, worldTop);
            double clZ1 = Math.min(WorldAtlasManager.ATLAS_MIN_Z + WorldAtlasManager.ATLAS_H, worldBot);

            if (clW1 > clW0 && clZ1 > clZ0) {
                float sx0 = (float) (left + w * 0.5 + (clW0 - cx) * sc);
                float sx1 = (float) (left + w * 0.5 + (clW1 - cx) * sc);
                float sy0 = (float) (top + h * 0.5 + (clZ0 - cz) * sc);
                float sy1 = (float) (top + h * 0.5 + (clZ1 - cz) * sc);

                float u0 = (float) ((clW0 - WorldAtlasManager.ATLAS_MIN_X) / WorldAtlasManager.ATLAS_W);
                float u1 = (float) ((clW1 - WorldAtlasManager.ATLAS_MIN_X) / WorldAtlasManager.ATLAS_W);
                float v0 = (float) ((clZ0 - WorldAtlasManager.ATLAS_MIN_Z) / WorldAtlasManager.ATLAS_H);
                float v1 = (float) ((clZ1 - WorldAtlasManager.ATLAS_MIN_Z) / WorldAtlasManager.ATLAS_H);

                RenderSystem.setShaderTexture(0, atlasId);
                RenderSystem.setShader(GameRenderer::getPositionTexProgram);
                Matrix4f mat = ctx.getMatrices().peek().getPositionMatrix();
                BufferBuilder bb = Tessellator.getInstance().getBuffer();
                bb.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE);
                bb.vertex(mat, sx0, sy1, 0f).texture(u0, v1).next();
                bb.vertex(mat, sx1, sy1, 0f).texture(u1, v1).next();
                bb.vertex(mat, sx1, sy0, 0f).texture(u1, v0).next();
                bb.vertex(mat, sx0, sy0, 0f).texture(u0, v0).next();
                BufferRenderer.drawWithGlobalProgram(bb.end());
            }
        }

        TextRenderer tr = mc.textRenderer;

        // 2. Administrative Region Borders
        if (showBorders) {
            for (ArenaMapData.CountryRegion c : ArenaMapData.COUNTRIES) {
                int edge = 0xCC000000 | (c.color & 0xFFFFFF);
                double sumX = 0, sumZ = 0;
                for (int i = 0; i < c.polygon.size(); i++) {
                    double[] a = c.polygon.get(i);
                    double[] b = c.polygon.get((i + 1) % c.polygon.size());
                    sumX += a[0]; sumZ += a[1];
                    drawLine(ctx,
                            (float) (left + w * 0.5 + (a[0] - cx) * sc), (float) (top + h * 0.5 + (a[1] - cz) * sc),
                            (float) (left + w * 0.5 + (b[0] - cx) * sc), (float) (top + h * 0.5 + (b[1] - cz) * sc),
                            1.5f, edge);
                }
                if (fullLabels && !c.polygon.isEmpty() && sc <= 0.9) {
                    float lx = (float) (left + w * 0.5 + (sumX / c.polygon.size() - cx) * sc);
                    float ly = (float) (top + h * 0.5 + (sumZ / c.polygon.size() - cz) * sc);
                    drawScaledCentered(ctx, tr, c.name, lx, ly, 0.85f, 0xFFEAEAEA);
                }
            }
        }

        // 3. YHT-1 Track Spine (Surface solid at portals vs Underground dashed in tunnel so it never cuts buildings!)
        int mainRouteColor = 0xFF00A86B;
        List<ArenaMapData.LiveRouteSegment> liveRoutes = ArenaMapData.getLiveRoutes();
        if (!liveRoutes.isEmpty()) {
            mainRouteColor = 0xFF000000 | (liveRoutes.get(0).color & 0xFFFFFF);
        }
        float rx = (float) (left + w * 0.5 + (-18.0 - cx) * sc);
        float zNorthDepot = (float) (top + h * 0.5 + (-10.0 - cz) * sc);
        float zNorthPortal = (float) (top + h * 0.5 + (52.0 - cz) * sc);
        float zSouthPortal = (float) (top + h * 0.5 + (1564.0 - cz) * sc);
        float zSouthLoop = (float) (top + h * 0.5 + (1608.0 - cz) * sc);

        drawLine(ctx, rx, zNorthDepot, rx, zNorthPortal, fullLabels ? 2.6f : 1.6f, mainRouteColor);
        drawDashedLine(ctx, rx, zNorthPortal, rx, zSouthPortal, fullLabels ? 2.0f : 1.2f, 6f, 5f, (0xB8 << 24) | (mainRouteColor & 0xFFFFFF));
        drawLine(ctx, rx, zSouthPortal, rx, zSouthLoop, fullLabels ? 2.6f : 1.6f, mainRouteColor);

        // Additional UITP/UIC Lines (M, B, HRS, T, MR, F, TF)
        for (ArenaMapData.CustomTransitLine cl : ArenaMapData.CUSTOM_LINES) {
            int col = 0xFF000000 | (cl.color & 0xFFFFFF);
            for (int i = 0; i < cl.points.size() - 1; i++) {
                float x0 = (float) (left + w * 0.5 + (cl.points.get(i)[0] - cx) * sc);
                float y0 = (float) (top + h * 0.5 + (cl.points.get(i)[1] - cz) * sc);
                float x1 = (float) (left + w * 0.5 + (cl.points.get(i + 1)[0] - cx) * sc);
                float y1 = (float) (top + h * 0.5 + (cl.points.get(i + 1)[1] - cz) * sc);
                if (cl.underground) {
                    drawDashedLine(ctx, x0, y0, x1, y1, fullLabels ? 2.2f : 1.3f, 5f, 4f, col);
                } else {
                    drawLine(ctx, x0, y0, x1, y1, fullLabels ? 2.5f : 1.5f, col);
                }
            }
        }

        // 4. MTR Station Interchange Circles (label placed cleanly on the LEFT side)
        for (ArenaMapData.LiveStationInfo st : ArenaMapData.getLiveStations()) {
            float sx = (float) (left + w * 0.5 + (st.x - cx) * sc);
            float sy = (float) (top + h * 0.5 + (st.z - cz) * sc);
            drawDisc(ctx, sx, sy, fullLabels ? 4.2f : 2.3f, 0xFFFFFFFF);
            drawDisc(ctx, sx, sy, fullLabels ? 2.4f : 1.2f, 0xFF181818);
            if (fullLabels && sc >= 0.35) {
                String clean = st.name != null ? st.name.split("\\|")[0] : "";
                if (st.underground) clean = "[M] " + clean;
                float tw = tr.getWidth(clean) * 0.85f;
                drawScaledText(ctx, tr, clean, sx - tw - 7f, sy - 3.5f, 0.85f, 0xFFF2F2F2);
            }
        }

        // 5. Live MTR Vehicles (label placed cleanly on the RIGHT side so it NEVER collides with stations!)
        for (ArenaMapData.LiveTrainInfo t : trains) {
            float tx = (float) (left + w * 0.5 + (t.x - cx) * sc);
            float ty = (float) (top + h * 0.5 + (t.z - cz) * sc);
            int tc = 0xFF000000 | (t.color & 0xFFFFFF);
            drawDisc(ctx, tx, ty, fullLabels ? 4.0f : 2.3f, 0xFFFFFFFF);
            drawDisc(ctx, tx, ty, fullLabels ? 2.7f : 1.6f, tc);
            if (fullLabels) {
                String badge = t.speedKmh < 1.5
                        ? (t.routeNumber + " (Peronda)")
                        : String.format(Locale.US, "%s %.0f km/s", t.routeNumber, t.speedKmh);
                int bw = Math.round(tr.getWidth(badge) * 0.8f) + 8;
                ctx.fill((int) tx + 7, (int) ty - 6, (int) tx + 7 + bw, (int) ty + 6, 0xDD1E1E1E);
                ctx.drawBorder((int) tx + 7, (int) ty - 6, bw, 12, tc);
                drawScaledText(ctx, tr, badge, tx + 11f, ty - 3f, 0.8f, 0xFFFFFFFF);
            }
        }

        // 6. Multiplayer Players (All loaded players in world)
        if (mc.world != null) {
            for (PlayerEntity p : mc.world.getPlayers()) {
                float px = (float) (left + w * 0.5 + (p.getX() - cx) * sc);
                float py = (float) (top + h * 0.5 + (p.getZ() - cz) * sc);
                boolean self = mc.player != null && p.getUuid().equals(mc.player.getUuid());
                int pc = self ? 0xFF42A5F5 : 0xFFFFCA28;
                drawDisc(ctx, px, py, fullLabels ? 3.5f : 2.2f, 0xFFFFFFFF);
                drawDisc(ctx, px, py, fullLabels ? 2.3f : 1.4f, pc);
                if (fullLabels) {
                    drawScaledText(ctx, tr, p.getName().getString(), px + 6f, py + 5f, 0.78f, self ? 0xFF90CAF9 : 0xFFFFE082);
                }
            }
        }

        ctx.disableScissor();
    }

    public static void drawScaledText(DrawContext ctx, TextRenderer tr, String text, float x, float y, float scale, int color) {
        ctx.getMatrices().push();
        ctx.getMatrices().translate(x, y, 0f);
        ctx.getMatrices().scale(scale, scale, 1f);
        ctx.drawText(tr, text, 0, 0, color, true);
        ctx.getMatrices().pop();
    }

    public static void drawScaledCentered(DrawContext ctx, TextRenderer tr, String text, float cx, float y, float scale, int color) {
        float w = tr.getWidth(text) * scale;
        drawScaledText(ctx, tr, text, cx - w * 0.5f, y, scale, color);
    }

    private static void drawLine(DrawContext ctx, float x1, float y1, float x2, float y2, float thickness, int argb) {
        float dx = x2 - x1;
        float dy = y2 - y1;
        float len = (float) Math.hypot(dx, dy);
        if (len < 0.01f) return;
        float nx = (-dy / len) * (thickness * 0.5f);
        float ny = (dx / len) * (thickness * 0.5f);

        int a = (argb >>> 24) & 0xFF;
        int r = (argb >>> 16) & 0xFF;
        int g = (argb >>> 8) & 0xFF;
        int b = argb & 0xFF;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);
        Matrix4f mat = ctx.getMatrices().peek().getPositionMatrix();
        BufferBuilder bb = Tessellator.getInstance().getBuffer();
        bb.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        bb.vertex(mat, x1 + nx, y1 + ny, 0f).color(r, g, b, a).next();
        bb.vertex(mat, x1 - nx, y1 - ny, 0f).color(r, g, b, a).next();
        bb.vertex(mat, x2 - nx, y2 - ny, 0f).color(r, g, b, a).next();
        bb.vertex(mat, x2 + nx, y2 + ny, 0f).color(r, g, b, a).next();
        BufferRenderer.drawWithGlobalProgram(bb.end());
    }

    private static void drawDashedLine(DrawContext ctx, float x1, float y1, float x2, float y2, float thickness, float dash, float gap, int argb) {
        float dx = x2 - x1;
        float dy = y2 - y1;
        float total = (float) Math.hypot(dx, dy);
        if (total < 1f) return;
        float ux = dx / total;
        float uy = dy / total;
        float pos = 0f;
        while (pos < total) {
            float end = Math.min(total, pos + dash);
            drawLine(ctx, x1 + ux * pos, y1 + uy * pos, x1 + ux * end, y1 + uy * end, thickness, argb);
            pos += dash + gap;
        }
    }

    private static void drawDisc(DrawContext ctx, float cx, float cy, float radius, int argb) {
        int a = (argb >>> 24) & 0xFF;
        int r = (argb >>> 16) & 0xFF;
        int g = (argb >>> 8) & 0xFF;
        int b = argb & 0xFF;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);
        Matrix4f mat = ctx.getMatrices().peek().getPositionMatrix();
        BufferBuilder bb = Tessellator.getInstance().getBuffer();
        bb.begin(VertexFormat.DrawMode.TRIANGLE_FAN, VertexFormats.POSITION_COLOR);
        bb.vertex(mat, cx, cy, 0f).color(r, g, b, a).next();
        int segs = 14;
        for (int i = 0; i <= segs; i++) {
            double ang = (Math.PI * 2.0 * i) / segs;
            bb.vertex(mat, cx + (float) Math.cos(ang) * radius, cy + (float) Math.sin(ang) * radius, 0f).color(r, g, b, a).next();
        }
        BufferRenderer.drawWithGlobalProgram(bb.end());
    }
}

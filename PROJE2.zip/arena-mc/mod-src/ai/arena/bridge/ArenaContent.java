package ai.arena.bridge;

import ai.arena.bridge.audio.LocalTtsManager;
import ai.arena.bridge.board.ArenaNewsManager;
import ai.arena.bridge.map.ArenaMapScreen;
import ai.arena.bridge.transit.MtrBridgeHelper;
import ai.arena.bridge.transit.RailPhysicsEngine;
import ai.arena.bridge.transit.RegionPolicyEngine;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerChunkEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.HorizontalFacingBlock;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityTicker;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.block.enums.DoubleBlockHalf;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.BlockEntityUpdateS2CPacket;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.scoreboard.ReadableScoreboardScore;
import net.minecraft.scoreboard.ScoreAccess;
import net.minecraft.scoreboard.ScoreHolder;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardCriterion;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.DirectionProperty;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.IntProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.StringIdentifiable;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.GameRules;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.chunk.WorldChunk;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Clean v7.0.0 ModInitializer:
 * 1. Orman Kart (MTR Concessionary Transit Card)
 * 2. World Map Board (Location-aware GL_NEAREST + GL_CLAMP_TO_EDGE Digital Map + MTR Line Diagram)
 * 3. Transit News Board (Real-time Transit Telemetry & Map-Backed Expansion Board)
 * 4. Tunnel Emergency Light (Slim Ceiling/Wall LED Fixture — 100% automatic red mode during storms, white when clear)
 * 5. Physical Server Weather (/havadurumu & /firtina with rain + thunder levels 1..5 & roof-safe lightning rods)
 */
public class ArenaContent implements ModInitializer {

    public static final String MOD_ID = "arena_ai_bridge";

    public static final DirectionProperty FACING = HorizontalFacingBlock.FACING;
    public static final EnumProperty<DoubleBlockHalf> HALF = Properties.DOUBLE_BLOCK_HALF;
    public static final IntProperty MAP_MODE = IntProperty.of("map_mode", 0, 4);
    public static final IntProperty POSTER_THEME = IntProperty.of("poster_theme", 0, 3);
    public static final BooleanProperty EMERGENCY = BooleanProperty.of("emergency");
    public static final BooleanProperty CEILING = BooleanProperty.of("ceiling");

    public enum BenchPart implements StringIdentifiable {
        SINGLE("single"),
        LEFT("left"),
        MIDDLE("middle"),
        RIGHT("right");

        private final String name;
        BenchPart(String name) { this.name = name; }

        @Override
        public String asString() { return this.name; }
    }

    public static final EnumProperty<BenchPart> BENCH_PART = EnumProperty.of("part", BenchPart.class);

    public enum BoardMount implements StringIdentifiable {
        WALL("wall"),
        STAND("stand"),
        POSTER("poster"),
        GANTRY("gantry");

        private final String name;
        BoardMount(String name) { this.name = name; }

        @Override
        public String asString() { return this.name; }
    }

    public static final EnumProperty<BoardMount> BOARD_MOUNT = EnumProperty.of("mount", BoardMount.class);

    public static net.minecraft.sound.SoundEvent TUNNEL_ALARM_BEEP_EVENT;
    public static final Identifier VENDING_ACTION_PACKET = new Identifier(MOD_ID, "vending_action");
    private static final List<net.minecraft.entity.decoration.ArmorStandEntity> ACTIVE_BENCH_SEATS =
            new java.util.concurrent.CopyOnWriteArrayList<>();

    public static Item ORMAN_KART;
    public static Block WORLD_MAP_BOARD;
    public static Block TRANSIT_NEWS_BOARD;
    public static Block TUNNEL_EMERGENCY_LIGHT;
    public static Block METRO_BENCH;
    public static Block VENDING_MACHINE;
    public static Block AD_LIGHTBOX;
    public static Block INFO_KIOSK;
    public static Block SAFETY_CABINET;
    public static Block PROGRAMMABLE_BOARD;
    public static Block HIZMET_DISI_SERIT;
    public static Block YAKINDA_SERIT;

    public static BlockEntityType<MapBoardBlockEntity> MAP_BOARD_BE_TYPE;
    public static BlockEntityType<TransitNewsBoardBlockEntity> NEWS_BOARD_BE_TYPE;
    public static BlockEntityType<VendingMachineBlockEntity> VENDING_BE_TYPE;
    public static BlockEntityType<ProgrammableBoardBlockEntity> PROGRAMMABLE_BOARD_BE_TYPE;

    // Configurable weather intensities (0 = clear, 1..5 = rain & thunder severity)
    public static volatile int rainIntensity = 0;
    public static volatile int thunderIntensity = 0;
    private static int serverTickCounter = 0;
    private static final Set<Integer> UPGRADED_TUNNEL_CHUNKS = new HashSet<>();
    private static final java.util.concurrent.ConcurrentLinkedQueue<Long> PENDING_HEAL_CHUNKS = new java.util.concurrent.ConcurrentLinkedQueue<>();
    private static final Set<Long> HEALED_CHUNKS_THIS_WORLD = new HashSet<>();
    private static ServerWorld lastTunnelUpgradeWorld = null;
    private static boolean railSpeedCappedThisSession = false;

    @Override
    public void onInitialize() {
        ORMAN_KART = Registry.register(
                Registries.ITEM,
                new Identifier(MOD_ID, "orman_kart"),
                new OrmanKartItem(new Item.Settings().maxCount(1))
        );

        WORLD_MAP_BOARD = registerBlock(
                "world_map_board",
                new WorldMapBoardBlock(AbstractBlock.Settings.create()
                        .strength(2.0f)
                        .nonOpaque()
                        .sounds(BlockSoundGroup.METAL)
                        .luminance(state -> 10))
        );

        TRANSIT_NEWS_BOARD = registerBlock(
                "transit_news_board",
                new TransitNewsBoardBlock(AbstractBlock.Settings.create()
                        .strength(2.0f)
                        .nonOpaque()
                        .sounds(BlockSoundGroup.METAL)
                        .luminance(state -> 10))
        );

        TUNNEL_EMERGENCY_LIGHT = registerBlock(
                "tunnel_emergency_light",
                new TunnelEmergencyLightBlock(AbstractBlock.Settings.create()
                        .strength(1.5f)
                        .nonOpaque()
                        .noCollision()
                        .sounds(BlockSoundGroup.METAL)
                        .luminance(state -> 15))
        );

        MAP_BOARD_BE_TYPE = Registry.register(
                Registries.BLOCK_ENTITY_TYPE,
                new Identifier(MOD_ID, "world_map_board_be"),
                FabricBlockEntityTypeBuilder.create(MapBoardBlockEntity::new, WORLD_MAP_BOARD).build()
        );

        NEWS_BOARD_BE_TYPE = Registry.register(
                Registries.BLOCK_ENTITY_TYPE,
                new Identifier(MOD_ID, "transit_news_board_be"),
                FabricBlockEntityTypeBuilder.create(TransitNewsBoardBlockEntity::new, TRANSIT_NEWS_BOARD).build()
        );

        METRO_BENCH = registerBlock(
                "metro_bench",
                new MetroBenchBlock(AbstractBlock.Settings.create()
                        .strength(2.0f)
                        .nonOpaque()
                        .sounds(BlockSoundGroup.WOOD))
        );

        VENDING_MACHINE = registerBlock(
                "vending_machine",
                new VendingMachineBlock(AbstractBlock.Settings.create()
                        .strength(2.5f)
                        .nonOpaque()
                        .sounds(BlockSoundGroup.METAL)
                        .luminance(state -> 11))
        );

        AD_LIGHTBOX = registerBlock(
                "ad_lightbox",
                new AdLightboxBlock(AbstractBlock.Settings.create()
                        .strength(2.0f)
                        .nonOpaque()
                        .sounds(BlockSoundGroup.GLASS)
                        .luminance(state -> 12))
        );

        INFO_KIOSK = registerBlock(
                "info_kiosk",
                new InfoKioskBlock(AbstractBlock.Settings.create()
                        .strength(2.5f)
                        .nonOpaque()
                        .sounds(BlockSoundGroup.METAL)
                        .luminance(state -> 12))
        );

        SAFETY_CABINET = registerBlock(
                "safety_cabinet",
                new SafetyCabinetBlock(AbstractBlock.Settings.create()
                        .strength(2.0f)
                        .nonOpaque()
                        .sounds(BlockSoundGroup.METAL)
                        .luminance(state -> 6))
        );

        VENDING_BE_TYPE = Registry.register(
                Registries.BLOCK_ENTITY_TYPE,
                new Identifier(MOD_ID, "vending_machine_be"),
                FabricBlockEntityTypeBuilder.create(VendingMachineBlockEntity::new, VENDING_MACHINE).build()
        );

        Identifier alarmId = new Identifier(MOD_ID, "tunnel_alarm_beep");
        TUNNEL_ALARM_BEEP_EVENT = Registry.register(
                Registries.SOUND_EVENT,
                alarmId,
                net.minecraft.sound.SoundEvent.of(alarmId)
        );

        PROGRAMMABLE_BOARD = registerBlock(
                "programmable_board",
                new ProgrammableBoardBlock(AbstractBlock.Settings.create()
                        .strength(2.5f)
                        .nonOpaque()
                        .sounds(BlockSoundGroup.METAL)
                        .luminance(state -> 12))
        );

        PROGRAMMABLE_BOARD_BE_TYPE = Registry.register(
                Registries.BLOCK_ENTITY_TYPE,
                new Identifier(MOD_ID, "programmable_board_be"),
                FabricBlockEntityTypeBuilder.create(ProgrammableBoardBlockEntity::new, PROGRAMMABLE_BOARD).build()
        );

        HIZMET_DISI_SERIT = registerBlock(
                "hizmet_disi_serit",
                new CautionTapeBlock(AbstractBlock.Settings.create()
                        .strength(0.35f)
                        .nonOpaque()
                        .noCollision()
                        .sounds(BlockSoundGroup.WOOL)
                        .luminance(state -> 4))
        );

        YAKINDA_SERIT = registerBlock(
                "yakinda_serit",
                new CautionTapeBlock(AbstractBlock.Settings.create()
                        .strength(0.35f)
                        .nonOpaque()
                        .noCollision()
                        .sounds(BlockSoundGroup.WOOL)
                        .luminance(state -> 4))
        );

        ItemGroupEvents.modifyEntriesEvent(RegistryKey.of(RegistryKeys.ITEM_GROUP, new Identifier("functional_blocks"))).register(entries -> {
            entries.add(ORMAN_KART);
            entries.add(WORLD_MAP_BOARD);
            entries.add(TRANSIT_NEWS_BOARD);
            entries.add(PROGRAMMABLE_BOARD);
            entries.add(HIZMET_DISI_SERIT);
            entries.add(YAKINDA_SERIT);
            entries.add(TUNNEL_EMERGENCY_LIGHT);
            entries.add(METRO_BENCH);
            entries.add(VENDING_MACHINE);
            entries.add(AD_LIGHTBOX);
            entries.add(INFO_KIOSK);
            entries.add(SAFETY_CABINET);
        });
        ItemGroupEvents.modifyEntriesEvent(RegistryKey.of(RegistryKeys.ITEM_GROUP, new Identifier("tools_and_utilities"))).register(entries -> {
            entries.add(ORMAN_KART);
            entries.add(HIZMET_DISI_SERIT);
            entries.add(YAKINDA_SERIT);
        });

        ArenaNewsManager.ensureLoaded();
        ai.arena.bridge.board.ProgrammableBoardManager.ensureLoaded();
        ai.arena.bridge.hotpatch.HotPatchManager.ensureLoaded();
        RegionPolicyEngine.ensureLoaded();

        net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.registerGlobalReceiver(
                VENDING_ACTION_PACKET,
                (server, player, handler, buf, responseSender) -> {
                    int op = buf.readByte();
                    int idx = buf.readVarInt();
                    BlockPos pos = buf.readBlockPos();
                    server.execute(() -> {
                        if (player == null || player.getServerWorld() == null) return;
                        ServerWorld sw = player.getServerWorld();
                        if (op == 0) {
                            handleVendingPurchase(sw, pos, player, idx);
                        } else {
                            boolean isEmerald = (op == 1);
                            Item reqItem = isEmerald ? Items.EMERALD : Items.GOLD_INGOT;
                            int add = isEmerald ? 10 : 5;
                            if (!player.getAbilities().creativeMode) {
                                int slot = player.getInventory().getSlotWithStack(new ItemStack(reqItem));
                                if (slot < 0) {
                                    player.sendMessage(Text.literal(
                                            isEmerald ? "Envanterde Zümrüt yok!" : "Envanterde Altın Külçesi yok!"
                                    ).formatted(Formatting.RED), true);
                                    return;
                                }
                                player.getInventory().getStack(slot).decrement(1);
                            }
                            int next = getPlayerMtrBalance(sw.getScoreboard(), player) + add;
                            setPlayerMtrBalance(server, player.getNameForScoreboard(), next);
                            sw.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.BLOCKS, 0.6f, 1.35f);
                            player.sendMessage(Text.literal("+" + add + " TL yüklendi! Bakiye: " + next + " TL").formatted(Formatting.GREEN), true);
                        }
                    });
                }
        );

        ServerLifecycleEvents.SERVER_STARTING.register(srv -> {
            this.registerCommands(srv);
            ai.arena.bridge.physics.GeoStructuralPhysicsEngine.loadBlueprintsFromDisk(srv);
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(srv -> {
            ai.arena.bridge.physics.GeoStructuralPhysicsEngine.saveBlueprintsToDisk(srv);
        });
        ServerChunkEvents.CHUNK_LOAD.register(this::onChunkLoadHeal);
        ServerTickEvents.END_SERVER_TICK.register(this::onServerTick);
    }

    /**
     * Lock-free, deadlock-proof chunk load listener:
     * NEVER calls world.getBlockState / world.setBlockState / world.getChunk inside CHUNK_LOAD
     * (which causes a re-entrant ServerChunkManager deadlock at 100% world load!).
     * Only enqueues the packed ChunkPos long to be processed safely on END_SERVER_TICK after player join.
     */
    public void onChunkLoadHeal(ServerWorld world, WorldChunk chunk) {
        if (world == null || chunk == null || world.getRegistryKey() != World.OVERWORLD) return;
        int cx = chunk.getPos().x;
        int cz = chunk.getPos().z;
        if (cx >= -3 && cx <= -1 && cz >= -3 && cz <= 101) {
            PENDING_HEAL_CHUNKS.offer(chunk.getPos().toLong());
        }
    }

    private void processPendingHealChunks(ServerWorld world) {
        if (world == null || world.getPlayers().isEmpty()) return;
        BlockPos.Mutable mp = new BlockPos.Mutable();
        int processed = 0;
        int scanned = 0;
        int qSize = PENDING_HEAL_CHUNKS.size();
        while (processed < 3 && scanned < Math.min(24, qSize)) {
            scanned++;
            Long keyObj = PENDING_HEAL_CHUNKS.poll();
            if (keyObj == null) break;
            long key = keyObj;
            if (HEALED_CHUNKS_THIS_WORLD.contains(key)) continue;
            int cx = net.minecraft.util.math.ChunkPos.getPackedX(key);
            int cz = net.minecraft.util.math.ChunkPos.getPackedZ(key);
            if (!world.isChunkLoaded(cx, cz)) {
                // Keep queued until player travels near this chunk!
                PENDING_HEAL_CHUNKS.offer(key);
                continue;
            }

            boolean isStationChunk = cx >= -3 && cx <= -1 && ((cz >= 0 && cz <= 3) || (cz >= 97 && cz <= 100));
            HEALED_CHUNKS_THIS_WORLD.add(key);
            processed++;

            if (cx == (-18 >> 4)) {
                int zStart = cz << 4;
                for (int lz = 0; lz < 16; lz++) {
                    int z = zStart + lz;
                    BlockState crown = world.getBlockState(mp.set(-18, 53, z));
                    if (crown.isOf(Blocks.STONE_BRICKS)) {
                        BlockState rail = world.getBlockState(mp.set(-18, 48, z));
                        String railId = Registries.BLOCK.getId(rail.getBlock()).toString();
                        if (railId.startsWith("mtr:rail")) {
                            BlockPos ledPos = new BlockPos(-18, 52, z);
                            BlockState cur = world.getBlockState(ledPos);
                            if (!cur.isOf(TUNNEL_EMERGENCY_LIGHT) || !cur.get(CEILING)) {
                                world.setBlockState(
                                        ledPos,
                                        TUNNEL_EMERGENCY_LIGHT.getDefaultState()
                                                .with(CEILING, true)
                                                .with(FACING, Direction.NORTH)
                                                .with(EMERGENCY, false),
                                        Block.NOTIFY_LISTENERS
                                );
                            }
                        }
                    }
                }
            }

            if (isStationChunk) {
                int x0 = cx << 4, z0 = cz << 4;
                for (int y = 48; y <= 60; y++) {
                    for (int dx = 0; dx < 16; dx++) {
                        for (int dz = 0; dz < 16; dz++) {
                            BlockPos bp = new BlockPos(x0 + dx, y, z0 + dz);
                            BlockState bs = world.getBlockState(bp);
                            if ((bs.isOf(VENDING_MACHINE) || bs.isOf(INFO_KIOSK)) && bs.get(HALF) == DoubleBlockHalf.LOWER) {
                                BlockPos up = bp.up();
                                BlockState upSt = world.getBlockState(up);
                                if (upSt.isAir()) {
                                    world.setBlockState(up, bs.with(HALF, DoubleBlockHalf.UPPER), Block.NOTIFY_LISTENERS);
                                }
                            } else if (bs.isOf(METRO_BENCH)) {
                                BenchPart desired = MetroBenchBlock.computeBenchPart(world, bp, bs.get(FACING));
                                if (bs.get(BENCH_PART) != desired) {
                                    world.setBlockState(bp, bs.with(BENCH_PART, desired), Block.NOTIFY_LISTENERS);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private static Block registerBlock(String name, Block block) {
        Identifier id = new Identifier(MOD_ID, name);
        Block registered = Registry.register(Registries.BLOCK, id, block);
        Registry.register(Registries.ITEM, id, new BlockItem(registered, new Item.Settings()));
        return registered;
    }

    // ==================== PLAYER & MTR BALANCE HELPERS ====================

    public static boolean playerHasOrmanKart(PlayerEntity player) {
        if (player == null) return false;
        for (int i = 0; i < player.getInventory().size(); i++) {
            ItemStack st = player.getInventory().getStack(i);
            if (!st.isEmpty() && st.isOf(ORMAN_KART)) return true;
        }
        return false;
    }

    public static int getPlayerMtrBalance(Scoreboard sb, PlayerEntity player) {
        if (sb == null || player == null) return 0;
        ScoreboardObjective obj = sb.getNullableObjective("mtr_balance");
        if (obj == null) return 0;
        ReadableScoreboardScore score = sb.getScore(ScoreHolder.fromProfile(player.getGameProfile()), obj);
        return score != null ? score.getScore() : 0;
    }

    public static void setPlayerMtrBalance(MinecraftServer server, String playerName, int amount) {
        if (server == null) return;
        Scoreboard sb = server.getScoreboard();
        ScoreboardObjective obj = sb.getNullableObjective("mtr_balance");
        if (obj == null) {
            obj = sb.addObjective("mtr_balance", ScoreboardCriterion.DUMMY, Text.literal("Balance"), ScoreboardCriterion.RenderType.INTEGER, true, null);
        }
        ScoreAccess access = sb.getOrCreateScore(ScoreHolder.fromName(playerName), obj);
        access.setScore(amount);
    }

    /**
     * Multiplayer-safe single-shot voice alert: speaks ONLY on the rejected player's client.
     */
    public static void onTurnstileDeniedForPlayer(PlayerEntity deniedPlayer) {
        if (deniedPlayer == null) return;
        if (FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT) {
            ClientDeniedVoiceBridge.playIfLocalPlayer(deniedPlayer.getUuid());
        }
    }

    private static final class ClientDeniedVoiceBridge {
        static void playIfLocalPlayer(UUID deniedUuid) {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc != null && mc.player != null && mc.player.getUuid().equals(deniedUuid)) {
                LocalTtsManager.speakAsync("Yetersiz bakiye.", "denied", 0.95f, true);
            }
        }
    }

    // ==================== WEATHER & AUTOMATIC STORM ENGINE ====================

    public static void applyServerWeather(ServerWorld overworld, String mode, int rainLvl, int thunderLvl) {
        if (overworld == null) return;
        int r = Math.max(0, Math.min(5, rainLvl));
        int t = Math.max(0, Math.min(5, thunderLvl));
        if ("clear".equalsIgnoreCase(mode) || "temiz".equalsIgnoreCase(mode) || (r == 0 && t == 0)) {
            rainIntensity = 0;
            thunderIntensity = 0;
            overworld.setWeather(24000, 0, false, false);
            ai.arena.bridge.physics.GeoStructuralPhysicsEngine.syncStormEmergencyLights(overworld, false);
        } else if ("rain".equalsIgnoreCase(mode) || "yagmur".equalsIgnoreCase(mode)) {
            rainIntensity = Math.max(1, r);
            thunderIntensity = 0;
            overworld.setWeather(0, 18000, true, false);
            ai.arena.bridge.physics.GeoStructuralPhysicsEngine.syncStormEmergencyLights(overworld, false);
        } else {
            rainIntensity = Math.max(1, r);
            thunderIntensity = Math.max(1, t);
            // Prevent uncontrolled fire spread onto wooden roofs while keeping real fire ignition on strike!
            overworld.getGameRules().get(GameRules.DO_FIRE_TICK).set(false, overworld.getServer());
            overworld.setWeather(0, 18000, true, true);
            ai.arena.bridge.physics.GeoStructuralPhysicsEngine.syncStormEmergencyLights(overworld, thunderIntensity >= 2);
        }
    }

    private void registerCommands(MinecraftServer server) {
        server.getCommandManager().getDispatcher().register(
                CommandManager.literal("firtina")
                        .executes(ctx -> {
                            applyServerWeather(ctx.getSource().getServer().getOverworld(), "thunder", 2, 2);
                            ctx.getSource().sendFeedback(() -> Text.literal(
                                    "Fırtına başlatıldı (Yağış: 2/5, Gök Gürültüsü: 2/5 — Tünel Acil Durum LED'leri Otomatik Aktif)."
                            ).formatted(Formatting.GRAY), true);
                            return 1;
                        })
                        .then(CommandManager.argument("siddet", IntegerArgumentType.integer(0, 5))
                                .executes(ctx -> {
                                    int lvl = IntegerArgumentType.getInteger(ctx, "siddet");
                                    applyServerWeather(ctx.getSource().getServer().getOverworld(), lvl == 0 ? "clear" : "thunder", lvl, lvl);
                                    String m = lvl == 0
                                            ? "Hava durumu açık olarak ayarlandı (Tünel LED'leri normal moda döndü)."
                                            : ("Fırtına şiddeti " + lvl + "/5 olarak ayarlandı.");
                                    ctx.getSource().sendFeedback(() -> Text.literal(m).formatted(Formatting.GRAY), true);
                                    return 1;
                                })
                                .then(CommandManager.argument("gok_gurultusu", IntegerArgumentType.integer(0, 5))
                                        .executes(ctx -> {
                                            int rLvl = IntegerArgumentType.getInteger(ctx, "siddet");
                                            int tLvl = IntegerArgumentType.getInteger(ctx, "gok_gurultusu");
                                            String mode = (rLvl == 0 && tLvl == 0) ? "clear" : (tLvl == 0 ? "rain" : "thunder");
                                            applyServerWeather(ctx.getSource().getServer().getOverworld(), mode, rLvl, tLvl);
                                            ctx.getSource().sendFeedback(() -> Text.literal(
                                                    "Hava durumu ayarlandı — Yağış: " + rLvl + "/5, Gök Gürültüsü: " + tLvl + "/5."
                                            ).formatted(Formatting.GRAY), true);
                                            return 1;
                                        })))
        );

        server.getCommandManager().getDispatcher().register(
                CommandManager.literal("havadurumu")
                        .then(CommandManager.literal("temiz").executes(ctx -> {
                            applyServerWeather(ctx.getSource().getServer().getOverworld(), "clear", 0, 0);
                            ctx.getSource().sendFeedback(() -> Text.literal("Hava durumu açık olarak ayarlandı.").formatted(Formatting.GRAY), true);
                            return 1;
                        }))
                        .then(CommandManager.literal("yagmur")
                                .executes(ctx -> {
                                    applyServerWeather(ctx.getSource().getServer().getOverworld(), "rain", 2, 0);
                                    ctx.getSource().sendFeedback(() -> Text.literal("Yağmurlu hava başlatıldı (2/5).").formatted(Formatting.GRAY), true);
                                    return 1;
                                })
                                .then(CommandManager.argument("siddet", IntegerArgumentType.integer(1, 5))
                                        .executes(ctx -> {
                                            int lvl = IntegerArgumentType.getInteger(ctx, "siddet");
                                            applyServerWeather(ctx.getSource().getServer().getOverworld(), "rain", lvl, 0);
                                            ctx.getSource().sendFeedback(() -> Text.literal("Yağmur şiddeti " + lvl + "/5 olarak ayarlandı.").formatted(Formatting.GRAY), true);
                                            return 1;
                                        })))
                        .then(CommandManager.literal("firtina")
                                .executes(ctx -> {
                                    applyServerWeather(ctx.getSource().getServer().getOverworld(), "thunder", 2, 2);
                                    ctx.getSource().sendFeedback(() -> Text.literal("Fırtına başlatıldı (2/5).").formatted(Formatting.GRAY), true);
                                    return 1;
                                })
                                .then(CommandManager.argument("siddet", IntegerArgumentType.integer(1, 5))
                                        .executes(ctx -> {
                                            int lvl = IntegerArgumentType.getInteger(ctx, "siddet");
                                            applyServerWeather(ctx.getSource().getServer().getOverworld(), "thunder", lvl, lvl);
                                            ctx.getSource().sendFeedback(() -> Text.literal("Fırtına şiddeti " + lvl + "/5 olarak ayarlandı.").formatted(Formatting.GRAY), true);
                                            return 1;
                                        })
                                        .then(CommandManager.argument("gok_gurultusu", IntegerArgumentType.integer(1, 5))
                                                .executes(ctx -> {
                                                    int rLvl = IntegerArgumentType.getInteger(ctx, "siddet");
                                                    int tLvl = IntegerArgumentType.getInteger(ctx, "gok_gurultusu");
                                                    applyServerWeather(ctx.getSource().getServer().getOverworld(), "thunder", rLvl, tLvl);
                                                    ctx.getSource().sendFeedback(() -> Text.literal(
                                                            "Fırtına ayarlandı — Yağış: " + rLvl + "/5, Gök Gürültüsü: " + tLvl + "/5."
                                                    ).formatted(Formatting.GRAY), true);
                                                    return 1;
                                                }))))
        );

        server.getCommandManager().getDispatcher().register(
                CommandManager.literal("hatfizik")
                        .executes(ctx -> {
                            ServerWorld ow = ctx.getSource().getServer().getOverworld();
                            RailPhysicsEngine.CorridorPhysicsDecision d = FabricLoader.getInstance().isModLoaded("mtr")
                                    ? RailPhysicsEngine.synchronizeSimulatorWithRealPhysics(ow, true)
                                    : RailPhysicsEngine.evaluateCorridorPhysics(1548.0, true);
                            if (d == null) {
                                d = RailPhysicsEngine.evaluateCorridorPhysics(1548.0, true);
                            }
                            for (String line : RailPhysicsEngine.formatTurkishReportLines(d)) {
                                ctx.getSource().sendFeedback(() -> Text.literal(line).formatted(
                                        line.startsWith("=>") ? Formatting.GREEN : Formatting.GRAY
                                ), false);
                            }
                            return 1;
                        })
                        .then(CommandManager.argument("mesafe_metre", IntegerArgumentType.integer(100, 100000))
                                .executes(ctx -> {
                                    int m = IntegerArgumentType.getInteger(ctx, "mesafe_metre");
                                    RailPhysicsEngine.CorridorPhysicsDecision d = RailPhysicsEngine.evaluateCorridorPhysics(m, true);
                                    for (String line : RailPhysicsEngine.formatTurkishReportLines(d)) {
                                        ctx.getSource().sendFeedback(() -> Text.literal(line).formatted(
                                                line.startsWith("=>") ? Formatting.AQUA : Formatting.GRAY
                                        ), false);
                                    }
                                    return 1;
                                }))
        );

        // Open-ended Dynamic Region Management (/bolge bilgi | /bolge tanimla <kod> <x1> <z1> <x2> <z2> <isim> | /bolge sil <kod>)
        server.getCommandManager().getDispatcher().register(
                CommandManager.literal("bolge")
                        .executes(ctx -> {
                            ServerPlayerEntity sp = ctx.getSource().getPlayer();
                            BlockPos bp = sp != null ? sp.getBlockPos() : BlockPos.ORIGIN;
                            Set<String> tags = RegionPolicyEngine.getActiveRegionIds(ctx.getSource().getWorld(), bp);
                            String disp = RegionPolicyEngine.getPrimaryRegionDisplay(ctx.getSource().getWorld(), bp);
                            ctx.getSource().sendFeedback(() -> Text.literal(
                                    "Aktif Bölge: " + disp + " (Etiketler: " + String.join(", ", tags) + ")"
                            ).formatted(Formatting.GREEN), false);
                            return 1;
                        })
                        .then(CommandManager.literal("bilgi").executes(ctx -> {
                            ServerPlayerEntity sp = ctx.getSource().getPlayer();
                            BlockPos bp = sp != null ? sp.getBlockPos() : BlockPos.ORIGIN;
                            Set<String> tags = RegionPolicyEngine.getActiveRegionIds(ctx.getSource().getWorld(), bp);
                            String disp = RegionPolicyEngine.getPrimaryRegionDisplay(ctx.getSource().getWorld(), bp);
                            ctx.getSource().sendFeedback(() -> Text.literal(
                                    "Aktif Bölge: " + disp + " | Kodlar: " + String.join(", ", tags)
                                            + " | Kayıtlı Özel Bölge Sayısı: " + RegionPolicyEngine.getExplicitRegions().size()
                            ).formatted(Formatting.AQUA), false);
                            return 1;
                        }))
                        .then(CommandManager.literal("tanimla")
                                .then(CommandManager.argument("kod", StringArgumentType.word())
                                        .then(CommandManager.argument("x1", IntegerArgumentType.integer())
                                                .then(CommandManager.argument("z1", IntegerArgumentType.integer())
                                                        .then(CommandManager.argument("x2", IntegerArgumentType.integer())
                                                                .then(CommandManager.argument("z2", IntegerArgumentType.integer())
                                                                        .then(CommandManager.argument("isim", StringArgumentType.greedyString())
                                                                                .executes(ctx -> {
                                                                                    String kod = StringArgumentType.getString(ctx, "kod");
                                                                                    int x1 = IntegerArgumentType.getInteger(ctx, "x1");
                                                                                    int z1 = IntegerArgumentType.getInteger(ctx, "z1");
                                                                                    int x2 = IntegerArgumentType.getInteger(ctx, "x2");
                                                                                    int z2 = IntegerArgumentType.getInteger(ctx, "z2");
                                                                                    String isim = StringArgumentType.getString(ctx, "isim");
                                                                                    RegionPolicyEngine.defineOrUpdateRegion(kod, isim, x1, z1, x2, z2);
                                                                                    ctx.getSource().sendFeedback(() -> Text.literal(
                                                                                            "Yeni bölge tanımlandı: " + isim + " [" + RegionPolicyEngine.normalizeId(kod) + "] ("
                                                                                                    + x1 + "," + z1 + " -> " + x2 + "," + z2 + ")"
                                                                                    ).formatted(Formatting.GREEN), true);
                                                                                    return 1;
                                                                                }))))))))
                        .then(CommandManager.literal("sil")
                                .then(CommandManager.argument("kod", StringArgumentType.word())
                                        .executes(ctx -> {
                                            String kod = StringArgumentType.getString(ctx, "kod");
                                            boolean ok = RegionPolicyEngine.removeRegionById(kod);
                                            ctx.getSource().sendFeedback(() -> Text.literal(
                                                    ok ? ("Bölge silindi: " + kod) : ("Bölge bulunamadı: " + kod)
                                            ).formatted(ok ? Formatting.YELLOW : Formatting.RED), true);
                                            return ok ? 1 : 0;
                                        })))
        );

        // Open-ended Regional Transit & Discount Card Minter (/kart ver <bolge_kodu> <bilet_ind_yuzde> <otomat_ind_yuzde> <kart_adi>)
        server.getCommandManager().getDispatcher().register(
                CommandManager.literal("kart")
                        .then(CommandManager.literal("ver")
                                .then(CommandManager.argument("bolge_kodu", StringArgumentType.word())
                                        .then(CommandManager.argument("bilet_indirim", IntegerArgumentType.integer(0, 100))
                                                .then(CommandManager.argument("alisveris_indirim", IntegerArgumentType.integer(0, 90))
                                                        .then(CommandManager.argument("kart_adi", StringArgumentType.greedyString())
                                                                .executes(ctx -> {
                                                                    ServerPlayerEntity sp = ctx.getSource().getPlayerOrThrow();
                                                                    String reg = StringArgumentType.getString(ctx, "bolge_kodu");
                                                                    int td = IntegerArgumentType.getInteger(ctx, "bilet_indirim");
                                                                    int sd = IntegerArgumentType.getInteger(ctx, "alisveris_indirim");
                                                                    String nm = StringArgumentType.getString(ctx, "kart_adi");
                                                                    ItemStack card = RegionPolicyEngine.createCustomRegionalCard(reg, td, sd, nm);
                                                                    sp.giveItemStack(card);
                                                                    ctx.getSource().sendFeedback(() -> Text.literal(
                                                                            nm + " verildi (Bölge: " + RegionPolicyEngine.normalizeId(reg)
                                                                                    + ", Bilet: %" + td + ", Otomat/Mağaza: %" + sd + ")."
                                                                    ).formatted(Formatting.GREEN), false);
                                                                    return 1;
                                                                }))))))
        );

        // Native Vending Screen Command Handler (/otomat al <idx> <x> <y> <z> | /otomat yukle <zumrut|altin>)
        server.getCommandManager().getDispatcher().register(
                CommandManager.literal("otomat")
                        .then(CommandManager.literal("al")
                                .then(CommandManager.argument("idx", IntegerArgumentType.integer(0, 8))
                                        .then(CommandManager.argument("mx", IntegerArgumentType.integer())
                                                .then(CommandManager.argument("my", IntegerArgumentType.integer())
                                                        .then(CommandManager.argument("mz", IntegerArgumentType.integer())
                                                                .executes(ctx -> {
                                                                    ServerPlayerEntity sp = ctx.getSource().getPlayerOrThrow();
                                                                    int idx = IntegerArgumentType.getInteger(ctx, "idx");
                                                                    BlockPos mp = new BlockPos(
                                                                            IntegerArgumentType.getInteger(ctx, "mx"),
                                                                            IntegerArgumentType.getInteger(ctx, "my"),
                                                                            IntegerArgumentType.getInteger(ctx, "mz")
                                                                    );
                                                                    return handleVendingPurchase(ctx.getSource().getWorld(), mp, sp, idx);
                                                                }))))))
                        .then(CommandManager.literal("yukle")
                                .then(CommandManager.argument("tip", StringArgumentType.word())
                                        .executes(ctx -> {
                                            ServerPlayerEntity sp = ctx.getSource().getPlayerOrThrow();
                                            String tip = StringArgumentType.getString(ctx, "tip");
                                            boolean isEmerald = "zumrut".equalsIgnoreCase(tip);
                                            Item reqItem = isEmerald ? Items.EMERALD : Items.GOLD_INGOT;
                                            int add = isEmerald ? 10 : 5;
                                            if (!sp.getAbilities().creativeMode) {
                                                int slot = sp.getInventory().getSlotWithStack(new ItemStack(reqItem));
                                                if (slot < 0) {
                                                    sp.sendMessage(Text.literal(
                                                            (isEmerald ? "Envanterde Zümrüt yok!" : "Envanterde Altın Külçesi yok!")
                                                    ).formatted(Formatting.RED), true);
                                                    return 0;
                                                }
                                                sp.getInventory().getStack(slot).decrement(1);
                                            }
                                            int cur = getPlayerMtrBalance(sp.getWorld().getScoreboard(), sp);
                                            int next = cur + add;
                                            setPlayerMtrBalance(ctx.getSource().getServer(), sp.getNameForScoreboard(), next);
                                            sp.getWorld().playSound(null, sp.getBlockPos(), SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.BLOCKS, 0.6f, 1.35f);
                                            sp.sendMessage(Text.literal("+" + add + " TL yüklendi! Bakiye: " + next + " TL").formatted(Formatting.GREEN), true);
                                            return 1;
                                        })))
        );

        // Geotechnical & Structural Radar toggle (/radar)
        server.getCommandManager().getDispatcher().register(
                CommandManager.literal("radar").executes(ctx -> {
                    if (FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT) {
                        ai.arena.bridge.client.LiveRigidBodyRenderer.radarOpen = !ai.arena.bridge.client.LiveRigidBodyRenderer.radarOpen;
                        ctx.getSource().sendFeedback(() -> Text.literal(
                                ai.arena.bridge.client.LiveRigidBodyRenderer.radarOpen
                                        ? "Jeoteknik ve Yapısal Radar açıldı (R tuşu ile de açıp kapatabilirsin)."
                                        : "Jeoteknik ve Yapısal Radar kapatıldı."
                        ).formatted(Formatting.AQUA), false);
                    }
                    return 1;
                })
        );

        // Engineering Structural Repair (/onar [hepsi]) — wired to BOTH Physics Mod Pro (NVIDIA PhysX 5) & ArenaAI!
        server.getCommandManager().getDispatcher().register(
                CommandManager.literal("onar")
                        .executes(ctx -> {
                            BlockPos origin = BlockPos.ofFloored(ctx.getSource().getPosition());
                            System.getProperties().put("arena.overworld.ref", ctx.getSource().getWorld());
                            int physModRestored = invokePhysicsModRepair(origin.getX(), origin.getY(), origin.getZ(), 80.0, false);
                            int proRestored = ai.arena.bridge.physics.pro.FractureAndSolidifier.repairStructuresNear(
                                    ctx.getSource().getWorld(), origin, 80.0
                            );
                            int n = physModRestored + proRestored + ai.arena.bridge.physics.GeoStructuralPhysicsEngine.repairStructuralDamageNear(
                                    ctx.getSource().getWorld(), origin, 80.0
                            );
                            ctx.getSource().sendFeedback(() -> Text.literal(
                                    n > 0 ? ("§a[Onarım] Physics Mod Pro enkazı temizlendi ve yıkılan yapı eski haline döndürüldü (" + n + " blok onarıldı)!")
                                          : "80m çevrede onarılacak yıkılmış yapı bulunamadı."
                            ).formatted(Formatting.GREEN), true);
                            return 1;
                        })
                        .then(CommandManager.literal("hepsi").executes(ctx -> {
                            BlockPos origin = BlockPos.ofFloored(ctx.getSource().getPosition());
                            System.getProperties().put("arena.overworld.ref", ctx.getSource().getWorld());
                            int physModRestored = invokePhysicsModRepair(origin.getX(), origin.getY(), origin.getZ(), 100000.0, true);
                            ai.arena.bridge.physics.pro.FractureAndSolidifier.rewindAllBlueprints(ctx.getSource().getWorld());
                            int n = physModRestored + ai.arena.bridge.physics.GeoStructuralPhysicsEngine.repairStructuralDamageNear(
                                    ctx.getSource().getWorld(), origin, 5000.0
                            );
                            ctx.getSource().sendFeedback(() -> Text.literal(
                                    "§a[Onarım] Tüm dünyadaki Physics Mod Pro enkazları temizlendi ve yıkılan yapılar eski haline döndürüldü (" + n + " blok)!"
                            ).formatted(Formatting.GREEN), true);
                            return 1;
                        }))
        );

        // Scientific Physics Telemetry & Scenario Trigger (/fizik durum | yikim | su | catlak | cokme | bina)
        server.getCommandManager().getDispatcher().register(
                CommandManager.literal("fizik")
                        .executes(ctx -> {
                            ctx.getSource().sendFeedback(() -> Text.literal(String.format(
                                    java.util.Locale.US,
                                    "Fizik Motoru Aktif — Tünel Min FoS: %.2f (Z=%dm) | u_w: %.1f kPa | Su: %.0f mm | Kolon DCR: %%%.0f | 6-DoF Blok: %d | Tren Wz: %.2f",
                                    ai.arena.bridge.physics.GeoStructuralPhysicsEngine.latestMinTunnelFos,
                                    ai.arena.bridge.physics.GeoStructuralPhysicsEngine.latestCriticalRingZ,
                                    ai.arena.bridge.physics.GeoStructuralPhysicsEngine.latestMaxPoreWaterKpa,
                                    ai.arena.bridge.physics.GeoStructuralPhysicsEngine.latestMaxWaterDepthMm,
                                    ai.arena.bridge.physics.GeoStructuralPhysicsEngine.latestNearestColumnDcr * 100.0,
                                    ai.arena.bridge.physics.GeoStructuralPhysicsEngine.RIGID_BODIES.size(),
                                    ai.arena.bridge.physics.GeoStructuralPhysicsEngine.clientSperlingWz
                            )).formatted(Formatting.AQUA), false);
                            return 1;
                        })
                        .then(CommandManager.argument("mod", StringArgumentType.word()).executes(ctx -> {
                            ServerPlayerEntity sp = ctx.getSource().getPlayerOrThrow();
                            String mod = StringArgumentType.getString(ctx, "mod");
                            String msg = ai.arena.bridge.physics.GeoStructuralPhysicsEngine.simulateScenario(
                                    ctx.getSource().getWorld(), sp.getBlockPos(), mod
                            );
                            ctx.getSource().sendFeedback(() -> Text.literal(msg).formatted(Formatting.GOLD), true);
                            return 1;
                        }))
        );

        // Multi-Size Programmable Board & Highway Gantry Configurator (/pano <genislik> <yukseklik> <stil> <tema> <id>)
        server.getCommandManager().getDispatcher().register(
                CommandManager.literal("pano")
                        .then(CommandManager.argument("genislik", IntegerArgumentType.integer(1, 8))
                                .then(CommandManager.argument("yukseklik", IntegerArgumentType.integer(1, 4))
                                        .then(CommandManager.argument("stil", StringArgumentType.word())
                                                .then(CommandManager.argument("tema", StringArgumentType.word())
                                                        .then(CommandManager.argument("id", StringArgumentType.word())
                                                                .executes(ctx -> {
                                                                    ServerPlayerEntity sp = ctx.getSource().getPlayerOrThrow();
                                                                    int w = IntegerArgumentType.getInteger(ctx, "genislik");
                                                                    int h = IntegerArgumentType.getInteger(ctx, "yukseklik");
                                                                    String stil = StringArgumentType.getString(ctx, "stil").toLowerCase(java.util.Locale.ROOT);
                                                                    String tema = StringArgumentType.getString(ctx, "tema");
                                                                    String id = StringArgumentType.getString(ctx, "id");
                                                                    net.minecraft.util.hit.HitResult hr = sp.raycast(8.0, 0.0f, false);
                                                                    if (hr instanceof BlockHitResult bhr) {
                                                                        BlockPos bp = bhr.getBlockPos();
                                                                        ServerWorld sw = ctx.getSource().getWorld();
                                                                        BlockState bs = sw.getBlockState(bp);
                                                                        if (bs.isOf(PROGRAMMABLE_BOARD)) {
                                                                            BoardMount mnt = switch (stil) {
                                                                                case "stand" -> BoardMount.STAND;
                                                                                case "poster" -> BoardMount.POSTER;
                                                                                case "gantry", "otoban" -> BoardMount.GANTRY;
                                                                                default -> BoardMount.WALL;
                                                                            };
                                                                            sw.setBlockState(bp, bs.with(BOARD_MOUNT, mnt), Block.NOTIFY_ALL);
                                                                            BlockEntity be = sw.getBlockEntity(bp);
                                                                            if (be instanceof ProgrammableBoardBlockEntity pbe) {
                                                                                pbe.boardId = id;
                                                                                pbe.customWidth = w;
                                                                                pbe.customHeight = h;
                                                                                pbe.customTheme = tema;
                                                                                pbe.markDirty();
                                                                                sw.getChunkManager().markForUpdate(bp);
                                                                            }
                                                                            ctx.getSource().sendFeedback(() -> Text.literal(
                                                                                    "Pano güncellendi: " + w + "x" + h + "m (" + stil + ", tema=" + tema + ", id=" + id + ")"
                                                                            ).formatted(Formatting.GREEN), false);
                                                                            return 1;
                                                                        }
                                                                    }
                                                                    ctx.getSource().sendFeedback(() -> Text.literal(
                                                                            "Önce bir Programlanabilir Pano bloğuna bakmalısın!"
                                                                    ).formatted(Formatting.RED), false);
                                                                    return 0;
                                                                }))))))
        );
    }

    private static int handleVendingPurchase(ServerWorld sw, BlockPos pos, ServerPlayerEntity player, int idx) {
        Item[] items = {
                Items.APPLE, Items.BREAD, Items.COOKIE,
                Items.SWEET_BERRIES, Items.GOLDEN_CARROT, Items.POTION,
                Items.HONEY_BOTTLE, Items.BAKED_POTATO, Items.GLOW_BERRIES
        };
        int[] bases = { 4, 4, 4, 4, 6, 3, 7, 5, 5 };
        int safeIdx = Math.max(0, Math.min(items.length - 1, idx));
        int curBal = getPlayerMtrBalance(sw.getScoreboard(), player);
        int price = RegionPolicyEngine.computeShopPrice(sw, pos, player, bases[safeIdx]);
        int disc = RegionPolicyEngine.getBestShopDiscountPct(sw, pos, player);
        boolean creative = player.getAbilities().creativeMode;

        if (!creative && curBal < price) {
            sw.playSound(null, pos, SoundEvents.BLOCK_NOTE_BLOCK_BASS.value(), SoundCategory.BLOCKS, 0.7f, 0.7f);
            player.sendMessage(Text.literal("Yetersiz bakiye! Gerekli: " + price + " TL (Mevcut: " + curBal + " TL)").formatted(Formatting.RED), true);
            return 0;
        }
        int nextBal = creative ? curBal : (curBal - price);
        if (!creative) {
            setPlayerMtrBalance(sw.getServer(), player.getNameForScoreboard(), nextBal);
        }
        player.giveItemStack(new ItemStack(items[safeIdx], 1));
        sw.playSound(null, pos, SoundEvents.BLOCK_DISPENSER_DISPENSE, SoundCategory.BLOCKS, 0.7f, 1.2f);
        String note = disc > 0 ? (" (%" + disc + " Bölge Kart İndirimi)") : "";
        player.sendMessage(Text.literal("Satın alındı! -" + price + " TL" + note + " • Kalan: " + nextBal + " TL").formatted(Formatting.AQUA), true);
        return 1;
    }

    private void onServerTick(MinecraftServer server) {
        serverTickCounter++;

        ServerWorld overworld = server.getOverworld();
        if (overworld != null) {
            RailPhysicsEngine.wetOutdoorRails = overworld.isRaining() || overworld.isThundering();
            if (lastTunnelUpgradeWorld != overworld) {
                lastTunnelUpgradeWorld = overworld;
                UPGRADED_TUNNEL_CHUNKS.clear();
                HEALED_CHUNKS_THIS_WORLD.clear();
                railSpeedCappedThisSession = false;
                // Seed corridor & station chunks into queue so already-loaded spawn chunks are healed too
                for (int cx = -3; cx <= -1; cx++) {
                    for (int cz = -3; cz <= 101; cz++) {
                        PENDING_HEAL_CHUNKS.offer(net.minecraft.util.math.ChunkPos.toLong(cx, cz));
                    }
                }
            }
            if (serverTickCounter > 40) {
                processPendingHealChunks(overworld);
                ai.arena.bridge.physics.GeoStructuralPhysicsEngine.onServerTick(server);
            }
            if (!ACTIVE_BENCH_SEATS.isEmpty()) {
                for (net.minecraft.entity.decoration.ArmorStandEntity seat : ACTIVE_BENCH_SEATS) {
                    if (seat == null || !seat.isAlive() || !seat.hasPassengers()) {
                        if (seat != null && seat.isAlive()) seat.discard();
                        ACTIVE_BENCH_SEATS.remove(seat);
                    }
                }
            }
            ai.arena.bridge.hotpatch.HotPatchManager.onServerTick(server);
        }

        // Every 5 seconds: enforce full passenger dwell + synchronize MTR corridor & Siding traction/braking physics!
        if (serverTickCounter % 100 == 20 && FabricLoader.getInstance().isModLoaded("mtr")) {
            MtrBridgeHelper.enforceGuaranteedStationDwell();
            if (!railSpeedCappedThisSession && overworld != null) {
                RailPhysicsEngine.CorridorPhysicsDecision phys =
                        RailPhysicsEngine.synchronizeSimulatorWithRealPhysics(overworld, true);
                if (phys != null) {
                    railSpeedCappedThisSession = true;
                }
            }
        }

        if (overworld == null || !overworld.isThundering()) return;

        int effThunder = Math.max(1, thunderIntensity);
        if (effThunder < 2) return; // Level 1 uses vanilla thunderstorm cadence

        int intervalTicks = Math.max(65, 330 - effThunder * 52);
        if (serverTickCounter % intervalTicks != 0) return;

        List<ServerPlayerEntity> players = overworld.getPlayers();
        if (players.isEmpty()) return;
        Random rng = overworld.getRandom();
        ServerPlayerEntity anchor = players.get(rng.nextInt(players.size()));

        double angle = rng.nextDouble() * Math.PI * 2.0;
        double dist = 24.0 + rng.nextDouble() * 64.0;
        int lx = (int) Math.round(anchor.getX() + Math.cos(angle) * dist);
        int lz = (int) Math.round(anchor.getZ() + Math.sin(angle) * dist);
        if (!overworld.isChunkLoaded(lx >> 4, lz >> 4)) return;

        // 1. Prioritize nearby lightning rods within 40m (authentic vanilla lightning rod physics!)
        BlockPos rodTarget = findNearbyLightningRod(overworld, lx, lz, 40);
        BlockPos strikePos = rodTarget;

        if (strikePos == null) {
            int ly = overworld.getTopY(Heightmap.Type.MOTION_BLOCKING, lx, lz);
            BlockPos below = new BlockPos(lx, ly - 1, lz);
            BlockState surface = overworld.getBlockState(below);
            // Protect crafted wooden building roofs (planks/slabs/stairs/fences) if unrodded
            if (surface.isIn(BlockTags.PLANKS) || surface.isIn(BlockTags.WOODEN_SLABS)
                    || surface.isIn(BlockTags.WOODEN_STAIRS) || surface.isIn(BlockTags.WOODEN_FENCES)) {
                return;
            }
            strikePos = new BlockPos(lx, ly, lz);
        }

        LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(overworld);
        if (bolt != null) {
            bolt.refreshPositionAfterTeleport(strikePos.getX() + 0.5, strikePos.getY(), strikePos.getZ() + 0.5);
            bolt.setCosmetic(false); // 100% real physical Minecraft lightning!
            overworld.spawnEntity(bolt);
            ai.arena.bridge.physics.GeoStructuralPhysicsEngine.onLightningStrike(overworld, strikePos, effThunder);
        }
    }

    private static void upgradeOneLoadedTunnelChunk(ServerWorld world) {
        // v7.3.0 Zero-Lag Guard: run at most once per second (20 ticks), touch ONLY middle bore cz=6..94 (z=96..1519)
        // so custom North/South underground stations are untouched, and skip chunks already upgraded on disk!
        if ((serverTickCounter % 20) != 0) return;
        if (UPGRADED_TUNNEL_CHUNKS.size() >= 89) return;
        boolean storm = world.isThundering();

        for (int cz = 6; cz <= 94; cz++) {
            if (UPGRADED_TUNNEL_CHUNKS.contains(cz)) continue;
            if (!world.isChunkLoaded(-1, cz) || !world.isChunkLoaded(-2, cz)) continue;

            UPGRADED_TUNNEL_CHUNKS.add(cz);
            int zStart = cz << 4;
            int zEnd = (cz << 4) + 15;
            BlockPos.Mutable mpos = new BlockPos.Mutable();

            // Fast non-destructive check: if chunk already has tunnel_emergency_light and zero sea_lantern/light, skip 100%!
            boolean hasLegacy = false;
            boolean hasModernLed = false;
            for (int z = zStart; z <= zEnd; z++) {
                for (int y = 47; y <= 55; y++) {
                    for (int x = -21; x <= -15; x++) {
                        BlockState st = world.getBlockState(mpos.set(x, y, z));
                        if (st.isOf(Blocks.SEA_LANTERN) || st.isOf(Blocks.LIGHT)) {
                            hasLegacy = true;
                            break;
                        } else if (st.isOf(TUNNEL_EMERGENCY_LIGHT)) {
                            hasModernLed = true;
                        }
                    }
                    if (hasLegacy) break;
                }
                if (hasLegacy) break;
            }
            if (!hasLegacy && hasModernLed) {
                continue; // Already clean on disk -> ZERO setBlockState & ZERO light-engine lag!
            }

            // 1. Clean legacy sea_lanterns -> stone_bricks, invisible light -> air
            for (int z = zStart; z <= zEnd; z++) {
                for (int y = 46; y <= 65; y++) {
                    for (int x = -22; x <= -14; x++) {
                        mpos.set(x, y, z);
                        BlockState st = world.getBlockState(mpos);
                        if (st.isOf(Blocks.SEA_LANTERN)) {
                            world.setBlockState(mpos, Blocks.STONE_BRICKS.getDefaultState(), Block.NOTIFY_LISTENERS);
                        } else if (st.isOf(Blocks.LIGHT)) {
                            world.setBlockState(mpos, Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
                        } else if (st.isOf(TUNNEL_EMERGENCY_LIGHT)) {
                            world.setBlockState(mpos, Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
                        }
                    }
                }
            }

            // 2. Install primary pure-white (emergency=red blinking) LED fixtures along tunnel ceiling & side walls!
            BlockState ceilingFixture = TUNNEL_EMERGENCY_LIGHT.getDefaultState()
                    .with(FACING, Direction.NORTH)
                    .with(CEILING, true)
                    .with(EMERGENCY, storm);
            BlockState westWallFixture = TUNNEL_EMERGENCY_LIGHT.getDefaultState()
                    .with(FACING, Direction.EAST)
                    .with(CEILING, false)
                    .with(EMERGENCY, storm);
            BlockState eastWallFixture = TUNNEL_EMERGENCY_LIGHT.getDefaultState()
                    .with(FACING, Direction.WEST)
                    .with(CEILING, false)
                    .with(EMERGENCY, storm);

            for (int z = zStart; z <= zEnd; z++) {
                if ((z & 3) != 0) continue; // Every 4 blocks -> unbroken luminance 13..15!
                int ceilAirY = -1;
                for (int y = 64; y >= 49; y--) {
                    mpos.set(-18, y, z);
                    BlockState cur = world.getBlockState(mpos);
                    BlockState above = world.getBlockState(mpos.up());
                    if (cur.isAir() && !above.isAir() && above.isSolidBlock(world, mpos.up())) {
                        ceilAirY = y;
                        break;
                    }
                }
                if (ceilAirY > 0) {
                    BlockPos cPos = new BlockPos(-18, ceilAirY, z);
                    world.setBlockState(cPos, ceilingFixture, Block.NOTIFY_ALL);

                    if ((z & 7) == 0 && ceilAirY - 2 >= 49) {
                        BlockPos wPos = new BlockPos(-20, ceilAirY - 2, z);
                        if (world.getBlockState(wPos).isAir()
                                && world.getBlockState(wPos.west()).isSolidBlock(world, wPos.west())) {
                            world.setBlockState(wPos, westWallFixture, Block.NOTIFY_ALL);
                        }
                        BlockPos ePos = new BlockPos(-16, ceilAirY - 2, z);
                        if (world.getBlockState(ePos).isAir()
                                && world.getBlockState(ePos.east()).isSolidBlock(world, ePos.east())) {
                            world.setBlockState(ePos, eastWallFixture, Block.NOTIFY_ALL);
                        }
                    }
                }
            }
            // Only upgrade 1 chunk per server tick so TPS stays locked at 20.0!
            return;
        }
    }

    private static BlockPos findNearbyLightningRod(ServerWorld world, int cx, int cz, int radius) {
        int baseTop = world.getTopY(Heightmap.Type.WORLD_SURFACE, cx, cz);
        for (int dx = -radius; dx <= radius; dx += 1) {
            for (int dz = -radius; dz <= radius; dz += 1) {
                int x = cx + dx;
                int z = cz + dz;
                if (!world.isChunkLoaded(x >> 4, z >> 4)) continue;
                int y = world.getTopY(Heightmap.Type.WORLD_SURFACE, x, z) - 1;
                if (Math.abs(y - baseTop) > 28) continue;
                BlockPos bp = new BlockPos(x, y, z);
                if (world.getBlockState(bp).isOf(Blocks.LIGHTNING_ROD)) {
                    return bp.up();
                }
            }
        }
        return null;
    }

    // ==================== ITEMS & BLOCKS ====================

    public static class OrmanKartItem extends Item {
        public OrmanKartItem(Settings settings) {
            super(settings);
        }

        @Override
        public void appendTooltip(ItemStack stack, World world, List<Text> tooltip, TooltipContext context) {
            RegionPolicyEngine.CardBenefit cb = RegionPolicyEngine.readCardBenefit(stack);
            if (cb != null) {
                tooltip.add(Text.literal("Geçerli Bölge: [" + cb.regionId + "]").formatted(Formatting.GREEN));
                String ticketInfo = cb.ticketDiscountPct >= 100
                        ? "Bilet: Bölge İçi Ücretsiz"
                        : ("Bilet İndirimi: %" + cb.ticketDiscountPct);
                tooltip.add(Text.literal(ticketInfo + " • Otomat İndirimi: %" + cb.shopDiscountPct).formatted(Formatting.GRAY));
            }
        }
    }

    public static class WorldMapBoardBlock extends Block implements BlockEntityProvider {
        private static final VoxelShape SHAPE_NORTH = Block.createCuboidShape(0.5, 1.0, 14.7, 15.5, 15.0, 16.0);
        private static final VoxelShape SHAPE_SOUTH = Block.createCuboidShape(0.5, 1.0, 0.0, 15.5, 15.0, 1.3);
        private static final VoxelShape SHAPE_EAST  = Block.createCuboidShape(0.0, 1.0, 0.5, 1.3, 15.0, 15.5);
        private static final VoxelShape SHAPE_WEST  = Block.createCuboidShape(14.7, 1.0, 0.5, 16.0, 15.0, 15.5);

        public WorldMapBoardBlock(Settings settings) {
            super(settings);
            setDefaultState(getStateManager().getDefaultState().with(FACING, Direction.NORTH).with(MAP_MODE, 0));
        }

        @Override
        public VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
            return switch (state.get(FACING)) {
                case SOUTH -> SHAPE_SOUTH;
                case EAST -> SHAPE_EAST;
                case WEST -> SHAPE_WEST;
                default -> SHAPE_NORTH;
            };
        }

        @Override
        protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
            builder.add(FACING, MAP_MODE);
        }

        @Override
        public BlockState getPlacementState(ItemPlacementContext ctx) {
            return getDefaultState().with(FACING, ctx.getHorizontalPlayerFacing().getOpposite()).with(MAP_MODE, 0);
        }

        @Override
        public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
            return new MapBoardBlockEntity(pos, state);
        }

        @Override
        public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
            if (player.isSneaking()) {
                if (world.isClient) {
                    ArenaMapScreen.openClientScreen(state.get(MAP_MODE));
                }
                return ActionResult.SUCCESS;
            }
            if (!world.isClient) {
                int next = (state.get(MAP_MODE) + 1) % 5;
                world.setBlockState(pos, state.with(MAP_MODE, next), Block.NOTIFY_ALL);
                String[] labels = {
                        "1:1 Yakın Çevre Haritası",
                        "1:2 İstasyon Bölgesi",
                        "1:3 Çevre Haritası",
                        "Bölge ve Sınır Haritası",
                        "MTR Hat Diyagramı"
                };
                player.sendMessage(Text.literal("Harita Modu: " + labels[next]).formatted(Formatting.GRAY), true);
            }
            return ActionResult.SUCCESS;
        }
    }

    public static class MapBoardBlockEntity extends BlockEntity {
        public MapBoardBlockEntity(BlockPos pos, BlockState state) {
            super(MAP_BOARD_BE_TYPE, pos, state);
        }

        @Override
        public NbtCompound toInitialChunkDataNbt() {
            return createNbt();
        }

        @Override
        public Packet<ClientPlayPacketListener> toUpdatePacket() {
            return BlockEntityUpdateS2CPacket.create(this);
        }
    }

    public static class TransitNewsBoardBlock extends Block implements BlockEntityProvider {
        private static final VoxelShape SHAPE_NORTH = Block.createCuboidShape(0.0, 1.4, 14.4, 16.0, 14.6, 16.0);
        private static final VoxelShape SHAPE_SOUTH = Block.createCuboidShape(0.0, 1.4, 0.0, 16.0, 14.6, 1.6);
        private static final VoxelShape SHAPE_EAST  = Block.createCuboidShape(0.0, 1.4, 0.0, 1.6, 14.6, 16.0);
        private static final VoxelShape SHAPE_WEST  = Block.createCuboidShape(14.4, 1.4, 0.0, 16.0, 14.6, 16.0);

        public TransitNewsBoardBlock(Settings settings) {
            super(settings);
            setDefaultState(getStateManager().getDefaultState().with(FACING, Direction.NORTH));
        }

        @Override
        public VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
            return switch (state.get(FACING)) {
                case SOUTH -> SHAPE_SOUTH;
                case EAST -> SHAPE_EAST;
                case WEST -> SHAPE_WEST;
                default -> SHAPE_NORTH;
            };
        }

        @Override
        protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
            builder.add(FACING);
        }

        @Override
        public BlockState getPlacementState(ItemPlacementContext ctx) {
            return getDefaultState().with(FACING, ctx.getHorizontalPlayerFacing().getOpposite());
        }

        @Override
        public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
            return new TransitNewsBoardBlockEntity(pos, state);
        }

        @Override
        public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
            BlockEntity be = world.getBlockEntity(pos);
            if (be instanceof TransitNewsBoardBlockEntity nbe) {
                nbe.manualOffset++;
                if (!world.isClient) {
                    world.playSound(null, pos, SoundEvents.UI_BUTTON_CLICK.value(), SoundCategory.BLOCKS, 0.35f, 1.2f);
                }
            }
            return ActionResult.SUCCESS;
        }
    }

    public static class TransitNewsBoardBlockEntity extends BlockEntity {
        public int manualOffset = 0;

        public TransitNewsBoardBlockEntity(BlockPos pos, BlockState state) {
            super(NEWS_BOARD_BE_TYPE, pos, state);
        }
    }

    /**
     * Seamless Connected Ceiling / Wall Linear Tunnel LED Rail (v7.4.0):
     * - ZERO BlockEntity & ZERO BlockEntityRenderer (renders in 1 chunk VBO draw call = 0.00ms!).
     * - Connects seamlessly end-to-end (0..16) along the tunnel ceiling crown.
     * - Dynamic red emergency illumination & blink-OFF darkness driven by LightmapTextureManager!
     */
    public static class TunnelEmergencyLightBlock extends Block {
        private static final VoxelShape SHAPE_CEILING = Block.createCuboidShape(5.0, 14.4, 0.0, 11.0, 16.0, 16.0);
        private static final VoxelShape SHAPE_NORTH   = Block.createCuboidShape(0.0, 6.0, 14.4, 16.0, 10.0, 16.0);
        private static final VoxelShape SHAPE_SOUTH   = Block.createCuboidShape(0.0, 6.0, 0.0, 16.0, 10.0, 1.6);
        private static final VoxelShape SHAPE_EAST    = Block.createCuboidShape(0.0, 6.0, 0.0, 1.6, 10.0, 16.0);
        private static final VoxelShape SHAPE_WEST    = Block.createCuboidShape(14.4, 6.0, 0.0, 16.0, 10.0, 16.0);

        public TunnelEmergencyLightBlock(Settings settings) {
            super(settings);
            setDefaultState(getStateManager().getDefaultState()
                    .with(FACING, Direction.NORTH)
                    .with(CEILING, true)
                    .with(EMERGENCY, false));
        }

        @Override
        public VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
            if (state.get(CEILING)) return SHAPE_CEILING;
            return switch (state.get(FACING)) {
                case SOUTH -> SHAPE_SOUTH;
                case EAST -> SHAPE_EAST;
                case WEST -> SHAPE_WEST;
                default -> SHAPE_NORTH;
            };
        }

        @Override
        protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
            builder.add(FACING, CEILING, EMERGENCY);
        }

        @Override
        public BlockState getPlacementState(ItemPlacementContext ctx) {
            boolean onCeiling = ctx.getSide() == Direction.DOWN;
            Direction horizontal = ctx.getSide().getAxis().isHorizontal()
                    ? ctx.getSide()
                    : ctx.getHorizontalPlayerFacing();
            return getDefaultState()
                    .with(FACING, horizontal)
                    .with(CEILING, onCeiling)
                    .with(EMERGENCY, false);
        }
    }

    // ==================== 5 CUSTOM 3D METRO ARCHITECTURE & FURNITURE BLOCKS (v7.5.0) ====================

    public static class MetroBenchBlock extends Block {
        private static final VoxelShape SHAPE_NS = Block.createCuboidShape(0.0, 0.0, 2.5, 16.0, 15.0, 14.2);
        private static final VoxelShape SHAPE_EW = Block.createCuboidShape(1.8, 0.0, 0.0, 13.5, 15.0, 16.0);

        public MetroBenchBlock(Settings settings) {
            super(settings);
            setDefaultState(getStateManager().getDefaultState()
                    .with(FACING, Direction.NORTH)
                    .with(BENCH_PART, BenchPart.SINGLE));
        }

        public static BenchPart computeBenchPart(WorldAccess world, BlockPos pos, Direction facing) {
            Direction leftDir = facing.rotateYCounterclockwise();
            Direction rightDir = facing.rotateYClockwise();
            BlockPos lp = pos.offset(leftDir);
            BlockPos rp = pos.offset(rightDir);
            boolean connLeft = world.isChunkLoaded(lp.getX() >> 4, lp.getZ() >> 4)
                    && world.getBlockState(lp).isOf(METRO_BENCH)
                    && world.getBlockState(lp).get(FACING) == facing;
            boolean connRight = world.isChunkLoaded(rp.getX() >> 4, rp.getZ() >> 4)
                    && world.getBlockState(rp).isOf(METRO_BENCH)
                    && world.getBlockState(rp).get(FACING) == facing;
            if (connLeft && connRight) return BenchPart.MIDDLE;
            if (connRight) return BenchPart.LEFT;
            if (connLeft) return BenchPart.RIGHT;
            return BenchPart.SINGLE;
        }

        @Override
        public VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
            Direction f = state.get(FACING);
            return (f == Direction.EAST || f == Direction.WEST) ? SHAPE_EW : SHAPE_NS;
        }

        @Override
        protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
            builder.add(FACING, BENCH_PART);
        }

        @Override
        public BlockState getPlacementState(ItemPlacementContext ctx) {
            Direction facing = ctx.getHorizontalPlayerFacing().getOpposite();
            BenchPart part = computeBenchPart(ctx.getWorld(), ctx.getBlockPos(), facing);
            return getDefaultState().with(FACING, facing).with(BENCH_PART, part);
        }

        @Override
        public BlockState getStateForNeighborUpdate(
                BlockState state, Direction direction, BlockState neighborState,
                WorldAccess world, BlockPos pos, BlockPos neighborPos
        ) {
            if (direction.getAxis().isHorizontal()) {
                return state.with(BENCH_PART, computeBenchPart(world, pos, state.get(FACING)));
            }
            return super.getStateForNeighborUpdate(state, direction, neighborState, world, pos, neighborPos);
        }

        @Override
        public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
            if (player.isSneaking() || player.hasVehicle()) return ActionResult.PASS;
            ItemStack held = player.getStackInHand(hand);
            if (!held.isEmpty() && held.getItem() instanceof BlockItem bi && bi.getBlock() == METRO_BENCH) {
                return ActionResult.PASS;
            }
            if (!world.isClient && world instanceof ServerWorld sw) {
                // Prevent duplicate riders on the same bench block
                net.minecraft.util.math.Box seatCheck = new net.minecraft.util.math.Box(pos).expand(0.2);
                if (!sw.getEntitiesByClass(net.minecraft.entity.decoration.ArmorStandEntity.class, seatCheck, net.minecraft.entity.Entity::hasPassengers).isEmpty()) {
                    return ActionResult.CONSUME;
                }
                Direction facing = state.get(FACING);
                double sx = pos.getX() + 0.5 + facing.getOffsetX() * 0.06;
                double sy = pos.getY() - 1.42; // ArmorStand passenger mount offset (+1.875) -> exact walnut seat height y+0.455!
                double sz = pos.getZ() + 0.5 + facing.getOffsetZ() * 0.06;
                net.minecraft.entity.decoration.ArmorStandEntity seat =
                        new net.minecraft.entity.decoration.ArmorStandEntity(sw, sx, sy, sz);
                seat.setInvisible(true);
                seat.setNoGravity(true);
                seat.setInvulnerable(true);
                seat.setSilent(true);
                seat.setYaw(facing.asRotation());
                sw.spawnEntity(seat);
                ACTIVE_BENCH_SEATS.add(seat);
                player.startRiding(seat, true);
            }
            return ActionResult.SUCCESS;
        }
    }

    public static class VendingMachineBlock extends Block implements BlockEntityProvider {
        private static final VoxelShape SHAPE = Block.createCuboidShape(0.5, 0.0, 2.0, 15.5, 16.0, 15.5);

        public VendingMachineBlock(Settings settings) {
            super(settings);
            setDefaultState(getStateManager().getDefaultState()
                    .with(FACING, Direction.SOUTH)
                    .with(HALF, DoubleBlockHalf.LOWER));
        }

        @Override
        public VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
            return SHAPE;
        }

        @Override
        protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
            builder.add(FACING, HALF);
        }

        @Override
        public BlockState getPlacementState(ItemPlacementContext ctx) {
            BlockPos pos = ctx.getBlockPos();
            World world = ctx.getWorld();
            if (pos.getY() < world.getTopY() - 1 && world.getBlockState(pos.up()).canReplace(ctx)) {
                return getDefaultState()
                        .with(FACING, ctx.getHorizontalPlayerFacing().getOpposite())
                        .with(HALF, DoubleBlockHalf.LOWER);
            }
            return null;
        }

        @Override
        public void onPlaced(World world, BlockPos pos, BlockState state, LivingEntity placer, ItemStack itemStack) {
            world.setBlockState(pos.up(), state.with(HALF, DoubleBlockHalf.UPPER), Block.NOTIFY_ALL);
        }

        @Override
        public BlockState onBreak(World world, BlockPos pos, BlockState state, PlayerEntity player) {
            if (!world.isClient) {
                BlockPos otherPos = (state.get(HALF) == DoubleBlockHalf.LOWER) ? pos.up() : pos.down();
                BlockState other = world.getBlockState(otherPos);
                if (other.isOf(this) && other.get(HALF) != state.get(HALF)) {
                    world.setBlockState(otherPos, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL | Block.SKIP_DROPS);
                }
            }
            return super.onBreak(world, pos, state, player);
        }

        @Override
        public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
            // Showcase shelves live in the UPPER half!
            return state.get(HALF) == DoubleBlockHalf.UPPER ? new VendingMachineBlockEntity(pos, state) : null;
        }

        @Override
        public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
            BlockPos basePos = state.get(HALF) == DoubleBlockHalf.UPPER ? pos.down() : pos;
            ItemStack held = player.getStackInHand(hand);
            if (held.isOf(Items.EMERALD) || held.isOf(Items.GOLD_INGOT)) {
                if (!world.isClient && world instanceof ServerWorld sw) {
                    int add = held.isOf(Items.EMERALD) ? 10 : 5;
                    if (!player.getAbilities().creativeMode) {
                        held.decrement(1);
                    }
                    int nextBal = getPlayerMtrBalance(sw.getScoreboard(), player) + add;
                    setPlayerMtrBalance(sw.getServer(), player.getNameForScoreboard(), nextBal);
                    sw.playSound(null, basePos, SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.BLOCKS, 0.6f, 1.35f);
                    player.sendMessage(Text.literal("+" + add + " TL yüklendi! Güncel Bakiye: " + nextBal + " TL").formatted(Formatting.GREEN), true);
                }
                return ActionResult.SUCCESS;
            }
            if (world.isClient) {
                ai.arena.bridge.client.MetroScreens.openVendingScreen(basePos);
            }
            return ActionResult.SUCCESS;
        }
    }

    public static class VendingMachineBlockEntity extends BlockEntity {
        public VendingMachineBlockEntity(BlockPos pos, BlockState state) {
            super(VENDING_BE_TYPE, pos, state);
        }
    }

    public static class AdLightboxBlock extends Block {
        private static final VoxelShape SHAPE_NORTH = Block.createCuboidShape(0.4, 0.8, 14.2, 15.6, 15.2, 16.0);
        private static final VoxelShape SHAPE_SOUTH = Block.createCuboidShape(0.4, 0.8, 0.0, 15.6, 15.2, 1.8);
        private static final VoxelShape SHAPE_EAST  = Block.createCuboidShape(0.0, 0.8, 0.4, 1.8, 15.2, 15.6);
        private static final VoxelShape SHAPE_WEST  = Block.createCuboidShape(14.2, 0.8, 0.4, 16.0, 15.2, 15.6);

        public AdLightboxBlock(Settings settings) {
            super(settings);
            setDefaultState(getStateManager().getDefaultState().with(FACING, Direction.SOUTH).with(POSTER_THEME, 0));
        }

        @Override
        public VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
            return switch (state.get(FACING)) {
                case NORTH -> SHAPE_NORTH;
                case EAST -> SHAPE_EAST;
                case WEST -> SHAPE_WEST;
                default -> SHAPE_SOUTH;
            };
        }

        @Override
        protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
            builder.add(FACING, POSTER_THEME);
        }

        @Override
        public BlockState getPlacementState(ItemPlacementContext ctx) {
            return getDefaultState().with(FACING, ctx.getHorizontalPlayerFacing().getOpposite()).with(POSTER_THEME, 0);
        }

        @Override
        public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
            if (!world.isClient) {
                int next = (state.get(POSTER_THEME) + 1) % 4;
                world.setBlockState(pos, state.with(POSTER_THEME, next), Block.NOTIFY_ALL);
                world.playSound(null, pos, SoundEvents.UI_BUTTON_CLICK.value(), SoundCategory.BLOCKS, 0.3f, 1.25f);
            }
            return ActionResult.SUCCESS;
        }
    }

    public static class InfoKioskBlock extends Block {
        private static final VoxelShape SHAPE = Block.createCuboidShape(2.5, 0.0, 3.5, 13.5, 16.0, 12.5);

        public InfoKioskBlock(Settings settings) {
            super(settings);
            setDefaultState(getStateManager().getDefaultState()
                    .with(FACING, Direction.SOUTH)
                    .with(HALF, DoubleBlockHalf.LOWER));
        }

        @Override
        public VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
            return SHAPE;
        }

        @Override
        protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
            builder.add(FACING, HALF);
        }

        @Override
        public BlockState getPlacementState(ItemPlacementContext ctx) {
            BlockPos pos = ctx.getBlockPos();
            World world = ctx.getWorld();
            if (pos.getY() < world.getTopY() - 1 && world.getBlockState(pos.up()).canReplace(ctx)) {
                return getDefaultState()
                        .with(FACING, ctx.getHorizontalPlayerFacing().getOpposite())
                        .with(HALF, DoubleBlockHalf.LOWER);
            }
            return null;
        }

        @Override
        public void onPlaced(World world, BlockPos pos, BlockState state, LivingEntity placer, ItemStack itemStack) {
            world.setBlockState(pos.up(), state.with(HALF, DoubleBlockHalf.UPPER), Block.NOTIFY_ALL);
        }

        @Override
        public BlockState onBreak(World world, BlockPos pos, BlockState state, PlayerEntity player) {
            if (!world.isClient) {
                BlockPos otherPos = (state.get(HALF) == DoubleBlockHalf.LOWER) ? pos.up() : pos.down();
                BlockState other = world.getBlockState(otherPos);
                if (other.isOf(this) && other.get(HALF) != state.get(HALF)) {
                    world.setBlockState(otherPos, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL | Block.SKIP_DROPS);
                }
            }
            return super.onBreak(world, pos, state, player);
        }

        @Override
        public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
            BlockPos basePos = state.get(HALF) == DoubleBlockHalf.UPPER ? pos.down() : pos;
            if (world.isClient) {
                ai.arena.bridge.client.MetroScreens.openInfoKioskScreen(basePos);
            }
            return ActionResult.SUCCESS;
        }
    }

    public static class SafetyCabinetBlock extends Block {
        private static final VoxelShape SHAPE_NORTH = Block.createCuboidShape(2.0, 1.0, 12.5, 14.0, 15.0, 16.0);
        private static final VoxelShape SHAPE_SOUTH = Block.createCuboidShape(2.0, 1.0, 0.0, 14.0, 15.0, 3.5);
        private static final VoxelShape SHAPE_EAST  = Block.createCuboidShape(0.0, 1.0, 2.0, 3.5, 15.0, 14.0);
        private static final VoxelShape SHAPE_WEST  = Block.createCuboidShape(12.5, 1.0, 2.0, 16.0, 15.0, 14.0);

        public SafetyCabinetBlock(Settings settings) {
            super(settings);
            setDefaultState(getStateManager().getDefaultState().with(FACING, Direction.SOUTH));
        }

        @Override
        public VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
            return switch (state.get(FACING)) {
                case NORTH -> SHAPE_NORTH;
                case EAST -> SHAPE_EAST;
                case WEST -> SHAPE_WEST;
                default -> SHAPE_SOUTH;
            };
        }

        @Override
        protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
            builder.add(FACING);
        }

        @Override
        public BlockState getPlacementState(ItemPlacementContext ctx) {
            return getDefaultState().with(FACING, ctx.getHorizontalPlayerFacing().getOpposite());
        }
    }

    public static class ProgrammableBoardBlock extends Block implements BlockEntityProvider {
        private static final VoxelShape SHAPE_STAND = Block.createCuboidShape(1.0, 0.0, 4.5, 15.0, 16.0, 11.5);
        private static final VoxelShape SHAPE_FULL  = Block.createCuboidShape(0.5, 0.5, 0.5, 15.5, 15.5, 15.5);

        public ProgrammableBoardBlock(Settings settings) {
            super(settings);
            setDefaultState(getStateManager().getDefaultState()
                    .with(FACING, Direction.NORTH)
                    .with(BOARD_MOUNT, BoardMount.STAND));
        }

        @Override
        public VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
            return state.get(BOARD_MOUNT) == BoardMount.STAND ? SHAPE_STAND : SHAPE_FULL;
        }

        @Override
        protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
            builder.add(FACING, BOARD_MOUNT);
        }

        @Override
        public BlockState getPlacementState(ItemPlacementContext ctx) {
            Direction side = ctx.getSide();
            BoardMount mount;
            Direction facing;
            if (side == Direction.DOWN) {
                mount = BoardMount.GANTRY;
                facing = ctx.getHorizontalPlayerFacing().getOpposite();
            } else if (side.getAxis().isHorizontal()) {
                mount = BoardMount.WALL;
                facing = side;
            } else {
                mount = ctx.getPlayer() != null && ctx.getPlayer().isSneaking() ? BoardMount.POSTER : BoardMount.STAND;
                facing = ctx.getHorizontalPlayerFacing().getOpposite();
            }
            return getDefaultState().with(FACING, facing).with(BOARD_MOUNT, mount);
        }

        @Override
        public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
            return new ProgrammableBoardBlockEntity(pos, state);
        }

        @Override
        public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
            if (player.isSneaking()) {
                // Sneak + Right-Click cycles mount style (wall -> stand -> poster -> gantry)
                if (!world.isClient) {
                    BoardMount[] vals = BoardMount.values();
                    BoardMount next = vals[(state.get(BOARD_MOUNT).ordinal() + 1) % vals.length];
                    world.setBlockState(pos, state.with(BOARD_MOUNT, next), Block.NOTIFY_ALL);
                    player.sendMessage(Text.literal("Pano montaj tipi: " + next.asString()).formatted(Formatting.AQUA), true);
                }
                return ActionResult.SUCCESS;
            }
            return ActionResult.PASS;
        }
    }

    public static class ProgrammableBoardBlockEntity extends BlockEntity {
        public String boardId = "default";
        public int customWidth = 0;
        public int customHeight = 0;
        public String customTheme = "";

        public ProgrammableBoardBlockEntity(BlockPos pos, BlockState state) {
            super(PROGRAMMABLE_BOARD_BE_TYPE, pos, state);
        }

        @Override
        protected void writeNbt(NbtCompound nbt) {
            super.writeNbt(nbt);
            nbt.putString("BoardId", boardId == null ? "default" : boardId);
            nbt.putInt("CustomW", customWidth);
            nbt.putInt("CustomH", customHeight);
            nbt.putString("CustomTheme", customTheme == null ? "" : customTheme);
        }

        @Override
        public void readNbt(NbtCompound nbt) {
            super.readNbt(nbt);
            if (nbt.contains("BoardId")) boardId = nbt.getString("BoardId");
            if (nbt.contains("CustomW")) customWidth = nbt.getInt("CustomW");
            if (nbt.contains("CustomH")) customHeight = nbt.getInt("CustomH");
            if (nbt.contains("CustomTheme")) customTheme = nbt.getString("CustomTheme");
        }

        @Override
        public Packet<ClientPlayPacketListener> toUpdatePacket() {
            return BlockEntityUpdateS2CPacket.create(this);
        }

        @Override
        public NbtCompound toInitialChunkDataNbt() {
            return createNbt();
        }
    }

    /**
     * Double-Ribbon Yellow Caution Barrier Tape Block ("HİZMET DIŞI" & "YAKINDA"):
     * Connects seamlessly across 1..N blocks, readable from both sides, with zero collision so MTR trains pass freely!
     */
    public static class CautionTapeBlock extends Block {
        private static final VoxelShape SHAPE_NS = Block.createCuboidShape(0.0, 2.5, 6.8, 16.0, 15.0, 9.2);
        private static final VoxelShape SHAPE_EW = Block.createCuboidShape(6.8, 2.5, 0.0, 9.2, 15.0, 16.0);

        public CautionTapeBlock(Settings settings) {
            super(settings);
            setDefaultState(getStateManager().getDefaultState().with(FACING, Direction.NORTH));
        }

        @Override
        public VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
            Direction f = state.get(FACING);
            return (f == Direction.EAST || f == Direction.WEST) ? SHAPE_EW : SHAPE_NS;
        }

        @Override
        protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
            builder.add(FACING);
        }

        @Override
        public BlockState getPlacementState(ItemPlacementContext ctx) {
            return getDefaultState().with(FACING, ctx.getHorizontalPlayerFacing().getOpposite());
        }
    }

    @SuppressWarnings("unchecked")
    private static int invokePhysicsModRepair(int x, int y, int z, double radius, boolean all) {
        try {
            Object fnObj = System.getProperties().get("arena.physicsmod.rpc");
            if (fnObj instanceof java.util.function.Function<?, ?> rawFn) {
                java.util.function.Function<String, String> rpc = (java.util.function.Function<String, String>) rawFn;
                String req = all
                        ? "{\"op\":\"repair_all\"}"
                        : String.format(java.util.Locale.US, "{\"op\":\"repair_near\",\"x\":%d,\"y\":%d,\"z\":%d,\"radius\":%.1f}", x, y, z, radius);
                String resp = rpc.apply(req);
                com.google.gson.JsonObject jo = com.google.gson.JsonParser.parseString(resp).getAsJsonObject();
                return jo.has("restored") ? jo.get("restored").getAsInt() : 0;
            }
        } catch (Throwable ignored) {}
        return 0;
    }
}

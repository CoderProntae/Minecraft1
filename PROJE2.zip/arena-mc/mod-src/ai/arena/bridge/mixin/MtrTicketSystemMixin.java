package ai.arena.bridge.mixin;

import ai.arena.bridge.ArenaContent;
import ai.arena.bridge.transit.RegionPolicyEngine;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.sound.SoundCategory;
import org.mtr.mapping.holder.BlockPos;
import org.mtr.mapping.holder.SoundEvent;
import org.mtr.mapping.holder.World;
import org.mtr.mapping.tool.HolderBase;
import org.mtr.mod.data.TicketSystem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

/**
 * Region-Aware MTR 4.0.5 TicketSystem Hook (v7.3.0):
 * - Regional cards (such as Orman Kart -> region "orman") grant free transit ticket entry ONLY in stations
 *   whose active region matches the card's region!
 * - In other regions (e.g. future City / Sahil / Merkez lines), Orman Kart does NOT bypass turnstile fares!
 */
@Mixin(value = TicketSystem.class, remap = false)
public abstract class MtrTicketSystemMixin {

    private static final Map<UUID, Long> LAST_VIP_PASS_MS = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> LAST_DENIED_MS = new ConcurrentHashMap<>();

    @Inject(method = "isConcessionary", at = @At("HEAD"), cancellable = true)
    private static void arena$checkRegionalCardConcessionary(
            org.mtr.mapping.holder.PlayerEntity mtrPlayer,
            CallbackInfoReturnable<Boolean> cir
    ) {
        try {
            PlayerEntity raw = unwrapPlayer(mtrPlayer);
            if (raw != null && RegionPolicyEngine.hasFreeTransitInRegion(raw.getWorld(), raw.getBlockPos(), raw)) {
                cir.setReturnValue(true);
            }
        } catch (Throwable ignored) {}
    }

    @Inject(method = "passThrough", at = @At("HEAD"), cancellable = true)
    private static void arena$handleTurnstilePassThrough(
            World world,
            BlockPos pos,
            org.mtr.mapping.holder.PlayerEntity mtrPlayer,
            boolean isEntrance,
            boolean isExit,
            SoundEvent entrySound,
            SoundEvent entrySoundConcessionary,
            SoundEvent exitSound,
            SoundEvent exitSoundConcessionary,
            SoundEvent failSound,
            boolean remindIfNoRecord,
            Consumer<TicketSystem.EnumTicketBarrierOpen> callback,
            CallbackInfo ci
    ) {
        try {
            PlayerEntity player = unwrapPlayer(mtrPlayer);
            if (player == null) return;
            long now = System.currentTimeMillis();
            UUID uuid = player.getUuid();
            net.minecraft.util.math.BlockPos mcPos = new net.minecraft.util.math.BlockPos(pos.getX(), pos.getY(), pos.getZ());

            // 1. Regional Card valid in THIS station's active region -> $0 free ticket pass!
            if (RegionPolicyEngine.hasFreeTransitInRegion(player.getWorld(), mcPos, player)) {
                callback.accept(TicketSystem.EnumTicketBarrierOpen.OPEN_CONCESSIONARY);
                Long prev = LAST_VIP_PASS_MS.put(uuid, now);
                if (prev == null || (now - prev) > 1500L) {
                    SoundEvent chosen = isEntrance ? entrySoundConcessionary : exitSoundConcessionary;
                    playMtrSoundOnce(player, pos, chosen);
                }
                ci.cancel();
                return;
            }

            // 2. Otherwise normal MTR fare applies; block entrance cleanly if balance <= 0
            if (isEntrance) {
                Scoreboard sb = player.getWorld().getScoreboard();
                int balance = ArenaContent.getPlayerMtrBalance(sb, player);
                if (balance <= 0) {
                    callback.accept(TicketSystem.EnumTicketBarrierOpen.CLOSED);
                    Long prev = LAST_DENIED_MS.put(uuid, now);
                    if (prev == null || (now - prev) > 1500L) {
                        playMtrSoundOnce(player, pos, failSound);
                        ArenaContent.onTurnstileDeniedForPlayer(player);
                    }
                    ci.cancel();
                }
            }
        } catch (Throwable ignored) {}
    }

    private static PlayerEntity unwrapPlayer(org.mtr.mapping.holder.PlayerEntity mtrPlayer) {
        if (mtrPlayer == null) return null;
        Object raw = ((HolderBase<?>) mtrPlayer).data;
        return (raw instanceof PlayerEntity p) ? p : null;
    }

    private static void playMtrSoundOnce(PlayerEntity player, BlockPos pos, SoundEvent mtrSound) {
        if (player == null || mtrSound == null) return;
        Object rawSound = ((HolderBase<?>) mtrSound).data;
        if (rawSound instanceof net.minecraft.sound.SoundEvent mcSound) {
            player.getWorld().playSound(
                    null,
                    pos.getX() + 0.5,
                    pos.getY() + 0.5,
                    pos.getZ() + 0.5,
                    mcSound,
                    SoundCategory.BLOCKS,
                    1.0f,
                    1.0f
            );
        }
    }
}

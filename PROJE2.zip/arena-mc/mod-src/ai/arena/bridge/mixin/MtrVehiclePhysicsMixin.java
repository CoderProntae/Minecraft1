package ai.arena.bridge.mixin;

import ai.arena.bridge.transit.RailPhysicsEngine;
import org.mtr.core.data.Data;
import org.mtr.core.data.TransportMode;
import org.mtr.core.data.Vehicle;
import org.mtr.core.data.VehicleExtraData;
import org.mtr.core.data.VehiclePosition;
import org.mtr.core.data.Position;
import org.mtr.core.generated.data.VehicleSchema;
import org.mtr.libraries.it.unimi.dsi.fastutil.objects.Object2ObjectAVLTreeMap;
import org.mtr.libraries.it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Hooks directly into MTR 4.0.5's Vehicle.simulateMoving(long, ObjectArrayList, int)
 * on BOTH server and client so every train accelerates and brakes according to real-world
 * speed-dependent motor power (P/v), Davis aerodynamic/tunnel resistance, grade slope,
 * wet-rail adhesion, and EN 13452 comfort braking curves!
 */
@Mixin(value = Vehicle.class, remap = false)
public abstract class MtrVehiclePhysicsMixin extends VehicleSchema {

    protected MtrVehiclePhysicsMixin(TransportMode transportMode, Data data) {
        super(transportMode, data);
    }

    @Redirect(
            method = "simulateMoving",
            at = @At(
                    value = "INVOKE",
                    target = "Lorg/mtr/core/data/VehicleExtraData;getAcceleration()D"
            ),
            remap = false
    )
    private double arena$realWorldSpeedDependentAcceleration(
            VehicleExtraData instance,
            long millisElapsed,
            ObjectArrayList<Object2ObjectAVLTreeMap<Position, Object2ObjectAVLTreeMap<Position, VehiclePosition>>> vehiclePositions,
            int pathIndex
    ) {
        return RailPhysicsEngine.computeVehicleAccelerationMtr(instance, this.speed, pathIndex);
    }

    @Redirect(
            method = "simulateMoving",
            at = @At(
                    value = "INVOKE",
                    target = "Lorg/mtr/core/data/VehicleExtraData;getDeceleration()D"
            ),
            remap = false
    )
    private double arena$realWorldSpeedDependentDeceleration(
            VehicleExtraData instance,
            long millisElapsed,
            ObjectArrayList<Object2ObjectAVLTreeMap<Position, Object2ObjectAVLTreeMap<Position, VehiclePosition>>> vehiclePositions,
            int pathIndex
    ) {
        return RailPhysicsEngine.computeVehicleDecelerationMtr(instance, this.speed, pathIndex);
    }
}

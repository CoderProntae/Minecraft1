const BASE = 'http://127.0.0.1:8080';

async function api(method, path, body) {
  const opts = { method, headers: {} };
  if (body !== undefined) {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(body);
  }
  const r = await fetch(BASE + path, opts);
  return r.json();
}

async function cmd(command) {
  return api('POST', '/api/act', { action: 'command', command });
}

function key(x, z) {
  return `${x},${z}`;
}

async function main() {
  console.log('1) Running WorldContextAnalyzer audit + purging orphan MTR surface rails...');
  // Move ArenaAI safely to air above surface before inspecting/editing surface chunks
  await cmd('tp ArenaAI -22 72 25');
  await new Promise(r => setTimeout(r, 400));

  const auditEntrance = await api('POST', '/api/mtr-control', {
    op: 'world_audit',
    x: -28,
    z: 25,
    radius: 20,
    purge: true
  });
  console.log('Entrance audit:', {
    ok: auditEntrance.ok,
    purgedOrphanRailNodes: auditEntrance.purgedOrphanRailNodes,
    orphanRailsLeft: auditEntrance.orphanMtrRailNodes?.length,
    cliffScars: auditEntrance.cliffScars?.length,
    landmarks: auditEntrance.landmarks?.length
  });

  // Sync MTR line (lowered 3D AreaBase y=42..75/84, 80 km/h physics, deduplicated stations, 20s dwell)
  const setupRes = await api('POST', '/api/mtr-control', {
    op: 'auto_setup_express',
    trainId: 'r_train_mini_cab_3'
  });
  console.log('MTR setup:', setupRes);

  // Build height lookup map around entrance (-48..-8, 5..45)
  const hMap1 = new Map();
  for (const cell of (auditEntrance.heightMap || [])) {
    hMap1.set(key(cell.x, cell.z), cell);
  }

  // Locate nearest wooden bridge / path west of Kuzey Orman lodge (x < -29, z in 18..34)
  let bridgeCells = (auditEntrance.landmarks || []).filter(
    l => l.kind === 'bridge_or_wood_deck' && l.x <= -31 && l.x >= -42 && l.z >= 20 && l.z <= 33
  );
  console.log('Detected bridge cells west of entrance:', bridgeCells.slice(0, 8));

  // Entrance west doorway porch is at x = -29 (doorway faces west toward x = -30..-35, z = 24..27)
  // Let's inspect exact cells x=-36..-28, z=22..30 so we see exact blocks and elevations!
  for (let z = 22; z <= 30; z++) {
    let row = `z=${String(z).padStart(2,' ')}: `;
    for (let x = -36; x <= -28; x++) {
      const c = hMap1.get(key(x, z));
      row += c ? `${x}:y${c.y}(${c.block.replace('minecraft:','').slice(0,6)}) ` : `${x}:? `;
    }
    console.log(row);
  }

  // 2) Connect Kuzey Orman entrance (x=-29/-30) to the wooden bridge (x=-35, z=26..28) dynamically using real groundY
  // Determine bridge target Z center & Y from detected bridge cells (fallback z=27 if slab/stair)
  let targetZ = 27;
  let bridgeY = 63;
  if (bridgeCells.length > 0) {
    targetZ = Math.round(bridgeCells.reduce((s, c) => s + c.z, 0) / bridgeCells.length);
    bridgeY = Math.round(bridgeCells.reduce((s, c) => s + c.y, 0) / bridgeCells.length);
  } else {
    const probe = hMap1.get(key(-35, 27)) || hMap1.get(key(-34, 27));
    if (probe && probe.y > 0) bridgeY = probe.y;
  }

  // Open west-side welcoming archway on Kuzey Orman surface lodge (x=-29, z=24..26, y=64..66) if solid wall blocks path!
  // Wait: check where stairs Flight 1 are! Flight 1 spruce stairs are x=-28..-26, z=21..27, y=63..57!
  // Let's check what is at x=-29..-25, z=18..31 first before opening anything!
  console.log('Lodge perimeter check (x=-31..-24, z=18..31):');
  for (let z = 18; z <= 31; z++) {
    let row = `z=${String(z).padStart(2,' ')}: `;
    for (let x = -31; x <= -24; x++) {
      const c = hMap1.get(key(x, z));
      row += c ? `${x}:y${c.y}(${c.block.replace('minecraft:','').slice(0,7)}) ` : '';
    }
    console.log(row);
  }

  // Now audit the z=84 cliff cut area!
  await cmd('tp ArenaAI -18 74 78');
  await new Promise(r => setTimeout(r, 400));
  const auditCliff = await api('POST', '/api/mtr-control', {
    op: 'world_audit',
    x: -18,
    z: 82,
    radius: 16,
    purge: true
  });
  console.log('Cliff audit:', {
    ok: auditCliff.ok,
    purgedOrphanRailNodes: auditCliff.purgedOrphanRailNodes,
    cliffScarsCount: auditCliff.cliffScars?.length,
    sampleScars: (auditCliff.cliffScars || []).slice(0, 8)
  });

  const hMap2 = new Map();
  for (const cell of (auditCliff.heightMap || [])) {
    hMap2.set(key(cell.x, cell.z), cell);
  }

  // Print z=74..90 height profile across x=-26..-10
  for (let z = 74; z <= 90; z += 2) {
    let row = `z=${String(z).padStart(2,' ')}: `;
    for (let x = -26; x <= -10; x += 2) {
      const c = hMap2.get(key(x, z));
      row += c ? `y${c.y}(${c.block.replace('minecraft:','').slice(0,5)}) ` : '? ';
    }
    console.log(row);
  }
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});

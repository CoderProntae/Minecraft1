const BASE = 'http://127.0.0.1:8080';
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

async function act(body) {
  for (let i = 0; i < 5; i++) {
    const r = await fetch(BASE + '/api/act', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...body, force: true })
    });
    const d = await r.json();
    if (d && d.ok !== false) return d;
    await sleep(400);
  }
  return { ok: false };
}

async function cmd(c) {
  await act({ action: 'command', command: c });
}

async function connectRail(z1, y1, z2, y2, item) {
  const r1 = await act({ action: 'interact', x: -18, y: y1, z: z1, side: 'up', item });
  const r2 = await act({ action: 'interact', x: -18, y: y2, z: z2, side: 'up', item });
  console.log(`[RAIL ${item}] ${z1}->${z2}:`, r1.result, r2.result);
}

async function main() {
  // Drain unread events
  for (let i = 0; i < 6; i++) {
    await fetch(BASE + '/api/wait-event?timeout=1').catch(() => {});
  }

  // Put ArenaAI in safe sunny clearing (-34, 68, 1565) so /tp to ArenaAI is 100% safe!
  await act({ action: 'stop' });
  await cmd('tp ArenaAI -34 68 1565');
  await sleep(250);

  // 1. Clear old upper viaduct & restore natural y=66 forest lawn in small loaded slices
  for (const [z1, z2] of [[1525, 1552], [1553, 1580], [1581, 1609]]) {
    await cmd(`fill -25 67 ${z1} -14 83 ${z2} minecraft:air`);
    await cmd(`fill -22 54 ${z1} -14 65 ${z2} minecraft:stone`);
    await cmd(`fill -25 65 ${z1} -14 65 ${z2} minecraft:dirt`);
    await cmd(`fill -25 66 ${z1} -14 66 ${z2} minecraft:grass_block`);
  }

  // 2. Flat y=48 Tunnel Approach (z=1525..1564) & Turnback Tail (z=1596..1612)
  await cmd('fill -21 47 1525 -15 53 1612 minecraft:stone_bricks');
  await cmd('fill -20 48 1525 -16 51 1611 minecraft:air');
  await cmd('fill -19 52 1525 -17 52 1611 minecraft:air');
  await cmd('fill -20 52 1525 -20 52 1611 minecraft:stone_brick_slab[type=top]');
  await cmd('fill -16 52 1525 -16 52 1611 minecraft:stone_brick_slab[type=top]');
  await cmd('fill -19 47 1525 -17 47 1611 minecraft:andesite');

  // 3. Grand Vaulted White-Quartz Underground Platform Hall (z=1565..1595, x=-28..-15, y=47..55)
  await cmd('fill -28 47 1565 -15 55 1595 minecraft:polished_deepslate');
  await cmd('fill -27 49 1566 -16 54 1594 minecraft:air');
  await cmd('fill -19 48 1565 -16 52 1595 minecraft:air');
  await cmd('fill -28 49 1566 -28 53 1594 minecraft:smooth_quartz');
  await cmd('fill -15 49 1566 -15 53 1594 minecraft:smooth_quartz');
  await cmd('fill -28 51 1566 -28 51 1594 minecraft:red_concrete');
  await cmd('fill -15 51 1566 -15 51 1594 minecraft:red_concrete');
  await cmd('fill -27 55 1566 -16 55 1594 minecraft:smooth_quartz');
  await cmd('fill -27 48 1566 -22 48 1594 minecraft:smooth_quartz');
  await cmd('fill -21 48 1568 -21 48 1592 minecraft:yellow_concrete');
  await cmd('fill -20 48 1568 -20 48 1592 mtr:platform[door_type=none,facing=west,side=0]');

  // 4. Waterproof Mezzanine Ticket Hall (y=56..62) + Stair Shafts + Surface [M1] Glass Pavilion (y=66..71)
  await cmd('fill -31 56 1566 -22 65 1586 minecraft:polished_deepslate');
  await cmd('fill -30 57 1567 -23 61 1585 minecraft:air');
  await cmd('fill -30 56 1567 -23 56 1585 minecraft:smooth_quartz');
  await cmd('fill -30 62 1567 -23 62 1585 minecraft:smooth_quartz');

  // Clear surface entrance & build sleek Glass + Dark-Titanium [M1] Pavilion
  await cmd('fill -32 67 1563 -25 74 1578 minecraft:air');
  await cmd('fill -32 66 1563 -25 66 1567 minecraft:smooth_quartz');
  await cmd('fill -31 67 1566 -31 69 1577 minecraft:glass');
  await cmd('fill -27 67 1566 -27 69 1577 minecraft:glass');
  await cmd('fill -31 67 1577 -27 69 1577 minecraft:glass');
  await cmd('fill -31 70 1566 -27 70 1577 minecraft:polished_deepslate');
  await cmd('fill -30 70 1566 -28 70 1566 minecraft:red_concrete');
  await cmd('fill -31 71 1566 -27 71 1577 minecraft:polished_deepslate_slab[type=bottom]');

  // Carve Stair Flight 1 shaft (x=-30..-28, z=1567..1577, y=57..69) & Flight 2 shaft (x=-26..-24, z=1571..1579, y=49..57)
  await cmd('fill -30 57 1567 -28 69 1577 minecraft:air');
  await cmd('fill -26 49 1571 -24 57 1579 minecraft:air');

  // 5. Crisp architectural details: Quartz Stairs, Turnstiles, Columns, Map/News Boards, & Pure White LEDs!
  const ops = [];
  // Flight 1: Surface (z=1567, y=66) -> Mezzanine (z=1576, y=57)
  for (let i = 0; i < 10; i++) {
    const sz = 1567 + i, sy = 66 - i;
    for (let x = -30; x <= -28; x++) {
      ops.push({ x, y: sy - 1, z: sz, block: 'minecraft:smooth_quartz' });
      ops.push({ x, y: sy, z: sz, block: 'minecraft:smooth_quartz_stairs[facing=north,half=bottom,shape=straight,waterlogged=false]' });
      for (let ay = sy + 1; ay <= sy + 4; ay++) ops.push({ x, y: ay, z: sz, block: 'minecraft:air' });
    }
  }
  // Flight 2: Mezzanine (z=1579, y=56) -> Underground Platform (z=1572, y=49)
  for (let i = 0; i < 8; i++) {
    const sz = 1579 - i, sy = 56 - i;
    for (let x = -26; x <= -24; x++) {
      ops.push({ x, y: sy - 1, z: sz, block: 'minecraft:smooth_quartz' });
      ops.push({ x, y: sy, z: sz, block: 'minecraft:smooth_quartz_stairs[facing=south,half=bottom,shape=straight,waterlogged=false]' });
      for (let ay = sy + 1; ay <= sy + 4; ay++) ops.push({ x, y: ay, z: sz, block: 'minecraft:air' });
    }
  }
  // Glass railing around Flight 2 opening on Platform ceiling / Mezzanine
  for (let z = 1572; z <= 1579; z++) {
    ops.push({ x: -27, y: 57, z, block: 'minecraft:tinted_glass' });
    ops.push({ x: -23, y: 57, z, block: 'minecraft:tinted_glass' });
  }
  // Mezzanine Turnstiles at x=-27, z=1580..1585 (walking floor y=57)
  for (let z = 1580; z <= 1585; z++) {
    if (z <= 1581) {
      ops.push({ x: -27, y: 57, z, block: 'mtr:ticket_barrier_entrance_1[facing=east,open=closed]' });
    } else if (z <= 1583) {
      ops.push({ x: -27, y: 57, z, block: 'mtr:ticket_barrier_exit_1[facing=west,open=closed]' });
    } else {
      ops.push({ x: -27, y: 57, z, block: 'minecraft:tinted_glass' });
      ops.push({ x: -27, y: 58, z, block: 'minecraft:tinted_glass' });
    }
  }
  // Columns + Digital World Map & Transit News Boards on Underground Platform!
  for (const cz of [1569, 1583, 1591]) {
    for (let y = 49; y <= 54; y++) {
      ops.push({ x: -24, y, z: cz, block: (y === 49 || y === 54) ? 'minecraft:chiseled_quartz_block' : 'minecraft:quartz_pillar[axis=y]' });
    }
  }
  ops.push({ x: -23, y: 50, z: 1583, block: 'arena_ai_bridge:world_map_board[facing=east,map_mode=0]' });
  ops.push({ x: -23, y: 50, z: 1591, block: 'arena_ai_bridge:transit_news_board[facing=east]' });

  // Pure White Primary LED Fixtures (Pavilion, Mezzanine, Platform Hall, & Tunnels!)
  for (const lz of [1568, 1571, 1574]) {
    ops.push({ x: -29, y: 69, z: lz, block: 'arena_ai_bridge:tunnel_emergency_light[ceiling=true,emergency=false,facing=north]' });
  }
  for (const lz of [1578, 1581, 1584]) {
    ops.push({ x: -29, y: 61, z: lz, block: 'arena_ai_bridge:tunnel_emergency_light[ceiling=true,emergency=false,facing=north]' });
    ops.push({ x: -25, y: 61, z: lz, block: 'arena_ai_bridge:tunnel_emergency_light[ceiling=true,emergency=false,facing=north]' });
  }
  for (let z = 1567; z <= 1593; z += 3) {
    ops.push({ x: -22, y: 54, z, block: 'arena_ai_bridge:tunnel_emergency_light[ceiling=true,emergency=false,facing=north]' });
    ops.push({ x: -18, y: 54, z, block: 'arena_ai_bridge:tunnel_emergency_light[ceiling=true,emergency=false,facing=north]' });
  }
  for (let z = 1528; z <= 1564; z += 4) {
    ops.push({ x: -18, y: 52, z, block: 'arena_ai_bridge:tunnel_emergency_light[ceiling=true,emergency=false,facing=north]' });
  }
  for (let z = 1596; z <= 1608; z += 4) {
    ops.push({ x: -18, y: 52, z, block: 'arena_ai_bridge:tunnel_emergency_light[ceiling=true,emergency=false,facing=north]' });
  }

  await act({ action: 'build', ops, recordUndo: false, strictPhysics: false, cleanFloating: false });

  // 6. Place MTR y=48 Rail Nodes, Ticket Machine & PIDS, then connect rails!
  await cmd('tp ArenaAI -22 49 1580');
  await sleep(250);
  await act({
    action: 'place_real',
    recordUndo: false,
    steps: [
      { x: -18, y: 48, z: 1546, item: 'mtr:rail', against: 'down', look: 'south', replace: true },
      { x: -18, y: 48, z: 1568, item: 'mtr:rail', against: 'down', look: 'south', replace: true },
      { x: -18, y: 48, z: 1592, item: 'mtr:rail', against: 'down', look: 'south', replace: true },
      { x: -18, y: 48, z: 1610, item: 'mtr:rail', against: 'down', look: 'south', replace: true },
      { x: -30, y: 57, z: 1581, item: 'mtr:ticket_machine', against: 'down', look: 'east', replace: true },
      { x: -21, y: 53, z: 1574, item: 'mtr:pids_1', against: 'up', look: 'east', replace: true },
      { x: -21, y: 53, z: 1586, item: 'mtr:pids_1', against: 'up', look: 'east', replace: true }
    ]
  });
  await sleep(200);

  await connectRail(1524, 48, 1546, 48, 'mtr:rail_connector_80');
  await connectRail(1546, 48, 1568, 48, 'mtr:rail_connector_80');
  await connectRail(1568, 48, 1592, 48, 'mtr:rail_connector_platform');
  await connectRail(1592, 48, 1610, 48, 'mtr:rail_connector_turn_back');

  // Stand right on the gleaming new y=49 underground white-quartz platform!
  await cmd('tp ArenaAI -23 49 1580');
  console.log('FAST_SOUTH_METRO_DONE');
}

main().catch(e => { console.error(e); process.exit(1); });

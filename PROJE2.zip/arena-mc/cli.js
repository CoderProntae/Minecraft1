const fs = require('fs');

const BASE = 'http://127.0.0.1:8080';

async function req(method, urlPath, body) {
  const opts = { method, headers: {} };
  if (body !== undefined) {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(body);
  }
  const r = await fetch(BASE + urlPath, opts);
  return r.json();
}

async function main() {
  const [, , cmd, ...args] = process.argv;
  let out;

  if (cmd === 'state') {
    out = await req('GET', '/api/state?refresh=1');
  } else if (cmd === 'mods') {
    out = await req('GET', '/api/mods');
  } else if (cmd === 'registry') {
    const [ns = 'mtr', q = '', type = 'block'] = args;
    out = await req('GET', `/api/registry?ns=${encodeURIComponent(ns)}&q=${encodeURIComponent(q)}&type=${encodeURIComponent(type)}`);
  } else if (cmd === 'templates') {
    const [q = ''] = args;
    out = await req('GET', `/api/templates?q=${encodeURIComponent(q)}`);
  } else if (cmd === 'mtr') {
    const [subPath = '/mtr/api/map/stations-and-routes?dimension=0'] = args;
    out = await req('GET', `/api/mtr?path=${encodeURIComponent(subPath)}`);
  } else if (cmd === 'mtr_state') {
    out = await req('GET', '/api/mtr-state');
  } else if (cmd === 'mtr_setup') {
    const [trainId = 'sp1900_mini_cab_3'] = args;
    out = await req('POST', '/api/mtr-control', { op: 'auto_setup_express', trainId });
  } else if (cmd === 'mtr_train') {
    const [trainId] = args;
    out = await req('POST', '/api/mtr-control', { op: 'set_train', trainId });
  } else if (cmd === 'mtr_rename') {
    const [target, ...nameParts] = args;
    out = await req('POST', '/api/mtr-control', { op: 'rename_station', target, name: nameParts.join(' ') });
  } else if (cmd === 'mtr_deploy') {
    out = await req('POST', '/api/mtr-control', { op: 'deploy' });
  } else if (cmd === 'mtr_board') {
    out = await req('POST', '/api/mtr-control', { op: 'board_bot' });
  } else if (cmd === 'announce') {
    const [voice = 'kadin', chime = 'station', ...textParts] = args;
    out = await req('POST', '/api/announce', { voice, chime, text: textParts.join(' ') });
  } else if (cmd === 'map') {
    if (!args.length) {
      out = await req('GET', '/api/map');
    } else {
      const payload = args[0].endsWith('.json') ? JSON.parse(fs.readFileSync(args[0], 'utf8')) : JSON.parse(args.join(' '));
      out = await req('POST', '/api/map', payload);
    }
  } else if (cmd === 'balance') {
    const [amount = '0', player = ''] = args;
    out = await req('POST', '/api/balance', { amount: Number(amount), player });
  } else if (cmd === 'wait') {
    const sec = args[0] || '300';
    out = await req('GET', `/api/wait-event?timeout=${sec}`);
  } else if (cmd === 'vision') {
    out = await req('POST', '/api/screenshot', {});
  } else if (cmd === 'eye') {
    if (args.length === 3) {
      out = await req('POST', '/api/bot-vision', { lookX: Number(args[0]), lookY: Number(args[1]), lookZ: Number(args[2]) });
    } else if (args.length === 2) {
      out = await req('POST', '/api/bot-vision', { yaw: Number(args[0]), pitch: Number(args[1]) });
    } else {
      out = await req('POST', '/api/bot-vision', {});
    }
  } else if (cmd === 'place_real') {
    const steps = JSON.parse(fs.readFileSync(args[0], 'utf8'));
    out = await req('POST', '/api/act', { action: 'place_real', steps });
  } else if (cmd === 'break_real') {
    const [x1, y1, z1, x2, y2, z2, leavesFlag] = args;
    out = await req('POST', '/api/act', {
      action: 'break_real',
      x1: Number(x1), y1: Number(y1), z1: Number(z1),
      x2: Number(x2), y2: Number(y2), z2: Number(z2),
      leavesOnly: leavesFlag === 'leaves'
    });
  } else if (cmd === 'place_nbt') {
    const [idOrFile, x, y, z, rotation = 'NONE'] = args;
    const isFile = idOrFile.endsWith('.nbt');
    out = await req('POST', '/api/act', {
      action: 'place_nbt',
      ...(isFile ? { file: idOrFile } : { id: idOrFile }),
      x: Number(x), y: Number(y), z: Number(z), rotation
    });
  } else if (cmd === 'save_nbt') {
    const [outFile, x1, y1, z1, x2, y2, z2] = args;
    out = await req('POST', '/api/act', {
      action: 'save_nbt', outFile,
      x1: Number(x1), y1: Number(y1), z1: Number(z1),
      x2: Number(x2), y2: Number(y2), z2: Number(z2)
    });
  } else if (cmd === 'scan') {
    const [x, z, r = '16', step = '1'] = args;
    const q = new URLSearchParams({ ...(x ? { x } : {}), ...(z ? { z } : {}), r, step }).toString();
    out = await req('GET', `/api/scan?${q}`);
  } else if (cmd === 'scan3d') {
    const [x1, y1, z1, x2, y2, z2] = args;
    const q = new URLSearchParams({ x1, y1, z1, x2, y2, z2 }).toString();
    out = await req('GET', `/api/scan3d?${q}`);
  } else if (cmd === 'clean') {
    const [x1, y1, z1, x2, y2, z2] = args.map(Number);
    out = await req('POST', '/api/act', Number.isFinite(x1) ? { action: 'clean_floating', x1, y1, z1, x2, y2, z2 } : { action: 'clean_floating', r: 48 });
  } else if (cmd === 'interact') {
    const [x, y, z, side = 'up', item = ''] = args;
    out = await req('POST', '/api/act', { action: 'interact', x: Number(x), y: Number(y), z: Number(z), side, item });
  } else if (cmd === 'say') {
    out = await req('POST', '/api/act', { action: 'chat', text: args.join(' ') });
  } else if (cmd === 'come') {
    out = await req('POST', '/api/act', { action: 'come' });
  } else if (cmd === 'follow') {
    out = await req('POST', '/api/act', { action: 'follow' });
  } else if (cmd === 'guard') {
    out = await req('POST', '/api/act', { action: 'guard' });
  } else if (cmd === 'stop') {
    out = await req('POST', '/api/act', { action: 'stop' });
  } else if (cmd === 'undo') {
    out = await req('POST', '/api/act', { action: 'undo' });
  } else if (cmd === 'goto') {
    const [x, y, z, range = '1.5'] = args;
    out = await req('POST', '/api/act', { action: 'goto', x: Number(x), y: Number(y), z: Number(z), range: Number(range) });
  } else if (cmd === 'equip') {
    out = await req('POST', '/api/act', args[0] === 'all' ? { action: 'equip', allArmor: true } : { action: 'equip', item: args[0], slot: args[1] || 'hand' });
  } else if (cmd === 'cmd') {
    out = await req('POST', '/api/act', { action: 'command', command: args.join(' ') });
  } else if (cmd === 'build') {
    const ops = JSON.parse(fs.readFileSync(args[0], 'utf8'));
    out = await req('POST', '/api/act', { action: 'build', ops });
  } else {
    out = { error: 'Unknown cli command: ' + cmd };
  }

  console.log(JSON.stringify(out, null, 2));
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});

const fs = require('fs');

async function generateAndStart() {
  const act = (body) =>
    fetch('http://127.0.0.1:8080/api/act', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    }).then((r) => r.json());

  await act({
    action: 'chat',
    text: ' super fikir kanka! Tam karsindaki alana tas temelli, ladin kutuklu, dumani tuten bacali 1. Ormanlik Baskanligi binasini kurup etrafini tayga camlari, tomruk yigini ve dogal patikayla donatiyorum. Yaparken konustugun her seyi duyuyorum!'
  });

  // Scan exact ground heights so nothing floats!
  const scan = await (await fetch('http://127.0.0.1:8080/api/scan?x=17&z=-39&r=13&step=1')).json();
  const groundY = new Map();
  if (scan.grid) {
    for (const row of scan.grid) {
      for (const c of row) {
        groundY.set(`${c.x},${c.z}`, c.y);
      }
    }
  }
  const gy = (x, z) => groundY.get(`${x},${z}`) ?? 66;

  const ops = [];
  const set = (x, y, z, block) => ops.push({ op: 'set', x, y, z, block });
  const fill = (x1, y1, z1, x2, y2, z2, block, hollow = false) =>
    ops.push({ op: 'fill', x1, y1, z1, x2, y2, z2, block, hollow });

  // Building footprint:
  // Main Lodge: x = 12..18 (width 7), z = -43..-35 (length 9), floor y = 67 (1 block raised masonry foundation above y=66 lawn)
  // Front Covered Porch (East, facing player at x=24): x = 19..20, z = -41..-37, floor y = 67, steps at x = 21

  // 0. Ensure ground at y=66 under footprint & porch is solid
  for (let x = 11; x <= 22; x++) {
    for (let z = -45; z <= -33; z++) {
      const top = gy(x, z);
      for (let y = Math.min(top, 65); y <= 66; y++) {
        set(x, y, z, y === 66 ? 'minecraft:grass_block' : 'minecraft:dirt');
      }
    }
  }

  // 1. Raised Stone Foundation (y = 67)
  const stones = ['minecraft:cobblestone', 'minecraft:mossy_cobblestone', 'minecraft:stone_bricks', 'minecraft:andesite'];
  for (let x = 12; x <= 18; x++) {
    for (let z = -43; z <= -35; z++) {
      const isEdge = x === 12 || x === 18 || z === -43 || z === -35;
      if (isEdge) {
        const pick = stones[(Math.abs(x * 7 + z * 13)) % stones.length];
        set(x, 67, z, pick);
      } else {
        set(x, 67, z, 'minecraft:spruce_planks');
      }
    }
  }

  // Front Veranda Deck (x = 19..20, z = -41..-37, y = 67)
  for (let x = 19; x <= 20; x++) {
    for (let z = -41; z <= -37; z++) {
      if (x === 20 && (z === -41 || z === -37)) {
        set(x, 67, z, 'minecraft:mossy_stone_bricks');
      } else {
        set(x, 67, z, 'minecraft:spruce_planks');
      }
    }
  }
  // Entrance Stairs at x = 21, z = -40..-38
  for (let z = -40; z <= -38; z++) {
    set(21, 67, z, 'minecraft:stone_brick_stairs[facing=west,half=bottom]');
  }
  // Porch railings
  set(19, 68, -41, 'minecraft:spruce_fence');
  set(19, 68, -37, 'minecraft:spruce_fence');
  set(20, 68, -37, 'minecraft:spruce_fence');
  set(20, 68, -41, 'minecraft:spruce_fence');
  // Porch corner posts up to y=70
  for (let y = 68; y <= 70; y++) {
    set(20, y, -41, 'minecraft:spruce_log[axis=y]');
    set(20, y, -37, 'minecraft:spruce_log[axis=y]');
  }

  // 2. Boreal Timber Cabin Walls (y = 68..70)
  // Clear interior air first
  fill(13, 68, -42, 17, 72, -36, 'minecraft:air');

  // Corner & mid vertical spruce log pillars (Northern Eurasian cross-log corners!)
  const pillars = [
    [12, -43], [18, -43], [12, -35], [18, -35],
    [12, -39], [18, -41], [18, -37]
  ];
  for (let y = 68; y <= 71; y++) {
    for (const [px, pz] of pillars) {
      set(px, y, pz, 'minecraft:spruce_log[axis=y]');
    }
  }

  // Wall infill (stripped_spruce_log bottom & top bands, spruce_planks middle + windows!)
  for (let z = -42; z <= -36; z++) {
    if (z === -39) continue; // pillar on west, doorway on east
    // West wall (x=12) facing river
    set(12, 68, z, 'minecraft:stripped_spruce_log[axis=z]');
    set(12, 69, z, (z === -41 || z === -37) ? 'minecraft:glass_pane' : 'minecraft:spruce_planks');
    set(12, 70, z, 'minecraft:stripped_spruce_log[axis=z]');

    // East front wall (x=18)
    if (z !== -41 && z !== -37) {
      set(18, 68, z, 'minecraft:stripped_spruce_log[axis=z]');
      set(18, 69, z, (z === -40 || z === -38) ? 'minecraft:glass_pane' : 'minecraft:spruce_planks');
      set(18, 70, z, 'minecraft:stripped_spruce_log[axis=z]');
    }
  }

  for (let x = 13; x <= 17; x++) {
    // North wall (z=-43)
    set(x, 68, -43, 'minecraft:stripped_spruce_log[axis=x]');
    set(x, 69, -43, x === 15 ? 'minecraft:cobblestone' : (x === 14 || x === 16 ? 'minecraft:spruce_planks' : 'minecraft:glass_pane'));
    set(x, 70, -43, 'minecraft:stripped_spruce_log[axis=x]');

    // South wall (z=-35)
    set(x, 68, -35, 'minecraft:stripped_spruce_log[axis=x]');
    set(x, 69, -35, (x === 14 || x === 16) ? 'minecraft:glass_pane' : 'minecraft:spruce_planks');
    set(x, 70, -35, 'minecraft:stripped_spruce_log[axis=x]');
  }

  // Front Door at (18, 68..69, -39) + transom above
  set(18, 70, -39, 'minecraft:stripped_spruce_log[axis=z]');
  set(18, 68, -39, 'minecraft:spruce_door[facing=west,half=lower,hinge=left,open=false]');
  set(18, 69, -39, 'minecraft:spruce_door[facing=west,half=upper,hinge=left,open=false]');

  // 3. Steep Northern Eurasian Gable Roof (running North-South along z = -44..-34, sloping East-West!)
  // Overhang eaves at x=11 and x=19, climbing to ridge at x=15 (y=75)
  for (let z = -44; z <= -34; z++) {
    const isTrim = z === -44 || z === -34;
    const stairMat = isTrim ? 'minecraft:deepslate_brick_stairs' : 'minecraft:dark_oak_stairs';
    const slabMat = isTrim ? 'minecraft:deepslate_brick_slab' : 'minecraft:dark_oak_slab';

    set(11, 71, z, `${stairMat}[facing=east,half=bottom]`);
    set(19, 71, z, `${stairMat}[facing=west,half=bottom]`);

    set(12, 72, z, `${stairMat}[facing=east,half=bottom]`);
    set(18, 72, z, `${stairMat}[facing=west,half=bottom]`);

    set(13, 73, z, `${stairMat}[facing=east,half=bottom]`);
    set(17, 73, z, `${stairMat}[facing=west,half=bottom]`);

    set(14, 74, z, `${stairMat}[facing=east,half=bottom]`);
    set(16, 74, z, `${stairMat}[facing=west,half=bottom]`);

    set(15, 74, z, 'minecraft:stripped_spruce_log[axis=z]');
    set(15, 75, z, `${slabMat}[type=bottom]`);
  }

  // Gable end triangles (z = -43 and z = -35)
  for (const gz of [-43, -35]) {
    for (let x = 13; x <= 17; x++) set(x, 71, gz, 'minecraft:spruce_planks');
    for (let x = 13; x <= 17; x++) set(x, 72, gz, x === 15 ? 'minecraft:glass_pane' : 'minecraft:spruce_planks');
    for (let x = 14; x <= 16; x++) set(x, 73, gz, 'minecraft:spruce_planks');
    set(15, 73, gz, 'minecraft:spruce_log[axis=y]');
  }

  // Porch Canopy Roof (x = 19..21, z = -42..-36)
  for (let z = -42; z <= -36; z++) {
    set(19, 71, z, 'minecraft:spruce_slab[type=top]');
    set(20, 71, z, 'minecraft:dark_oak_slab[type=bottom]');
  }
  // Hanging Lanterns under front porch!
  set(20, 70, -39, 'minecraft:lantern[hanging=true]');

  // 4. Stone & Brick Fireplace + Smoking Chimney (North side x=15, z=-44)
  set(15, 68, -43, 'minecraft:campfire[lit=true,signal_fire=false,facing=south]');
  set(15, 69, -43, 'minecraft:cobblestone_wall');
  for (let y = 67; y <= 75; y++) {
    set(15, y, -44, y < 71 ? 'minecraft:cobblestone' : 'minecraft:bricks');
  }
  set(15, 76, -44, 'minecraft:campfire[lit=true,signal_fire=false,facing=north]');
  set(15, 76, -45, 'minecraft:spruce_trapdoor[facing=north,open=true]');
  set(15, 76, -43, 'minecraft:spruce_trapdoor[facing=south,open=true]');
  set(14, 76, -44, 'minecraft:spruce_trapdoor[facing=west,open=true]');
  set(16, 76, -44, 'minecraft:spruce_trapdoor[facing=east,open=true]');

  // 5. Forestry Directorate Interior (y = 68..69)
  // Forestry Chief Map Table & Desk
  set(14, 68, -41, 'minecraft:cartography_table');
  set(13, 68, -41, 'minecraft:lectern[facing=east]');
  set(13, 68, -40, 'minecraft:spruce_stairs[facing=west,half=bottom]');
  // Bookshelves & Barrels & Workstations
  set(13, 68, -42, 'minecraft:bookshelf');
  set(13, 69, -42, 'minecraft:bookshelf');
  set(17, 68, -42, 'minecraft:barrel[facing=south]');
  set(17, 69, -42, 'minecraft:barrel[facing=south]');
  set(16, 68, -42, 'minecraft:crafting_table');
  set(14, 68, -42, 'minecraft:furnace[facing=south]');
  // Ranger Bed & Carpet in South wing
  set(13, 68, -36, 'minecraft:green_bed[facing=west,part=head]');
  set(14, 68, -36, 'minecraft:green_bed[facing=west,part=foot]');
  set(16, 68, -36, 'minecraft:chest[facing=north]');
  for (let x = 15; x <= 17; x++) {
    for (let z = -40; z <= -38; z++) {
      set(x, 68, z, (x + z) % 2 === 0 ? 'minecraft:moss_carpet' : 'minecraft:brown_carpet');
    }
  }
  // Interior warm lanterns
  set(15, 71, -39, 'minecraft:chain[axis=y]');
  set(15, 70, -39, 'minecraft:lantern[hanging=true]');

  // Green Banner (Forestry Emblem!) flanking front entrance
  set(18, 70, -40, 'minecraft:green_wall_banner[facing=east]');
  set(18, 70, -38, 'minecraft:green_wall_banner[facing=east]');

  // 6. NATURALIZING THE SURROUNDINGS (Kuzey Avrasya Tayga Peyzaji!)
  // Helper: Hand-crafted Boreal Conical Spruce Tree
  function addBorealSpruce(tx, tz, height = 8) {
    const base = gy(tx, tz) + 1;
    // Podzol & moss roots around base
    for (let dx = -1; dx <= 1; dx++) {
      for (let dz = -1; dz <= 1; dz++) {
        if (Math.abs(dx) + Math.abs(dz) <= 1) {
          set(tx + dx, gy(tx + dx, tz + dz), tz + dz, 'minecraft:podzol');
        }
      }
    }
    for (let dy = 0; dy < height; dy++) {
      set(tx, base + dy, tz, 'minecraft:spruce_log[axis=y]');
    }
    // Tapered boreal pine needles layers
    const crownStart = base + 2;
    for (let y = crownStart; y <= base + height + 1; y++) {
      const rel = y - crownStart;
      const rad = y >= base + height ? 0 : (rel % 2 === 0 ? Math.max(1, 2 - Math.floor(rel / 4)) : 1);
      for (let dx = -rad; dx <= rad; dx++) {
        for (let dz = -rad; dz <= rad; dz++) {
          if (dx === 0 && dz === 0 && y < base + height) continue;
          if (rad === 2 && Math.abs(dx) === 2 && Math.abs(dz) === 2) continue;
          ops.push({ op: 'set', x: tx + dx, y, z: tz + dz, block: 'minecraft:spruce_leaves[persistent=true]', onlyAir: true });
        }
      }
    }
  }

  // Place 3 scenic Northern Spruce trees around the lodge WITHOUT blocking East front view!
  addBorealSpruce(14, -47, 9);
  addBorealSpruce(11, -32, 8);
  addBorealSpruce(21, -46, 7);

  // Stacked Forestry Timber Pile (Tomruk Istifi!) at South-East side (x=20..21, z=-34..-32)
  for (let z = -34; z <= -32; z++) {
    set(19, gy(19, z) + 1, z, 'minecraft:spruce_log[axis=z]');
    set(20, gy(20, z) + 1, z, 'minecraft:spruce_log[axis=z]');
    set(21, gy(21, z) + 1, z, 'minecraft:spruce_log[axis=z]');
    set(20, gy(20, z) + 2, z, 'minecraft:spruce_log[axis=z]');
  }
  set(18, gy(18, -33) + 1, -33, 'minecraft:spruce_fence');
  set(22, gy(22, -33) + 1, -33, 'minecraft:spruce_fence');

  // Natural Winding Boreal Forest Path from front steps (22, -39) east/north
  const pathPoints = [
    [22, -39], [22, -38], [23, -39], [23, -40], [24, -40], [25, -40], [25, -41], [26, -41]
  ];
  const pathMats = ['minecraft:coarse_dirt', 'minecraft:podzol', 'minecraft:gravel', 'minecraft:mossy_cobblestone'];
  for (let i = 0; i < pathPoints.length; i++) {
    const [px, pz] = pathPoints[i];
    const py = gy(px, pz);
    set(px, py, pz, pathMats[i % pathMats.length]);
    if (i % 2 === 0 && gy(px, pz + 1) === py) {
      set(px, py, pz + 1, pathMats[(i + 1) % pathMats.length]);
    }
  }

  // Wooden Trail Lamp Post at (23, -37)
  const lpY = gy(23, -37) + 1;
  set(23, lpY, -37, 'minecraft:cobblestone_wall');
  set(23, lpY + 1, -37, 'minecraft:spruce_fence');
  set(23, lpY + 2, -37, 'minecraft:spruce_fence');
  set(23, lpY + 3, -37, 'minecraft:spruce_fence');
  set(22, lpY + 3, -37, 'minecraft:spruce_fence');
  set(22, lpY + 2, -37, 'minecraft:lantern[hanging=true]');

  // Mossy Boulders + Boreal Undergrowth (Ferns, Sweet Berry Bushes, Moss Carpet)
  const boulderSpots = [[22, -43], [16, -32]];
  for (const [bx, bz] of boulderSpots) {
    const by = gy(bx, bz) + 1;
    set(bx, by, bz, 'minecraft:mossy_cobblestone');
    set(bx + 1, gy(bx + 1, bz) + 1, bz, 'minecraft:cobblestone_slab[type=bottom]');
    set(bx, gy(bx, bz + 1) + 1, bz + 1, 'minecraft:andesite_slab[type=bottom]');
  }

  const flora = [
    [21, -42, 'minecraft:sweet_berry_bush[age=3]'],
    [21, -36, 'minecraft:sweet_berry_bush[age=3]'],
    [23, -42, 'minecraft:fern'],
    [24, -38, 'minecraft:fern'],
    [19, -44, 'minecraft:fern'],
    [17, -45, 'minecraft:fern'],
    [15, -33, 'minecraft:fern'],
    [20, -43, 'minecraft:dandelion'],
    [22, -36, 'minecraft:poppy']
  ];
  for (const [fx, fz, fb] of flora) {
    ops.push({ op: 'set', x: fx, y: gy(fx, fz) + 1, z: fz, block: fb, onlyAir: true });
  }

  fs.writeFileSync('/home/user/arena-mc/forestry_ops.json', JSON.stringify(ops));
  console.log('Total Forestry Directorate + Taiga ops:', ops.length);

  // Start ASYNC progressive build so we listen in real-time while building!
  const startRes = await act({ action: 'build', ops, delayMs: 40, async: true });
  console.log('Async build started:', startRes);
}

generateAndStart().catch(console.error);

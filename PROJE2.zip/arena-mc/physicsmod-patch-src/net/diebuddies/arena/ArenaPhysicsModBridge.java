package net.diebuddies.arena;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.diebuddies.config.ConfigAnimations;
import net.diebuddies.config.ConfigBlocks;
import net.diebuddies.config.ConfigClient;
import net.diebuddies.config.ConfigCloth;
import net.diebuddies.config.ConfigMobs;
import net.diebuddies.config.ConfigServer;
import net.diebuddies.config.ConfigVines;
import net.diebuddies.physics.Explosion;
import net.diebuddies.physics.IRigidBody;
import net.diebuddies.physics.PhysicsMod;
import net.diebuddies.physics.PhysicsWorld;
import net.diebuddies.physics.ServerPhysicsMod;
import net.diebuddies.physics.animation.AnimationType;
import net.diebuddies.physics.animation.CurveType;
import net.diebuddies.physics.settings.blocks.BlockPhysicsType;
import net.diebuddies.physics.settings.blocks.BlockSetting;
import net.diebuddies.physics.settings.mobs.MobPhysicsType;
import net.diebuddies.physics.settings.mobs.MobSetting;
import net.diebuddies.physics.vines.DynamicSetting;
import net.diebuddies.util.DoublyLinkedList;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.registry.Registries;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.property.Property;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import org.joml.Vector3f;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;

/**
 * ArenaAI <-> Physics Mod Pro (NVIDIA PhysX 5) Full Universal Bridge (v2.0):
 * - 100% Read/Write/Save/Reload API access across ALL 7 Physics Mod Pro config classes:
 *   ConfigClient (~110 settings + custom 3D Gravity & Buoyancy), ConfigServer,
 *   ConfigBlocks (global + per-block overrides), ConfigMobs (global + per-mob overrides),
 *   ConfigVines (doors/trapdoors/signs/vines), ConfigCloth (capes/cloth), ConfigAnimations.
 * - Records every structurally collapsed block (and trigger block) for instant /onar rewind.
 * - Cleans up active PhysX 5 rigid bodies & suppresses break-debris during /onar restore.
 */
public final class ArenaPhysicsModBridge {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static final Map<BlockPos, BlockState> COLLAPSED_BLUEPRINTS = new ConcurrentHashMap<>();
    private static final Map<BlockPos, BrokenSeedEntry> RECENT_BROKEN_TRIGGERS = new ConcurrentHashMap<>();
    private static final Map<BlockPos, Long> SUPPRESSED_UNTIL_MS = new ConcurrentHashMap<>();

    public static volatile boolean suppressCollapseHooks = false;
    private static volatile boolean clientInitialized = false;
    private static volatile boolean commonHooksRegistered = false;
    private static volatile boolean blueprintsLoaded = false;

    private record BrokenSeedEntry(BlockState state, long timestampMs) {}

    private ArenaPhysicsModBridge() {}

    public static void ensureOptimalServerDefaults() {
        ConfigServer.collapse = true;
        ConfigServer.dropBlocks = false;
        if (ConfigServer.maxCollapseObjects < 2500) {
            ConfigServer.maxCollapseObjects = 2500;
        }
        if (ConfigServer.collapseSpeed <= 0) {
            ConfigServer.collapseSpeed = 2;
        }
        try { ConfigServer.save(); } catch (Throwable ignored) {}
    }

    public static void initClient() {
        if (clientInitialized) return;
        clientInitialized = true;
        try {
            if (ConfigBlocks.PARENT_BLOCK_SETTING != null) {
                if (ConfigBlocks.PARENT_BLOCK_SETTING.lifetime < 30.0) {
                    ConfigBlocks.PARENT_BLOCK_SETTING.lifetime = 45.0;
                    ConfigBlocks.PARENT_BLOCK_SETTING.lifetimeVariance = 5.0;
                }
                if (ConfigBlocks.PARENT_BLOCK_SETTING.type == null
                        || ConfigBlocks.PARENT_BLOCK_SETTING.type == BlockPhysicsType.PARTICLES
                        || ConfigBlocks.PARENT_BLOCK_SETTING.type == BlockPhysicsType.OFF) {
                    ConfigBlocks.PARENT_BLOCK_SETTING.type = BlockPhysicsType.BLOCKY;
                }
                ConfigBlocks.save();
            }
            if (ConfigClient.maxPhysicsObjects < 800) {
                ConfigClient.maxPhysicsObjects = 1200;
                ConfigClient.save();
            }
        } catch (Throwable ignored) {}

        registerCommonHooks();
    }

    public static void initServer() {
        ensureOptimalServerDefaults();
        registerCommonHooks();
    }

    private static synchronized void registerCommonHooks() {
        if (commonHooksRegistered) return;
        commonHooksRegistered = true;

        Function<String, String> rpcHandler = ArenaPhysicsModBridge::handleRpcJson;
        System.getProperties().put("arena.physicsmod.rpc", rpcHandler);
        System.setProperty("arena.physicsmod.active", "true");
        System.setProperty("arena.physicsmod.version", "3.0.14-ArenaPro-v2-FullAPI");

        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (!world.isClient && world instanceof ServerWorld sw && !suppressCollapseHooks) {
                BlockPos target = hitResult.getBlockPos().offset(hitResult.getSide());
                ServerPhysicsMod.scheduleStructuralCheck(sw, target, 3);
            }
            return ActionResult.PASS;
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(
                    CommandManager.literal("fizikmod")
                            .executes(ctx -> {
                                ctx.getSource().sendFeedback(() -> Text.literal(buildStatusSummary()), false);
                                return 1;
                            })
                            .then(CommandManager.literal("durum").executes(ctx -> {
                                ctx.getSource().sendFeedback(() -> Text.literal(buildStatusSummary()), false);
                                return 1;
                            }))
                            .then(CommandManager.literal("blok").executes(ctx -> {
                                setClientBlockMode(BlockPhysicsType.BLOCKY);
                                ctx.getSource().sendFeedback(() -> Text.literal("§a[Physics Mod Pro] Yıkım modu: TAM BLOK (BLOCKY) olarak ayarlandı."), true);
                                return 1;
                            }))
                            .then(CommandManager.literal("kirik").executes(ctx -> {
                                setClientBlockMode(BlockPhysicsType.FRACTURED);
                                ctx.getSource().sendFeedback(() -> Text.literal("§a[Physics Mod Pro] Yıkım modu: PARÇALI KIRILMA (FRACTURED) olarak ayarlandı."), true);
                                return 1;
                            }))
                            .then(CommandManager.literal("voksel").executes(ctx -> {
                                setClientBlockMode(BlockPhysicsType.FRACTURED_VOXEL);
                                ctx.getSource().sendFeedback(() -> Text.literal("§a[Physics Mod Pro] Yıkım modu: VOKSEL KIRILMA (FRACTURED_VOXEL) olarak ayarlandı."), true);
                                return 1;
                            }))
                            .then(CommandManager.literal("omur")
                                    .then(CommandManager.argument("saniye", DoubleArgumentType.doubleArg(5.0, 300.0))
                                            .executes(ctx -> {
                                                double sec = DoubleArgumentType.getDouble(ctx, "saniye");
                                                setClientBlockLifetime(sec);
                                                ctx.getSource().sendFeedback(() -> Text.literal("§a[Physics Mod Pro] Yıkılan enkaz ömrü: " + (int) sec + " sn olarak ayarlandı."), true);
                                                return 1;
                                            })))
                            .then(CommandManager.literal("hiz")
                                    .then(CommandManager.argument("carpan", FloatArgumentType.floatArg(0.05f, 4.0f))
                                            .executes(ctx -> {
                                                float sp = FloatArgumentType.getFloat(ctx, "carpan");
                                                ConfigClient.playbackSpeed = sp;
                                                ConfigClient.save();
                                                ctx.getSource().sendFeedback(() -> Text.literal("§a[Physics Mod Pro] Fizik simülasyon hızı (playbackSpeed): " + sp + "x"), true);
                                                return 1;
                                            })))
                            .then(CommandManager.literal("yercekimi")
                                    .then(CommandManager.argument("x", FloatArgumentType.floatArg(-50f, 50f))
                                            .then(CommandManager.argument("y", FloatArgumentType.floatArg(-50f, 50f))
                                                    .then(CommandManager.argument("z", FloatArgumentType.floatArg(-50f, 50f))
                                                            .executes(ctx -> {
                                                                float gx = FloatArgumentType.getFloat(ctx, "x");
                                                                float gy = FloatArgumentType.getFloat(ctx, "y");
                                                                float gz = FloatArgumentType.getFloat(ctx, "z");
                                                                String dim = ctx.getSource().getWorld().getRegistryKey().getValue().toString();
                                                                ConfigClient.setGravity(dim, new Vector3f(gx, gy, gz));
                                                                ConfigClient.gravityChanged = true;
                                                                ConfigClient.save();
                                                                ctx.getSource().sendFeedback(() -> Text.literal(
                                                                        String.format(Locale.US, "§a[Physics Mod Pro] Yerçekimi (%s) = (%.2f, %.2f, %.2f) olarak ayarlandı!", dim, gx, gy, gz)
                                                                ), true);
                                                                return 1;
                                                            })))))
                            .then(CommandManager.literal("ayar")
                                    .then(CommandManager.argument("alan", StringArgumentType.word())
                                            .then(CommandManager.argument("deger", StringArgumentType.greedyString())
                                                    .executes(ctx -> {
                                                        String field = StringArgumentType.getString(ctx, "alan");
                                                        String val = StringArgumentType.getString(ctx, "deger");
                                                        boolean ok = applySingleSettingByName(field, val);
                                                        ctx.getSource().sendFeedback(() -> Text.literal(
                                                                ok ? ("§a[Physics Mod Pro] Ayar güncellendi: " + field + " = " + val)
                                                                   : ("§c[Physics Mod Pro] Geçersiz alan veya değer: " + field)
                                                        ), true);
                                                        return ok ? 1 : 0;
                                                    }))))
                            .then(CommandManager.literal("mod")
                                    .then(CommandManager.argument("tip", StringArgumentType.word())
                                            .executes(ctx -> {
                                                String raw = StringArgumentType.getString(ctx, "tip").toUpperCase(Locale.ROOT);
                                                BlockPhysicsType t = BlockPhysicsType.BLOCKY;
                                                if (raw.contains("VOX")) t = BlockPhysicsType.FRACTURED_VOXEL;
                                                else if (raw.contains("FRAC") || raw.contains("KIR")) t = BlockPhysicsType.FRACTURED;
                                                else if (raw.contains("PART")) t = BlockPhysicsType.PARTICLES;
                                                setClientBlockMode(t);
                                                final BlockPhysicsType chosen = t;
                                                ctx.getSource().sendFeedback(() -> Text.literal("§a[Physics Mod Pro] Blok modu -> " + chosen.name()), true);
                                                return 1;
                                            })))
            );
        });
    }

    public static boolean applySingleSettingByName(String name, String rawVal) {
        try {
            JsonObject req = new JsonObject();
            req.addProperty("op", "set_settings");
            JsonObject target = new JsonObject();
            if ("true".equalsIgnoreCase(rawVal) || "false".equalsIgnoreCase(rawVal)) {
                target.addProperty(name, Boolean.parseBoolean(rawVal));
            } else {
                try {
                    target.addProperty(name, Double.parseDouble(rawVal));
                } catch (NumberFormatException nfe) {
                    target.addProperty(name, rawVal);
                }
            }
            if (hasStaticField(ConfigServer.class, name)) {
                req.add("server", target);
            } else {
                req.add("client", target);
            }
            JsonObject out = JsonParser.parseString(handleRpcJson(req.toString())).getAsJsonObject();
            return out.has("updatedCount") && out.get("updatedCount").getAsInt() > 0;
        } catch (Throwable t) {
            return false;
        }
    }

    private static boolean hasStaticField(Class<?> cls, String name) {
        for (Field f : cls.getDeclaredFields()) {
            if (Modifier.isPublic(f.getModifiers()) && Modifier.isStatic(f.getModifiers()) && !Modifier.isFinal(f.getModifiers()) && f.getName().equals(name)) {
                return true;
            }
        }
        return false;
    }

    public static void recordBrokenTriggerBlock(ServerWorld world, BlockPos pos, BlockState state) {
        if (suppressCollapseHooks || state == null || state.isAir()) return;
        ensureBlueprintsLoaded();
        BlockPos imm = pos.toImmutable();
        RECENT_BROKEN_TRIGGERS.put(imm, new BrokenSeedEntry(state, System.currentTimeMillis()));
        long now = System.currentTimeMillis();
        RECENT_BROKEN_TRIGGERS.entrySet().removeIf(e -> now - e.getValue().timestampMs() > 15_000L);
    }

    public static void recordCollapsedBlock(ServerWorld world, BlockPos pos, BlockState state) {
        if (suppressCollapseHooks || state == null || state.isAir()) return;
        ensureBlueprintsLoaded();
        BlockPos imm = pos.toImmutable();
        COLLAPSED_BLUEPRINTS.putIfAbsent(imm, state);

        long now = System.currentTimeMillis();
        for (Map.Entry<BlockPos, BrokenSeedEntry> e : RECENT_BROKEN_TRIGGERS.entrySet()) {
            if (now - e.getValue().timestampMs() <= 8_000L && e.getKey().getSquaredDistance(imm) <= 900.0) {
                COLLAPSED_BLUEPRINTS.putIfAbsent(e.getKey(), e.getValue().state());
            }
        }
    }

    public static boolean isSuppressedPos(BlockPos pos) {
        if (pos == null) return false;
        if (suppressCollapseHooks) return true;
        Long until = SUPPRESSED_UNTIL_MS.get(pos);
        if (until == null) return false;
        if (System.currentTimeMillis() <= until) return true;
        SUPPRESSED_UNTIL_MS.remove(pos, until);
        return false;
    }

    public static void suppressDebrisAt(BlockPos pos, long durationMs) {
        if (pos == null) return;
        SUPPRESSED_UNTIL_MS.put(pos.toImmutable(), System.currentTimeMillis() + durationMs);
    }

    public static synchronized int repairNear(ServerWorld world, BlockPos center, double radius) {
        ensureBlueprintsLoaded();
        double r2 = radius * radius;
        List<Map.Entry<BlockPos, BlockState>> toRestore = new ArrayList<>();
        for (Map.Entry<BlockPos, BlockState> e : COLLAPSED_BLUEPRINTS.entrySet()) {
            if (e.getKey().getSquaredDistance(center) <= r2) {
                toRestore.add(e);
            }
        }
        toRestore.sort(Comparator.comparingInt(e -> e.getKey().getY()));

        ServerPhysicsMod spm = ServerPhysicsMod.INSTANCE;
        if (spm != null) {
            spm.clearActiveWavesNear(world, center, radius + 16.0);
        }

        int restored = 0;
        suppressCollapseHooks = true;
        try {
            for (Map.Entry<BlockPos, BlockState> e : toRestore) {
                BlockPos p = e.getKey();
                BlockState target = e.getValue();
                suppressDebrisAt(p, 4000L);
                BlockState cur = world.getBlockState(p);
                if (!cur.equals(target)) {
                    world.setBlockState(p, target, Block.NOTIFY_ALL);
                    restored++;
                }
                COLLAPSED_BLUEPRINTS.remove(p);
                liftEntitiesOutOfBlock(world, p);
            }
        } finally {
            suppressCollapseHooks = false;
        }

        clearClientPhysXBodiesNear(center.getX() + 0.5, center.getY() + 0.5, center.getZ() + 0.5, radius + 20.0);
        saveBlueprintsAsync();
        return restored;
    }

    public static int clearClientPhysXBodiesNear(double cx, double cy, double cz, double radius) {
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc == null || mc.world == null) return 0;
            PhysicsMod pm = PhysicsMod.getInstance(mc.world);
            if (pm == null || pm.getPhysicsWorld() == null) return 0;
            PhysicsWorld pw = pm.getPhysicsWorld();
            double r2 = radius * radius;
            pw.queue(() -> {
                try {
                    DoublyLinkedList<IRigidBody> list = pw.getBodies();
                    for (IRigidBody body : list) {
                        if (body == null || body.isDestroyed()) continue;
                        BlockPos bp = body.getBlockPos();
                        if (bp != null) {
                            double dx = bp.getX() - cx, dy = bp.getY() - cy, dz = bp.getZ() - cz;
                            if (dx * dx + dy * dy + dz * dz <= r2) {
                                body.destroy();
                            }
                        } else if (radius >= 50000.0) {
                            body.destroy();
                        }
                    }
                    pm.fallingBlocks.clear();
                } catch (Throwable ignored) {}
            });
            return 1;
        } catch (Throwable ignored) {
            return 0;
        }
    }

    private static void liftEntitiesOutOfBlock(ServerWorld world, BlockPos p) {
        Box box = new Box(p).expand(0.05);
        for (Entity ent : world.getOtherEntities(null, box)) {
            BlockPos check = p.up();
            while (check.getY() < p.getY() + 16 && !world.getBlockState(check).getCollisionShape(world, check).isEmpty()) {
                check = check.up();
            }
            ent.requestTeleport(ent.getX(), check.getY() + 0.05, ent.getZ());
            ent.setVelocity(ent.getVelocity().x, Math.max(0.0, ent.getVelocity().y), ent.getVelocity().z);
            ent.fallDistance = 0f;
        }
    }

    public static void setClientBlockMode(BlockPhysicsType type) {
        try {
            if (ConfigBlocks.PARENT_BLOCK_SETTING != null) {
                ConfigBlocks.PARENT_BLOCK_SETTING.type = type;
                ConfigBlocks.save();
            }
            if (ConfigClient.blockSetting != null) {
                ConfigClient.blockSetting.type = type;
                ConfigClient.save();
            }
        } catch (Throwable ignored) {}
    }

    public static void setClientBlockLifetime(double seconds) {
        try {
            if (ConfigBlocks.PARENT_BLOCK_SETTING != null) {
                ConfigBlocks.PARENT_BLOCK_SETTING.lifetime = seconds;
                ConfigBlocks.save();
            }
            if (ConfigClient.blockSetting != null) {
                ConfigClient.blockSetting.lifetime = seconds;
                ConfigClient.save();
            }
        } catch (Throwable ignored) {}
    }

    public static String buildStatusSummary() {
        StringBuilder sb = new StringBuilder();
        sb.append("§b§l[Physics Mod Pro v3.0.14 + ArenaAI v2 Full API]§r\n");
        try {
            sb.append("§7PhysX 5: §aAktif§7 (Hız: §f").append(ConfigClient.playbackSpeed).append("x§7)\n");
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc != null && mc.world != null) {
                PhysicsMod pm = PhysicsMod.getInstance(mc.world);
                if (pm != null && pm.getPhysicsWorld() != null) {
                    PhysicsWorld pw = pm.getPhysicsWorld();
                    sb.append("§7Sahnedeki Rijit Cisim: §f").append(pw.getBodies().size())
                      .append(" §7| Ragdoll: §f").append(pw.getRagdolls().size())
                      .append(" §7| Okyanus: ").append(ConfigClient.oceanPhysics ? "§aAçık" : "§cKapalı")
                      .append(" §7| Rüzgar: ").append(ConfigClient.windPhysics ? "§aAçık" : "§cKapalı")
                      .append("\n");
                }
            }
            Vector3f g = ConfigClient.getGravity("minecraft:overworld");
            if (g != null) {
                sb.append(String.format(Locale.US, "§7Yerçekimi (Overworld): §f(%.2f, %.2f, %.2f)\n", g.x, g.y, g.z));
            }
            BlockPhysicsType bType = ConfigBlocks.PARENT_BLOCK_SETTING != null
                    ? ConfigBlocks.PARENT_BLOCK_SETTING.type : BlockPhysicsType.BLOCKY;
            double life = ConfigBlocks.PARENT_BLOCK_SETTING != null
                    ? ConfigBlocks.PARENT_BLOCK_SETTING.lifetime : 45.0;
            sb.append("§7Blok Modu: §e").append(bType.name())
              .append(" §7| Enkaz Ömrü: §e").append((int) life).append("sn")
              .append(" §7| Kayıtlı /onar Şablonu: §e").append(COLLAPSED_BLUEPRINTS.size()).append(" blok");
        } catch (Throwable t) {
            sb.append("§cDurum okunurken hata: ").append(t.getMessage());
        }
        return sb.toString();
    }

    public static String handleRpcJson(String rawJson) {
        JsonObject out = new JsonObject();
        try {
            JsonObject req = (rawJson == null || rawJson.isBlank())
                    ? new JsonObject()
                    : JsonParser.parseString(rawJson).getAsJsonObject();
            String op = req.has("op") ? req.get("op").getAsString() : "status";

            switch (op) {
                case "status" -> {
                    out.addProperty("ok", true);
                    out.addProperty("physicsModLoaded", true);
                    out.addProperty("version", "3.0.14-ArenaPro-v2-FullAPI");
                    out.addProperty("fullSettingsApi", true);
                    out.addProperty("collapseEnabled", ConfigServer.collapse);
                    out.addProperty("dropBlocks", ConfigServer.dropBlocks);
                    out.addProperty("maxCollapseObjects", ConfigServer.maxCollapseObjects);
                    out.addProperty("collapseSpeed", ConfigServer.collapseSpeed);
                    out.addProperty("storedBlueprintBlocks", COLLAPSED_BLUEPRINTS.size());
                    out.addProperty("playbackSpeed", ConfigClient.playbackSpeed);
                    out.addProperty("oceanPhysics", ConfigClient.oceanPhysics);
                    out.addProperty("snowPhysics", ConfigClient.snowPhysics);
                    out.addProperty("smokePhysics", ConfigClient.smokePhysics);
                    out.addProperty("windPhysics", ConfigClient.windPhysics);
                    out.addProperty("liquidPhysics", ConfigClient.liquidPhysics);
                    out.addProperty("cudaLiquids", ConfigClient.cudaLiquids);
                    out.addProperty("mobPhysics", ConfigClient.mobPhysics);
                    out.addProperty("blockPhysics", ConfigClient.blockPhysics);
                    Vector3f g = ConfigClient.getGravity("minecraft:overworld");
                    if (g != null) {
                        JsonObject gj = new JsonObject();
                        gj.addProperty("x", g.x);
                        gj.addProperty("y", g.y);
                        gj.addProperty("z", g.z);
                        out.add("overworldGravity", gj);
                    }
                    try {
                        if (ConfigBlocks.PARENT_BLOCK_SETTING != null) {
                            out.addProperty("blockPhysicsType", ConfigBlocks.PARENT_BLOCK_SETTING.type.name());
                            out.addProperty("blockLifetimeSec", ConfigBlocks.PARENT_BLOCK_SETTING.lifetime);
                        }
                        if (ConfigClient.mobSetting != null) {
                            out.addProperty("mobPhysicsType", ConfigClient.mobSetting.type.name());
                            out.addProperty("mobLifetimeSec", ConfigClient.mobSetting.lifetime);
                        }
                        MinecraftClient mc = MinecraftClient.getInstance();
                        if (mc != null && mc.world != null) {
                            PhysicsMod pm = PhysicsMod.getInstance(mc.world);
                            if (pm != null && pm.getPhysicsWorld() != null) {
                                out.addProperty("activePhysxBodies", pm.getPhysicsWorld().getBodies().size());
                                out.addProperty("activeRagdolls", pm.getPhysicsWorld().getRagdolls().size());
                                out.addProperty("gpuMemoryBytes", pm.getPhysicsWorld().getGPUMemoryUsage());
                                out.addProperty("cudaAvailable", pm.getPhysicsWorld().getGPUMemoryUsage() >= 0);
                            }
                        }
                    } catch (Throwable ignored) {}
                }
                case "get_all_settings" -> {
                    String cat = req.has("category") ? req.get("category").getAsString().toLowerCase(Locale.ROOT) : "all";
                    out.addProperty("ok", true);
                    if ("all".equals(cat) || "client".equals(cat)) {
                        out.add("client", dumpStaticFields(ConfigClient.class));
                    }
                    if ("all".equals(cat) || "server".equals(cat)) {
                        out.add("server", dumpStaticFields(ConfigServer.class));
                    }
                    if ("all".equals(cat) || "blocks".equals(cat)) {
                        JsonObject bj = new JsonObject();
                        if (ConfigBlocks.PARENT_BLOCK_SETTING != null) {
                            bj.add("default", serializeBlockSetting(ConfigBlocks.PARENT_BLOCK_SETTING));
                        }
                        JsonObject custom = new JsonObject();
                        if (ConfigBlocks.customizedBlocks != null) {
                            for (Map.Entry<String, BlockSetting> e : ConfigBlocks.customizedBlocks.entrySet()) {
                                if (e.getValue() != null && e.getValue().type != BlockPhysicsType.MAIN_RULE) {
                                    custom.add(e.getKey(), serializeBlockSetting(e.getValue()));
                                }
                            }
                        }
                        bj.addProperty("totalRegisteredBlocks", ConfigBlocks.customizedBlocks != null ? ConfigBlocks.customizedBlocks.size() : 0);
                        bj.add("overrides", custom);
                        out.add("blocks", bj);
                    }
                    if ("all".equals(cat) || "mobs".equals(cat)) {
                        JsonObject mj = new JsonObject();
                        if (ConfigClient.mobSetting != null) {
                            mj.add("globalRule", serializeMobSetting(ConfigClient.mobSetting));
                        }
                        if (ConfigMobs.PARENT_MOB_SETTING != null) {
                            mj.add("default", serializeMobSetting(ConfigMobs.PARENT_MOB_SETTING));
                        }
                        JsonObject custom = new JsonObject();
                        if (ConfigMobs.customizedMobs != null) {
                            for (Map.Entry<String, MobSetting> e : ConfigMobs.customizedMobs.entrySet()) {
                                if (e.getValue() != null && e.getValue().type != MobPhysicsType.MAIN_RULE) {
                                    custom.add(e.getKey(), serializeMobSetting(e.getValue()));
                                }
                            }
                        }
                        mj.addProperty("totalRegisteredMobs", ConfigMobs.customizedMobs != null ? ConfigMobs.customizedMobs.size() : 0);
                        mj.add("overrides", custom);
                        out.add("mobs", mj);
                    }
                    if ("all".equals(cat) || "gravities".equals(cat)) {
                        JsonObject gravs = new JsonObject();
                        if (ConfigClient.customizedGravities != null) {
                            for (Map.Entry<String, Vector3f> e : ConfigClient.customizedGravities.entrySet()) {
                                Vector3f v = e.getValue();
                                if (v != null) {
                                    JsonObject vj = new JsonObject();
                                    vj.addProperty("x", v.x); vj.addProperty("y", v.y); vj.addProperty("z", v.z);
                                    gravs.add(e.getKey(), vj);
                                }
                            }
                        }
                        JsonObject buoys = new JsonObject();
                        if (ConfigClient.customizedBuoyancies != null) {
                            for (Map.Entry<String, Vector3f> e : ConfigClient.customizedBuoyancies.entrySet()) {
                                Vector3f v = e.getValue();
                                if (v != null) {
                                    JsonObject vj = new JsonObject();
                                    vj.addProperty("x", v.x); vj.addProperty("y", v.y); vj.addProperty("z", v.z);
                                    buoys.add(e.getKey(), vj);
                                }
                            }
                        }
                        out.add("gravities", gravs);
                        out.add("buoyancies", buoys);
                    }
                    if ("all".equals(cat) || "vines".equals(cat)) {
                        JsonObject vj = new JsonObject();
                        if (ConfigVines.configSettings != null) {
                            vj.addProperty("count", ConfigVines.configSettings.size());
                            JsonObject sample = new JsonObject();
                            int shown = 0;
                            for (Map.Entry<Block, DynamicSetting> e : ConfigVines.configSettings.entrySet()) {
                                if (shown++ >= 40) break;
                                Identifier id = Registries.BLOCK.getId(e.getKey());
                                JsonObject dj = new JsonObject();
                                dj.addProperty("type", e.getValue().getClass().getSimpleName());
                                dj.addProperty("linkedPhysics", e.getValue().linkedPhysics);
                                sample.add(id.toString(), dj);
                            }
                            vj.add("entries", sample);
                        }
                        out.add("vines", vj);
                    }
                    if ("all".equals(cat) || "animations".equals(cat)) {
                        if (ConfigAnimations.DEFAULT_ANIMATION != null) {
                            JsonObject aj = new JsonObject();
                            aj.addProperty("name", ConfigAnimations.DEFAULT_ANIMATION.name);
                            aj.addProperty("speed", ConfigAnimations.DEFAULT_ANIMATION.speed);
                            if (ConfigAnimations.DEFAULT_ANIMATION.curve != null) {
                                aj.addProperty("curve", ConfigAnimations.DEFAULT_ANIMATION.curve.name());
                            }
                            if (ConfigAnimations.DEFAULT_ANIMATION.despawnType != null) {
                                aj.addProperty("despawnType", ConfigAnimations.DEFAULT_ANIMATION.despawnType.name());
                            }
                            out.add("animationDefault", aj);
                        }
                    }
                }
                case "set_settings" -> {
                    int updated = 0;
                    List<String> changedFields = new ArrayList<>();
                    List<String> errors = new ArrayList<>();

                    if (req.has("client") && req.get("client").isJsonObject()) {
                        updated += applyStaticFields(ConfigClient.class, req.getAsJsonObject("client"), changedFields, errors);
                    }
                    if (req.has("server") && req.get("server").isJsonObject()) {
                        updated += applyStaticFields(ConfigServer.class, req.getAsJsonObject("server"), changedFields, errors);
                    }
                    if (req.has("blockDefault") && req.get("blockDefault").isJsonObject()) {
                        JsonObject bd = req.getAsJsonObject("blockDefault");
                        updated += applyBlockSettingJson(ConfigBlocks.PARENT_BLOCK_SETTING, bd, changedFields, errors);
                        if (ConfigClient.blockSetting != null && ConfigClient.blockSetting != ConfigBlocks.PARENT_BLOCK_SETTING) {
                            applyBlockSettingJson(ConfigClient.blockSetting, bd, new ArrayList<>(), new ArrayList<>());
                        }
                    }
                    if (req.has("mobDefault") && req.get("mobDefault").isJsonObject()) {
                        JsonObject md = req.getAsJsonObject("mobDefault");
                        updated += applyMobSettingJson(ConfigMobs.PARENT_MOB_SETTING, md, changedFields, errors);
                        if (ConfigClient.mobSetting != null && ConfigClient.mobSetting != ConfigMobs.PARENT_MOB_SETTING) {
                            applyMobSettingJson(ConfigClient.mobSetting, md, new ArrayList<>(), new ArrayList<>());
                        }
                    }
                    if (req.has("animationDefault") && req.get("animationDefault").isJsonObject() && ConfigAnimations.DEFAULT_ANIMATION != null) {
                        JsonObject ad = req.getAsJsonObject("animationDefault");
                        if (ad.has("speed")) { ConfigAnimations.DEFAULT_ANIMATION.speed = ad.get("speed").getAsFloat(); updated++; changedFields.add("animation.speed"); }
                        if (ad.has("curve")) { ConfigAnimations.DEFAULT_ANIMATION.curve = CurveType.valueOf(ad.get("curve").getAsString().toUpperCase(Locale.ROOT)); updated++; changedFields.add("animation.curve"); }
                        if (ad.has("despawnType")) { ConfigAnimations.DEFAULT_ANIMATION.despawnType = AnimationType.valueOf(ad.get("despawnType").getAsString().toUpperCase(Locale.ROOT)); updated++; changedFields.add("animation.despawnType"); }
                    }

                    boolean doReload = !req.has("reload") || req.get("reload").getAsBoolean();
                    boolean doSave = !req.has("save") || req.get("save").getAsBoolean();
                    scheduleClientConfigFlush(doSave, doReload);
                    if (doSave) {
                        try { ConfigServer.save(); } catch (Throwable ignored) {}
                    }

                    out.addProperty("ok", errors.isEmpty());
                    out.addProperty("updatedCount", updated);
                    out.add("changedFields", GSON.toJsonTree(changedFields));
                    if (!errors.isEmpty()) out.add("errors", GSON.toJsonTree(errors));
                }
                case "set_gravity" -> {
                    String dim = req.has("dimension") ? req.get("dimension").getAsString() : "minecraft:overworld";
                    float gx = req.has("x") ? req.get("x").getAsFloat() : 0f;
                    float gy = req.has("y") ? req.get("y").getAsFloat() : -9.81f;
                    float gz = req.has("z") ? req.get("z").getAsFloat() : 0f;
                    ConfigClient.setGravity(dim, new Vector3f(gx, gy, gz));
                    ConfigClient.gravityChanged = true;
                    scheduleClientConfigFlush(true, false);
                    out.addProperty("ok", true);
                    out.addProperty("dimension", dim);
                    out.addProperty("x", gx);
                    out.addProperty("y", gy);
                    out.addProperty("z", gz);
                }
                case "set_buoyancy" -> {
                    String dim = req.has("dimension") ? req.get("dimension").getAsString() : "minecraft:overworld";
                    float bx = req.has("x") ? req.get("x").getAsFloat() : 0f;
                    float by = req.has("y") ? req.get("y").getAsFloat() : 2.0f;
                    float bz = req.has("z") ? req.get("z").getAsFloat() : 0f;
                    ConfigClient.setBuoyancy(dim, new Vector3f(bx, by, bz));
                    ConfigClient.gravityChanged = true;
                    scheduleClientConfigFlush(true, false);
                    out.addProperty("ok", true);
                    out.addProperty("dimension", dim);
                    out.addProperty("x", bx);
                    out.addProperty("y", by);
                    out.addProperty("z", bz);
                }
                case "set_block_override" -> {
                    String rawId = req.get("block").getAsString();
                    String fullId = rawId.contains(":") ? rawId : ("minecraft:" + rawId);
                    Block b = Registries.BLOCK.get(new Identifier(fullId));
                    BlockSetting bs = ConfigBlocks.customizedBlocks != null ? ConfigBlocks.customizedBlocks.get(fullId) : null;
                    if (bs == null) {
                        bs = ConfigBlocks.getBlockSetting(b) != null ? ConfigBlocks.getBlockSetting(b).copy() : new BlockSetting();
                        if (ConfigBlocks.customizedBlocks != null) ConfigBlocks.customizedBlocks.put(fullId, bs);
                    }
                    List<String> changed = new ArrayList<>();
                    List<String> errs = new ArrayList<>();
                    applyBlockSettingJson(bs, req, changed, errs);
                    scheduleClientConfigFlush(true, true);
                    out.addProperty("ok", errs.isEmpty());
                    out.addProperty("block", fullId);
                    out.add("setting", serializeBlockSetting(bs));
                }
                case "set_mob_override" -> {
                    String rawId = req.get("entity").getAsString();
                    String fullId = rawId.contains(":") ? rawId : ("minecraft:" + rawId);
                    MobSetting ms = ConfigMobs.customizedMobs != null ? ConfigMobs.customizedMobs.get(fullId) : null;
                    if (ms == null) {
                        ms = ConfigMobs.PARENT_MOB_SETTING != null ? ConfigMobs.PARENT_MOB_SETTING.copy() : new MobSetting();
                        if (ConfigMobs.customizedMobs != null) ConfigMobs.customizedMobs.put(fullId, ms);
                    }
                    List<String> changed = new ArrayList<>();
                    List<String> errs = new ArrayList<>();
                    applyMobSettingJson(ms, req, changed, errs);
                    scheduleClientConfigFlush(true, false);
                    out.addProperty("ok", errs.isEmpty());
                    out.addProperty("entity", fullId);
                    out.add("setting", serializeMobSetting(ms));
                }
                case "set_cloth" -> {
                    String target = req.has("target") ? req.get("target").getAsString() : ConfigCloth.YOURSELF;
                    String slot = req.get("slot").getAsString();
                    String clothName = req.get("cloth").getAsString();
                    MinecraftClient mc = MinecraftClient.getInstance();
                    if (mc != null) {
                        mc.execute(() -> {
                            ConfigCloth.setCategory(target, slot, clothName);
                            ConfigCloth.save();
                            PhysicsMod.reloadCloth = true;
                        });
                    }
                    out.addProperty("ok", true);
                    out.addProperty("target", target);
                    out.addProperty("slot", slot);
                    out.addProperty("cloth", clothName);
                }
                case "reset_section" -> {
                    String sec = req.has("section") ? req.get("section").getAsString().toLowerCase(Locale.ROOT) : "all";
                    MinecraftClient mc = MinecraftClient.getInstance();
                    if (mc != null) {
                        mc.execute(() -> {
                            switch (sec) {
                                case "ocean" -> { ConfigClient.resetOceanSettings(); ConfigClient.reload(); ConfigClient.save(); }
                                case "snow" -> { ConfigClient.resetSnowSettings(); ConfigClient.reload(); ConfigClient.save(); }
                                case "smoke" -> { ConfigClient.resetSmokeSettings(); ConfigClient.reload(); ConfigClient.save(); }
                                case "weather" -> { ConfigClient.resetWeatherSettings(); ConfigClient.reload(); ConfigClient.save(); }
                                case "gravities" -> { ConfigClient.resetGravities(); ConfigClient.gravityChanged = true; ConfigClient.save(); }
                                case "blocks" -> { ConfigBlocks.resetBlocks(); ConfigBlocks.reload(); ConfigBlocks.save(); }
                                case "mobs" -> { ConfigMobs.resetMobs(); ConfigMobs.save(); }
                                case "vines" -> { ConfigVines.resetVines(); ConfigVines.save(); ConfigClient.reload(); }
                                default -> { ConfigClient.resetOptions(); ConfigClient.reload(); ConfigClient.save(); }
                            }
                        });
                    }
                    out.addProperty("ok", true);
                    out.addProperty("resetSection", sec);
                }
                case "clear_debris" -> {
                    double x = req.has("x") ? req.get("x").getAsDouble() : 0.0;
                    double y = req.has("y") ? req.get("y").getAsDouble() : 64.0;
                    double z = req.has("z") ? req.get("z").getAsDouble() : 0.0;
                    double r = req.has("radius") ? req.get("radius").getAsDouble() : 100000.0;
                    clearClientPhysXBodiesNear(x, y, z, r);
                    out.addProperty("ok", true);
                    out.addProperty("clearedRadius", r);
                }
                case "repair_near" -> {
                    ServerWorld sw = resolveOverworld();
                    if (sw == null) {
                        out.addProperty("ok", false);
                        out.addProperty("error", "no_server_world");
                    } else {
                        int x = req.get("x").getAsInt();
                        int y = req.get("y").getAsInt();
                        int z = req.get("z").getAsInt();
                        double radius = req.has("radius") ? req.get("radius").getAsDouble() : 80.0;
                        int n = repairNear(sw, new BlockPos(x, y, z), radius);
                        out.addProperty("ok", true);
                        out.addProperty("restored", n);
                    }
                }
                case "repair_all" -> {
                    ServerWorld sw = resolveOverworld();
                    if (sw == null) {
                        out.addProperty("ok", false);
                        out.addProperty("error", "no_server_world");
                    } else {
                        int n = repairNear(sw, BlockPos.ORIGIN, 100_000.0);
                        out.addProperty("ok", true);
                        out.addProperty("restored", n);
                    }
                }
                case "collapse_at" -> {
                    ServerWorld sw = resolveOverworld();
                    ServerPhysicsMod spm = ServerPhysicsMod.INSTANCE;
                    if (sw == null || spm == null) {
                        out.addProperty("ok", false);
                        out.addProperty("error", "server_physics_not_ready");
                    } else {
                        int x = req.get("x").getAsInt();
                        int y = req.get("y").getAsInt();
                        int z = req.get("z").getAsInt();
                        int rad = req.has("radius") ? req.get("radius").getAsInt() : 6;
                        int collapsed = spm.evaluateNeighborhoodAndCollapse(sw, null, new BlockPos(x, y, z), rad);
                        out.addProperty("ok", true);
                        out.addProperty("collapsedBlocks", collapsed);
                    }
                }
                case "explosion" -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    if (mc != null && mc.world != null) {
                        double x = req.get("x").getAsDouble();
                        double y = req.get("y").getAsDouble();
                        double z = req.get("z").getAsDouble();
                        float force = req.has("force") ? req.get("force").getAsFloat() : 12.0f;
                        PhysicsMod pm = PhysicsMod.getInstance(mc.world);
                        if (pm != null) {
                            Explosion exp = new Explosion();
                            exp.position = new org.joml.Vector3d(x, y, z);
                            exp.strength = force;
                            exp.tickDelay = 0;
                            pm.explosions.add(exp);
                            out.addProperty("ok", true);
                        }
                    }
                }
                case "set_mode" -> {
                    String mode = req.has("mode") ? req.get("mode").getAsString().toUpperCase(Locale.ROOT) : "BLOCKY";
                    BlockPhysicsType t = BlockPhysicsType.valueOf(mode);
                    setClientBlockMode(t);
                    if (req.has("lifetimeSec")) {
                        setClientBlockLifetime(req.get("lifetimeSec").getAsDouble());
                    }
                    out.addProperty("ok", true);
                    out.addProperty("mode", t.name());
                }
                default -> {
                    out.addProperty("ok", false);
                    out.addProperty("error", "unknown_op:" + op);
                }
            }
        } catch (Throwable t) {
            out.addProperty("ok", false);
            out.addProperty("error", t.toString());
        }
        return out.toString();
    }

    private static void scheduleClientConfigFlush(boolean save, boolean reload) {
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc != null) {
                mc.execute(() -> {
                    try {
                        // CRITICAL: Save to disk FIRST so reload() never overwrites new memory values with stale disk JSON!
                        if (save) {
                            ConfigClient.save();
                            ConfigBlocks.save();
                            ConfigMobs.save();
                            ConfigAnimations.save();
                            ConfigVines.save();
                        }
                        if (reload) {
                            ConfigClient.reload();
                            ConfigBlocks.reload();
                            PhysicsMod.reloadCloth = true;
                        }
                    } catch (Throwable ignored) {}
                });
            }
        } catch (Throwable ignored) {}
    }

    private static JsonObject dumpStaticFields(Class<?> cls) {
        JsonObject jo = new JsonObject();
        for (Field f : cls.getDeclaredFields()) {
            int mod = f.getModifiers();
            if (!Modifier.isPublic(mod) || !Modifier.isStatic(mod) || Modifier.isFinal(mod)) continue;
            String name = f.getName();
            if ("verificationCode".equals(name)) continue;
            try {
                Object val = f.get(null);
                if (val == null) continue;
                if (val instanceof Boolean b) jo.addProperty(name, b);
                else if (val instanceof Number n) jo.addProperty(name, n);
                else if (val instanceof String s) jo.addProperty(name, s);
                else if (val instanceof Enum<?> en) jo.addProperty(name, en.name());
            } catch (Throwable ignored) {}
        }
        return jo;
    }

    private static int applyStaticFields(Class<?> cls, JsonObject values, List<String> changed, List<String> errors) {
        int count = 0;
        for (Map.Entry<String, JsonElement> entry : values.entrySet()) {
            String key = entry.getKey();
            if ("verificationCode".equals(key)) continue;
            JsonElement el = entry.getValue();
            try {
                Field f = cls.getDeclaredField(key);
                int mod = f.getModifiers();
                if (!Modifier.isPublic(mod) || !Modifier.isStatic(mod) || Modifier.isFinal(mod)) {
                    errors.add(cls.getSimpleName() + "." + key + ":not_mutable");
                    continue;
                }
                Class<?> t = f.getType();
                if (t == boolean.class || t == Boolean.class) f.setBoolean(null, el.getAsBoolean());
                else if (t == int.class || t == Integer.class) f.setInt(null, el.getAsInt());
                else if (t == float.class || t == Float.class) f.setFloat(null, el.getAsFloat());
                else if (t == double.class || t == Double.class) f.setDouble(null, el.getAsDouble());
                else if (t == byte.class || t == Byte.class) f.setByte(null, el.getAsByte());
                else if (t == long.class || t == Long.class) f.setLong(null, el.getAsLong());
                else if (t == String.class) f.set(null, el.getAsString());
                else if (t.isEnum()) {
                    @SuppressWarnings({"unchecked", "rawtypes"})
                    Object ev = Enum.valueOf((Class<Enum>) t, el.getAsString().toUpperCase(Locale.ROOT));
                    f.set(null, ev);
                } else {
                    errors.add(cls.getSimpleName() + "." + key + ":unsupported_type:" + t.getSimpleName());
                    continue;
                }
                changed.add(cls.getSimpleName() + "." + key);
                count++;
            } catch (Throwable ex) {
                errors.add(cls.getSimpleName() + "." + key + ":" + ex.getClass().getSimpleName());
            }
        }
        return count;
    }

    private static JsonObject serializeBlockSetting(BlockSetting bs) {
        JsonObject jo = new JsonObject();
        if (bs.type != null) jo.addProperty("type", bs.type.name());
        jo.addProperty("lifetime", bs.lifetime);
        jo.addProperty("lifetimeVariance", bs.lifetimeVariance);
        jo.addProperty("scale", bs.scale);
        return jo;
    }

    private static int applyBlockSettingJson(BlockSetting bs, JsonObject jo, List<String> changed, List<String> errors) {
        if (bs == null) return 0;
        int c = 0;
        try {
            if (jo.has("type")) {
                bs.type = BlockPhysicsType.valueOf(jo.get("type").getAsString().toUpperCase(Locale.ROOT));
                changed.add("BlockSetting.type");
                c++;
            }
            if (jo.has("lifetime")) { bs.lifetime = jo.get("lifetime").getAsDouble(); changed.add("BlockSetting.lifetime"); c++; }
            if (jo.has("lifetimeVariance")) { bs.lifetimeVariance = jo.get("lifetimeVariance").getAsDouble(); changed.add("BlockSetting.lifetimeVariance"); c++; }
            if (jo.has("scale")) { bs.scale = jo.get("scale").getAsDouble(); changed.add("BlockSetting.scale"); c++; }
        } catch (Throwable ex) {
            errors.add("BlockSetting:" + ex.getMessage());
        }
        return c;
    }

    private static JsonObject serializeMobSetting(MobSetting ms) {
        JsonObject jo = new JsonObject();
        if (ms.type != null) jo.addProperty("type", ms.type.name());
        jo.addProperty("lifetime", ms.lifetime);
        jo.addProperty("lifetimeVariance", ms.lifetimeVariance);
        return jo;
    }

    private static int applyMobSettingJson(MobSetting ms, JsonObject jo, List<String> changed, List<String> errors) {
        if (ms == null) return 0;
        int c = 0;
        try {
            if (jo.has("type")) {
                ms.type = MobPhysicsType.valueOf(jo.get("type").getAsString().toUpperCase(Locale.ROOT));
                changed.add("MobSetting.type");
                c++;
            }
            if (jo.has("lifetime")) { ms.lifetime = jo.get("lifetime").getAsDouble(); changed.add("MobSetting.lifetime"); c++; }
            if (jo.has("lifetimeVariance")) { ms.lifetimeVariance = jo.get("lifetimeVariance").getAsDouble(); changed.add("MobSetting.lifetimeVariance"); c++; }
        } catch (Throwable ex) {
            errors.add("MobSetting:" + ex.getMessage());
        }
        return c;
    }

    private static ServerWorld resolveOverworld() {
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc != null && mc.getServer() != null) {
                return mc.getServer().getOverworld();
            }
            Object srvObj = System.getProperties().get("arena.overworld.ref");
            if (srvObj instanceof ServerWorld sw) return sw;
        } catch (Throwable ignored) {}
        return null;
    }

    private static File getBlueprintFile() {
        File dir = new File(FabricLoader.getInstance().getConfigDir().toFile(), "physicsmod");
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, "arena_collapse_blueprints.json");
    }

    private static synchronized void ensureBlueprintsLoaded() {
        if (blueprintsLoaded) return;
        blueprintsLoaded = true;
        try {
            File f = getBlueprintFile();
            if (!f.exists()) return;
            JsonObject root = JsonParser.parseString(Files.readString(f.toPath(), StandardCharsets.UTF_8)).getAsJsonObject();
            if (!root.has("blocks") || !root.get("blocks").isJsonObject()) return;
            JsonObject blocks = root.getAsJsonObject("blocks");
            for (Map.Entry<String, JsonElement> entry : blocks.entrySet()) {
                String[] parts = entry.getKey().split(",");
                if (parts.length != 3) continue;
                BlockPos pos = new BlockPos(
                        Integer.parseInt(parts[0]),
                        Integer.parseInt(parts[1]),
                        Integer.parseInt(parts[2])
                );
                BlockState st = deserializeBlockState(entry.getValue().getAsString());
                if (st != null && !st.isAir()) {
                    COLLAPSED_BLUEPRINTS.putIfAbsent(pos, st);
                }
            }
        } catch (Throwable ignored) {}
    }

    public static void saveBlueprintsAsync() {
        try {
            Map<BlockPos, BlockState> snap = new HashMap<>(COLLAPSED_BLUEPRINTS);
            Thread t = new Thread(() -> {
                try {
                    JsonObject root = new JsonObject();
                    JsonObject blocks = new JsonObject();
                    for (Map.Entry<BlockPos, BlockState> e : snap.entrySet()) {
                        BlockPos p = e.getKey();
                        blocks.addProperty(p.getX() + "," + p.getY() + "," + p.getZ(), serializeBlockState(e.getValue()));
                    }
                    root.add("blocks", blocks);
                    Files.writeString(getBlueprintFile().toPath(), GSON.toJson(root), StandardCharsets.UTF_8);
                } catch (Throwable ignored) {}
            }, "Arena-PhysicsMod-Blueprint-Save");
            t.setDaemon(true);
            t.start();
        } catch (Throwable ignored) {}
    }

    private static String serializeBlockState(BlockState state) {
        Identifier id = Registries.BLOCK.getId(state.getBlock());
        if (state.getEntries().isEmpty()) return id.toString();
        StringBuilder sb = new StringBuilder(id.toString()).append('[');
        boolean first = true;
        for (Map.Entry<Property<?>, Comparable<?>> e : state.getEntries().entrySet()) {
            if (!first) sb.append(',');
            first = false;
            sb.append(e.getKey().getName()).append('=').append(nameValue(e.getKey(), e.getValue()));
        }
        return sb.append(']').toString();
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static String nameValue(Property prop, Comparable val) {
        return prop.name(val);
    }

    private static BlockState deserializeBlockState(String raw) {
        try {
            int idx = raw.indexOf('[');
            String blockId = idx >= 0 ? raw.substring(0, idx) : raw;
            Block b = Registries.BLOCK.get(new Identifier(blockId));
            if (b == Blocks.AIR) return null;
            BlockState st = b.getDefaultState();
            if (idx >= 0 && raw.endsWith("]")) {
                String props = raw.substring(idx + 1, raw.length() - 1);
                if (!props.isEmpty()) {
                    for (String kv : props.split(",")) {
                        int eq = kv.indexOf('=');
                        if (eq <= 0) continue;
                        String k = kv.substring(0, eq);
                        String v = kv.substring(eq + 1);
                        Property<?> prop = b.getStateManager().getProperty(k);
                        if (prop != null) {
                            st = applyProperty(st, prop, v);
                        }
                    }
                }
            }
            return st;
        } catch (Throwable ignored) {
            return null;
        }
    }

    private static <T extends Comparable<T>> BlockState applyProperty(BlockState st, Property<T> prop, String val) {
        Optional<T> parsed = prop.parse(val);
        return parsed.map(t -> st.with(prop, t)).orElse(st);
    }
}

package net.diebuddies.physics;

import net.diebuddies.arena.ArenaPhysicsModBridge;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * Patched BlockUpdate for Physics Mod Pro 3.0.14 (MC 1.20.4):
 * 1. Fixes upstream X-X-X hashCode() copy-paste bug that caused O(N^2) HashSet collisions during vertical wall collapses.
 * 2. Suppresses spurious break-debris spawning when /onar restores or cleans blocks.
 */
public class BlockUpdate {
    public World level;
    public BlockPos pos;
    public BlockState state;
    public BlockEntity blockEntity;

    public BlockUpdate(World level, BlockPos pos, BlockState state) {
        this.level = level;
        this.pos = pos;
        if (pos != null && ArenaPhysicsModBridge.isSuppressedPos(pos)) {
            this.state = Blocks.AIR.getDefaultState();
        } else {
            this.state = state;
        }
    }

    @Override
    public int hashCode() {
        if (this.pos == null) return 0;
        return (this.pos.getX() * 73856093) ^ (this.pos.getY() * 19349663) ^ (this.pos.getZ() * 83492791);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        BlockUpdate other = (BlockUpdate) obj;
        if (this.pos == null) return other.pos == null;
        return this.pos.equals(other.pos);
    }
}

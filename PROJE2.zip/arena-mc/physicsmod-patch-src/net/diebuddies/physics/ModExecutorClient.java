package net.diebuddies.physics;

import net.diebuddies.arena.ArenaPhysicsModBridge;
import net.fabricmc.api.ClientModInitializer;

public class ModExecutorClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        StarterClient.onInitializeClient();
        ArenaPhysicsModBridge.initClient();
    }
}

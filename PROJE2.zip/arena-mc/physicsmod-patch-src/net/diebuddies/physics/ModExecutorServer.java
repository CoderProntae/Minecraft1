package net.diebuddies.physics;

import net.diebuddies.arena.ArenaPhysicsModBridge;
import net.fabricmc.api.DedicatedServerModInitializer;

public class ModExecutorServer implements DedicatedServerModInitializer {
    @Override
    public void onInitializeServer() {
        StarterServer.onInitializeServer();
        ArenaPhysicsModBridge.initServer();
    }
}

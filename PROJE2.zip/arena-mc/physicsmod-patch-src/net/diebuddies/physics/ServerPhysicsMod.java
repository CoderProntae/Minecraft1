package net.diebuddies.physics;

import net.diebuddies.arena.ArenaPhysicsModBridge;
import net.diebuddies.bridge.FabricAPIServer;
import net.diebuddies.config.ConfigServer;
import net.minecraft.block.*;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Upgraded ServerPhysicsMod for Physics Mod Pro 3.0.14 + ArenaAI Bridge:
 * - Fixes upstream naive `pos.down() == AIR` bug (which collapsed supported roofs/bridges on a single block break).
 * - Fixes upstream NullPointerException when `fallingBlocks.player == null` (API / explosion collapses).
 * - Protects underground MTR Metro infrastructure (y < 61, mtr:*, arena_ai_bridge:*).
 * - Adds real 3D Grounded Support BFS + Cantilever Span & Heavy-Load Overload Collapse (IRON/GOLD/NETHERITE/ANVIL).
 * - Records every collapsed block into ArenaPhysicsModBridge blueprints so `/onar` & `/onar hepsi` rewind cleanly!
 */
public class ServerPhysicsMod implements FabricAPIServer.StartWorldTick, FabricAPIServer.After {

    public static volatile ServerPhysicsMod INSTANCE;

    private static final Direction[] DIRS_6 = Direction.values();
    private static final int[][] DIAG_EDGES = {
            {1, 1, 0}, {-1, 1, 0}, {0, 1, 1}, {0, 1, -1},
            {1, -1, 0}, {-1, -1, 0}, {0, -1, 1}, {0, -1, -1},
            {1, 0, 1}, {1, 0, -1}, {-1, 0, 1}, {-1, 0, -1}
    };

    private record CollapseWave(
            ServerWorld world,
            PlayerEntity player,
            List<BlockPos> orderedBlocks,
            int cursor,
            int tickCounter
    ) {}

    private record PendingCheck(ServerWorld world, BlockPos center, int delayTicks) {}

    private final Map<World, List<CollapseWave>> activeWaves = new ConcurrentHashMap<>();
    private final Queue<PendingCheck> pendingPlacementChecks = new ConcurrentLinkedQueue<>();

    public ServerPhysicsMod() {
        INSTANCE = this;
        ConfigServer.init();
        ArenaPhysicsModBridge.ensureOptimalServerDefaults();
    }

    public static void scheduleStructuralCheck(ServerWorld world, BlockPos pos, int delayTicks) {
        ServerPhysicsMod inst = INSTANCE;
        if (inst != null && world != null && pos != null) {
            inst.pendingPlacementChecks.add(new PendingCheck(world, pos.toImmutable(), Math.max(1, delayTicks)));
        }
    }

    public void clearActiveWavesNear(World world, BlockPos center, double radius) {
        List<CollapseWave> list = activeWaves.get(world);
        if (list == null) return;
        double r2 = radius * radius;
        list.removeIf(w -> w.orderedBlocks.isEmpty() || w.orderedBlocks.get(0).getSquaredDistance(center) <= r2);
    }

    public int getActiveWaveCount() {
        int sum = 0;
        for (List<CollapseWave> l : activeWaves.values()) sum += l.size();
        return sum;
    }

    @Override
    public void afterBlockBreak(World world, PlayerEntity player, BlockPos pos, BlockState brokenState, BlockEntity blockEntity) {
        if (!ConfigServer.collapse || !(world instanceof ServerWorld sw)) return;
        if (ArenaPhysicsModBridge.suppressCollapseHooks) return;
        if (pos.getY() < 61) return;

        if (isStructuralBlock(sw, pos, brokenState)) {
            ArenaPhysicsModBridge.recordBrokenTriggerBlock(sw, pos, brokenState);
        }
        evaluateNeighborhoodAndCollapse(sw, player, pos, 2);
    }

    @Override
    public void onStartTick(ServerWorld world) {
        if (!pendingPlacementChecks.isEmpty()) {
            List<PendingCheck> requeue = new ArrayList<>();
            PendingCheck pc;
            while ((pc = pendingPlacementChecks.poll()) != null) {
                if (pc.world != world) {
                    requeue.add(pc);
                    continue;
                }
                if (pc.delayTicks > 1) {
                    requeue.add(new PendingCheck(pc.world, pc.center, pc.delayTicks - 1));
                } else if (ConfigServer.collapse && !ArenaPhysicsModBridge.suppressCollapseHooks && pc.center.getY() >= 61) {
                    evaluateNeighborhoodAndCollapse(world, null, pc.center, 1);
                }
            }
            pendingPlacementChecks.addAll(requeue);
        }

        List<CollapseWave> waves = activeWaves.get(world);
        if (waves == null || waves.isEmpty()) return;

        int blocksPerTick = Math.max(24, ConfigServer.collapseSpeed <= 1 ? 42 : (48 / Math.max(1, ConfigServer.collapseSpeed)));
        List<CollapseWave> nextWaves = new ArrayList<>();

        for (CollapseWave w : waves) {
            int cur = w.cursor;
            int end = Math.min(w.orderedBlocks.size(), cur + blocksPerTick);
            boolean playedSoundThisTick = false;

            for (int i = cur; i < end; i++) {
                BlockPos bp = w.orderedBlocks.get(i);
                if (!world.isChunkLoaded(bp.getX() >> 4, bp.getZ() >> 4)) continue;
                BlockState st = world.getBlockState(bp);
                if (st.isAir() || isProtectedInfrastructure(bp, st) || isNaturalTerrain(st)) continue;

                // Save original BlockState for `/onar` & `/onar hepsi` BEFORE removing!
                ArenaPhysicsModBridge.recordCollapsedBlock(world, bp, st);

                if (ConfigServer.dropBlocks) {
                    BlockEntity be = world.getBlockEntity(bp);
                    ItemStack tool = (w.player != null) ? w.player.getActiveItem() : ItemStack.EMPTY;
                    Block.dropStacks(st, world, bp, be, w.player, tool);
                }

                if (!playedSoundThisTick && (i == cur)) {
                    playedSoundThisTick = true;
                    world.playSound(null, bp, st.getSoundGroup().getBreakSound(), SoundCategory.BLOCKS, 0.9f, 0.82f);
                }

                // Setting Blocks.AIR triggers Physics Mod Pro's MixinLevelChunk -> NVIDIA PhysX 5 RigidBody / Fracture spawn!
                world.setBlockState(bp, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);
            }

            if (end < w.orderedBlocks.size()) {
                nextWaves.add(new CollapseWave(w.world, w.player, w.orderedBlocks, end, w.tickCounter + 1));
            }
        }

        if (nextWaves.isEmpty()) {
            activeWaves.remove(world);
            ArenaPhysicsModBridge.saveBlueprintsAsync();
        } else {
            activeWaves.put(world, nextWaves);
        }
    }

    public int evaluateNeighborhoodAndCollapse(ServerWorld world, PlayerEntity player, BlockPos origin, int searchRadius) {
        Set<BlockPos> globalVisited = new HashSet<>();
        List<BlockPos> toCollapseAll = new ArrayList<>();

        for (int dx = -searchRadius; dx <= searchRadius; dx++) {
            for (int dy = -searchRadius; dy <= searchRadius; dy++) {
                for (int dz = -searchRadius; dz <= searchRadius; dz++) {
                    BlockPos seed = origin.add(dx, dy, dz);
                    if (seed.getY() < 61 || globalVisited.contains(seed)) continue;
                    if (!world.isChunkLoaded(seed.getX() >> 4, seed.getZ() >> 4)) continue;
                    BlockState sst = world.getBlockState(seed);
                    if (!isStructuralBlock(world, seed, sst)) continue;

                    List<BlockPos> failed = analyzeComponent(world, seed, origin, globalVisited);
                    if (!failed.isEmpty()) {
                        toCollapseAll.addAll(failed);
                    }
                }
            }
        }

        if (!toCollapseAll.isEmpty()) {
            // Sort failure wave from closest to origin & lowest-to-highest so building crumbles naturally!
            toCollapseAll.sort(Comparator.comparingDouble((BlockPos p) ->
                    p.getSquaredDistance(origin) * 0.35 + (p.getY() - origin.getY()) * 2.0));
            activeWaves.computeIfAbsent(world, k -> new ArrayList<>())
                    .add(new CollapseWave(world, player, toCollapseAll, 0, 0));
        }
        return toCollapseAll.size();
    }

    private List<BlockPos> analyzeComponent(ServerWorld world, BlockPos seed, BlockPos eventOrigin, Set<BlockPos> globalVisited) {
        int maxCap = Math.max(600, ConfigServer.maxCollapseObjects);
        Set<BlockPos> component = new LinkedHashSet<>();
        ArrayDeque<BlockPos> bfs = new ArrayDeque<>();
        component.add(seed.toImmutable());
        bfs.add(seed.toImmutable());

        boolean touchesLeaves = false;
        boolean hasManufactured = false;

        while (!bfs.isEmpty() && component.size() < maxCap) {
            BlockPos cur = bfs.poll();
            BlockState cst = world.getBlockState(cur);
            if (!cst.isIn(BlockTags.LOGS)) {
                hasManufactured = true;
            }

            for (Direction d : DIRS_6) {
                BlockPos nb = cur.offset(d);
                if (nb.getY() < 61 || Math.abs(nb.getX() - seed.getX()) > 48 || Math.abs(nb.getZ() - seed.getZ()) > 48) continue;
                if (component.contains(nb) || !world.isChunkLoaded(nb.getX() >> 4, nb.getZ() >> 4)) continue;
                BlockState nst = world.getBlockState(nb);
                if (nst.isIn(BlockTags.LEAVES)) { touchesLeaves = true; continue; }
                if (!isStructuralBlock(world, nb, nst)) continue;
                BlockPos imm = nb.toImmutable();
                component.add(imm);
                bfs.add(imm);
            }

            for (int[] dg : DIAG_EDGES) {
                BlockPos nb = cur.add(dg[0], dg[1], dg[2]);
                if (nb.getY() < 61 || Math.abs(nb.getX() - seed.getX()) > 48 || Math.abs(nb.getZ() - seed.getZ()) > 48) continue;
                if (component.contains(nb) || !world.isChunkLoaded(nb.getX() >> 4, nb.getZ() >> 4)) continue;
                BlockState nst = world.getBlockState(nb);
                if (!isStructuralBlock(world, nb, nst)) continue;
                BlockPos imm = nb.toImmutable();
                component.add(imm);
                bfs.add(imm);
            }
        }

        globalVisited.addAll(component);
        if (component.isEmpty()) return List.of();
        if (touchesLeaves && !hasManufactured) return List.of(); // Skip natural forest trees

        // Dijkstra structural load-path distance from true natural terrain foundations
        Map<BlockPos, Double> spanCost = new HashMap<>(component.size() * 2);
        PriorityQueue<Map.Entry<BlockPos, Double>> pq = new PriorityQueue<>(Comparator.comparingDouble(Map.Entry::getValue));

        int groundedCount = 0;
        for (BlockPos p : component) {
            if (isAnchoredToTerrain(world, p, component)) {
                groundedCount++;
                spanCost.put(p, 0.0);
                pq.add(Map.entry(p, 0.0));
            }
        }

        // Case 1: Zero grounded anchors -> 100% of floating/undermined building collapses!
        if (groundedCount == 0) {
            return new ArrayList<>(component);
        }

        // Compute top dead-weight surcharge (IRON / GOLD / NETHERITE / ANVIL blocks amplify cantilever bending!)
        while (!pq.isEmpty()) {
            var curEntry = pq.poll();
            BlockPos u = curEntry.getKey();
            double dU = curEntry.getValue();
            if (dU > spanCost.getOrDefault(u, Double.POSITIVE_INFINITY) + 1.0e-6) continue;

            for (Direction dir : DIRS_6) {
                BlockPos v = u.offset(dir);
                if (!component.contains(v)) continue;
                BlockState vst = world.getBlockState(v);
                // Moving vertically UP a column/wall costs very little span; moving horizontally out a cantilever costs 1.0 + surcharge!
                double stepCost = (dir == Direction.UP) ? 0.18 : (dir == Direction.DOWN ? 0.35 : 1.0);
                stepCost += computeHeavySurchargeAt(world, v, vst);

                double cand = dU + stepCost;
                if (cand < spanCost.getOrDefault(v, Double.POSITIVE_INFINITY)) {
                    spanCost.put(v, cand);
                    pq.add(Map.entry(v, cand));
                }
            }
            for (int[] dg : DIAG_EDGES) {
                BlockPos v = u.add(dg[0], dg[1], dg[2]);
                if (!component.contains(v)) continue;
                BlockState vst = world.getBlockState(v);
                double stepCost = (dg[1] != 0 ? 0.85 : 1.35) + computeHeavySurchargeAt(world, v, vst);
                double cand = dU + stepCost;
                if (cand < spanCost.getOrDefault(v, Double.POSITIVE_INFINITY)) {
                    spanCost.put(v, cand);
                    pq.add(Map.entry(v, cand));
                }
            }
        }

        // Collect any cantilevered/overloaded members exceeding material span strength
        List<BlockPos> overloaded = new ArrayList<>();
        for (BlockPos p : component) {
            double cost = spanCost.getOrDefault(p, Double.POSITIVE_INFINITY);
            BlockState st = world.getBlockState(p);
            double limit = maxMaterialSpanCapacity(st);
            if (cost > limit) {
                overloaded.add(p);
            }
        }

        if (overloaded.isEmpty()) return List.of();

        // Also include any blocks supported exclusively by the overloaded failed zone!
        Set<BlockPos> failedSet = new LinkedHashSet<>(overloaded);
        Set<BlockPos> survivingGrounded = new HashSet<>();
        ArrayDeque<BlockPos> checkQ = new ArrayDeque<>();
        for (BlockPos p : component) {
            if (!failedSet.contains(p) && isAnchoredToTerrain(world, p, component)) {
                survivingGrounded.add(p);
                checkQ.add(p);
            }
        }
        while (!checkQ.isEmpty()) {
            BlockPos u = checkQ.poll();
            for (Direction dir : DIRS_6) {
                BlockPos v = u.offset(dir);
                if (component.contains(v) && !failedSet.contains(v) && survivingGrounded.add(v)) {
                    checkQ.add(v);
                }
            }
        }
        for (BlockPos p : component) {
            if (!survivingGrounded.contains(p)) {
                failedSet.add(p);
            }
        }
        return new ArrayList<>(failedSet);
    }

    private static double computeHeavySurchargeAt(ServerWorld world, BlockPos p, BlockState selfState) {
        double extra = heavyBlockWeightPenalty(selfState) * 0.55;
        BlockState above1 = world.getBlockState(p.up());
        extra += heavyBlockWeightPenalty(above1);
        BlockState above2 = world.getBlockState(p.up(2));
        extra += heavyBlockWeightPenalty(above2) * 0.75;
        return extra;
    }

    private static double heavyBlockWeightPenalty(BlockState st) {
        if (st == null || st.isAir()) return 0.0;
        Block b = st.getBlock();
        if (b == Blocks.NETHERITE_BLOCK) return 4.6;
        if (b == Blocks.GOLD_BLOCK || b == Blocks.RAW_GOLD_BLOCK) return 3.8;
        if (b == Blocks.ANVIL || b == Blocks.CHIPPED_ANVIL || b == Blocks.DAMAGED_ANVIL) return 3.4;
        if (b == Blocks.IRON_BLOCK || b == Blocks.RAW_IRON_BLOCK || b == Blocks.COPPER_BLOCK) return 2.6;
        if (b == Blocks.DIAMOND_BLOCK || b == Blocks.EMERALD_BLOCK || b == Blocks.LAPIS_BLOCK) return 1.8;
        return 0.0;
    }

    private static double maxMaterialSpanCapacity(BlockState st) {
        Block b = st.getBlock();
        if (b == Blocks.SAND || b == Blocks.RED_SAND || b == Blocks.GRAVEL) return 0.25;
        if (st.isOf(Blocks.GLASS) || st.isOf(Blocks.GLASS_PANE) || st.isOf(Blocks.ICE)
                || st.isOf(Blocks.PACKED_ICE) || b instanceof StainedGlassBlock || b instanceof StainedGlassPaneBlock) {
            return 3.5;
        }
        if (b == Blocks.IRON_BLOCK || b == Blocks.IRON_BARS || b == Blocks.QUARTZ_BLOCK || b == Blocks.SMOOTH_QUARTZ) {
            return 9.5;
        }
        if (st.isIn(BlockTags.LOGS) || st.isIn(BlockTags.PLANKS) || st.isIn(BlockTags.WOODEN_SLABS)
                || st.isIn(BlockTags.WOODEN_STAIRS) || st.isIn(BlockTags.WOODEN_FENCES)) {
            return 7.8;
        }
        return 6.8;
    }

    private static boolean isAnchoredToTerrain(ServerWorld world, BlockPos p, Set<BlockPos> component) {
        BlockPos below = p.down();
        if (!component.contains(below)) {
            BlockState bst = world.getBlockState(below);
            if (isSolidFoundation(world, below, bst)) return true;
        }
        for (Direction hd : Direction.Type.HORIZONTAL) {
            BlockPos side = p.offset(hd);
            if (!component.contains(side)) {
                BlockState sst = world.getBlockState(side);
                if (isNaturalTerrain(sst) && !sst.isOf(Blocks.SAND) && !sst.isOf(Blocks.GRAVEL)) {
                    return true;
                }
            }
        }
        return false;
    }

    private static boolean isSolidFoundation(ServerWorld world, BlockPos p, BlockState st) {
        if (st.isAir() || !st.getFluidState().isEmpty()) return false;
        if (isNaturalTerrain(st) || isProtectedInfrastructure(p, st)) return true;
        return st.isOf(Blocks.BEDROCK) || st.isOf(Blocks.OBSIDIAN) || st.isOf(Blocks.CRYING_OBSIDIAN);
    }

    public static boolean isProtectedInfrastructure(BlockPos p, BlockState st) {
        if (p.getY() < 61) return true;
        if (st.isOf(Blocks.BEDROCK) || st.isOf(Blocks.BARRIER) || st.isOf(Blocks.COMMAND_BLOCK)) return true;
        Identifier id = Registries.BLOCK.getId(st.getBlock());
        String ns = id.getNamespace();
        return "mtr".equals(ns) || "arena_ai_bridge".equals(ns);
    }

    public static boolean isNaturalTerrain(BlockState st) {
        return st.isOf(Blocks.STONE) || st.isOf(Blocks.GRASS_BLOCK) || st.isOf(Blocks.DIRT)
                || st.isOf(Blocks.COARSE_DIRT) || st.isOf(Blocks.PODZOL) || st.isOf(Blocks.MYCELIUM)
                || st.isOf(Blocks.SAND) || st.isOf(Blocks.RED_SAND) || st.isOf(Blocks.SANDSTONE)
                || st.isOf(Blocks.RED_SANDSTONE) || st.isOf(Blocks.GRAVEL) || st.isOf(Blocks.CLAY)
                || st.isOf(Blocks.ANDESITE) || st.isOf(Blocks.DIORITE) || st.isOf(Blocks.GRANITE)
                || st.isOf(Blocks.TUFF) || st.isOf(Blocks.CALCITE) || st.isOf(Blocks.DEEPSLATE)
                || st.isOf(Blocks.BEDROCK) || st.isOf(Blocks.TERRACOTTA) || st.isIn(BlockTags.COAL_ORES)
                || st.isIn(BlockTags.IRON_ORES) || st.isIn(BlockTags.COPPER_ORES) || st.isIn(BlockTags.GOLD_ORES);
    }

    public static boolean isStructuralBlock(ServerWorld world, BlockPos p, BlockState st) {
        if (st == null || st.isAir() || !st.getFluidState().isEmpty()) return false;
        if (isProtectedInfrastructure(p, st) || isNaturalTerrain(st)) return false;
        if (st.isIn(BlockTags.FLOWERS) || st.isIn(BlockTags.SAPLINGS) || st.isIn(BlockTags.CROPS)
                || st.isOf(Blocks.SHORT_GRASS) || st.isOf(Blocks.TALL_GRASS) || st.isOf(Blocks.FERN)
                || st.isOf(Blocks.DEAD_BUSH) || st.isOf(Blocks.SNOW) || st.isOf(Blocks.VINE)) {
            return false;
        }
        return true;
    }
}

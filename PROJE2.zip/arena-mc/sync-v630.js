const http = require('http');

function reqJson(method, path, bodyObj) {
  return new Promise((resolve) => {
    const payload = bodyObj ? Buffer.from(JSON.stringify(bodyObj), 'utf8') : null;
    const req = http.request({
      hostname: '127.0.0.1',
      port: 8080,
      path,
      method,
      headers: payload ? {
        'Content-Type': 'application/json',
        'Content-Length': payload.length
      } : {}
    }, (res) => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => {
        try { resolve(JSON.parse(d)); } catch { resolve(null); }
      });
    });
    req.on('error', () => resolve(null));
    if (payload) req.write(payload);
    req.end();
  });
}

let appliedForSession = null;

async function tick() {
  try {
    const st = await reqJson('GET', '/api/state?refresh=1');
    const cs = st && st.clientState;
    const ver = cs && cs.telemetry && cs.telemetry.modVersion;
    const inWorld = cs && cs.inWorld;
    const connectedAt = cs && cs.connectedAt;

    if (ver === '6.3.0' && inWorld && appliedForSession !== connectedAt) {
      appliedForSession = connectedAt;
      console.log('[sync-v630] Detected v6.3.0 in-world! Applying MTR dwell fix + News Boards...');
      await new Promise(r => setTimeout(r, 2500));

      const mtrRes = await reqJson('POST', '/api/mtr-control', {
        op: 'auto_setup_express',
        routeNumber: 'YHT-1',
        routeName: 'Avrasya Orman YHT',
        routeType: 'HIGH_SPEED',
        frequencyPerHour: 20,
        dwellMillis: 20000
      });
      console.log('[sync-v630] MTR result:', JSON.stringify(mtrRes));

      await reqJson('POST', '/api/act', {
        action: 'command',
        command: 'setblock -22 66 38 arena_ai_bridge:transit_news_board[facing=east]'
      });
      await reqJson('POST', '/api/act', {
        action: 'command',
        command: 'setblock -24 66 32 arena_ai_bridge:transit_news_board[facing=west]'
      });
      await reqJson('POST', '/api/act', {
        action: 'command',
        command: 'setblock -22 66 32 arena_ai_bridge:world_map_board[facing=east,map_mode=4]'
      });
      await reqJson('POST', '/api/act', {
        action: 'command',
        command: 'setblock -24 66 26 arena_ai_bridge:world_map_board[facing=west,map_mode=0]'
      });

      await reqJson('GET', '/api/wait-event?timeout=1');
      await reqJson('POST', '/api/act', {
        action: 'chat',
        message: 'Hos geldin Ilkan! v6.3.0 aktif: YHT-1 duraklarda tam 20 sn bekleyecek, sag sutuna (-22,66,38) Canli Haritali Pano asildi, Harita ve Orman Kart hazir!'
      });
      console.log('[sync-v630] Post-upgrade setup complete!');
    }
  } catch (e) {
    console.error('[sync-v630] err:', e.message);
  }
}

console.log('[sync-v630] Watching for v6.3.0 world load...');
setInterval(tick, 2500);
tick();

async function buildSouthernForest() {
  const act = (body) =>
    fetch('http://127.0.0.1:8080/api/act', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    }).then((r) => r.json());

  // 1. High-res 1x1 scan of the entire Southern Forest Reserve (x = -138..-31, z = 114..226)
  const tiles = [
    [-112, 142, 30], [-60, 142, 30],
    [-112, 198, 30], [-60, 198, 30]
  ];
  const scans = await Promise.all(
    tiles.map(([cx, cz, r]) =>
      fetch(`http://127.0.0.1:8080/api/scan?x=${cx}&z=${cz}&r=${r}&step=1`).then((res) => res.json())
    )
  );

  const map = new Map();
  for (const s of scans) {
    for (const row of s.grid || []) {
      for (const c of row) map.set(`${c.x},${c.z}`, c);
    }
  }
  const cell = (x, z) => map.get(`${x},${z}`) || { x, y: 68, z, b: 'grass_block' };
  const groundY = (x, z) => {
    const c = cell(x, z);
    // If top block is a high tree trunk, estimate true ground from neighbors
    if (c.b.includes('log') || c.y > 82) {
      const ys = [];
      for (let dx = -3; dx <= 3; dx++) {
        for (let dz = -3; dz <= 3; dz++) {
          const nc = cell(x + dx, z + dz);
          if (!nc.b.includes('log') && nc.y <= 80) ys.push(nc.y);
        }
      }
      if (ys.length) {
        ys.sort((a, b) => a - b);
        return ys[Math.floor(ys.length / 2)];
      }
    }
    return c.y;
  };

  const ops = [];
  const set = (x, y, z, block, onlyAir = false) => ops.push({ op: 'set', x, y, z, block, onlyAir });
  const foundation = (x, y, z, block) => ops.push({ op: 'foundation', x, y, z, block });

  const minX = -136, maxX = -33;
  const minZ = 116, maxZ = 224;

  // ==================== 1. GRAND SOUTHERN PERIMETER BORDER WALL (MUD BRICKS + MOSSY STONE + JUNGLE TIMBER) ====================
  function placeSouthernWallColumn(x, z, idx) {
    // Skip North Main Gateway opening at z === minZ, x in [-90..-80]
    if (z === minZ && x >= -90 && x <= -80) return;
    // Skip South Trail Arch opening at z === maxZ, x in [-88..-82]
    if (z === maxZ && x >= -88 && x <= -82) return;
    // Skip Corner Pagoda footprints (3x3 around corners)
    for (const [cx, cz] of [[minX, minZ], [maxX, minZ], [minX, maxZ], [maxX, maxZ]]) {
      if (Math.abs(x - cx) <= 2 && Math.abs(z - cz) <= 2) return;
    }

    const g = groundY(x, z);
    const isWater = cell(x, z).b.includes('water');
    const wallBase = isWater ? Math.max(g + 1, 63) : g;

    // Grounded foundation all the way down into riverbed/slope!
    foundation(x, wallBase, z, 'minecraft:mossy_stone_bricks');
    set(x, wallBase + 1, z, (x + z) % 3 === 0 ? 'minecraft:mossy_stone_bricks' : 'minecraft:mud_bricks');

    if (idx % 6 === 0) {
      // Timber Pillar + Grounded Lantern!
      set(x, wallBase + 2, z, 'minecraft:stripped_jungle_log[axis=y]');
      set(x, wallBase + 3, z, 'minecraft:stripped_jungle_log[axis=y]');
      set(x, wallBase + 4, z, 'minecraft:mud_brick_slab[type=bottom]');
      if (idx % 12 === 0) {
        set(x, wallBase + 4, z, 'minecraft:chiseled_stone_bricks');
        set(x, wallBase + 5, z, 'minecraft:lantern');
      }
    } else {
      // Auto-connected Mud Brick Wall + Bamboo Fence crest!
      set(x, wallBase + 2, z, 'minecraft:mud_brick_wall');
      set(x, wallBase + 3, z, 'minecraft:jungle_fence');
    }
  }

  let runIdx = 0;
  for (let x = minX; x <= maxX; x++) placeSouthernWallColumn(x, minZ, runIdx++);
  for (let x = minX; x <= maxX; x++) placeSouthernWallColumn(x, maxZ, runIdx++);
  for (let z = minZ + 1; z < maxZ; z++) placeSouthernWallColumn(minX, z, runIdx++);
  for (let z = minZ + 1; z < maxZ; z++) placeSouthernWallColumn(maxX, z, runIdx++);

  // ==================== 2. FOUR SOUTHERN CORNER WATCH-PAGODAS ====================
  for (const [cx, cz] of [[minX, minZ], [maxX, minZ], [minX, maxZ], [maxX, maxZ]]) {
    const base = Math.max(64, groundY(cx, cz));
    for (let dx = -2; dx <= 2; dx++) {
      for (let dz = -2; dz <= 2; dz++) {
        foundation(cx + dx, base, cz + dz, 'minecraft:mossy_stone_bricks');
        set(cx + dx, base + 1, cz + dz, 'minecraft:mud_bricks');
        for (let y = base + 2; y <= base + 10; y++) set(cx + dx, y, cz + dz, 'minecraft:air');
      }
    }
    // 4 Corner Jungle Log Columns
    for (let y = base + 2; y <= base + 8; y++) {
      for (const [px, pz] of [[-2, -2], [2, -2], [-2, 2], [2, 2]]) {
        set(cx + px, y, cz + pz, 'minecraft:jungle_log[axis=y]');
      }
    }
    // Watch Deck at base + 6
    for (let dx = -2; dx <= 2; dx++) {
      for (let dz = -2; dz <= 2; dz++) {
        set(cx + dx, base + 6, cz + dz, 'minecraft:jungle_planks');
        if ((Math.abs(dx) === 2 || Math.abs(dz) === 2) && !(Math.abs(dx) === 2 && Math.abs(dz) === 2)) {
          set(cx + dx, base + 7, cz + dz, 'minecraft:bamboo_fence');
        }
      }
    }
    // Solid Pagoda Roof at base + 9 .. base + 11 (100% solid interior so campfire & hanging lantern never float!)
    for (let dx = -3; dx <= 3; dx++) {
      for (let dz = -3; dz <= 3; dz++) {
        const edge = Math.max(Math.abs(dx), Math.abs(dz));
        if (edge === 3) {
          set(cx + dx, base + 9, cz + dz, 'minecraft:mud_brick_slab[type=bottom]');
        } else {
          set(cx + dx, base + 9, cz + dz, 'minecraft:jungle_planks');
          if (edge <= 1) set(cx + dx, base + 10, cz + dz, 'minecraft:mud_bricks');
        }
      }
    }
    set(cx, base + 11, cz, 'minecraft:campfire[lit=true]');
    set(cx, base + 8, cz, 'minecraft:chain[axis=y]');
    set(cx, base + 7, cz, 'minecraft:lantern[hanging=true]');
  }

  // ==================== 3. GRAND NORTHERN GATEWAY OF SOUTHERN FOREST (z = 116, x = -90..-80) ====================
  const gateY = Math.max(65, groundY(-85, 116));
  for (let x = -90; x <= -80; x++) {
    for (let z = 114; z <= 118; z++) {
      foundation(x, gateY, z, 'minecraft:mossy_stone_bricks');
      set(x, gateY, z, Math.abs(x + 85) <= 2 ? 'minecraft:chiseled_stone_bricks' : 'minecraft:mud_bricks');
      for (let y = gateY + 1; y <= gateY + 9; y++) set(x, y, z, 'minecraft:air');
    }
  }
  // Twin Gate Towers at x = -89 and x = -81
  for (const gx of [-89, -81]) {
    for (let dz = -1; dz <= 1; dz++) {
      for (let y = gateY + 1; y <= gateY + 6; y++) {
        set(gx, y, 116 + dz, dz === 0 ? 'minecraft:mud_bricks' : 'minecraft:stripped_jungle_log[axis=y]');
      }
    }
  }
  // Grand Arch Beam & Pagoda Crest (y = gateY + 6 .. +8)
  for (let x = -90; x <= -80; x++) {
    for (let z = 115; z <= 117; z++) {
      set(x, gateY + 6, z, 'minecraft:jungle_planks');
      if (z === 116) set(x, gateY + 7, z, 'minecraft:mud_bricks');
    }
    set(x, gateY + 7, 114, 'minecraft:mud_brick_slab[type=bottom]');
    set(x, gateY + 7, 118, 'minecraft:mud_brick_slab[type=bottom]');
  }
  // Hanging Gate Lanterns solidly chained under gateY+6!
  for (const lx of [-87, -83]) {
    set(lx, gateY + 5, 116, 'minecraft:chain[axis=y]');
    set(lx, gateY + 4, 116, 'minecraft:lantern[hanging=true]');
  }

  // ==================== 4. SOUTHERN TRAILS & GROUNDED BAMBOO LAMP POSTS ====================
  const pathPalette = ['minecraft:packed_mud', 'minecraft:mud_bricks', 'minecraft:mossy_cobblestone', 'minecraft:podzol'];
  function buildSouthernTrail(x1, z1, x2, z2, curveAmp = 2.0) {
    const steps = Math.max(1, Math.round(Math.hypot(x2 - x1, z2 - z1)));
    let lastLamp = -12;
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      const px = -(z2 - z1) / steps;
      const pz = (x2 - x1) / steps;
      const w = Math.sin(t * Math.PI * 2) * curveAmp;
      const cx = Math.round(x1 + (x2 - x1) * t + px * w);
      const cz = Math.round(z1 + (z2 - z1) * t + pz * w);

      for (let dx = -1; dx <= 1; dx++) {
        for (let dz = -1; dz <= 1; dz++) {
          if (Math.abs(dx) + Math.abs(dz) > 1) continue;
          const rx = cx + dx, rz = cz + dz;
          const c = cell(rx, rz);
          if (c.b.includes('log') || c.y > 80) continue;
          if (c.b.includes('water')) {
            set(rx, c.y + 1, rz, 'minecraft:jungle_slab[type=bottom]');
          } else {
            set(rx, c.y, rz, pathPalette[Math.abs(rx * 3 + rz * 7) % pathPalette.length]);
            set(rx, c.y + 1, rz, 'minecraft:air');
          }
        }
      }

      if (i - lastLamp >= 15 && i > 3 && i < steps - 3) {
        const lx = cx + 2, lz = cz + 2;
        const lc = cell(lx, lz);
        if (!lc.b.includes('water') && !lc.b.includes('log') && lc.y <= 78) {
          lastLamp = i;
          foundation(lx, lc.y, lz, 'minecraft:mud_bricks');
          set(lx, lc.y + 1, lz, 'minecraft:mud_brick_wall');
          set(lx, lc.y + 2, lz, 'minecraft:bamboo_fence');
          set(lx, lc.y + 3, lz, 'minecraft:lantern');
        }
      }
    }
  }

  // Hub at Colossal Southern Banyan Tree (-85, 168)
  buildSouthernTrail(-85, 118, -85, 168, 2.0);   // North Gate -> Ulu Banyan Meydani
  buildSouthernTrail(-85, 168, -56, 156, 1.8);   // Ulu Banyan -> Bambu Cay Kosku
  buildSouthernTrail(-85, 168, -112, 164, 1.8);  // Ulu Banyan -> Kasif Kerem'in Kulubesi
  buildSouthernTrail(-85, 168, -68, 196, 2.0);   // Ulu Banyan -> Zumrut Bambu Korusu
  buildSouthernTrail(-85, 168, -85, 222, 2.0);   // Ulu Banyan -> Guney Ucu

  // ==================== 5. COLOSSAL MONUMENT TREE: "ULU BANYAN - BİN KÖKLÜ GÜNEY RUHU" (-85, 168) ====================
  const bx = -85, bz = 168;
  const bGround = groundY(bx, bz);

  // Moss & Mud-Brick Sanctuary Plaza (radius 7, 100% grounded via foundation!)
  for (let dx = -7; dx <= 7; dx++) {
    for (let dz = -7; dz <= 7; dz++) {
      const d = Math.hypot(dx, dz);
      if (d > 7.2) continue;
      const rim = d >= 5.8;
      const mat = rim
        ? ((dx + dz) % 2 === 0 ? 'minecraft:mud_bricks' : 'minecraft:mossy_stone_bricks')
        : ((Math.abs(dx * 5 + dz)) % 3 === 0 ? 'minecraft:moss_block' : 'minecraft:packed_mud');
      foundation(bx + dx, bGround, bz + dz, mat);
      if (d >= 3.2) {
        for (let y = bGround + 1; y <= bGround + 5; y++) set(bx + dx, y, bz + dz, 'minecraft:air');
      }
    }
  }

  // 4 Shrine Lantern Pillars on Plaza Rim
  for (const [sx, sz] of [[0, -7], [0, 7], [7, 0], [-7, 0]]) {
    set(bx + sx, bGround + 1, bz + sz, 'minecraft:chiseled_stone_bricks');
    set(bx + sx, bGround + 2, bz + sz, 'minecraft:mud_brick_wall');
    set(bx + sx, bGround + 3, bz + sz, 'minecraft:lantern');
  }

  // Massive Banyan Trunk (21 blocks tall!)
  for (let dy = 1; dy <= 21; dy++) {
    const r = dy <= 5 ? 2 : (dy <= 14 ? 1 : 0);
    for (let dx = -r; dx <= r; dx++) {
      for (let dz = -r; dz <= r; dz++) {
        if (r === 2 && Math.abs(dx) === 2 && Math.abs(dz) === 2) continue;
        set(bx + dx, bGround + dy, bz + dz, 'minecraft:jungle_wood');
      }
    }
  }

  // Banyan Aerial Prop Roots — grounded ALL THE WAY DOWN to solid plaza floor so ZERO roots float!
  const boughs = [
    [0, 21, 0, 6],
    [5, 16, 0, 4], [-5, 16, 0, 4], [0, 16, 5, 4], [0, 16, -5, 4],
    [4, 14, 4, 3], [-4, 14, 4, 3], [4, 14, -4, 3], [-4, 14, -4, 3]
  ];
  for (const [ox, oy, oz, rad] of boughs) {
    const steps = Math.max(1, Math.abs(ox), Math.abs(oz));
    for (let s = 0; s <= steps; s++) {
      const lx = Math.round((ox * s) / steps);
      const ly = Math.round(12 + ((oy - 12) * s) / steps);
      const lz = Math.round((oz * s) / steps);
      set(bx + lx, bGround + ly, bz + lz, 'minecraft:jungle_wood');
    }
    // Grounded Aerial Prop Root on diagonal boughs (connects branch straight down to ground!)
    if (Math.abs(ox) === 4 && Math.abs(oz) === 4) {
      for (let y = 1; y <= oy - 1; y++) {
        set(bx + ox, bGround + y, bz + oz, 'minecraft:mangrove_roots');
      }
    }
    // Lush Tropical Canopy + Ochre Froglight Golden Fruits
    for (let dx = -rad; dx <= rad; dx++) {
      for (let dy = -2; dy <= 2; dy++) {
        for (let dz = -rad; dz <= rad; dz++) {
          if (Math.sqrt(dx * dx + dy * dy * 1.7 + dz * dz) <= rad + 0.3) {
            const lf = (Math.abs(dx * 3 + dy * 5 + dz * 7) % 4 === 0)
              ? 'minecraft:flowering_azalea_leaves[persistent=true]'
              : 'minecraft:jungle_leaves[persistent=true]';
            set(bx + ox + dx, bGround + oy + dy, bz + oz + dz, lf, true);
          }
        }
      }
    }
    set(bx + ox, bGround + oy - 1, bz + oz, 'minecraft:ochre_froglight[axis=y]');
  }

  // ==================== 6. TWO NAMED SOUTHERN BUILDINGS + BAMBOO GROVE ====================
  // Building A: "Bambu Cay & Gozlem Kosku" (-56, 156)
  const px = -56, pz = 156;
  const pFloor = groundY(px, pz) + 1;
  for (let dx = -3; dx <= 3; dx++) {
    for (let dz = -3; dz <= 3; dz++) {
      const rim = Math.abs(dx) === 3 || Math.abs(dz) === 3;
      foundation(px + dx, pFloor, pz + dz, rim ? 'minecraft:mud_bricks' : 'minecraft:bamboo_planks');
      for (let y = pFloor + 1; y <= pFloor + 7; y++) set(px + dx, y, pz + dz, 'minecraft:air');
    }
  }
  for (let y = pFloor + 1; y <= pFloor + 3; y++) {
    for (const [cx0, cz0] of [[-3, -3], [3, -3], [-3, 3], [3, 3]]) {
      set(px + cx0, y, pz + cz0, 'minecraft:bamboo_block[axis=y]');
    }
  }
  for (let d = -2; d <= 2; d++) {
    if (d !== 0) {
      set(px - 3, pFloor + 1, pz + d, 'minecraft:bamboo_fence');
      set(px + 3, pFloor + 1, pz + d, 'minecraft:bamboo_fence');
      set(px + d, pFloor + 1, pz - 3, 'minecraft:bamboo_fence');
      set(px + d, pFloor + 1, pz + 3, 'minecraft:bamboo_fence');
    }
  }
  // Entry steps on West (-60, 156) facing Banyan Trail
  foundation(px - 4, pFloor - 1, pz, 'minecraft:mud_bricks');
  set(px - 4, pFloor, pz, 'minecraft:mud_brick_stairs[facing=east,half=bottom]');
  // Solid Tiered Bamboo Roof
  for (let dx = -4; dx <= 4; dx++) {
    for (let dz = -4; dz <= 4; dz++) {
      const edge = Math.max(Math.abs(dx), Math.abs(dz));
      if (edge === 4) set(px + dx, pFloor + 4, pz + dz, 'minecraft:bamboo_mosaic_slab[type=bottom]');
      else {
        set(px + dx, pFloor + 4, pz + dz, 'minecraft:bamboo_planks');
        if (edge <= 2) set(px + dx, pFloor + 5, pz + dz, 'minecraft:bamboo_mosaic');
        if (edge === 0) set(px + dx, pFloor + 6, pz + dz, 'minecraft:mud_brick_slab[type=bottom]');
      }
    }
  }
  set(px, pFloor + 3, pz, 'minecraft:chain[axis=y]');
  set(px, pFloor + 2, pz, 'minecraft:lantern[hanging=true]');
  // Tea table inside pavilion
  set(px, pFloor + 1, pz, 'minecraft:bamboo_fence');
  set(px, pFloor + 2, pz + 1, 'minecraft:air'); // keep clear
  set(px + 1, pFloor + 1, pz, 'minecraft:jungle_stairs[facing=west,half=bottom]');
  set(px - 1, pFloor + 1, pz, 'minecraft:jungle_stairs[facing=east,half=bottom]');

  // Building B: "Kasif Kerem'in Yagmur Ormani Arastirma Kulubesi" (-112, 164)
  const kx = -112, kz = 164;
  const kFloor = groundY(kx, kz) + 1;
  for (let dx = -3; dx <= 3; dx++) {
    for (let dz = -3; dz <= 3; dz++) {
      const rim = Math.abs(dx) === 3 || Math.abs(dz) === 3;
      foundation(kx + dx, kFloor, kz + dz, rim ? 'minecraft:mud_bricks' : 'minecraft:jungle_planks');
      for (let y = kFloor + 1; y <= kFloor + 7; y++) set(kx + dx, y, kz + dz, 'minecraft:air');
    }
  }
  for (let y = kFloor + 1; y <= kFloor + 3; y++) {
    for (const [cx0, cz0] of [[-3, -3], [3, -3], [-3, 3], [3, 3]]) {
      set(kx + cx0, y, kz + cz0, 'minecraft:jungle_log[axis=y]');
    }
  }
  for (let d = -2; d <= 2; d++) {
    for (let y = kFloor + 1; y <= kFloor + 3; y++) {
      const win = y === kFloor + 2 && Math.abs(d) <= 1;
      set(kx + d, y, kz - 3, win ? 'minecraft:glass_pane' : 'minecraft:mud_bricks');
      set(kx + d, y, kz + 3, win ? 'minecraft:glass_pane' : 'minecraft:mud_bricks');
      set(kx - 3, y, kz + d, win ? 'minecraft:glass_pane' : 'minecraft:stripped_jungle_log[axis=z]');
      if (d === 0 && y <= kFloor + 2) continue; // Door on East (+3, 0)
      set(kx + 3, y, kz + d, (y === kFloor + 2 && Math.abs(d) === 2) ? 'minecraft:glass_pane' : 'minecraft:stripped_jungle_log[axis=z]');
    }
  }
  set(kx + 3, kFloor + 1, kz, 'minecraft:jungle_door[facing=west,half=lower,hinge=left,open=false]');
  set(kx + 3, kFloor + 2, kz, 'minecraft:jungle_door[facing=west,half=upper,hinge=left,open=false]');
  foundation(kx + 4, kFloor - 1, kz, 'minecraft:mud_bricks');
  set(kx + 4, kFloor, kz, 'minecraft:mud_brick_stairs[facing=west,half=bottom]');

  // Solid Gable Roof on Kerem's Cabin
  for (let dz = -4; dz <= 4; dz++) {
    set(kx - 4, kFloor + 3, kz + dz, 'minecraft:jungle_stairs[facing=east,half=bottom]');
    set(kx + 4, kFloor + 3, kz + dz, 'minecraft:jungle_stairs[facing=west,half=bottom]');
    set(kx - 3, kFloor + 4, kz + dz, 'minecraft:jungle_stairs[facing=east,half=bottom]');
    set(kx + 3, kFloor + 4, kz + dz, 'minecraft:jungle_stairs[facing=west,half=bottom]');
    set(kx - 2, kFloor + 5, kz + dz, 'minecraft:jungle_stairs[facing=east,half=bottom]');
    set(kx + 2, kFloor + 5, kz + dz, 'minecraft:jungle_stairs[facing=west,half=bottom]');
    set(kx - 1, kFloor + 6, kz + dz, 'minecraft:jungle_stairs[facing=east,half=bottom]');
    set(kx + 1, kFloor + 6, kz + dz, 'minecraft:jungle_stairs[facing=west,half=bottom]');
    set(kx, kFloor + 6, kz + dz, 'minecraft:jungle_planks');
    set(kx, kFloor + 7, kz + dz, 'minecraft:mud_brick_slab[type=bottom]');
  }
  for (const gz of [-3, 3]) {
    for (let dx = -2; dx <= 2; dx++) set(kx + dx, kFloor + 4, kz + gz, 'minecraft:mud_bricks');
    for (let dx = -1; dx <= 1; dx++) set(kx + dx, kFloor + 5, kz + gz, 'minecraft:mud_bricks');
  }
  set(kx, kFloor + 5, kz, 'minecraft:chain[axis=y]');
  set(kx, kFloor + 4, kz, 'minecraft:lantern[hanging=true]');
  // Interior: Cartography Table (Haritaci Masasi!), Green Bed, Bookshelf, Barrel
  set(kx - 2, kFloor + 1, kz - 2, 'minecraft:green_bed[facing=west,part=head]');
  set(kx - 1, kFloor + 1, kz - 2, 'minecraft:green_bed[facing=west,part=foot]');
  set(kx - 2, kFloor + 1, kz + 2, 'minecraft:cartography_table');
  set(kx - 1, kFloor + 1, kz + 2, 'minecraft:bookshelf');
  set(kx + 2, kFloor + 1, kz - 2, 'minecraft:barrel[facing=south]');

  // Special Grove C: "Zumrut Bambu & Orkide Korusu" (-68, 196)
  const gx0 = -68, gz0 = 196;
  const gBase = groundY(gx0, gz0);
  for (let dx = -4; dx <= 4; dx++) {
    for (let dz = -4; dz <= 4; dz++) {
      if (Math.hypot(dx, dz) <= 4.2) {
        foundation(gx0 + dx, gBase, gz0 + dz, 'minecraft:moss_block');
      }
    }
  }
  for (const [bdx, bdz, h] of [[0, 0, 10], [2, 1, 8], [-2, 1, 9], [1, -2, 7], [-1, -2, 8], [3, -1, 6]]) {
    for (let y = 1; y <= h; y++) {
      set(gx0 + bdx, gBase + y, gz0 + bdz, 'minecraft:bamboo_block[axis=y]');
    }
    set(gx0 + bdx, gBase + h + 1, gz0 + bdz, 'minecraft:jungle_leaves[persistent=true]');
  }
  set(gx0 - 3, gBase + 1, gz0, 'minecraft:chiseled_stone_bricks');
  set(gx0 - 3, gBase + 2, gz0, 'minecraft:lantern');

  console.log('Submitting Southern Forest ops:', ops.length);
  const res = await act({ action: 'build', ops });
  console.log('SOUTHERN FOREST BUILD RESULT:', JSON.stringify({
    ok: res.ok,
    changedBlocks: res.changedBlocks,
    autoConnected: res.autoConnected,
    autoChained: res.autoChained,
    cleanedFloating: res.cleanedFloating,
    physicsRejectedCount: (res.physicsRejected || []).length,
    errors: res.errors
  }, null, 2));

  // Place Named Signs & Lectern Lore Books (pure data commands, ZERO bot chat!)
  const cmds = [
    // North Gate Plaque of 2nd Region
    `setblock -85 ${gateY + 6} 114 minecraft:jungle_wall_sign[facing=north]{front_text:{messages:['{"text":"🌴 2. BOLGE 🌴","bold":true,"color":"gold"}','{"text":"GUNEY YAGMUR","bold":true,"color":"green"}','{"text":"ORMAN REZERVI","bold":true,"color":"white"}','{"text":"KUZEY KAPISI","color":"yellow"}']},is_waxed:1b}`,

    // Ulu Banyan Monument Tree Sign + Lore Lectern
    `setblock ${bx} ${bGround + 1} ${bz - 6} minecraft:jungle_sign[rotation=8]{front_text:{messages:['{"text":"🌴 ANIT AGAC #2","bold":true,"color":"gold"}','{"text":"ULU BANYAN RUHU","bold":true,"color":"white"}','{"text":"Bin Koklu Muhafiz","color":"green"}','{"text":"Guney Merkez","color":"yellow"}']},is_waxed:1b}`,
    `setblock ${bx + 2} ${bGround + 1} ${bz - 6} minecraft:lectern[facing=north,has_book=true]{Book:{id:"minecraft:written_book",Count:1b,tag:{title:"Guney Yagmur Ormani Tarihi",author:"2. Bolge Mudurlugu",pages:['{"text":"[2. BOLGE: GUNEY ORMANI]\\n\\nNehir bogazinin guneyinde uzanan bu tropikal kusak, asirlik Ulu Banyan agacinin hava kokleriyle beslenir.\\n\\nKuzey Avrasya Rezervi ile kardes bolge ilan edilmistir."}','{"text":"[ULASIM PROJESI]\\n\\nKuzey ve Guney ormanlarini nehir uzerinden birbirine baglayacak MTR Demir Yolu hatti planlanmistir."}']}}}`,

    // Bambu Cay Kosku Sign
    `setblock ${px - 3} ${pFloor + 2} ${pz - 1} minecraft:bamboo_wall_sign[facing=west]{front_text:{messages:['{"text":"🎋 KOSK #1","bold":true,"color":"gold"}','{"text":"BAMBU CAY KOSKU","bold":true,"color":"white"}','{"text":"Dinlenme & Seyir","color":"green"}','{"text":"Dogu Yamaci","color":"gray"}']},is_waxed:1b}`,

    // Kasif Kerem'in Kulubesi Sign + Explorer Journal Lectern
    `setblock ${kx + 4} ${kFloor + 2} ${kz - 1} minecraft:jungle_wall_sign[facing=east]{front_text:{messages:['{"text":"🧭 KULUBE #2","bold":true,"color":"gold"}','{"text":"KASIF KEREM","bold":true,"color":"white"}','{"text":"Harita & Kesif Evi","color":"aqua"}','{"text":"Bati Korusu","color":"gray"}']},is_waxed:1b}`,
    `setblock ${kx - 1} ${kFloor + 1} ${kz - 1} minecraft:lectern[facing=east,has_book=true]{Book:{id:"minecraft:written_book",Count:1b,tag:{title:"Kasif Keremin Harita Notlari",author:"Kasif Kerem",pages:['{"text":"[GUNEY KESIF NOTU]\\n\\nNehrin guneyinde bambu ve orman agaclarinin ic ice gectigi muhtesem bir vadi buldum.\\n\\nHarita masamda Avrasya Kuzey-Guney sinirlarini cizmeye basladim."}']}}}`,

    // Zumrut Bambu Korusu Sign
    `setblock ${gx0 - 3} ${gBase + 1} ${gz0 - 1} minecraft:bamboo_sign[rotation=4]{front_text:{messages:['{"text":"🎍 OZEL KORU","bold":true,"color":"green"}','{"text":"ZUMRUT BAMBU","bold":true,"color":"white"}','{"text":"Koruma Alani","color":"yellow"}','{"text":"Guney Ucu","color":"gray"}']},is_waxed:1b}`
  ];

  for (const c of cmds) {
    await act({ action: 'command', command: c });
  }
}

buildSouthernForest().catch(console.error);

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const JAR_PATH = process.argv[2] || '/tmp/mcbuild/remapped-v740.jar';
const WORK = '/tmp/mcbuild/verify-jar';
const JAVAP = '/tmp/mcbuild/jdk17/bin/javap';
const JAR = '/tmp/mcbuild/jdk17/bin/jar';

fs.rmSync(WORK, { recursive: true, force: true });
fs.mkdirSync(WORK, { recursive: true });
execSync(`${JAR} xf "${JAR_PATH}"`, { cwd: WORK });

let errors = [];
function assert(cond, msg) {
  if (!cond) errors.push(msg);
}

// 1. Validate JSON syntax across entire JAR
function walk(dir) {
  let out = [];
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) out = out.concat(walk(p));
    else out.push(p);
  }
  return out;
}

const allFiles = walk(WORK);
for (const f of allFiles.filter(x => x.endsWith('.json'))) {
  try {
    JSON.parse(fs.readFileSync(f, 'utf8'));
  } catch (e) {
    errors.push(`Invalid JSON: ${f} -> ${e.message}`);
  }
}

// 2. Validate Mixins exist
const mixinsJson = JSON.parse(fs.readFileSync(path.join(WORK, 'arena_ai_bridge.mixins.json'), 'utf8'));
const pkgPath = mixinsJson.package.replace(/\./g, '/');
for (const m of (mixinsJson.mixins || []).concat(mixinsJson.client || [])) {
  const cls = path.join(WORK, pkgPath, `${m}.class`);
  assert(fs.existsSync(cls), `Missing Mixin class in JAR: ${cls}`);
}

// 3. Validate Blockstates -> Models -> Textures & PNG Power-of-Two headers
const bsDir = path.join(WORK, 'assets/arena_ai_bridge/blockstates');
for (const bf of fs.readdirSync(bsDir)) {
  const bs = JSON.parse(fs.readFileSync(path.join(bsDir, bf), 'utf8'));
  for (const [variant, spec] of Object.entries(bs.variants || {})) {
    const modRef = spec.model;
    assert(modRef && modRef.startsWith('arena_ai_bridge:block/'), `${bf} [${variant}] invalid model ref ${modRef}`);
    const mFile = path.join(WORK, 'assets/arena_ai_bridge/models/block', modRef.split('/')[1] + '.json');
    assert(fs.existsSync(mFile), `${bf} [${variant}] missing model file ${mFile}`);
  }
}

const bmDir = path.join(WORK, 'assets/arena_ai_bridge/models/block');
for (const mf of fs.readdirSync(bmDir)) {
  const md = JSON.parse(fs.readFileSync(path.join(bmDir, mf), 'utf8'));
  const isCustomFurnitureOrLight = !mf.includes('world_map_board') && !mf.includes('transit_news_board');
  for (const [tKey, tRef] of Object.entries(md.textures || {})) {
    if (isCustomFurnitureOrLight) {
      assert(!tRef.startsWith('minecraft:'), `Model ${mf} #${tKey} uses vanilla texture (${tRef}) instead of bespoke UV texture!`);
    }
    if (tRef.startsWith('arena_ai_bridge:')) {
      const relTex = tRef.split(':')[1];
      const pngPath = path.join(WORK, 'assets/arena_ai_bridge/textures', relTex + '.png');
      assert(fs.existsSync(pngPath), `Model ${mf} texture #${tKey} missing PNG: ${pngPath}`);
      if (fs.existsSync(pngPath)) {
        const buf = fs.readFileSync(pngPath);
        assert(buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4E && buf[3] === 0x47, `Corrupt PNG header: ${pngPath}`);
        const w = buf.readUInt32BE(16);
        const h = buf.readUInt32BE(20);
        assert((w & (w - 1)) === 0 && (h & (h - 1)) === 0, `Non-power-of-2 PNG (${w}x${h}) causes mipmap drop: ${pngPath}`);
      }
    }
  }
}

for (const guiFile of ['vending_gui.png', 'kiosk_gui.png']) {
  const gp = path.join(WORK, 'assets/arena_ai_bridge/textures/gui', guiFile);
  assert(fs.existsSync(gp), `Missing custom GUI texture: ${gp}`);
  if (fs.existsSync(gp)) {
    const buf = fs.readFileSync(gp);
    assert(buf.readUInt32BE(16) === 256 && buf.readUInt32BE(20) === 256, `GUI texture ${guiFile} must be 256x256!`);
  }
}

// 4. Bytecode Safety Checks on Renderers (Zero VertexFormat BufferBuilder Corruption & Zero Quad UI)
assert(!fs.existsSync(path.join(WORK, 'ai/arena/bridge/board/TunnelLightRenderer.class')), 'TunnelLightRenderer must be removed (0 tunnel BlockEntities)!');

const vendCls = path.join(WORK, 'ai/arena/bridge/board/MetroFurnitureRenderers$VendingMachineRenderer.class');
assert(fs.existsSync(vendCls), 'Missing VendingMachineRenderer.class');
const vendAsm = execSync(`${JAVAP} -c "${vendCls}"`).toString();
assert(!vendAsm.includes('method_23593') && !vendAsm.includes('getGui'), 'VendingMachineRenderer must NOT use RenderLayer.getGui() rectangle drawing!');

const wmbCls = path.join(WORK, 'ai/arena/bridge/board/WorldMapBoardRenderer.class');
const wmbAsm = execSync(`${JAVAP} -c -p "${wmbCls}"`).toString();
const schemPart = wmbAsm.split('renderSchematicDiagram')[1]?.split('static void')[0] || '';
const lastQuadIdx = schemPart.lastIndexOf('Method quad:');
const firstTextIdx = schemPart.indexOf('Method drawWallText:');
assert(lastQuadIdx > 0 && firstTextIdx > lastQuadIdx, `CRITICAL: drawWallText (${firstTextIdx}) appears BEFORE quad (${lastQuadIdx}) in renderSchematicDiagram!`);

// 5. Chunk-Manager Deadlock Guard (Zero synchronous chunk/block mutation inside CHUNK_LOAD or SERVER_STARTED)
const acSrc = fs.readFileSync('/home/user/arena-mc/mod-src/ai/arena/bridge/ArenaContent.java', 'utf8');
assert(!acSrc.includes('SERVER_STARTED'), 'DEADLOCK HAZARD: ArenaContent.java registers SERVER_STARTED synchronous world chunk access!');
const hookMatch = acSrc.match(/public void onChunkLoadHeal[\s\S]*?\n    \}/);
if (hookMatch) {
  assert(!hookMatch[0].includes('setBlockState') && !hookMatch[0].includes('getBlockState'),
    'DEADLOCK HAZARD: onChunkLoadHeal accesses world/chunk blocks synchronously during CHUNK_LOAD!');
}

// 6. Verify recorded mono Ogg Vorbis alarm sound + GPU-animated red emergency sprite + ProgrammableBoardRenderer ordering
const oggPath = path.join(WORK, 'assets/arena_ai_bridge/sounds/tunnel_alarm_beep.ogg');
assert(fs.existsSync(oggPath), 'Missing recorded tunnel_alarm_beep.ogg!');
if (fs.existsSync(oggPath)) {
  const oggBuf = fs.readFileSync(oggPath);
  assert(oggBuf.subarray(0, 4).toString('ascii') === 'OggS', 'tunnel_alarm_beep.ogg is not valid Ogg Vorbis!');
  const vIdx = oggBuf.indexOf(Buffer.from([0x01, 0x76, 0x6f, 0x72, 0x62, 0x69, 0x73]));
  assert(vIdx > 0 && oggBuf[vIdx + 11] === 1, 'tunnel_alarm_beep.ogg MUST be mono (1 channel) for 3D OpenAL distance attenuation!');
}
assert(fs.existsSync(path.join(WORK, 'assets/arena_ai_bridge/textures/block/led_red_emergency.png.mcmeta')),
  'Missing led_red_emergency.png.mcmeta GPU animation!');

const pbCls = path.join(WORK, 'ai/arena/bridge/board/ProgrammableBoardRenderer.class');
assert(fs.existsSync(pbCls), 'Missing ProgrammableBoardRenderer.class!');
const pbAsm = execSync(`${JAVAP} -c -p "${pbCls}"`).toString();
const pbLastQuad = pbAsm.lastIndexOf('quad:');
const pbFirstText = pbAsm.indexOf('drawWallText:');
assert(pbLastQuad > 0 && pbFirstText > pbLastQuad, 'ProgrammableBoardRenderer calls drawWallText before finishing quad calls!');

if (errors.length > 0) {
  console.error('PRE-FLIGHT VERIFICATION FAILED:', errors);
  process.exit(1);
}
console.log('PRE-FLIGHT VERIFICATION PASSED 100%: 0 JSON errors, 0 missing/non-POT PNGs, 0 Mixin gaps, 0 VertexFormat hazards!');

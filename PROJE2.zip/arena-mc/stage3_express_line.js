// Stage 3: 1.6 km Kuzey-Güney "Avrasya Orman Ekspres Hattı" (MTR 4.0.5 200 km/h Tünel + Portallar + Viyadük)
const BASE = 'http://127.0.0.1:8080';

async function postAct(body) {
  const r = await fetch(BASE + '/api/act', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  return r.json();
}

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

async function connectRail(z1, y1, z2, y2, item) {
  const r1 = await postAct({ action: 'interact', x: -18, y: y1, z: z1, side: 'up', item });
  const r2 = await postAct({ action: 'interact', x: -18, y: y2, z: z2, side: 'up', item });
  if (r1.result !== 'SUCCESS' || r2.result !== 'SUCCESS') {
    console.log(`  [WARN] Rail ${z1}(y=${y1})->${z2}(y=${y2}) ${item}:`, r1.result, r2.result);
  }
  return r1.result === 'SUCCESS' && r2.result === 'SUCCESS';
}

async function main() {
  // --- PART A: North Approach & Monumental North Tunnel Portal (z=45..84) ---
  await postAct({ action: 'command', command: 'tp ArenaAI -18 65 52' });
  await sleep(700);

  const northOps = [];
  // Surface approach z=45..52 (y=63 trackbed, y=64 parapet walls)
  for (let z = 45; z <= 52; z++) {
    for (let x = -20; x <= -16; x++) {
      northOps.push({ x, y: 62, z, block: 'minecraft:cobblestone' });
      northOps.push({ x, y: 63, z, block: (x >= -19 && x <= -17) ? 'minecraft:andesite' : 'minecraft:stone_bricks' });
    }
    for (let y = 64; y <= 68; y++) {
      for (let x = -20; x <= -16; x++) northOps.push({ x, y, z, block: 'minecraft:air' });
    }
    northOps.push({ x: -20, y: 64, z, block: 'minecraft:stone_brick_wall' });
    northOps.push({ x: -16, y: 64, z, block: 'minecraft:stone_brick_wall' });
  }

  // Grand North Tunnel Portal Facade at z=52..54 (carved cleanly into the z=53 hillside, ZERO trees cut above y=70!)
  for (let z = 52; z <= 54; z++) {
    for (let y = 63; y <= 69; y++) {
      for (let x = -21; x <= -15; x++) {
        const isOuter = (x === -21 || x === -15 || y === 69);
        const isArchCorner = (y === 68 && (x === -20 || x === -16));
        if (isOuter || isArchCorner) {
          northOps.push({ x, y, z, block: (z === 52 && (y === 69 || x === -21 || x === -15)) ? 'minecraft:chiseled_stone_bricks' : 'minecraft:stone_bricks' });
        } else if (y >= 64) {
          northOps.push({ x, y, z, block: 'minecraft:air' });
        }
      }
    }
  }

  // North Descent Ramp Bore (z=53..84: floor steps smoothly from y=63 at z=52 down to y=47 at z=84)
  for (let z = 53; z <= 84; z++) {
    const t = (z - 52) / 32.0; // 0..1
    const floorY = Math.round(63 - 16 * t); // 63 -> 47
    const ceilY = floorY + 6;
    for (let y = floorY; y <= ceilY; y++) {
      for (let x = -21; x <= -15; x++) {
        if (y === floorY) {
          northOps.push({ x, y, z, block: (x >= -19 && x <= -17) ? 'minecraft:andesite' : 'minecraft:stone_bricks' });
        } else if (y === ceilY || x === -21 || x === -15) {
          const isLight = (z % 8 === 0 && y === floorY + 3 && (x === -21 || x === -15));
          northOps.push({ x, y, z, block: isLight ? 'minecraft:sea_lantern' : 'minecraft:stone_bricks' });
        } else {
          northOps.push({ x, y, z, block: 'minecraft:air' });
        }
      }
    }
  }
  await postAct({ action: 'build', ops: northOps, recordUndo: true, strictPhysics: false, cleanFloating: false });

  // Place North Portal lanterns, stairs & MTR rail nodes via /place_real!
  await postAct({
    action: 'place_real',
    steps: [
      { x: -21, y: 66, z: 51, item: 'minecraft:lantern', against: 'south', look: 'south' },
      { x: -15, y: 66, z: 51, item: 'minecraft:lantern', against: 'south', look: 'south' },
      { x: -18, y: 64, z: 52, item: 'mtr:rail', against: 'down', look: 'south', replace: true },
      { x: -18, y: 48, z: 84, item: 'mtr:rail', against: 'down', look: 'south', replace: true }
    ]
  });
  const okN1 = await connectRail(44, 64, 52, 64, 'mtr:rail_connector_80');
  const okN2 = await connectRail(52, 64, 84, 48, 'mtr:rail_connector_120');
  console.log('[Kuzey Portal + Rampa]:', { okN1, okN2 });

  // --- PART B: 1,440m High-Speed Continental Express Tunnel (z=84 -> 1524 at y=48, 45 x 32m segments @ 200 km/h!) ---
  let connectedExpress = 0;
  // Build in 96-block chunk-loaded hops (15 hops total -> super fast!)
  for (let segStart = 84; segStart < 1524; segStart += 96) {
    const segEnd = Math.min(1524, segStart + 96);
    const midZ = Math.round((segStart + segEnd) / 2);
    await postAct({ action: 'command', command: `tp ArenaAI -18 49 ${midZ}` });
    await sleep(450);

    const tunOps = [];
    for (let z = segStart + 1; z <= segEnd; z++) {
      const isRib = (z % 16 === 0);
      const isLight = (z % 8 === 0);
      for (let y = 47; y <= 53; y++) {
        for (let x = -21; x <= -15; x++) {
          if (y === 47) {
            tunOps.push({ x, y, z, block: (x >= -19 && x <= -17) ? 'minecraft:andesite' : 'minecraft:polished_andesite' });
          } else if (y === 53 || x === -21 || x === -15) {
            if (isLight && y === 50 && (x === -21 || x === -15)) {
              tunOps.push({ x, y, z, block: 'minecraft:sea_lantern' });
            } else if (isRib) {
              tunOps.push({ x, y, z, block: 'minecraft:polished_deepslate' });
            } else {
              tunOps.push({ x, y, z, block: 'minecraft:stone_bricks' });
            }
          } else if (y === 52 && (x === -20 || x === -16)) {
            tunOps.push({ x, y, z, block: isRib ? 'minecraft:polished_deepslate' : 'minecraft:stone_brick_slab[type=top]' });
          } else {
            tunOps.push({ x, y, z, block: 'minecraft:air' });
          }
        }
      }
    }
    await postAct({ action: 'build', ops: tunOps, recordUndo: false, strictPhysics: false, cleanFloating: false });

    // Place 32m-spaced MTR rail nodes via /place_real & connect with 200 km/h connector!
    const railSteps = [];
    for (let rz = segStart + 32; rz <= segEnd; rz += 32) {
      railSteps.push({ x: -18, y: 48, z: rz, item: 'mtr:rail', against: 'down', look: 'south', replace: true });
    }
    await postAct({ action: 'place_real', steps: railSteps, recordUndo: false });

    for (let rz = segStart; rz < segEnd; rz += 32) {
      const ok = await connectRail(rz, 48, rz + 32, 48, 'mtr:rail_connector_200');
      if (ok) connectedExpress++;
    }
  }
  console.log(`[Avrasya Ekspres Tüneli 200 km/s]: ${connectedExpress}/45 segment bağlandı!`);

  // --- PART C: South Ascent Ramp & Grand Southern Portal -> Viaduct into Güney Orman Garı (z=1524 -> 1568) ---
  await postAct({ action: 'command', command: 'tp ArenaAI -18 68 1550' });
  await sleep(800);

  const southOps = [];
  // 1) Underground ascent z=1525..1548: floor y=47 -> y=59 (rail y=48 -> y=60)
  for (let z = 1525; z <= 1548; z++) {
    const t = (z - 1524) / 24.0;
    const floorY = Math.round(47 + 12 * t); // 47 -> 59
    const ceilY = floorY + 6;
    for (let y = floorY; y <= ceilY; y++) {
      for (let x = -21; x <= -15; x++) {
        if (y === floorY) {
          southOps.push({ x, y, z, block: (x >= -19 && x <= -17) ? 'minecraft:andesite' : 'minecraft:stone_bricks' });
        } else if (y === ceilY || x === -21 || x === -15) {
          const isLight = (z % 8 === 0 && y === floorY + 3 && (x === -21 || x === -15));
          southOps.push({ x, y, z, block: isLight ? 'minecraft:sea_lantern' : 'minecraft:stone_bricks' });
        } else {
          southOps.push({ x, y, z, block: 'minecraft:air' });
        }
      }
    }
  }

  // 2) Emerging cut-and-cover portal & grounded stone viaduct ramp z=1549..1567: floor y=60 -> y=72 (rail y=61 -> y=73 at z=1568!)
  for (let z = 1549; z <= 1567; z++) {
    const t = (z - 1548) / 20.0;
    const floorY = Math.round(59 + 13 * t); // 59 -> 72
    // Solid grounded stone-brick substructure down to y=58 so ZERO blocks float over the sand bluff!
    for (let x = -20; x <= -16; x++) {
      if (z % 5 === 0 || x === -20 || x === -16 || floorY <= 67) {
        for (let y = 58; y < floorY; y++) {
          southOps.push({ x, y, z, block: 'minecraft:stone_bricks' });
        }
      }
      southOps.push({ x, y: floorY - 1, z, block: 'minecraft:stone_bricks' });
      southOps.push({ x, y: floorY, z, block: (x >= -19 && x <= -17) ? 'minecraft:andesite' : 'minecraft:stone_bricks' });
    }
    // Clear train headroom above ramp!
    for (let y = floorY + 1; y <= floorY + 6; y++) {
      for (let x = -20; x <= -16; x++) {
        southOps.push({ x, y, z, block: 'minecraft:air' });
      }
    }
    if (z <= 1556) {
      // Enclosed Southern Tunnel Portal Arch emerging out of the sand bluff at z=1556!
      const ceilY = floorY + 6;
      for (let y = floorY; y <= ceilY; y++) {
        southOps.push({ x: -21, y, z, block: z === 1556 ? 'minecraft:chiseled_stone_bricks' : 'minecraft:stone_bricks' });
        southOps.push({ x: -15, y, z, block: z === 1556 ? 'minecraft:chiseled_stone_bricks' : 'minecraft:stone_bricks' });
      }
      for (let x = -21; x <= -15; x++) {
        southOps.push({ x, y: ceilY, z, block: z === 1556 ? 'minecraft:chiseled_stone_bricks' : 'minecraft:stone_bricks' });
      }
    } else {
      // Open-air viaduct parapet walls approaching Güney Orman Garı!
      southOps.push({ x: -20, y: floorY + 1, z, block: 'minecraft:stone_brick_wall' });
      southOps.push({ x: -16, y: floorY + 1, z, block: 'minecraft:stone_brick_wall' });
    }
  }
  await postAct({ action: 'build', ops: southOps, recordUndo: true, strictPhysics: false, cleanFloating: false });

  await postAct({
    action: 'place_real',
    steps: [
      { x: -18, y: 60, z: 1548, item: 'mtr:rail', against: 'down', look: 'south', replace: true },
      { x: -21, y: 68, z: 1557, item: 'minecraft:lantern', against: 'north', look: 'north' },
      { x: -15, y: 68, z: 1557, item: 'minecraft:lantern', against: 'north', look: 'north' }
    ]
  });

  const okS1 = await connectRail(1524, 48, 1548, 60, 'mtr:rail_connector_120');
  const okS2 = await connectRail(1548, 60, 1568, 73, 'mtr:rail_connector_80');
  console.log('[Güney Portal + Viyadük Bağlantısı]:', { okS1, okS2 });
}

main().catch(console.error);

const BASE = 'http://127.0.0.1:8080';
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

async function act(body) {
  for (let i = 0; i < 5; i++) {
    const r = await fetch(BASE + '/api/act', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...body, force: true })
    });
    const d = await r.json();
    if (d && d.ok !== false) return d;
    await sleep(400);
  }
  return { ok: false };
}

async function cmd(c) {
  await act({ action: 'command', command: c });
}

async function connectRail(z1, y1, z2, y2, item) {
  const r1 = await act({ action: 'interact', x: -18, y: y1, z: z1, side: 'up', item });
  const r2 = await act({ action: 'interact', x: -18, y: y2, z: z2, side: 'up', item });
  console.log(`[NORTH RAIL ${item}] ${z1}->${z2}:`, r1.result, r2.result);
}

async function main() {
  await act({ action: 'stop' });
  await cmd('tp ArenaAI -24 65 32');
  await sleep(300);

  // 1. Disconnect old ramp at (-18, 64, 52)->(-18, 48, 84) and clear old y=64 surface station & depot (-36..83)
  await connectRail(52, 64, 84, 48, 'mtr:rail_remover');
  for (const [z1, z2] of [[-38, -8], [-7, 24], [25, 54], [55, 83]]) {
    await cmd(`fill -25 64 ${z1} -14 76 ${z2} minecraft:air`);
    await cmd(`fill -22 54 ${z1} -14 61 ${z2} minecraft:stone`);
    await cmd(`fill -25 62 ${z1} -14 62 ${z2} minecraft:dirt`);
    await cmd(`fill -25 63 ${z1} -14 63 ${z2} minecraft:grass_block`);
  }

  // 2. Build flat y=48 Underground Depot + Turnback (z=-37..18) & Approach Tunnel (z=46..83)
  for (const [z1, z2] of [[-37, -10], [-9, 18], [46, 83]]) {
    await cmd(`fill -21 47 ${z1} -15 53 ${z2} minecraft:stone_bricks`);
    await cmd(`fill -20 48 ${z1} -16 51 ${z2} minecraft:air`);
    await cmd(`fill -19 52 ${z1} -17 52 ${z2} minecraft:air`);
    await cmd(`fill -20 52 ${z1} -20 52 ${z2} minecraft:stone_brick_slab[type=top]`);
    await cmd(`fill -16 52 ${z1} -16 52 ${z2} minecraft:stone_brick_slab[type=top]`);
    await cmd(`fill -19 47 ${z1} -17 47 ${z2} minecraft:andesite`);
  }
  // End wall at z=-38
  await cmd('fill -21 47 -38 -15 53 -38 minecraft:polished_deepslate');

  // 3. Grand Vaulted White-Quartz Underground Platform Hall (z=19..45, x=-28..-15, y=47..55)
  await cmd('fill -28 47 19 -15 55 45 minecraft:polished_deepslate');
  await cmd('fill -27 49 20 -16 54 44 minecraft:air');
  await cmd('fill -19 48 19 -16 52 45 minecraft:air');
  await cmd('fill -28 49 20 -28 53 44 minecraft:smooth_quartz');
  await cmd('fill -15 49 20 -15 53 44 minecraft:smooth_quartz');
  await cmd('fill -28 51 20 -28 51 44 minecraft:red_concrete');
  await cmd('fill -15 51 20 -15 51 44 minecraft:red_concrete');
  await cmd('fill -27 55 20 -16 55 44 minecraft:smooth_quartz');
  await cmd('fill -27 48 20 -22 48 44 minecraft:smooth_quartz');
  await cmd('fill -21 48 20 -21 48 44 minecraft:yellow_concrete');
  await cmd('fill -20 48 20 -20 48 44 mtr:platform[door_type=none,facing=west,side=0]');

  // 4. Waterproof Mezzanine Ticket Hall (x=-29..-21, y=56..62, z=20..40) + Surface [M1] Glass Pavilion (y=63..68)
  await cmd('fill -29 56 20 -21 62 40 minecraft:polished_deepslate');
  await cmd('fill -28 57 21 -22 61 39 minecraft:air');
  await cmd('fill -28 56 21 -22 56 39 minecraft:smooth_quartz');
  await cmd('fill -28 62 21 -22 62 39 minecraft:smooth_quartz');

  // Surface [M1] Glass & Dark-Titanium Entrance Pavilion at y=63..68 (x=-29..-25, z=19..30)
  await cmd('fill -29 64 18 -24 72 31 minecraft:air');
  await cmd('fill -29 63 18 -25 63 21 minecraft:smooth_quartz');
  await cmd('fill -29 64 20 -29 66 29 minecraft:glass');
  await cmd('fill -25 64 20 -25 66 29 minecraft:glass');
  await cmd('fill -29 64 29 -25 66 29 minecraft:glass');
  await cmd('fill -29 67 20 -25 67 29 minecraft:polished_deepslate');
  await cmd('fill -28 67 20 -26 67 20 minecraft:red_concrete');
  await cmd('fill -29 68 20 -25 68 29 minecraft:polished_deepslate_slab[type=bottom]');

  // Carve Stair Flight 1 shaft (x=-28..-26, z=21..28, y=57..66) & Flight 2 shaft (x=-24..-22, z=25..33, y=49..57)
  await cmd('fill -28 57 21 -26 66 28 minecraft:air');
  await cmd('fill -24 49 25 -22 57 33 minecraft:air');

  // 5. Stairs, Turnstiles, Columns, Map/News Boards & Pure White LEDs
  const ops = [];
  // Flight 1: Surface (z=21, y=63) -> Mezzanine (z=27, y=57)
  for (let i = 0; i < 7; i++) {
    const sz = 21 + i, sy = 63 - i;
    for (let x = -28; x <= -26; x++) {
      ops.push({ x, y: sy - 1, z: sz, block: 'minecraft:smooth_quartz' });
      ops.push({ x, y: sy, z: sz, block: 'minecraft:smooth_quartz_stairs[facing=north,half=bottom,shape=straight,waterlogged=false]' });
      for (let ay = sy + 1; ay <= sy + 4; ay++) ops.push({ x, y: ay, z: sz, block: 'minecraft:air' });
    }
  }
  // Flight 2: Mezzanine (z=33, y=56) -> Underground Platform (z=26, y=49)
  for (let i = 0; i < 8; i++) {
    const sz = 33 - i, sy = 56 - i;
    for (let x = -24; x <= -22; x++) {
      ops.push({ x, y: sy - 1, z: sz, block: 'minecraft:smooth_quartz' });
      ops.push({ x, y: sy, z: sz, block: 'minecraft:smooth_quartz_stairs[facing=south,half=bottom,shape=straight,waterlogged=false]' });
      for (let ay = sy + 1; ay <= sy + 4; ay++) ops.push({ x, y: ay, z: sz, block: 'minecraft:air' });
    }
  }
  // Glass balustrade around Flight 2 opening in Mezzanine
  for (let z = 26; z <= 33; z++) {
    ops.push({ x: -25, y: 57, z, block: 'minecraft:tinted_glass' });
  }
  // Mezzanine Turnstiles at x=-25, z=34..39 (walking floor y=57)
  for (let z = 34; z <= 39; z++) {
    if (z <= 35) {
      ops.push({ x: -25, y: 57, z, block: 'mtr:ticket_barrier_entrance_1[facing=east,open=closed]' });
    } else if (z <= 37) {
      ops.push({ x: -25, y: 57, z, block: 'mtr:ticket_barrier_exit_1[facing=west,open=closed]' });
    } else {
      ops.push({ x: -25, y: 57, z, block: 'minecraft:tinted_glass' });
      ops.push({ x: -25, y: 58, z, block: 'minecraft:tinted_glass' });
    }
  }
  // Underground Platform Columns + Digital Map & Transit News Boards!
  for (const cz of [22, 36, 42]) {
    for (let y = 49; y <= 54; y++) {
      ops.push({ x: -25, y, z: cz, block: (y === 49 || y === 54) ? 'minecraft:chiseled_quartz_block' : 'minecraft:quartz_pillar[axis=y]' });
    }
  }
  ops.push({ x: -24, y: 50, z: 36, block: 'arena_ai_bridge:world_map_board[facing=east,map_mode=0]' });
  ops.push({ x: -24, y: 50, z: 42, block: 'arena_ai_bridge:transit_news_board[facing=east]' });

  // Pure White Primary LEDs (Pavilion, Mezzanine, Platform Hall, Depot & Approach Tunnel!)
  for (const lz of [22, 25, 28]) {
    ops.push({ x: -27, y: 66, z: lz, block: 'arena_ai_bridge:tunnel_emergency_light[ceiling=true,emergency=false,facing=north]' });
  }
  for (const lz of [31, 35, 38]) {
    ops.push({ x: -27, y: 61, z: lz, block: 'arena_ai_bridge:tunnel_emergency_light[ceiling=true,emergency=false,facing=north]' });
    ops.push({ x: -23, y: 61, z: lz, block: 'arena_ai_bridge:tunnel_emergency_light[ceiling=true,emergency=false,facing=north]' });
  }
  for (let z = 21; z <= 43; z += 3) {
    ops.push({ x: -21, y: 54, z, block: 'arena_ai_bridge:tunnel_emergency_light[ceiling=true,emergency=false,facing=north]' });
    ops.push({ x: -18, y: 54, z, block: 'arena_ai_bridge:tunnel_emergency_light[ceiling=true,emergency=false,facing=north]' });
  }
  for (let z = -36; z <= 16; z += 4) {
    ops.push({ x: -18, y: 52, z, block: 'arena_ai_bridge:tunnel_emergency_light[ceiling=true,emergency=false,facing=north]' });
  }
  for (let z = 48; z <= 80; z += 4) {
    ops.push({ x: -18, y: 52, z, block: 'arena_ai_bridge:tunnel_emergency_light[ceiling=true,emergency=false,facing=north]' });
  }

  await act({ action: 'build', ops, recordUndo: false, strictPhysics: false, cleanFloating: false });

  // 6. Place MTR y=48 Rail Nodes, Ticket Machine & PIDS, then connect Depot + Turnback + Platform + Tunnel!
  await cmd('tp ArenaAI -18 49 -10');
  await sleep(250);
  await act({
    action: 'place_real',
    recordUndo: false,
    steps: [
      { x: -18, y: 48, z: -36, item: 'mtr:rail', against: 'down', look: 'south', replace: true },
      { x: -18, y: 48, z: -18, item: 'mtr:rail', against: 'down', look: 'south', replace: true },
      { x: -18, y: 48, z: 4, item: 'mtr:rail', against: 'down', look: 'south', replace: true }
    ]
  });
  await sleep(200);
  await connectRail(-36, 48, -18, 48, 'mtr:rail_connector_turn_back');
  await connectRail(-18, 48, 4, 48, 'mtr:rail_connector_siding');

  await cmd('tp ArenaAI -22 49 32');
  await sleep(250);
  await act({
    action: 'place_real',
    recordUndo: false,
    steps: [
      { x: -18, y: 48, z: 20, item: 'mtr:rail', against: 'down', look: 'south', replace: true },
      { x: -18, y: 48, z: 44, item: 'mtr:rail', against: 'down', look: 'south', replace: true },
      { x: -18, y: 48, z: 64, item: 'mtr:rail', against: 'down', look: 'south', replace: true },
      { x: -28, y: 57, z: 35, item: 'mtr:ticket_machine', against: 'down', look: 'east', replace: true },
      { x: -21, y: 53, z: 26, item: 'mtr:pids_1', against: 'up', look: 'east', replace: true },
      { x: -21, y: 53, z: 38, item: 'mtr:pids_1', against: 'up', look: 'east', replace: true }
    ]
  });
  await sleep(200);

  await connectRail(4, 48, 20, 48, 'mtr:rail_connector_80');
  await connectRail(20, 48, 44, 48, 'mtr:rail_connector_platform');
  await connectRail(44, 48, 64, 48, 'mtr:rail_connector_80');
  await connectRail(64, 48, 84, 48, 'mtr:rail_connector_80');

  console.log('FAST_NORTH_METRO_DONE');
}

main().catch(e => { console.error(e); process.exit(1); });

// Stage 2: Güney Zümrüt Ormanı Bölgesi + Güney Orman Garı (z = 1568..1620, 1.6 km South!)
// Uses v4.0 /place_nbt (mtr_forest_station.nbt & forest_cabin_v4.nbt) + /place_real (ItemStack.useOnBlock)
const fs = require('fs');
const BASE = 'http://127.0.0.1:8080';

async function postAct(body) {
  const r = await fetch(BASE + '/api/act', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  return r.json();
}

async function runReal(steps, label) {
  let placed = 0;
  let failed = [];
  for (let i = 0; i < steps.length; i += 250) {
    const res = await postAct({ action: 'place_real', steps: steps.slice(i, i + 250) });
    placed += (res.placedCount || 0);
    if (res.failed && res.failed.length) failed.push(...res.failed);
  }
  console.log(`[${label}] Placed: ${placed}/${steps.length}, Failed: ${failed.length}`);
  if (failed.length) console.log('  Sample failed:', failed.slice(0, 4));
}

async function main() {
  // Ensure ArenaAI is at South site so ServerWorld chunks (z=1560..1625) are loaded!
  await postAct({ action: 'command', command: 'tp ArenaAI -35 74 1585' });
  await new Promise(r => setTimeout(r, 1200));

  // 1. Place our verified player-built Station .nbt at (-24, 71, 1568)!
  // Foundation bottom=71, ballast=72, Platform & Rail=73, Roof ridge=79
  const stNbt = await postAct({
    action: 'place_nbt',
    file: '/home/user/arena-mc/schematics/mtr_forest_station.nbt',
    x: -24, y: 71, z: 1568,
    rotation: 'NONE',
    groundFoundation: false
  });
  console.log('[Güney Orman Garı .nbt]:', { ok: stNbt.ok, sizeX: stNbt.sizeX, sizeY: stNbt.sizeY, sizeZ: stNbt.sizeZ });

  // 2. Anchor solid stone-brick viaduct piers under Güney Orman Garı down to y=62 (ZERO floating!),
  //    build Southern Turnback Siding (z=1593..1602 at y=73), and Grand Staircase down to y=65 Plaza!
  const viaductSteps = [];
  const pushV = (x, y, z, item, opts = {}) => viaductSteps.push({ x, y, z, item, ...opts });

  for (const pz of [1568, 1574, 1580, 1586, 1592]) {
    for (const px of [-23, -20, -16]) {
      for (let y = 62; y <= 70; y++) {
        pushV(px, y, pz, 'minecraft:stone_bricks', { replace: true, look: 'south' });
      }
    }
    // Arch cross-beam at y=70 between piers
    for (let x = -23; x <= -16; x++) {
      pushV(x, 70, pz, 'minecraft:stone_bricks', { replace: true, look: 'east' });
    }
  }

  // Southern Turnback Track Deck (z=1593..1602, x=-20..-16, y=72 ballast, y=73 parapet & rail)
  for (let z = 1593; z <= 1602; z++) {
    if (z === 1598 || z === 1602) {
      for (const px of [-20, -16]) {
        for (let y = 62; y <= 71; y++) {
          pushV(px, y, z, 'minecraft:stone_bricks', { replace: true, look: 'south' });
        }
      }
    }
    for (let x = -20; x <= -16; x++) {
      pushV(x, 71, z, 'minecraft:stone_bricks', { replace: true, look: 'south' });
      const mat = (x >= -19 && x <= -17) ? 'minecraft:andesite' : 'minecraft:stone_bricks';
      pushV(x, 72, z, mat, { replace: true, look: 'south' });
    }
    pushV(-20, 73, z, 'minecraft:stone_brick_wall', { against: 'down', look: 'south' });
    pushV(-16, 73, z, 'minecraft:stone_brick_wall', { against: 'down', look: 'south' });
  }
  // South Buffer Stop at z=1602
  for (let x = -20; x <= -16; x++) {
    pushV(x, 73, 1602, 'minecraft:chiseled_stone_bricks', { replace: true, against: 'down', look: 'north' });
  }
  pushV(-18, 74, 1602, 'minecraft:lantern', { against: 'down', look: 'north' });
  pushV(-18, 73, 1601, 'mtr:rail', { against: 'down', look: 'south', replace: true });

  // Grand Stepped Stone Staircase from Station Entrance (x=-24, y=73, z=1569..1572) down West to Plaza (x=-32, y=65)
  // At x=-24, .nbt already placed stairs at y=73. Let's step cleanly down x=-25 (y=72) -> x=-32 (y=65)!
  for (let i = 0; i < 8; i++) {
    const sx = -25 - i;      // -25 .. -32
    const sy = 72 - i;       // 72 .. 65
    for (let z = 1569; z <= 1572; z++) {
      // Solid grounded stone support all the way down to y=63!
      for (let y = 63; y < sy; y++) {
        pushV(sx, y, z, 'minecraft:stone_bricks', { replace: true, look: 'east' });
      }
      if (z === 1569 || z === 1572) {
        pushV(sx, sy, z, 'minecraft:stone_bricks', { replace: true, look: 'east' });
        pushV(sx, sy + 1, z, 'minecraft:stone_brick_wall', { against: 'down', look: 'east' });
        if (i === 0 || i === 7) pushV(sx, sy + 2, z, 'minecraft:lantern', { against: 'down', look: 'east' });
      } else {
        // Ascending player walks EAST toward station -> look="east" makes stairs ascend East!
        pushV(sx, sy, z, 'minecraft:stone_brick_stairs', { replace: true, against: 'down', half: 'bottom', look: 'east' });
      }
    }
  }

  await runReal(viaductSteps, 'Güney Viyadük Ayakları + Merdiven + Turnback');

  // Connect Güney Orman Garı MTR Rails (z=1568 -> 1592 platform, z=1592 -> 1601 turn_back)!
  const c1 = await postAct({ action: 'interact', x: -18, y: 73, z: 1568, side: 'up', item: 'mtr:rail_connector_platform' });
  const c2 = await postAct({ action: 'interact', x: -18, y: 73, z: 1592, side: 'up', item: 'mtr:rail_connector_platform' });
  const c3 = await postAct({ action: 'interact', x: -18, y: 73, z: 1592, side: 'up', item: 'mtr:rail_connector_turn_back' });
  const c4 = await postAct({ action: 'interact', x: -18, y: 73, z: 1601, side: 'up', item: 'mtr:rail_connector_turn_back' });
  console.log('[Güney MTR Ray Bağlantısı]:', c1.result, c2.result, '| Turnback:', c3.result, c4.result);

  // 3. Build "2. Güney Orman Bölge Başkanlığı" (x=-43..-35, z=1569..1577, floor y=65) via /place_real!
  const lodge = [];
  const pushL = (x, y, z, item, opts = {}) => lodge.push({ x, y, z, item, ...opts });

  // Grounded stone foundation y=63..65
  for (let z = 1569; z <= 1577; z++) {
    for (let x = -43; x <= -35; x++) {
      pushL(x, 63, z, 'minecraft:cobblestone', { replace: true, look: 'east' });
      pushL(x, 64, z, 'minecraft:stone_bricks', { replace: true, look: 'east' });
      const isEdge = (x === -43 || x === -35 || z === 1569 || z === 1577);
      pushL(x, 65, z, isEdge ? 'minecraft:stone_bricks' : 'minecraft:spruce_planks', { replace: true, look: 'east' });
    }
  }
  // Porch step at East entrance (x=-34, z=1572..1574) facing Station Staircase!
  for (let z = 1572; z <= 1574; z++) {
    pushL(-34, 64, z, 'minecraft:stone_bricks', { replace: true, look: 'west' });
    pushL(-34, 65, z, 'minecraft:stone_brick_stairs', { replace: true, half: 'bottom', look: 'west' });
  }
  // Walls (y=66..69): corner spruce logs, stripped spruce & glass pane windows, East entrance door at (-35, 66, 1573)
  for (let y = 66; y <= 69; y++) {
    for (let z = 1569; z <= 1577; z++) {
      for (let x = -43; x <= -35; x++) {
        const isBorder = (x === -43 || x === -35 || z === 1569 || z === 1577);
        if (!isBorder) continue;
        const isCorner = (x === -43 || x === -35) && (z === 1569 || z === 1577);
        const isDoor = (x === -35 && z === 1573 && (y === 66 || y === 67));
        if (isDoor) continue;
        if (isCorner || y === 69) {
          pushL(x, y, z, 'minecraft:spruce_log', { against: 'down', look: 'south' });
        } else if ((y === 67 || y === 68) && (z === 1571 || z === 1575 || x === -39)) {
          pushL(x, y, z, 'minecraft:glass_pane', { against: 'down', look: 'south' });
        } else {
          pushL(x, y, z, 'minecraft:stripped_spruce_wood', { against: 'down', look: 'south' });
        }
      }
    }
  }
  // Real player door placement (walking WEST into lodge -> look="west")
  pushL(-35, 66, 1573, 'minecraft:spruce_door', { against: 'down', look: 'west' });
  // Pitched Dark Oak Stair Roof (ring 0: y=70 at x=-44..-34, z=1568..1578; ring 1: y=71; ring 2: y=72; ridge slabs y=73)
  for (let r = 0; r <= 3; r++) {
    const x1 = -43 + r, x2 = -35 - r, z1 = 1569 + r, z2 = 1577 - r, ry = 70 + r;
    for (let z = z1; z <= z2; z++) {
      for (let x = x1; x <= x2; x++) {
        if (r === 3) {
          pushL(x, ry, z, 'minecraft:dark_oak_planks', { look: 'east' });
          pushL(x, ry + 1, z, 'minecraft:dark_oak_slab', { half: 'bottom', look: 'east' });
        } else if (x === x1 || x === x2 || z === z1 || z === z2) {
          // Fill solid support block inside ring first so stairs never fail to click!
          pushL(x, ry, z, 'minecraft:spruce_planks', { look: 'east' });
        }
      }
    }
    if (r < 3) {
      // Eave stairs around outside of ring!
      for (let z = z1; z <= z2; z++) {
        pushL(x1 - 1, ry, z, 'minecraft:dark_oak_stairs', { half: 'bottom', look: 'east' });
        pushL(x2 + 1, ry, z, 'minecraft:dark_oak_stairs', { half: 'bottom', look: 'west' });
      }
      for (let x = x1 - 1; x <= x2 + 1; x++) {
        pushL(x, ry, z1 - 1, 'minecraft:dark_oak_stairs', { half: 'bottom', look: 'south' });
        pushL(x, ry, z2 + 1, 'minecraft:dark_oak_stairs', { half: 'bottom', look: 'north' });
      }
    }
  }
  // Interior furnishings & hanging lanterns
  pushL(-39, 69, 1573, 'minecraft:lantern', { against: 'up', look: 'west' });
  pushL(-41, 66, 1571, 'minecraft:crafting_table', { against: 'down', look: 'west' });
  pushL(-41, 66, 1573, 'minecraft:cartography_table', { against: 'down', look: 'west' });
  pushL(-41, 66, 1575, 'minecraft:lectern', { against: 'down', look: 'east' });
  pushL(-42, 66, 1576, 'minecraft:green_bed', { against: 'down', look: 'west' });
  pushL(-34, 68, 1572, 'minecraft:lantern', { against: 'west', look: 'west' });
  pushL(-34, 68, 1574, 'minecraft:lantern', { against: 'west', look: 'west' });

  await runReal(lodge, '2. Güney Orman Bölge Başkanlığı');

  // 4. Build Cabin 1 (x=-46..-40, z=1587..1593, floor y=64) via /place_real, save as forest_cabin_v4.nbt,
  //    and place Cabin 2 at (-36, 63, 1586) with CLOCKWISE_90 native .nbt rotation!
  const cab = [];
  const pushC = (x, y, z, item, opts = {}) => cab.push({ x, y, z, item, ...opts });
  for (let z = 1587; z <= 1593; z++) {
    for (let x = -46; x <= -40; x++) {
      pushC(x, 63, z, 'minecraft:cobblestone', { replace: true, look: 'east' });
      const edge = (x === -46 || x === -40 || z === 1587 || z === 1593);
      pushC(x, 64, z, edge ? 'minecraft:stone_bricks' : 'minecraft:oak_planks', { replace: true, look: 'east' });
    }
  }
  for (let y = 65; y <= 67; y++) {
    for (let z = 1587; z <= 1593; z++) {
      for (let x = -46; x <= -40; x++) {
        const edge = (x === -46 || x === -40 || z === 1587 || z === 1593);
        if (!edge) continue;
        const corner = (x === -46 || x === -40) && (z === 1587 || z === 1593);
        if (x === -40 && z === 1590 && (y === 65 || y === 66)) continue; // Door
        if (corner || y === 67) {
          pushC(x, y, z, 'minecraft:spruce_log', { against: 'down', look: 'east' });
        } else if (y === 66 && (z === 1589 || z === 1591 || x === -43)) {
          pushC(x, y, z, 'minecraft:glass_pane', { against: 'down', look: 'east' });
        } else {
          pushC(x, y, z, 'minecraft:spruce_planks', { against: 'down', look: 'east' });
        }
      }
    }
  }
  pushC(-40, 65, 1590, 'minecraft:spruce_door', { against: 'down', look: 'west' });
  pushC(-39, 64, 1590, 'minecraft:stone_brick_stairs', { replace: true, half: 'bottom', look: 'west' });
  for (let r = 0; r <= 2; r++) {
    const x1 = -46 + r, x2 = -40 - r, z1 = 1587 + r, z2 = 1593 - r, ry = 68 + r;
    for (let z = z1; z <= z2; z++) {
      for (let x = x1; x <= x2; x++) {
        pushC(x, ry, z, 'minecraft:spruce_planks', { look: 'east' });
      }
    }
    for (let z = z1; z <= z2; z++) {
      pushC(x1 - 1, ry, z, 'minecraft:dark_oak_stairs', { half: 'bottom', look: 'east' });
      pushC(x2 + 1, ry, z, 'minecraft:dark_oak_stairs', { half: 'bottom', look: 'west' });
    }
    for (let x = x1 - 1; x <= x2 + 1; x++) {
      pushC(x, ry, z1 - 1, 'minecraft:dark_oak_stairs', { half: 'bottom', look: 'south' });
      pushC(x, ry, z2 + 1, 'minecraft:dark_oak_stairs', { half: 'bottom', look: 'north' });
    }
  }
  pushC(-43, 67, 1590, 'minecraft:lantern', { against: 'up', look: 'west' });
  pushC(-45, 65, 1588, 'minecraft:red_bed', { against: 'down', look: 'north' });
  pushC(-45, 65, 1592, 'minecraft:crafting_table', { against: 'down', look: 'west' });
  pushC(-44, 65, 1592, 'minecraft:barrel', { against: 'down', look: 'east' });

  await runReal(cab, '1. Güney Orman Kulübesi');

  // Save Cabin 1 as reusable .nbt template (-47.. -39, 63..70, 1586..1594 = 9x8x9)!
  const saveCab = await postAct({
    action: 'save_nbt',
    outFile: '/home/user/arena-mc/schematics/forest_cabin_v4.nbt',
    x1: -47, y1: 63, z1: 1586, x2: -39, y2: 70, z2: 1594
  });
  console.log('[forest_cabin_v4.nbt kaydedildi]:', saveCab);

  // Place Cabin 2 at (-29, 64, 1585) rotated CLOCKWISE_90 (so it faces South toward the z=1596 Lagoon Trail!)
  // Wait: with CLOCKWISE_90 around (x,z), size 9x9 rotates dx->-dz, dz->dx -> x spans -29..-37, z spans 1585..1593!
  const placeCab2 = await postAct({
    action: 'place_nbt',
    file: '/home/user/arena-mc/schematics/forest_cabin_v4.nbt',
    x: -29, y: 64, z: 1585,
    rotation: 'CLOCKWISE_90',
    groundFoundation: true
  });
  console.log('[2. Güney Orman Kulübesi (.nbt CLOCKWISE_90)]:', { ok: placeCab2.ok });

  // 5. Zümrüt Gölü Ahşap İskelesi (x=-76..-68, z=1596..1598, y=63) + Lantern-Lit Trail & Anıt Ağacı Sanctuary!
  const trail = [];
  const pushT = (x, y, z, item, opts = {}) => trail.push({ x, y, z, item, ...opts });

  // Pier pilings down to y=59 in lagoon water so NOTHING floats!
  for (const px of [-76, -72, -68]) {
    for (const pz of [1596, 1598]) {
      for (let y = 58; y <= 62; y++) {
        pushT(px, y, pz, 'minecraft:spruce_log', { replace: true, look: 'west' });
      }
    }
  }
  for (let x = -76; x <= -68; x++) {
    for (let z = 1596; z <= 1598; z++) {
      pushT(x, 63, z, 'minecraft:spruce_slab', { replace: true, half: 'bottom', look: 'west' });
    }
  }
  for (const pz of [1596, 1598]) {
    pushT(-76, 63, pz, 'minecraft:spruce_planks', { replace: true, look: 'west' });
    pushT(-76, 64, pz, 'minecraft:spruce_fence', { against: 'down', look: 'west' });
    pushT(-76, 65, pz, 'minecraft:lantern', { against: 'down', look: 'west' });
  }

  // Plaza & Trail Lamps along the natural tree-free corridor:
  // Plaza (-34..-32, z=1570..1596) + West Lagoon Path (z=1596..1597, x=-67..-33)
  for (let z = 1570; z <= 1597; z += 9) {
    pushT(-33, 64, z, 'minecraft:stone_bricks', { replace: true, look: 'south' });
    pushT(-33, 65, z, 'minecraft:cobblestone_wall', { replace: true, against: 'down', look: 'south' });
    pushT(-33, 66, z, 'minecraft:lantern', { replace: true, against: 'down', look: 'south' });
  }
  for (let x = -66; x <= -38; x += 9) {
    pushT(x, 63, 1595, 'minecraft:stone_bricks', { replace: true, look: 'west' });
    pushT(x, 64, 1595, 'minecraft:cobblestone_wall', { replace: true, against: 'down', look: 'west' });
    pushT(x, 65, 1595, 'minecraft:lantern', { replace: true, against: 'down', look: 'west' });
  }

  // Sanctuary Lantern Posts honoring the natural y=102 Colossus "Güney Zümrüt Anıt Ağacı" at (-56, 1620)
  // (Placed 5 blocks away from the trunk so ZERO tree roots/trunks/leaves are touched!)
  await postAct({ action: 'command', command: 'tp ArenaAI -56 76 1614' });
  await new Promise(r => setTimeout(r, 400));
  for (const [ax, az] of [[-60, 1616], [-52, 1616], [-60, 1624], [-52, 1624]]) {
    pushT(ax, 73, az, 'minecraft:mossy_stone_bricks', { replace: true, look: 'south' });
    pushT(ax, 74, az, 'minecraft:mossy_stone_bricks', { replace: true, look: 'south' });
    pushT(ax, 75, az, 'minecraft:mossy_stone_brick_wall', { replace: true, against: 'down', look: 'south' });
    pushT(ax, 76, az, 'minecraft:lantern', { replace: true, against: 'down', look: 'south' });
  }

  await runReal(trail, 'Zümrüt Gölü İskelesi + Fenerli Yol + Anıt Ağacı Meydanı');
}

main().catch(console.error);

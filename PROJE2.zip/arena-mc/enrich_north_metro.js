const BASE = 'http://127.0.0.1:8080';
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

async function act(body) {
  for (let i = 0; i < 5; i++) {
    const r = await fetch(BASE + '/api/act', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...body, force: true })
    });
    const d = await r.json();
    if (d && d.ok !== false) return d;
    await sleep(300);
  }
  return { ok: false };
}

async function cmd(c) {
  await act({ action: 'command', command: c });
}

async function main() {
  // Check ilkan's exact position first so we NEVER trap him
  const st = await (await fetch(BASE + '/api/state')).json();
  const p = st.clientState?.telemetry?.player;
  console.log('Player at start:', p ? `${p.x.toFixed(1)}, ${p.y.toFixed(1)}, ${p.z.toFixed(1)}` : 'unknown');

  await act({ action: 'stop' });
  await cmd('tp ArenaAI -22 49 30');
  await sleep(200);

  // 1. Carve Underground "Orman Kafe & Büfe" Shop Alcove (x=-33..-28, y=48..54, z=34..43)
  await cmd('fill -33 48 34 -28 54 43 minecraft:polished_deepslate');
  await cmd('fill -32 49 35 -28 53 42 minecraft:air');
  await cmd('fill -32 48 35 -28 48 42 minecraft:polished_andesite');
  await cmd('fill -32 54 35 -28 54 42 minecraft:spruce_planks');

  // 2. Carve Recessed Emerald Mosaic & Indoor Botanical Planter Niche (x=-30..-28, y=48..54, z=20..26)
  await cmd('fill -30 48 20 -28 54 26 minecraft:polished_deepslate');
  await cmd('fill -29 49 21 -28 53 25 minecraft:air');
  await cmd('fill -30 49 21 -30 53 25 mtr:mosaic_tile');
  await cmd('fill -29 49 21 -29 49 25 minecraft:moss_block');

  const ops = [];

  // Botanical Planter greenery & frame (x=-29, z=21..25)
  ops.push({ x: -29, y: 50, z: 21, block: 'minecraft:flowering_azalea' });
  ops.push({ x: -29, y: 50, z: 22, block: 'minecraft:azalea' });
  ops.push({ x: -29, y: 50, z: 23, block: 'minecraft:flowering_azalea' });
  ops.push({ x: -29, y: 51, z: 23, block: 'minecraft:azalea_leaves[distance=1,persistent=true]' });
  ops.push({ x: -29, y: 50, z: 24, block: 'minecraft:azalea' });
  ops.push({ x: -29, y: 50, z: 25, block: 'minecraft:flowering_azalea' });
  ops.push({ x: -29, y: 53, z: 22, block: 'arena_ai_bridge:tunnel_emergency_light[ceiling=true,emergency=false,facing=east]' });
  ops.push({ x: -29, y: 53, z: 24, block: 'arena_ai_bridge:tunnel_emergency_light[ceiling=true,emergency=false,facing=east]' });
  for (let z = 21; z <= 25; z++) {
    ops.push({ x: -28, y: 49, z, block: 'minecraft:polished_deepslate_slab[type=bottom]' });
  }

  // Orman Kafe & Büfe interior details (x=-32..-29, z=35..42)
  for (let y = 49; y <= 53; y++) {
    ops.push({ x: -32, y, z: 35, block: 'minecraft:stripped_spruce_log[axis=y]' });
    ops.push({ x: -32, y, z: 42, block: 'minecraft:stripped_spruce_log[axis=y]' });
    ops.push({ x: -29, y, z: 35, block: y === 53 ? 'minecraft:spruce_planks' : (y === 49 ? 'minecraft:stripped_spruce_log[axis=y]' : 'minecraft:air') });
    ops.push({ x: -29, y, z: 42, block: 'minecraft:stripped_spruce_log[axis=y]' });
  }
  // Cafe header beam + red/emerald signboard trim
  for (let z = 35; z <= 42; z++) {
    ops.push({ x: -29, y: 53, z, block: 'minecraft:stripped_spruce_log[axis=z]' });
    ops.push({ x: -28, y: 53, z, block: 'minecraft:spruce_slab[type=top]' });
  }
  // Back shelves & barrels (x=-32, z=36..41)
  for (let z = 36; z <= 41; z++) {
    ops.push({ x: -32, y: 49, z, block: 'minecraft:spruce_planks' });
    ops.push({ x: -32, y: 50, z, block: (z % 2 === 0) ? 'minecraft:barrel[facing=east,open=false]' : 'minecraft:bookshelf' });
    ops.push({ x: -32, y: 52, z, block: 'minecraft:spruce_slab[type=top]' });
  }
  // Quartz & Spruce Cafe Bar Counter (x=-29, z=36..40; walk pass-through at z=41)
  for (let z = 36; z <= 40; z++) {
    ops.push({ x: -29, y: 49, z, block: 'minecraft:smooth_quartz_stairs[facing=west,half=top,shape=straight,waterlogged=false]' });
  }
  ops.push({ x: -29, y: 50, z: 36, block: 'minecraft:brewing_stand' });
  ops.push({ x: -29, y: 50, z: 38, block: 'minecraft:cake[bites=0]' });
  ops.push({ x: -29, y: 50, z: 40, block: 'minecraft:potted_flowering_azalea' });
  ops.push({ x: -30, y: 53, z: 37, block: 'minecraft:lantern[hanging=true]' });
  ops.push({ x: -30, y: 53, z: 40, block: 'minecraft:lantern[hanging=true]' });
  // Cafe barstools (x=-27, z=37, 39)
  ops.push({ x: -27, y: 49, z: 37, block: 'minecraft:dark_oak_stairs[facing=west,half=bottom,shape=straight,waterlogged=false]' });
  ops.push({ x: -27, y: 49, z: 39, block: 'minecraft:dark_oak_stairs[facing=west,half=bottom,shape=straight,waterlogged=false]' });

  // 3. Sculpted Diagonal Ribbon Staircase Soffit (Flight 2: z=33..26, x=-24..-22) + Side Glass Guardrail
  for (let i = 0; i < 8; i++) {
    const sz = 33 - i, sy = 56 - i;
    for (let x = -24; x <= -22; x++) {
      // Smooth upside-down stair soffit underneath instead of boxy blocks!
      if (sy - 1 >= 49) {
        ops.push({ x, y: sy - 1, z: sz, block: 'minecraft:smooth_quartz_stairs[facing=north,half=top,shape=straight,waterlogged=false]' });
      }
    }
    // Sleek tinted-glass handrail along west edge of stairs (x=-25)
    if (sy + 1 <= 55) {
      ops.push({ x: -25, y: sy, z: sz, block: 'minecraft:tinted_glass' });
      ops.push({ x: -25, y: sy + 1, z: sz, block: 'minecraft:tinted_glass' });
    }
  }

  // 4. Coffered Vault Ceiling Ribs + East Track-Side Pilasters (x=-15)
  for (const rz of [22, 27, 32, 37, 42]) {
    for (let y = 49; y <= 54; y++) {
      if (y !== 51) ops.push({ x: -15, y, z: rz, block: 'minecraft:polished_deepslate' });
    }
    for (let x = -27; x <= -16; x++) {
      // Don't block the stair shaft (x=-24..-22, z=25..33)
      if (x >= -25 && x <= -22 && rz >= 25 && rz <= 33) continue;
      if (x === -21 || x === -18) continue; // Keep LED lines crisp
      ops.push({ x, y: 54, z: rz, block: 'minecraft:polished_deepslate_slab[type=top]' });
    }
  }

  // 5. Modern Platform Waiting Benches (x=-26, z=22..24 and x=-23, z=39..41)
  for (let z = 22; z <= 24; z++) {
    ops.push({ x: -26, y: 49, z, block: 'minecraft:polished_deepslate_stairs[facing=west,half=bottom,shape=straight,waterlogged=false]' });
  }
  ops.push({ x: -26, y: 49, z: 21, block: 'minecraft:potted_bamboo' });
  for (let z = 39; z <= 40; z++) {
    ops.push({ x: -23, y: 49, z, block: 'minecraft:polished_deepslate_stairs[facing=west,half=bottom,shape=straight,waterlogged=false]' });
  }

  // Mezzanine warm planter & seating accents (y=57)
  ops.push({ x: -22, y: 57, z: 38, block: 'minecraft:potted_flowering_azalea' });
  ops.push({ x: -22, y: 57, z: 22, block: 'minecraft:potted_flowering_azalea' });
  ops.push({ x: -23, y: 57, z: 22, block: 'minecraft:polished_deepslate_stairs[facing=north,half=bottom,shape=straight,waterlogged=false]' });
  ops.push({ x: -24, y: 57, z: 22, block: 'minecraft:polished_deepslate_stairs[facing=north,half=bottom,shape=straight,waterlogged=false]' });

  await act({ action: 'build', ops, recordUndo: false, strictPhysics: false, cleanFloating: false });

  // 6. Real MTR Station Furniture via place_real (Clocks, Route Map, Station Name Signs, Trash Bins, Tactile Map, Logo!)
  await cmd('tp ArenaAI -22 49 32');
  await sleep(200);
  await act({
    action: 'place_real',
    recordUndo: false,
    steps: [
      // Hanging Central Railway Clock on Platform
      { x: -21, y: 54, z: 32, item: 'mtr:clock_pole', against: 'up', look: 'east', replace: true },
      { x: -21, y: 53, z: 32, item: 'mtr:clock', against: 'up', look: 'east', replace: true },
      // Stainless Steel Metro Rubbish Bins
      { x: -26, y: 49, z: 25, item: 'mtr:rubbish_bin_1', against: 'down', look: 'west', replace: true },
      { x: -27, y: 49, z: 34, item: 'mtr:rubbish_bin_1', against: 'down', look: 'west', replace: true },
      // Tactile Station Directory Map & Illuminated MTR Route Sign on West Wall (x=-27, z=28..31)
      { x: -27, y: 49, z: 28, item: 'mtr:tactile_map', against: 'down', look: 'west', replace: true },
      { x: -27, y: 50, z: 30, item: 'mtr:route_sign_wall_light', against: 'west', look: 'west', replace: true },
      // Trackside "Kuzey Orman" MTR Station Name Wall Signs facing passengers across the rail (x=-16 against east wall x=-15)!
      { x: -16, y: 51, z: 24, item: 'mtr:station_name_wall_black', against: 'east', look: 'east', replace: true },
      { x: -16, y: 51, z: 29, item: 'mtr:station_name_wall_black', against: 'east', look: 'east', replace: true },
      { x: -16, y: 51, z: 35, item: 'mtr:station_name_wall_black', against: 'east', look: 'east', replace: true },
      { x: -16, y: 51, z: 40, item: 'mtr:station_name_wall_black', against: 'east', look: 'east', replace: true },
      // Mezzanine Ticket Hall extras: 2nd Ticket Machine, Orman Kart Balance Enquiry Processor & Rubbish Bin
      { x: -28, y: 57, z: 37, item: 'mtr:ticket_machine', against: 'down', look: 'west', replace: true },
      { x: -28, y: 58, z: 33, item: 'mtr:ticket_processor_enquiry', against: 'west', look: 'west', replace: true },
      { x: -28, y: 57, z: 31, item: 'mtr:rubbish_bin_1', against: 'down', look: 'west', replace: true },
      // Surface [M1] Pavilion MTR Glowing Logo Medallion
      { x: -27, y: 67, z: 19, item: 'mtr:logo', against: 'south', look: 'south', replace: true }
    ]
  });

  // Put ArenaAI back into friendly follow mode next to ilkan!
  await act({ action: 'follow', target: 'ilkan', distance: 3 });
  console.log('ENRICH_NORTH_METRO_DONE');
}

main().catch(e => { console.error(e); process.exit(1); });

const fs = require('fs');

async function buildLivingForestWorld() {
  const act = (body) =>
    fetch('http://127.0.0.1:8080/api/act', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    }).then((r) => r.json());

  await act({
    action: 'chat',
    text: 'Hemen kuledeki havada duran feneri sabitleyip tum ormanin icine Ulu Anit Agaci, 3 ozel efsanevi agac, 3 hikayeli orman kulubesi/serasi, birbirine bagli patika yol agi ve icinde okunabilir hikaye kitaplari kuruyorum kanka!'
  });

  // 1. High-resolution 1x1 scan across the entire Forest Reserve interior (x=-134..-34, z=-92..+20)
  const tiles = [
    [-58, -64, 28], [-108, -64, 28],
    [-58, -28, 28], [-108, -28, 28],
    [-58, 4, 24],   [-108, 4, 24]
  ];
  const scans = await Promise.all(
    tiles.map(([cx, cz, r]) =>
      fetch(`http://127.0.0.1:8080/api/scan?x=${cx}&z=${cz}&r=${r}&step=1`).then((res) => res.json())
    )
  );

  const map = new Map();
  for (const s of scans) {
    for (const row of s.grid || []) {
      for (const c of row) map.set(`${c.x},${c.z}`, c);
    }
  }
  const cell = (x, z) => map.get(`${x},${z}`) || { x, y: 65, z, b: 'grass_block' };
  const isWater = (x, z) => cell(x, z).b.includes('water');
  const isTrunk = (x, z) => cell(x, z).b.includes('log');

  const ops = [];
  const set = (x, y, z, block, onlyAir = false) => {
    ops.push({ op: 'set', x, y, z, block, onlyAir });
  };

  // ==================== 1. FIX FLOATING TOWER & BASTION LANTERNS/CEILINGS ====================
  // Check both (-45, -30) and (-46, -30) Fire-Watch Tower roof centers & hang lantern on a real chain from solid ceiling!
  for (const tx of [-46, -45]) {
    const twBase = cell(tx, -30).y;
    // Scan vertical column via safe solid beam at roof peak:
    // Earlier twBase = cell(-46,-30).y + 1, topY = twBase + 11, roof planks at topY+4 (edge=2), slab at topY+5 (edge<=1), lantern at topY+3
    // Find exact dark_oak_slab roof peak by filling solid dark_oak_planks directly under topY+5!
  }
  // Even better: we know exact formula used earlier for (-46, -30):
  // Let's also remove any dropped floating lanterns and attach solid ceiling planks + chain!
  // Let's inspect (-46, -30) via nearby non-modified cell (-49, -30) ground height:
  const towerGround = cell(-49, -30).y;
  for (let baseGuess = towerGround; baseGuess <= towerGround + 3; baseGuess++) {
    // Only fill where tower roof actually is: let's place a clean central support post/chain inside (-46, -30) from deck+4!
  }
  // Better yet: scan (-46, -30) exact topY right from `map`: `cell(-46, -30).y` IS THE ROOF PEAK `topY + 5`!!
  // AHA!! `MOTION_BLOCKING_NO_LEAVES` returns the HIGHEST SOLID BLOCK at (-46, -30), which IS the tower's own roof slab `topY + 5`!!
  const roofPeak46 = cell(-46, -30).y;
  if (roofPeak46 >= 75) {
    // roofPeak46 is topY + 5! So topY + 4 is roofPeak46 - 1, and lantern is at roofPeak46 - 2!
    for (let dx = -1; dx <= 1; dx++) {
      for (let dz = -1; dz <= 1; dz++) {
        set(-46 + dx, roofPeak46 - 1, -30 + dz, 'minecraft:dark_oak_planks');
      }
    }
    set(-46, roofPeak46 - 2, -30, 'minecraft:chain[axis=y]');
    set(-46, roofPeak46 - 3, -30, 'minecraft:lantern[hanging=true]');
  }
  const roofPeak45 = cell(-45, -30).y;
  if (roofPeak45 >= 75 && roofPeak45 !== roofPeak46) {
    set(-45, roofPeak45 - 1, -30, 'minecraft:dark_oak_planks');
    set(-45, roofPeak45 - 2, -30, 'minecraft:chain[axis=y]');
    set(-45, roofPeak45 - 3, -30, 'minecraft:lantern[hanging=true]');
  }

  // ==================== 2. INTERCONNECTED FOREST ROAD NETWORK (WITH WOODEN FOOTBRIDGES OVER WATER!) ====================
  const roadMats = ['minecraft:coarse_dirt', 'minecraft:podzol', 'minecraft:mossy_cobblestone', 'minecraft:stone_bricks', 'minecraft:gravel'];

  function buildNaturalRoad(x1, z1, x2, z2, wobble = 2.0) {
    const steps = Math.max(1, Math.round(Math.hypot(x2 - x1, z2 - z1)));
    let lastLampStep = -10;
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      const perpX = -(z2 - z1) / steps;
      const perpZ = (x2 - x1) / steps;
      const curve = Math.sin(t * Math.PI * 2) * wobble;
      const cx = Math.round(x1 + (x2 - x1) * t + perpX * curve);
      const cz = Math.round(z1 + (z2 - z1) * t + perpZ * curve);

      for (let dx = -1; dx <= 1; dx++) {
        for (let dz = -1; dz <= 1; dz++) {
          if (Math.abs(dx) + Math.abs(dz) > 1) continue;
          const rx = cx + dx, rz = cz + dz;
          const c = cell(rx, rz);
          if (c.b.includes('log') || c.y > 74) continue; // Don't cut trunks or climb roofs!
          if (c.b.includes('water')) {
            // Wooden footbridge flush above water!
            set(rx, c.y + 1, rz, 'minecraft:spruce_slab[type=bottom]');
          } else {
            set(rx, c.y, rz, roadMats[Math.abs(rx * 5 + rz * 3) % roadMats.length]);
            // Clear tall grass/ferns on road
            set(rx, c.y + 1, rz, 'minecraft:air');
          }
        }
      }

      // Solid Grounded Lamp Post every 14 blocks along the road (NEVER floating!)
      if (i - lastLampStep >= 14 && i > 3 && i < steps - 3) {
        const lx = cx + 2, lz = cz + 2;
        const lc = cell(lx, lz);
        if (!lc.b.includes('water') && !lc.b.includes('log') && lc.y <= 72) {
          lastLampStep = i;
          set(lx, lc.y, lz, 'minecraft:mossy_stone_bricks');
          set(lx, lc.y + 1, lz, 'minecraft:cobblestone_wall');
          set(lx, lc.y + 2, lz, 'minecraft:spruce_fence');
          set(lx, lc.y + 3, lz, 'minecraft:lantern'); // Non-hanging lantern sits solidly ON TOP of spruce_fence!
        }
      }
    }
  }

  // Hub Plaza at Monument Tree: (-84, -36)
  buildNaturalRoad(-35, -27, -84, -36, 2.5);   // East Main Gate -> Ulu Anit Agaci Meydani
  buildNaturalRoad(-84, -36, -133, -27, 2.5);  // Ulu Anit Agaci -> West Gate
  buildNaturalRoad(-84, -36, -110, -46, 1.5);  // Ulu Anit Agaci -> Botanikci Elif'in Serasi
  buildNaturalRoad(-84, -36, -72, -12, 2.0);   // Ulu Anit Agaci -> Basbekci Igor'un Kulubesi
  buildNaturalRoad(-72, -12, -94, 6, 2.0);     // Igor'un Kulubesi -> Somon Koyu Balikci Barinagi & Ikiz Sogut
  buildNaturalRoad(-84, -36, -70, -68, 2.5);   // Ulu Anit Agaci -> Altin Recine Cami (Kuzey Korusu)
  buildNaturalRoad(-84, -36, -106, -12, 2.0);  // Ulu Anit Agaci -> Kizil Safak Agaci

  // ==================== 3. COLOSSAL MONUMENT TREE: "ULU KAYIN - ASIRLIK KUZEY MUHAFIZI" (-84, -36) ====================
  const mtX = -84, mtZ = -36;
  // Find natural ground around (-84, -36) ignoring any high tree
  let mtGround = 66;
  const nearYs = [];
  for (let dx = -5; dx <= 5; dx++) {
    for (let dz = -5; dz <= 5; dz++) {
      const c = cell(mtX + dx, mtZ + dz);
      if (!c.b.includes('log') && !c.b.includes('water') && c.y <= 73) nearYs.push(c.y);
    }
  }
  if (nearYs.length > 0) {
    nearYs.sort((a, b) => a - b);
    mtGround = nearYs[Math.floor(nearYs.length / 2)];
  }

  // Stone Sanctuary Ring & Mossy Plaza around Monument Tree (radius 7)
  for (let dx = -7; dx <= 7; dx++) {
    for (let dz = -7; dz <= 7; dz++) {
      const d = Math.hypot(dx, dz);
      if (d > 7.3) continue;
      const g = Math.min(mtGround, cell(mtX + dx, mtZ + dz).y);
      for (let y = g; y <= mtGround; y++) {
        if (d >= 5.8) {
          set(mtX + dx, y, mtZ + dz, (dx + dz) % 2 === 0 ? 'minecraft:mossy_stone_bricks' : 'minecraft:chiseled_stone_bricks');
        } else {
          set(mtX + dx, y, mtZ + dz, (Math.abs(dx * 3 + dz)) % 3 === 0 ? 'minecraft:moss_block' : 'minecraft:podzol');
        }
      }
      // Clear low clutter in plaza
      if (d >= 3.2) {
        for (let y = mtGround + 1; y <= mtGround + 5; y++) set(mtX + dx, y, mtZ + dz, 'minecraft:air');
      }
    }
  }

  // 4 Stone Shrine Pillars at N/S/E/W of Sanctuary Ring (grounded!)
  for (const [sx, sz] of [[0, -7], [0, 7], [7, 0], [-7, 0]]) {
    set(mtX + sx, mtGround + 1, mtZ + sz, 'minecraft:chiseled_stone_bricks');
    set(mtX + sx, mtGround + 2, mtZ + sz, 'minecraft:mossy_stone_brick_wall');
    set(mtX + sx, mtGround + 3, mtZ + sz, 'minecraft:lantern');
  }

  // Gnarled Ancient Roots (y = mtGround+1 .. +3)
  const rootDirs = [[3, 0], [-3, 0], [0, 3], [0, -3], [2, 2], [-2, 2], [2, -2], [-2, -2]];
  for (const [rx, rz] of rootDirs) {
    set(mtX + rx, mtGround + 1, mtZ + rz, 'minecraft:dark_oak_wood');
    if (Math.abs(rx) + Math.abs(rz) === 3) {
      set(mtX + Math.sign(rx) * 4, mtGround + 1, mtZ + Math.sign(rz) * 4, 'minecraft:mossy_cobblestone');
    }
  }

  // Massive 3x3 -> 2x2 Twisting Ancient Trunk rising 20 blocks high!
  for (let dy = 0; dy <= 19; dy++) {
    const r = dy < 4 ? 2 : (dy < 12 ? 1 : 0);
    for (let dx = -r; dx <= r; dx++) {
      for (let dz = -r; dz <= r; dz++) {
        if (r === 2 && Math.abs(dx) === 2 && Math.abs(dz) === 2) continue;
        if (r === 1 && Math.abs(dx) === 1 && Math.abs(dz) === 1 && dy > 7) continue;
        set(mtX + dx, mtGround + 1 + dy, mtZ + dz, 'minecraft:dark_oak_wood');
      }
    }
  }

  // Sweeping Great Boughs & Luminous Ancient Canopy (flowering_azalea_leaves + dark_oak_leaves + shroomlight spirit fruits!)
  const boughs = [
    [0, 20, 0, 6],
    [5, 16, 2, 4], [-5, 16, -2, 4], [2, 17, 5, 4], [-2, 17, -5, 4],
    [4, 14, -4, 3], [-4, 14, 4, 3], [0, 22, 0, 4]
  ];
  for (const [bx, by, bz, br] of boughs) {
    // Solid branch from trunk to bough center!
    const steps = Math.max(1, Math.abs(bx), Math.abs(bz));
    for (let s = 0; s <= steps; s++) {
      const lx = Math.round((bx * s) / steps);
      const ly = Math.round(13 + ((by - 13) * s) / steps);
      const lz = Math.round((bz * s) / steps);
      set(mtX + lx, mtGround + ly, mtZ + lz, 'minecraft:dark_oak_wood');
    }
    // Leaf cloud around bough
    for (let dx = -br; dx <= br; dx++) {
      for (let dy = -2; dy <= 2; dy++) {
        for (let dz = -br; dz <= br; dz++) {
          const dist = Math.sqrt(dx * dx + dy * dy * 1.8 + dz * dz);
          if (dist <= br + 0.3) {
            const leaf = (Math.abs(dx * 7 + dy * 3 + dz * 11) % 4 === 0)
              ? 'minecraft:flowering_azalea_leaves[persistent=true]'
              : 'minecraft:azalea_leaves[persistent=true]';
            set(mtX + bx + dx, mtGround + by + dy, mtZ + bz + dz, leaf, true);
          }
        }
      }
    }
    // Glowing Spirit-Heart Fruit tucked directly under solid branch!
    set(mtX + bx, mtGround + by - 1, mtZ + bz, 'minecraft:shroomlight');
  }

  // ==================== 4. THREE SPECIAL NAMED TREES ACROSS THE FOREST ====================
  function buildSpecialTree(cx, cz, style) {
    let g = cell(cx, cz).y;
    if (g > 72 || isTrunk(cx, cz)) g = 66;
    for (let dx = -3; dx <= 3; dx++) {
      for (let dz = -3; dz <= 3; dz++) {
        if (Math.hypot(dx, dz) <= 3.2 && !isWater(cx + dx, cz + dz)) {
          const gy0 = Math.min(g, cell(cx + dx, cz + dz).y);
          for (let y = gy0; y <= g; y++) {
            set(cx + dx, y, cz + dz, style === 'cherry' ? 'minecraft:moss_block' : 'minecraft:podzol');
          }
        }
      }
    }
    // Stone marker pedestal on East side (cx+3, cz)
    set(cx + 3, g + 1, cz, 'minecraft:mossy_stone_bricks');
    set(cx + 3, g + 2, cz, 'minecraft:lantern');

    const wood = style === 'cherry' ? 'minecraft:cherry_wood' : (style === 'amber' ? 'minecraft:spruce_wood' : 'minecraft:oak_wood');
    const leafA = style === 'cherry' ? 'minecraft:cherry_leaves[persistent=true]' : (style === 'amber' ? 'minecraft:spruce_leaves[persistent=true]' : 'minecraft:azalea_leaves[persistent=true]');
    const leafB = style === 'cherry' ? 'minecraft:flowering_azalea_leaves[persistent=true]' : (style === 'amber' ? 'minecraft:oak_leaves[persistent=true]' : 'minecraft:flowering_azalea_leaves[persistent=true]');

    for (let y = 1; y <= 11; y++) {
      set(cx, g + y, cz, wood);
      if (y <= 3) {
        set(cx + 1, g + y, cz, wood);
        set(cx, g + y, cz + 1, wood);
      }
    }
    for (let dx = -4; dx <= 4; dx++) {
      for (let dy = 7; dy <= 13; dy++) {
        for (let dz = -4; dz <= 4; dz++) {
          const d = Math.sqrt(dx * dx + (dy - 10) * (dy - 10) * 1.5 + dz * dz);
          if (d <= 4.1) {
            set(cx + dx, g + dy, cz + dz, (dx + dy + dz) % 3 === 0 ? leafB : leafA, true);
          }
        }
      }
    }
    set(cx, g + 8, cz + 1, 'minecraft:shroomlight');
    if (style === 'willow') {
      // Hanging willow leaf curtains!
      for (const [wx, wz] of [[3, 2], [-3, 2], [2, -3], [-2, -3], [4, 0], [-4, 0]]) {
        for (let y = 4; y <= 8; y++) set(cx + wx, g + y, cz + wz, leafA, true);
      }
    }
    return g;
  }

  const gCherry = buildSpecialTree(-106, -12, 'cherry');  // Kizil Safak Agaci
  const gAmber  = buildSpecialTree(-70, -68, 'amber');    // Altin Recine Cami
  const gWillow = buildSpecialTree(-96, 6, 'willow');     // Ikiz Gozyasi Sogudu

  // ==================== 5. THREE STORYBOOK FOREST CABINS & OUTPOSTS (ZERO FLOATING BLOCKS!) ====================
  function buildForestCabin(cx, cz, theme) {
    // Flatten & build solid stone foundation up from real terrain
    const samples = [];
    for (let dx = -3; dx <= 3; dx++) {
      for (let dz = -3; dz <= 3; dz++) {
        const c = cell(cx + dx, cz + dz);
        if (!c.b.includes('log') && c.y <= 73) samples.push(c.y);
      }
    }
    samples.sort((a, b) => a - b);
    const floorY = (samples[Math.floor(samples.length / 2)] || 65) + 1;

    // 7x7 Footprint (dx = -3..3, dz = -3..3)
    for (let dx = -3; dx <= 3; dx++) {
      for (let dz = -3; dz <= 3; dz++) {
        const g = Math.min(floorY - 1, cell(cx + dx, cz + dz).y);
        for (let y = Math.min(g, 61); y <= floorY; y++) {
          const isRim = Math.abs(dx) === 3 || Math.abs(dz) === 3;
          set(cx + dx, y, cz + dz, y < floorY ? 'minecraft:cobblestone' : (isRim ? 'minecraft:mossy_stone_bricks' : 'minecraft:spruce_planks'));
        }
        // Clear interior & roof headroom
        for (let y = floorY + 1; y <= floorY + 8; y++) {
          set(cx + dx, y, cz + dz, 'minecraft:air');
        }
      }
    }

    const wallMat = theme === 'greenhouse' ? 'minecraft:glass' : 'minecraft:stripped_spruce_log[axis=x]';
    const wallMatZ = theme === 'greenhouse' ? 'minecraft:glass' : 'minecraft:stripped_spruce_log[axis=z]';

    // Corner spruce log pillars (y = floorY+1 .. +3)
    for (let y = floorY + 1; y <= floorY + 3; y++) {
      for (const [px, pz] of [[-3, -3], [3, -3], [-3, 3], [3, 3]]) {
        set(cx + px, y, cz + pz, 'minecraft:spruce_log[axis=y]');
      }
    }

    // Walls (y = floorY+1 .. +3), Door on East side (dx = +3, dz = 0)
    for (let d = -2; d <= 2; d++) {
      for (let y = floorY + 1; y <= floorY + 3; y++) {
        // North & South walls
        const isWinNS = y === floorY + 2 && Math.abs(d) <= 1;
        set(cx + d, y, cz - 3, isWinNS ? 'minecraft:glass_pane[east=true,west=true]' : wallMat);
        set(cx + d, y, cz + 3, isWinNS ? 'minecraft:glass_pane[east=true,west=true]' : wallMat);
        // West wall
        const isWinW = y === floorY + 2 && Math.abs(d) <= 1;
        set(cx - 3, y, cz + d, isWinW ? 'minecraft:glass_pane[north=true,south=true]' : wallMatZ);
        // East wall (skip doorway at d===0, y<=floorY+2)
        if (d === 0 && y <= floorY + 2) continue;
        const isWinE = y === floorY + 2 && Math.abs(d) === 2;
        set(cx + 3, y, cz + d, isWinE ? 'minecraft:glass_pane[north=true,south=true]' : wallMatZ);
      }
    }

    // Door & Entry Steps on East (cx+3, cz)
    set(cx + 3, floorY + 1, cz, 'minecraft:spruce_door[facing=west,half=lower,hinge=left,open=false]');
    set(cx + 3, floorY + 2, cz, 'minecraft:spruce_door[facing=west,half=upper,hinge=left,open=false]');
    for (let y = Math.min(cell(cx + 4, cz).y, floorY - 1); y < floorY; y++) {
      set(cx + 4, y, cz, 'minecraft:mossy_stone_bricks');
    }
    set(cx + 4, floorY, cz, 'minecraft:stone_brick_stairs[facing=west,half=bottom]');

    // Solid Gable Roof (running N-S along dz = -4..4) - EVERY block supported, ZERO floating lanterns!
    const roofStair = theme === 'greenhouse' ? 'minecraft:oak_stairs' : 'minecraft:dark_oak_stairs';
    for (let dz = -4; dz <= 4; dz++) {
      set(cx - 4, floorY + 3, dz + cz, `${roofStair}[facing=east,half=bottom]`);
      set(cx + 4, floorY + 3, dz + cz, `${roofStair}[facing=west,half=bottom]`);
      set(cx - 3, floorY + 4, dz + cz, `${roofStair}[facing=east,half=bottom]`);
      set(cx + 3, floorY + 4, dz + cz, `${roofStair}[facing=west,half=bottom]`);
      set(cx - 2, floorY + 5, dz + cz, theme === 'greenhouse' ? 'minecraft:tinted_glass' : `${roofStair}[facing=east,half=bottom]`);
      set(cx + 2, floorY + 5, dz + cz, theme === 'greenhouse' ? 'minecraft:tinted_glass' : `${roofStair}[facing=west,half=bottom]`);
      set(cx - 1, floorY + 6, dz + cz, theme === 'greenhouse' ? 'minecraft:glass' : `${roofStair}[facing=east,half=bottom]`);
      set(cx + 1, floorY + 6, dz + cz, theme === 'greenhouse' ? 'minecraft:glass' : `${roofStair}[facing=west,half=bottom]`);
      // Solid ridge beam at floorY+6 + cap slab at floorY+7 so interior ceiling lantern hangs on a REAL solid block!
      set(cx, floorY + 6, dz + cz, 'minecraft:spruce_planks');
      set(cx, floorY + 7, dz + cz, 'minecraft:dark_oak_slab[type=bottom]');
    }
    // Gable end triangles
    for (const gz of [-3, 3]) {
      for (let dx = -2; dx <= 2; dx++) set(cx + dx, floorY + 4, cz + gz, 'minecraft:spruce_planks');
      for (let dx = -1; dx <= 1; dx++) set(cx + dx, floorY + 5, cz + gz, 'minecraft:spruce_planks');
    }
    // Interior Ceiling Lantern hung on a solid chain attached to (cx, floorY+6, cz)!
    set(cx, floorY + 5, cz, 'minecraft:chain[axis=y]');
    set(cx, floorY + 4, cz, 'minecraft:lantern[hanging=true]');

    // Thematic Interior Furnishings!
    if (theme === 'igor') {
      // Basbekci Igor'un Kulubesi: Stone Hearth, Red Bed, Armor/Tools Barrel, Table
      set(cx - 2, floorY + 1, cz - 2, 'minecraft:red_bed[facing=west,part=head]');
      set(cx - 1, floorY + 1, cz - 2, 'minecraft:red_bed[facing=west,part=foot]');
      set(cx - 2, floorY + 1, cz + 2, 'minecraft:smoker[facing=east]');
      set(cx - 1, floorY + 1, cz + 2, 'minecraft:crafting_table');
      set(cx + 2, floorY + 1, cz - 2, 'minecraft:barrel[facing=south]');
      set(cx + 1, floorY + 1, cz + 2, 'minecraft:bookshelf');
      // Brick chimney on South wall
      for (let y = floorY; y <= floorY + 7; y++) set(cx - 2, y, cz + 4, 'minecraft:bricks');
      set(cx - 2, floorY + 8, cz + 4, 'minecraft:campfire[lit=true]');
    } else if (theme === 'greenhouse') {
      // Botanikci Elif'in Serasi: Lush Plant Beds, Brewing Stand, Composter, Beehives
      set(cx - 2, floorY + 1, cz - 2, 'minecraft:moss_block');
      set(cx - 2, floorY + 2, cz - 2, 'minecraft:flowering_azalea');
      set(cx - 2, floorY + 1, cz - 1, 'minecraft:moss_block');
      set(cx - 2, floorY + 2, cz - 1, 'minecraft:azalea');
      set(cx - 2, floorY + 1, cz + 1, 'minecraft:podzol');
      set(cx - 2, floorY + 2, cz + 1, 'minecraft:fern');
      set(cx - 2, floorY + 1, cz + 2, 'minecraft:composter[level=8]');
      set(cx + 1, floorY + 1, cz - 2, 'minecraft:spruce_planks');
      set(cx + 1, floorY + 2, cz - 2, 'minecraft:brewing_stand');
      set(cx + 2, floorY + 1, cz + 2, 'minecraft:barrel[facing=north]');
    } else if (theme === 'fisherman') {
      // Somon Koyu Balikci Barinagi: Barrels, Blue Bed, Smoker, Drying Campfire outside
      set(cx - 2, floorY + 1, cz - 2, 'minecraft:cyan_bed[facing=west,part=head]');
      set(cx - 1, floorY + 1, cz - 2, 'minecraft:cyan_bed[facing=west,part=foot]');
      set(cx - 2, floorY + 1, cz + 2, 'minecraft:barrel[facing=east]');
      set(cx - 2, floorY + 2, cz + 2, 'minecraft:barrel[facing=east]');
      set(cx + 1, floorY + 1, cz + 2, 'minecraft:smoker[facing=north]');
      set(cx + 2, floorY + 1, cz - 2, 'minecraft:chest[facing=south]');
    }

    // Exterior grounded lamp post right beside front steps (cx+4, cz-2)
    const extG = Math.min(floorY - 1, cell(cx + 4, cz - 2).y);
    for (let y = extG; y <= floorY; y++) set(cx + 4, y, cz - 2, 'minecraft:mossy_stone_bricks');
    set(cx + 4, floorY + 1, cz - 2, 'minecraft:spruce_fence');
    set(cx + 4, floorY + 2, cz - 2, 'minecraft:lantern');

    return floorY;
  }

  const yIgor   = buildForestCabin(-72, -12, 'igor');
  const yElif   = buildForestCabin(-110, -46, 'greenhouse');
  const yFisher = buildForestCabin(-88, 6, 'fisherman');

  console.log('Total Living Forest World ops:', ops.length);
  const res = await act({ action: 'build', ops, instant: true });
  console.log('INSTANT LIVING FOREST RESULT:', res);

  // ==================== 6. NAMED SIGNS + INTERACTIVE MULTI-PAGE LORE BOOKS ON LECTERNS! ====================
  const cmds = [
    // 1) Monument Tree Glowing Sign + Lore Book Lectern!
    `setblock ${mtX + 6} ${mtGround + 1} ${mtZ - 1} minecraft:spruce_sign[rotation=12]{front_text:{messages:['{"text":"🌳 ANIT AGAC 🌳","bold":true,"color":"gold"}','{"text":"ULU KUZEY MUHAFIZI","bold":true,"color":"white"}','{"text":"Tahmini Yas: 2438","color":"green"}','{"text":"Koruma No: #001","color":"gray"}']},is_waxed:1b}`,
    `setblock ${mtX + 6} ${mtGround + 1} ${mtZ + 1} minecraft:lectern[facing=east,has_book=true]{Book:{id:"minecraft:written_book",Count:1b,tag:{title:"Ulu Kuzey Agacinin Efsanesi",author:"1. Ormanlik Baskanligi",pages:['{"text":"[ULU KUZEY MUHAFIZI]\\n\\nM.O. 412 yilinda filizlendigi tahmin edilen bu devasa agac, Kuzey Avrasya Ormanlarinin kalbidir.\\n\\nKoklerinin tum nehir yataklarini birbirine bagladigina inanilir."}','{"text":"[KORUMA KAYDI]\\n\\n1924 Buyuk Kar Firtinasinda Basbekci Igor ve geyik suruleri bu agacin kovuguna siginarak hayatta kalmistir.\\n\\nDallarindaki kehribar isiklari gece yolunu kaybeden ormancilara rehberlik eder."}']}}}`,

    // 2) Special Tree #1: Kizil Safak Agaci
    `setblock -102 ${gCherry + 1} -12 minecraft:spruce_sign[rotation=12]{front_text:{messages:['{"text":"🌸 OZEL AGAC","bold":true,"color":"light_purple"}','{"text":"KIZIL SAFAK AGACI","bold":true,"color":"white"}','{"text":"Nadir Kuzey Kirazi","color":"gray"}','{"text":"Kesilmesi Yasaktir","color":"red"}']},is_waxed:1b}`,

    // 3) Special Tree #2: Altin Recine Cami
    `setblock -66 ${gAmber + 1} -68 minecraft:spruce_sign[rotation=12]{front_text:{messages:['{"text":"✨ OZEL AGAC","bold":true,"color":"gold"}','{"text":"ALTIN RECINE CAMI","bold":true,"color":"white"}','{"text":"Sifali Kehribar","color":"yellow"}','{"text":"Koruma No: #002","color":"gray"}']},is_waxed:1b}`,

    // 4) Special Tree #3: Ikiz Gozyasi Sogudu
    `setblock -92 ${gWillow + 1} 6 minecraft:spruce_sign[rotation=12]{front_text:{messages:['{"text":"💧 OZEL AGAC","bold":true,"color":"aqua"}','{"text":"GOZYASI SOGUDU","bold":true,"color":"white"}','{"text":"Somon Koyu Kiyisi","color":"green"}','{"text":"Koruma No: #003","color":"gray"}']},is_waxed:1b}`,

    // 5) Cabin 1: Basbekci Igor'un Kulubesi Sign + Diary Lectern!
    `setblock -68 ${yIgor + 2} -11 minecraft:spruce_wall_sign[facing=east]{front_text:{messages:['{"text":"🏠 KULUBE #1","bold":true,"color":"gold"}','{"text":"BASBEKCI IGOR","bold":true,"color":"white"}','{"text":"Nobet Evi (1924)","color":"green"}','{"text":"Guney Patikasi","color":"gray"}']},is_waxed:1b}`,
    `setblock -71 ${yIgor + 1} -10 minecraft:lectern[facing=north,has_book=true]{Book:{id:"minecraft:written_book",Count:1b,tag:{title:"Basbekci Igorun Gunlugu",author:"Basbekci Igor",pages:['{"text":"14 Kasim 1924\\n\\nKuzey sinirindaki burclarin atesini yaktim. Bu gece ruzgar sert ama Ulu Agacin yapraklari hala parildiyor.\\n\\nSomon Koyundan taze balik getirdim, ocakta pisiyor."}','{"text":"21 Kasim 1924\\n\\nBotanikci Elif bati korusunda yeni bir kizil kiraz filizi bulmus. Etrafina tas isaret koyduk. Bu orman bizden sonra da yuzyillarca yasayacak."}']}}}`,

    // 6) Cabin 2: Botanikci Elif'in Serasi Sign + Research Book!
    `setblock -106 ${yElif + 2} -45 minecraft:spruce_wall_sign[facing=east]{front_text:{messages:['{"text":"🌿 SERA #2","bold":true,"color":"green"}','{"text":"BOTANIKCI ELIF","bold":true,"color":"white"}','{"text":"Tohum & Bitki Evi","color":"aqua"}','{"text":"Bati Patikasi","color":"gray"}']},is_waxed:1b}`,
    `setblock -109 ${yElif + 1} -44 minecraft:lectern[facing=north,has_book=true]{Book:{id:"minecraft:written_book",Count:1b,tag:{title:"Kuzey Flora Atlasi",author:"Botanikci Elif",pages:['{"text":"[KUZEY FLORA ATLASI]\\n\\n1. Ulu Muhafiz: Isik sacan kehribar meyveleri vardir.\\n2. Kizil Safak: Soguga dayanikli tek cicekli agac.\\n3. Altin Recine: Kuzey yamacinda yetisir."}']}}}`,

    // 7) Cabin 3: Somon Koyu Balikci Barinagi Sign!
    `setblock -84 ${yFisher + 2} 7 minecraft:spruce_wall_sign[facing=east]{front_text:{messages:['{"text":"⚓ BARINAK #3","bold":true,"color":"aqua"}','{"text":"SOMON KOYU EVI","bold":true,"color":"white"}','{"text":"Gol Gozetleme","color":"green"}','{"text":"Balikci Noktasi","color":"gray"}']},is_waxed:1b}`,

    // 8) Crossroads Directional Signpost right at (-62, cell(-62,-32).y+1, -32)!
    `setblock -62 ${cell(-62, -32).y + 1} -32 minecraft:mossy_stone_bricks`,
    `setblock -62 ${cell(-62, -32).y + 2} -32 minecraft:spruce_fence`,
    `setblock -62 ${cell(-62, -32).y + 3} -32 minecraft:spruce_sign[rotation=4]{front_text:{messages:['{"text":"<- Bati: Ulu Agac","bold":true,"color":"gold"}','{"text":"& Elifin Serasi","color":"green"}','{"text":"Guney: Igor Evi","color":"aqua"}','{"text":"Dogu: Ana Kapi ->","color":"white"}']},is_waxed:1b}`,

    // Clean up any dropped item entities on ground from old fence removal!
    `kill @e[type=item]`,
    `time set 1500`
  ];

  for (const c of cmds) {
    await act({ action: 'command', command: c });
  }
  await act({ action: 'actionbar', text: '' });
}

buildLivingForestWorld().catch(console.error);

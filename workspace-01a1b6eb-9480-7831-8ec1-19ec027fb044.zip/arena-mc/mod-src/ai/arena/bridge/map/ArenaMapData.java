package ai.arena.bridge.map;

import ai.arena.bridge.transit.MtrBridgeHelper;
import ai.arena.bridge.transit.UitpSystemType;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import org.mtr.core.data.Platform;
import org.mtr.core.data.Route;
import org.mtr.core.data.RoutePlatformData;
import org.mtr.core.data.Siding;
import org.mtr.core.data.Station;
import org.mtr.core.data.Vehicle;
import org.mtr.core.simulation.Simulator;
import org.mtr.core.tool.Vector;
import org.mtr.mod.client.MinecraftClientData;
import org.mtr.mod.data.VehicleExtension;

import java.io.File;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Transit & administrative data model:
 * - Reads live MTR 4.0.5 vehicles, platforms, stations, and routes (surface vs underground aware!).
 * - Supports custom UITP/UIC planned/active lines (YHT, M, B, HRS, T, MR, F, TF) and region polygons.
 */
public final class ArenaMapData {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static class CountryRegion {
        public String id;
        public String name;
        public String capitalName;
        public double capitalX;
        public double capitalZ;
        public int color;
        public List<double[]> polygon = new ArrayList<>();
    }

    public static class CustomTransitLine {
        public String id;
        public String code;
        public String name;
        public UitpSystemType systemType = UitpSystemType.METRO;
        public int color;
        public boolean underground;
        public List<double[]> points = new ArrayList<>();
    }

    public static class MapLandmark {
        public String id;
        public String name;
        public String category;
        public double x;
        public double y;
        public double z;
        public int color;
    }

    public static class LiveTrainInfo {
        public String routeNumber;
        public String routeName;
        public UitpSystemType uitpSystem;
        public String thisStation;
        public String nextStation;
        public String destination;
        public int color;
        public double x;
        public double y;
        public double z;
        public double speedKmh;
        public boolean moving;
    }

    public static class LiveStationInfo {
        public long id;
        public String name;
        public int color;
        public double x;
        public double y;
        public double z;
        public boolean underground;
    }

    public static class LiveRouteSegment {
        public String routeNumber;
        public String name;
        public UitpSystemType uitpSystem;
        public int color;
        public List<double[]> waypointsXYZ = new ArrayList<>();
    }

    public static final List<CountryRegion> COUNTRIES = new CopyOnWriteArrayList<>();
    public static final List<CustomTransitLine> CUSTOM_LINES = new CopyOnWriteArrayList<>();
    public static final List<MapLandmark> LANDMARKS = new CopyOnWriteArrayList<>();
    public static volatile boolean minimapEnabled = true;

    private static boolean initialized = false;
    private static Field vehicleSpeedField = null;

    private ArenaMapData() {}

    public static File getConfigFile() {
        return new File(FabricLoader.getInstance().getGameDir().toFile(), "arena-map-data.json");
    }

    public static synchronized void ensureLoaded() {
        if (initialized) return;
        initialized = true;
        File f = getConfigFile();
        if (f.exists()) {
            try {
                loadFromJson(JsonParser.parseString(Files.readString(f.toPath(), StandardCharsets.UTF_8)).getAsJsonObject());
                if (!COUNTRIES.isEmpty()) return;
            } catch (Throwable ignored) {}
        }
        seedDefaults();
        saveToDisk();
    }

    public static synchronized void seedDefaults() {
        COUNTRIES.clear();
        CUSTOM_LINES.clear();
        LANDMARKS.clear();

        addCountry("kuzey_avrasya", "Kuzey Avrasya Orman Bölgesi", "1. Orman Bölge Başkanlığı", 19, -37, 0x2ECC71,
                new double[][]{{-380, -360}, {260, -360}, {260, 800}, {-380, 800}});
        addCountry("guney_zumrut", "Güney Zümrüt Özerk Bölgesi", "2. Güney Orman Başkanlığı", -39, 1573, 0x00CEC9,
                new double[][]{{-380, 800}, {260, 800}, {260, 1920}, {-380, 1920}});
        addCountry("bati_yaban", "Batı Sıradağlar Koruma Kuşağı", "Batı Gözlem Noktası", -520, 400, 0x9B59B6,
                new double[][]{{-820, -360}, {-380, -360}, {-380, 1920}, {-820, 1920}});
        addCountry("dogu_nehir", "Doğu Nehir Serbest Kuşağı", "Doğu Nehir İskelesi", 420, 200, 0xF39C12,
                new double[][]{{260, -360}, {720, -360}, {720, 1920}, {260, 1920}});

        addLm("hq_north", "1. Orman Bölge Başkanlığı", "hq", 19, 65, -37, 0xF1C40F);
        addLm("st_north", "Kuzey Orman Merkez Garı", "station", -18, 65, 32, 0x00A86B);
        addLm("depot_north", "YHT-1 Merkez Deposu", "depot", -18, 64, -7, 0x42A5F5);
        addLm("tower_north", "Kuzey Gözetleme Kulesi", "tower", -52, 78, -28, 0xEF5350);
        addLm("border_800", "Bölge Sınır Geçişi (z=800)", "border", -18, 48, 800, 0xFFA726);
        addLm("st_south", "Güney Zümrüt Ormanı Garı", "station", -18, 73, 1580, 0x00CEC9);
        addLm("hq_south", "2. Güney Orman Başkanlığı", "hq", -39, 68, 1573, 0xF1C40F);
    }

    private static void addCountry(String id, String name, String cap, double cx, double cz, int col, double[][] pts) {
        CountryRegion c = new CountryRegion();
        c.id = id; c.name = name; c.capitalName = cap; c.capitalX = cx; c.capitalZ = cz; c.color = col;
        for (double[] p : pts) c.polygon.add(p);
        COUNTRIES.add(c);
    }

    private static void addLm(String id, String name, String cat, double x, double y, double z, int col) {
        MapLandmark lm = new MapLandmark();
        lm.id = id; lm.name = name; lm.category = cat; lm.x = x; lm.y = y; lm.z = z; lm.color = col;
        LANDMARKS.add(lm);
    }

    public static synchronized void saveToDisk() {
        try {
            Files.writeString(getConfigFile().toPath(), GSON.toJson(toJson()), StandardCharsets.UTF_8);
        } catch (Throwable ignored) {}
    }

    private static double readVehicleSpeedMps(Vehicle v) {
        try {
            if (vehicleSpeedField == null) {
                Field f = v.getClass().getSuperclass().getDeclaredField("speed");
                f.setAccessible(true);
                vehicleSpeedField = f;
            }
            return Math.abs(vehicleSpeedField.getDouble(v)) * 1000.0;
        } catch (Throwable ignored) {
            return v.isMoving() ? 25.0 : 0.0;
        }
    }

    private static List<LiveTrainInfo> cachedTrains = java.util.Collections.emptyList();
    private static long lastTrainCacheMs = 0L;
    private static List<LiveStationInfo> cachedStations = java.util.Collections.emptyList();
    private static long lastStationCacheMs = 0L;

    public static List<LiveTrainInfo> getLiveTrains() {
        long now = System.currentTimeMillis();
        if ((now - lastTrainCacheMs) < 180L && cachedTrains != null) {
            return cachedTrains;
        }
        List<LiveTrainInfo> out = new ArrayList<>();
        try {
            MinecraftClientData cd = MinecraftClientData.getInstance();
            if (cd != null && cd.vehicles != null && !cd.vehicles.isEmpty()) {
                for (VehicleExtension ve : cd.vehicles) {
                    LiveTrainInfo ti = extractVehicle(ve);
                    if (ti != null) out.add(ti);
                }
            }
            if (out.isEmpty()) {
                Simulator sim = MtrBridgeHelper.getOverworldSimulator();
                if (sim != null) {
                    for (Siding s : sim.sidings) {
                        Field vf = s.getClass().getSuperclass().getDeclaredField("vehicles");
                        vf.setAccessible(true);
                        Iterable<?> vs = (Iterable<?>) vf.get(s);
                        for (Object o : vs) {
                            if (o instanceof Vehicle v) {
                                LiveTrainInfo ti = extractVehicle(v);
                                if (ti != null) out.add(ti);
                            }
                        }
                    }
                }
            }
        } catch (Throwable ignored) {}
        cachedTrains = out;
        lastTrainCacheMs = now;
        return out;
    }

    private static LiveTrainInfo extractVehicle(Vehicle v) {
        try {
            Vector head = v.getHeadPosition();
            if (head == null) return null;
            LiveTrainInfo ti = new LiveTrainInfo();
            ti.x = head.x();
            ti.y = head.y();
            ti.z = head.z();
            ti.speedKmh = Math.min(320.0, Math.round(readVehicleSpeedMps(v) * 3.6 * 10.0) / 10.0);
            ti.moving = v.isMoving() || ti.speedKmh > 0.6;

            if (v.vehicleExtraData != null) {
                ti.routeNumber = nonBlank(v.vehicleExtraData.getThisRouteNumber(), "YHT-1");
                ti.routeName = nonBlank(v.vehicleExtraData.getThisRouteName(), "Avrasya Orman YHT");
                ti.thisStation = nonBlank(v.vehicleExtraData.getThisStationName(), "");
                ti.nextStation = nonBlank(v.vehicleExtraData.getNextStationName(), "");
                ti.destination = nonBlank(v.vehicleExtraData.getThisRouteDestination(), "");
                ti.uitpSystem = UitpSystemType.fromRouteCodeOrType(ti.routeNumber);
                int c = v.vehicleExtraData.getThisRouteColor();
                ti.color = c != 0 ? (c & 0xFFFFFF) : ti.uitpSystem.defaultColor;
            } else {
                ti.routeNumber = "YHT-1";
                ti.routeName = "Avrasya Orman YHT";
                ti.uitpSystem = UitpSystemType.YHT;
                ti.color = UitpSystemType.YHT.defaultColor;
            }
            return ti;
        } catch (Throwable ignored) {
            return null;
        }
    }

    public static List<LiveStationInfo> getLiveStations() {
        long now = System.currentTimeMillis();
        if ((now - lastStationCacheMs) < 250L && cachedStations != null && !cachedStations.isEmpty()) {
            return cachedStations;
        }
        List<LiveStationInfo> out = new ArrayList<>();
        try {
            MinecraftClientData cd = MinecraftClientData.getInstance();
            Iterable<Station> stations = (cd != null && !cd.stations.isEmpty()) ? cd.stations : null;
            Iterable<Platform> platforms = (cd != null && !cd.platforms.isEmpty()) ? cd.platforms : null;
            Simulator sim = MtrBridgeHelper.getOverworldSimulator();
            if (stations == null && sim != null) stations = sim.stations;
            if (platforms == null && sim != null) platforms = sim.platforms;

            if (stations != null) {
                java.util.Set<String> seenNames = new java.util.HashSet<>();
                for (Station s : stations) {
                    String cleanName = nonBlank(s.getName(), "İstasyon");
                    if (!seenNames.add(cleanName.toLowerCase(java.util.Locale.ROOT))) continue;
                    LiveStationInfo st = new LiveStationInfo();
                    st.id = s.getId();
                    st.name = cleanName;
                    st.color = s.getColor() != 0 ? (s.getColor() & 0xFFFFFF) : 0x00A86B;
                    st.x = (s.getMinX() + s.getMaxX()) * 0.5;
                    st.z = (s.getMinZ() + s.getMaxZ()) * 0.5;
                    st.y = 48.0;
                    if (platforms != null) {
                        for (Platform p : platforms) {
                            if (s.inArea(p.getMidPosition())) {
                                st.x = p.getMidPosition().getX();
                                st.y = p.getMidPosition().getY();
                                st.z = p.getMidPosition().getZ();
                                break;
                            }
                        }
                    }
                    st.underground = st.y < 58.0;
                    out.add(st);
                }
                out.sort(java.util.Comparator.comparingDouble(a -> a.z));
            }
        } catch (Throwable ignored) {}
        cachedStations = out;
        lastStationCacheMs = now;
        return out;
    }

    public static List<LiveRouteSegment> getLiveRoutes() {
        List<LiveRouteSegment> out = new ArrayList<>();
        try {
            MinecraftClientData cd = MinecraftClientData.getInstance();
            Iterable<Route> routes = (cd != null && !cd.routes.isEmpty()) ? cd.routes : null;
            Iterable<Platform> platforms = (cd != null && !cd.platforms.isEmpty()) ? cd.platforms : null;
            Simulator sim = MtrBridgeHelper.getOverworldSimulator();
            if (routes == null && sim != null) routes = sim.routes;
            if (platforms == null && sim != null) platforms = sim.platforms;

            Map<Long, Platform> pMap = new HashMap<>();
            if (platforms != null) {
                for (Platform p : platforms) pMap.put(p.getId(), p);
            }
            if (routes != null) {
                java.util.Set<String> seenCodes = new java.util.HashSet<>();
                for (Route r : routes) {
                    if (r.getHidden()) continue;
                    String num = nonBlank(r.getRouteNumber(), "YHT-1");
                    if (!seenCodes.add(num)) continue;
                    LiveRouteSegment seg = new LiveRouteSegment();
                    seg.routeNumber = num;
                    seg.name = nonBlank(r.getName(), "Avrasya Orman YHT");
                    seg.uitpSystem = UitpSystemType.fromRouteCodeOrType(num);
                    seg.color = r.getColor() != 0 ? (r.getColor() & 0xFFFFFF) : seg.uitpSystem.defaultColor;
                    for (RoutePlatformData rpd : r.getRoutePlatforms()) {
                        Platform p = rpd.getPlatform();
                        if (p != null) {
                            seg.waypointsXYZ.add(new double[]{
                                    p.getMidPosition().getX(),
                                    p.getMidPosition().getY(),
                                    p.getMidPosition().getZ()
                            });
                        }
                    }
                    out.add(seg);
                }
            }
        } catch (Throwable ignored) {}
        return out;
    }

    private static String nonBlank(String v, String fallback) {
        return (v == null || v.isBlank()) ? fallback : v;
    }

    public static JsonObject toJson() {
        JsonObject root = new JsonObject();
        root.addProperty("ok", true);
        root.addProperty("minimapEnabled", minimapEnabled);

        JsonArray cArr = new JsonArray();
        for (CountryRegion c : COUNTRIES) {
            JsonObject o = new JsonObject();
            o.addProperty("id", c.id);
            o.addProperty("name", c.name);
            o.addProperty("capitalName", c.capitalName);
            o.addProperty("capitalX", c.capitalX);
            o.addProperty("capitalZ", c.capitalZ);
            o.addProperty("color", String.format("#%06X", c.color & 0xFFFFFF));
            JsonArray poly = new JsonArray();
            for (double[] pt : c.polygon) {
                JsonArray pa = new JsonArray(); pa.add(pt[0]); pa.add(pt[1]); poly.add(pa);
            }
            o.add("polygon", poly);
            cArr.add(o);
        }
        root.add("countries", cArr);

        JsonArray lArr = new JsonArray();
        for (CustomTransitLine cl : CUSTOM_LINES) {
            JsonObject o = new JsonObject();
            o.addProperty("id", cl.id);
            o.addProperty("code", cl.code);
            o.addProperty("name", cl.name);
            o.addProperty("systemType", cl.systemType.name());
            o.addProperty("color", String.format("#%06X", cl.color & 0xFFFFFF));
            o.addProperty("underground", cl.underground);
            JsonArray pts = new JsonArray();
            for (double[] pt : cl.points) {
                JsonArray pa = new JsonArray(); pa.add(pt[0]); pa.add(pt[1]); pts.add(pa);
            }
            o.add("points", pts);
            lArr.add(o);
        }
        root.add("customLines", lArr);
        return root;
    }

    private static void loadFromJson(JsonObject root) {
        if (root == null) return;
        if (root.has("minimapEnabled")) minimapEnabled = root.get("minimapEnabled").getAsBoolean();
        if (root.has("countries") && root.get("countries").isJsonArray()) {
            COUNTRIES.clear();
            for (JsonElement el : root.getAsJsonArray("countries")) {
                JsonObject o = el.getAsJsonObject();
                CountryRegion c = new CountryRegion();
                c.id = o.get("id").getAsString();
                c.name = o.get("name").getAsString();
                c.capitalName = o.has("capitalName") ? o.get("capitalName").getAsString() : "";
                c.capitalX = o.has("capitalX") ? o.get("capitalX").getAsDouble() : 0;
                c.capitalZ = o.has("capitalZ") ? o.get("capitalZ").getAsDouble() : 0;
                c.color = parseHex(o.has("color") ? o.get("color").getAsString() : "#2ECC71", 0x2ECC71);
                if (o.has("polygon")) {
                    for (JsonElement pe : o.getAsJsonArray("polygon")) {
                        JsonArray pa = pe.getAsJsonArray();
                        c.polygon.add(new double[]{pa.get(0).getAsDouble(), pa.get(1).getAsDouble()});
                    }
                }
                COUNTRIES.add(c);
            }
        }
        if (root.has("customLines") && root.get("customLines").isJsonArray()) {
            CUSTOM_LINES.clear();
            for (JsonElement el : root.getAsJsonArray("customLines")) {
                JsonObject o = el.getAsJsonObject();
                CustomTransitLine cl = new CustomTransitLine();
                cl.id = o.get("id").getAsString();
                cl.code = o.get("code").getAsString();
                cl.name = o.get("name").getAsString();
                cl.systemType = UitpSystemType.fromRouteCodeOrType(
                        o.has("systemType") ? o.get("systemType").getAsString() : cl.code
                );
                cl.color = parseHex(o.has("color") ? o.get("color").getAsString() : "#E53935", cl.systemType.defaultColor);
                cl.underground = o.has("underground") ? o.get("underground").getAsBoolean() : cl.systemType.requiresUndergroundStations;
                if (o.has("points")) {
                    for (JsonElement pe : o.getAsJsonArray("points")) {
                        JsonArray pa = pe.getAsJsonArray();
                        cl.points.add(new double[]{pa.get(0).getAsDouble(), pa.get(1).getAsDouble()});
                    }
                }
                CUSTOM_LINES.add(cl);
            }
        }
    }

    public static JsonObject handleMapApi(String method, String body) {
        ensureLoaded();
        if (body != null) {
            if (body.contains("\"hotpatch\"")) {
                return ai.arena.bridge.hotpatch.HotPatchManager.handleHttp(method, body);
            }
            if (body.contains("\"board\"")) {
                return ai.arena.bridge.board.ProgrammableBoardManager.handleApi(body);
            }
            if (body.contains("\"news\"")) {
                JsonObject parsed = JsonParser.parseString(body).getAsJsonObject();
                return ai.arena.bridge.board.ArenaNewsManager.handleApiPost(parsed.get("news").toString());
            }
            if (body.contains("\"physics\"")) {
                return ai.arena.bridge.physics.GeoStructuralPhysicsEngine.handleApi(
                        body, ai.arena.bridge.hotpatch.HotPatchManager.getLastServer()
                );
            }
        }
        if (!"POST".equalsIgnoreCase(method)) return toJson();
        try {
            JsonObject req = JsonParser.parseString(body == null || body.isBlank() ? "{}" : body).getAsJsonObject();
            if (req.has("hotpatch")) {
                return ai.arena.bridge.hotpatch.HotPatchManager.handleHttp(method, body);
            }
            String op = req.has("op") ? req.get("op").getAsString() : "";
            if ("upsert_line".equalsIgnoreCase(op)) {
                String id = req.has("id") ? req.get("id").getAsString() : ("line_" + System.currentTimeMillis());
                CUSTOM_LINES.removeIf(l -> l.id.equals(id));
                CustomTransitLine cl = new CustomTransitLine();
                cl.id = id;
                cl.code = req.get("code").getAsString();
                cl.name = req.get("name").getAsString();
                cl.systemType = UitpSystemType.fromRouteCodeOrType(
                        req.has("systemType") ? req.get("systemType").getAsString() : cl.code
                );
                cl.color = parseHex(req.has("color") ? req.get("color").getAsString() : "", cl.systemType.defaultColor);
                cl.underground = req.has("underground") ? req.get("underground").getAsBoolean() : cl.systemType.requiresUndergroundStations;
                if (req.has("points")) {
                    for (JsonElement pe : req.getAsJsonArray("points")) {
                        JsonArray pa = pe.getAsJsonArray();
                        cl.points.add(new double[]{pa.get(0).getAsDouble(), pa.get(1).getAsDouble()});
                    }
                }
                CUSTOM_LINES.add(cl);
                saveToDisk();
            } else if ("reset".equalsIgnoreCase(op)) {
                seedDefaults();
                saveToDisk();
            }
        } catch (Throwable ignored) {}
        return toJson();
    }

    private static int parseHex(String hex, int fallback) {
        if (hex == null || hex.isBlank()) return fallback;
        try {
            return Integer.parseInt(hex.replace("#", "").trim(), 16) & 0xFFFFFF;
        } catch (Throwable ignored) {
            return fallback;
        }
    }
}

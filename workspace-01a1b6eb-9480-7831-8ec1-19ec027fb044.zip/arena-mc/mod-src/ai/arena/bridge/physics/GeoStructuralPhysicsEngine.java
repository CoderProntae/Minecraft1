package ai.arena.bridge.physics;

import ai.arena.bridge.ArenaContent;
import ai.arena.bridge.map.ArenaMapData;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.passive.IronGolemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.world.Heightmap;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Peer-Reviewed Geotechnical, Structural & Vehicle-Track Coupled Physics Engine (v7.7.0):
 *
 * Scientific formulations implemented:
 * 1. Shallow Tunnel Hydro-Mechanical Stability (Tandfonline 2021; Hoek 2008 Kersten Lecture):
 *    - Green-Ampt rainfall infiltration wetting front + pore-water pressure u_w (kPa).
 *    - Effective stress Mohr-Coulomb shear resistance: tau_f = c' + (sigma_n - u_w) * tan(phi').
 *    - Boussinesq vertical stress bulb under surface dead/live/entity loads:
 *      Delta_sigma_z = (3 * Q / (2 * pi * z^2)) * (1 + (r / z)^2)^(-5/2).
 * 2. Structural Column Axial Buckling & P-Delta Amplification (Euler 1744; AISC P-Delta):
 *    - P_cr = (pi^2 * E * I) / (K * L)^2, slenderness lambda = K * L / r_g, B2 = 1 / (1 - P / P_cr).
 * 3. Human/Entity Dynamic Jumping Impulse & Slab Resonance (Bachmann & Baumann 1988; EN 1991-1-1; EN 81-20):
 *    - Peak impact factor K_p = 1 + min(6.0, |v_impact| / (g * dt_contact)), F_peak = m * g * K_p.
 *    - Unpropped clear-span bending M = q*L^2/8 + F_peak*L/4 & elevator rope dynamic overload trip (>1.25x).
 * 4. Continuous 6-DoF Rigid-Body Fracture & Rotational P-Delta Building Tilt (Physics-Mod style):
 *    - Detached voxels NEVER snap back to grid blocks; they integrate 80 Hz quaternion rigid-body dynamics
 *      with 8-corner OBB torque/restitution/Coulomb friction and rest at continuous 3D poses.
 */
public final class GeoStructuralPhysicsEngine {

    public static final int RING_MIN_CZ = -2;
    public static final int RING_MAX_CZ = 100;
    public static final int RING_COUNT = RING_MAX_CZ - RING_MIN_CZ + 1; // 103 rings covering z = -32 .. 1615
    private static final int MAX_RIGID_BODIES = 96;
    private static final AtomicLong ID_GEN = new AtomicLong(1L);

    /** Continuous 6-DoF falling/tumbling block rigid body (NEVER converted back into integer floor blocks!). */
    public static final class PhysicsRigidBody {
        public final long id;
        public final BlockState state;
        public final BlockPos originPos;
        public volatile double px, py, pz;
        public volatile double prevPx, prevPy, prevPz;
        public double vx, vy, vz;
        public final Quaternionf quat = new Quaternionf();
        public final Quaternionf prevQuat = new Quaternionf();
        public double wx, wy, wz;
        public final double massKg;
        public final double invMass;
        public final double invInertia;
        public final double restitution;
        public final double friction;
        public volatile boolean sleeping = false;
        public int ageTicks = 0;
        public int lowEnergyTicks = 0;

        public PhysicsRigidBody(BlockPos origin, BlockState state, double ivx, double ivy, double ivz,
                                double iwx, double iwy, double iwz) {
            this.id = ID_GEN.getAndIncrement();
            this.originPos = origin.toImmutable();
            this.state = state;
            this.px = origin.getX() + 0.5;
            this.py = origin.getY() + 0.5;
            this.pz = origin.getZ() + 0.5;
            this.prevPx = this.px;
            this.prevPy = this.py;
            this.prevPz = this.pz;
            this.vx = ivx;
            this.vy = ivy;
            this.vz = ivz;
            this.wx = iwx;
            this.wy = iwy;
            this.wz = iwz;
            this.massKg = estimateBlockMassKg(state);
            this.invMass = 1.0 / Math.max(20.0, this.massKg);
            // Cube moment of inertia I = (1/6) * m * s^2 (s = 0.96m)
            this.invInertia = 6.0 / (Math.max(20.0, this.massKg) * 0.9216);
            boolean wood = state.isIn(BlockTags.PLANKS) || state.isIn(BlockTags.LOGS) || state.isIn(BlockTags.WOODEN_STAIRS);
            this.restitution = wood ? 0.30 : 0.20;
            this.friction = wood ? 0.50 : 0.65;
        }
    }

    public record RelBlock(int dx, int dy, int dz, BlockState state) {}

    /** Multi-block building/frame rotating continuously around its foundation settlement hinge (P-Delta ODE). */
    public static final class TiltingStructureBody {
        public final long id;
        public final String label;
        public final BlockPos hinge;
        public final List<RelBlock> blocks;
        public final double totalMassKg;
        public final double cmHeightMeters;
        public final double rotationalInertia;
        public volatile double tiltXRad = 0.0, tiltZRad = 0.0;
        public volatile double prevTiltXRad = 0.0, prevTiltZRad = 0.0;
        public double omegaX = 0.0, omegaZ = 0.0;
        public double plasticTiltXRad = 0.0, plasticTiltZRad = 0.0;
        public double soilStiffnessFactor = 1.0;
        public volatile boolean repairing = false;
        public int spalledCount = 0;

        public TiltingStructureBody(String label, BlockPos hinge, List<RelBlock> blocks,
                                    double totalMassKg, double cmHeightMeters) {
            this.id = ID_GEN.getAndIncrement();
            this.label = label;
            this.hinge = hinge.toImmutable();
            this.blocks = new CopyOnWriteArrayList<>(blocks);
            this.totalMassKg = Math.max(1500.0, totalMassKg);
            this.cmHeightMeters = Math.max(1.5, cmHeightMeters);
            this.rotationalInertia = this.totalMassKg * (this.cmHeightMeters * this.cmHeightMeters + 4.0);
        }
    }

    /** Per-16m tunnel ring hydro-mechanical state. */
    public static final class TunnelRingState {
        public final int ringIdx;
        public final int cz;
        public final int centerZ;
        public volatile double coverDepthM = 14.0;
        public volatile double poreWaterKpa = 0.0;
        public volatile double liveBoussinesqKpa = 0.0;
        public volatile double trainDynamicKpa = 0.0;
        public volatile double seismicKpa = 0.0;
        public volatile double fatigueDamage = 0.0; // 0.0 .. 1.0
        public volatile double settlementMm = 0.0;  // 0 .. 45 mm vertical track settlement
        public volatile double factorOfSafety = 2.35;
        public volatile int crackStage = 0;         // 0=intact, 1=cracked/alarm, 2=spalling/partial collapse
        public volatile boolean emergencyLedActive = false;
        public final List<BlockPos> missingBlocks = new CopyOnWriteArrayList<>();

        public TunnelRingState(int ringIdx, int cz) {
            this.ringIdx = ringIdx;
            this.cz = cz;
            this.centerZ = (cz << 4) + 8;
        }
    }

    /** Scanned structural column buckling state. */
    public static final class ColumnHealth {
        public BlockPos basePos;
        public String material;
        public int heightM;
        public double slenderness;
        public double axialLoadKn;
        public double eulerCriticalKn;
        public double pDeltaFactor;
        public double dcr; // Demand / Capacity Ratio
        public double fos;
    }

    /** Active structural/elevator/tunnel fault shown on Player & ArenaAI Geotechnical Radar. */
    public static final class StructuralAlert {
        public final String id;
        public final String kind; // TUNNEL_CRACK, TUNNEL_COLLAPSE, BUILDING_TILT, SLAB_IMPACT, ELEVATOR_BRAKE
        public final String summary;
        public final BlockPos pos;
        public final double severity; // 0..1
        public final long createdAtMs;

        public StructuralAlert(String id, String kind, String summary, BlockPos pos, double severity) {
            this.id = id;
            this.kind = kind;
            this.summary = summary;
            this.pos = pos.toImmutable();
            this.severity = severity;
            this.createdAtMs = System.currentTimeMillis();
        }
    }

    public static final List<PhysicsRigidBody> RIGID_BODIES = new CopyOnWriteArrayList<>();
    public static final List<TiltingStructureBody> TILTING_STRUCTURES = new CopyOnWriteArrayList<>();
    public static final TunnelRingState[] TUNNEL_RINGS = new TunnelRingState[RING_COUNT];
    public static final List<ColumnHealth> SCANNED_COLUMNS = new CopyOnWriteArrayList<>();
    public static final List<StructuralAlert> ACTIVE_ALERTS = new CopyOnWriteArrayList<>();

    private static final Map<UUID, Double> PREV_ENTITY_VY = new HashMap<>();
    private static final Map<UUID, Boolean> PREV_ENTITY_ONGROUND = new HashMap<>();
    private static final Map<Long, Double> SLAB_FATIGUE = new HashMap<>();
    private static final Map<String, Integer> ELEVATOR_JUMP_COUNTS = new HashMap<>();

    // Live telemetry exposed to Client Radar HUD & ArenaAI Radar HTTP API
    public static volatile double latestNearestColumnDcr = 0.18;
    public static volatile double latestNearestColumnFos = 5.4;
    public static volatile int latestNearestColumnHeight = 6;
    public static volatile double latestSurfaceImpulseKn = 0.0;
    public static volatile double latestMaxPoreWaterKpa = 0.0;
    public static volatile double latestMinTunnelFos = 2.35;
    public static volatile int latestCriticalRingZ = 800;
    public static volatile boolean elevatorBrakeTripped = false;
    public static volatile BlockPos elevatorFaultPos = null;

    // Client-coupled 3-DoF train suspension telemetry (updated at 60 Hz on client, read by server & radar)
    public static volatile float clientTrainRollDeg = 0.0f;
    public static volatile float clientTrainPitchDeg = 0.0f;
    public static volatile float clientTrainHeaveM = 0.0f;
    public static volatile float clientSperlingWz = 1.65f;
    public static volatile boolean physicsEnabled = true;

    private static int tickCounter = 0;

    static {
        for (int i = 0; i < RING_COUNT; i++) {
            TUNNEL_RINGS[i] = new TunnelRingState(i, RING_MIN_CZ + i);
        }
    }

    private GeoStructuralPhysicsEngine() {}

    public static TunnelRingState getRingForZ(double z) {
        int cz = ((int) Math.floor(z)) >> 4;
        int idx = cz - RING_MIN_CZ;
        if (idx < 0 || idx >= RING_COUNT) return null;
        return TUNNEL_RINGS[idx];
    }

    public static double estimateBlockMassKg(BlockState st) {
        if (st.isIn(BlockTags.LOGS) || st.isIn(BlockTags.PLANKS) || st.isIn(BlockTags.WOODEN_STAIRS) || st.isIn(BlockTags.WOODEN_SLABS)) {
            return 560.0;
        }
        if (st.isOf(Blocks.GLASS) || st.isOf(Blocks.TINTED_GLASS)) return 1200.0;
        if (st.isOf(Blocks.QUARTZ_PILLAR) || st.isOf(Blocks.SMOOTH_QUARTZ) || st.isOf(Blocks.CHISELED_QUARTZ_BLOCK)) return 2650.0;
        if (st.isOf(Blocks.POLISHED_DEEPSLATE) || st.isOf(Blocks.DEEPSLATE_TILES)) return 2720.0;
        return 2400.0; // Stone bricks / masonry arch ring
    }

    public static double estimateEntityMassKg(LivingEntity e) {
        double baseKg;
        if (e instanceof PlayerEntity) {
            baseKg = 78.0;
        } else if (e instanceof IronGolemEntity) {
            baseKg = 1420.0;
        } else {
            Box bb = e.getBoundingBox();
            double vol = Math.max(0.05, bb.getLengthX() * bb.getLengthY() * bb.getLengthZ());
            baseKg = Math.min(950.0, Math.max(3.0, vol * 420.0));
        }
        // Add physical armor mass (iron/diamond/netherite/gold)
        double armorKg = 0.0;
        for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            ItemStack stack = e.getEquippedStack(slot);
            if (!stack.isEmpty() && stack.getItem() instanceof ArmorItem ai) {
                armorKg += Math.max(2.0, ai.getProtection() * 2.8);
            }
        }
        return baseKg + armorKg;
    }

    /**
     * Called from ArenaContent.onServerTick (20 Hz).
     */
    public static void onServerTick(MinecraftServer server) {
        if (!physicsEnabled || server == null) return;
        ServerWorld world = server.getOverworld();
        if (world == null || world.getPlayers().isEmpty()) return;
        tickCounter++;

        // 1. Sub-stepped 80 Hz 6-DoF rigid-body solver for all live falling/tumbling blocks
        tickRigidBodies(world);

        // 2. Continuous rotational P-Delta ODE for any tilting surface buildings
        tickTiltingStructures(world);

        // 3. Track LivingEntity landings (Bachmann dynamic impact on uncolumned spans, elevators & Boussinesq tunnel bulbs)
        tickEntityImpactsAndLiveLoads(world);

        // 4. Every 10 ticks (0.5s): update hydro-geotechnical tunnel ring FoS, pore-water seepage, and localized red alarms
        if (tickCounter % 10 == 0) {
            updateTunnelGeotechnics(world);
        }

        // 5. Every 40 ticks (2.0s): scan structural columns near players for Euler buckling & P-Delta DCR
        if (tickCounter % 40 == 5) {
            scanNearbyColumns(world);
        }

        // Decay transient surface impulse meter smoothly
        latestSurfaceImpulseKn *= 0.90;
    }

    /**
     * Called when a physical lightning bolt strikes (or storm shock occurs) to inject seismic PPV stress!
     */
    public static void onLightningStrike(ServerWorld world, BlockPos strikePos, int stormLevel) {
        if (world == null || strikePos == null) return;
        double energyFactor = 1.0 + 0.45 * Math.max(1, stormLevel);
        for (TunnelRingState ring : TUNNEL_RINGS) {
            // Skip station caverns (Kuzey z=19..45, Güney z=1565..1595) for crown rockfall, only stress bore tunnel
            if ((ring.centerZ >= 16 && ring.centerZ <= 48) || (ring.centerZ >= 1562 && ring.centerZ <= 1598)) continue;
            double dx = strikePos.getX() - (-18.0);
            double dz = strikePos.getZ() - ring.centerZ;
            double dy = strikePos.getY() - 53.0;
            double r = Math.max(8.0, Math.sqrt(dx * dx + dy * dy + dz * dz));
            if (r < 95.0) {
                // Peak Particle Velocity attenuation R^-1.55 -> dynamic shear kPa
                double seismicPulseKpa = (420.0 * energyFactor) / Math.pow(r / 10.0, 1.55);
                ring.seismicKpa = Math.min(95.0, ring.seismicKpa + seismicPulseKpa);
                if (seismicPulseKpa > 22.0) {
                    ring.fatigueDamage = Math.min(1.0, ring.fatigueDamage + 0.08 * (seismicPulseKpa / 40.0));
                }
            }
        }
        // Check if lightning struck within 24m of a surface timber/masonry building on saturated soil -> induce P-Delta foundation tilt!
        if (world.isRaining() || world.isThundering()) {
            maybeInitiateBuildingTiltNear(world, strikePos, 0.035 * energyFactor);
        }
    }

    private static void tickEntityImpactsAndLiveLoads(ServerWorld world) {
        // Decay per-ring Boussinesq & seismic transient loads
        for (TunnelRingState r : TUNNEL_RINGS) {
            r.liveBoussinesqKpa *= 0.85;
            r.seismicKpa *= 0.92;
            r.trainDynamicKpa *= 0.85;
        }

        // Apply moving MTR train dynamic axle load (UIC 518 impact factor 1 + phi_dyn)
        for (ArenaMapData.LiveTrainInfo t : ArenaMapData.getLiveTrains()) {
            TunnelRingState tr = getRingForZ(t.z);
            if (tr != null) {
                double vRatio = Math.max(0.0, t.speedKmh / 80.0);
                double settleAmp = 1.0 + (tr.settlementMm / 18.0);
                double axleKpa = (14.0 + 18.0 * vRatio * settleAmp);
                tr.trainDynamicKpa = Math.max(tr.trainDynamicKpa, axleKpa);
                if (tr.crackStage >= 1 && t.speedKmh > 25.0) {
                    tr.fatigueDamage = Math.min(1.0, tr.fatigueDamage + 0.0018 * vRatio);
                }
            }
        }

        // Gather living entities around players in loaded chunks (never iterate entire world!)
        Map<UUID, LivingEntity> uniqueEntities = new HashMap<>();
        for (ServerPlayerEntity sp : world.getPlayers()) {
            uniqueEntities.put(sp.getUuid(), sp);
            Box scanBox = sp.getBoundingBox().expand(36.0, 24.0, 36.0);
            for (LivingEntity le : world.getEntitiesByClass(LivingEntity.class, scanBox, Entity::isAlive)) {
                uniqueEntities.put(le.getUuid(), le);
            }
        }

        for (LivingEntity le : uniqueEntities.values()) {
            UUID uid = le.getUuid();
            double massKg = estimateEntityMassKg(le);
            double staticWeightN = massKg * 9.81;
            double vyNow = le.getVelocity().y;
            boolean onGroundNow = le.isOnGround();
            double prevVy = PREV_ENTITY_VY.getOrDefault(uid, 0.0);
            boolean wasOnGround = PREV_ENTITY_ONGROUND.getOrDefault(uid, true);

            // Detect jump/drop impact velocity: on server PlayerEntity velocity can already be zeroed on landing tick,
            // so combine prevVy AND le.fallDistance (v = sqrt(2 * g * h))!
            double impactSpeedMps = 0.0;
            if (!wasOnGround && onGroundNow) {
                double fromFallDist = le.fallDistance > 0.15 ? Math.sqrt(2.0 * 9.81 * le.fallDistance) : 0.0;
                double fromVel = prevVy < -0.08 ? Math.abs(prevVy) * 20.0 * 0.35 : 0.0;
                impactSpeedMps = Math.max(fromFallDist, Math.max(fromVel, 4.2)); // normal 1.25m MC jump => ~4.95 m/s!
            }

            PREV_ENTITY_VY.put(uid, vyNow);
            PREV_ENTITY_ONGROUND.put(uid, onGroundNow);

            double dynamicForceN = staticWeightN;
            if (impactSpeedMps > 1.5) {
                // Bachmann & Baumann (1988): Kp = 1 + min(6.0, v_impact / (g * t_c)), t_c = 0.14s
                double kp = 1.0 + Math.min(6.0, impactSpeedMps / (9.81 * 0.14));
                dynamicForceN = staticWeightN * kp;
                latestSurfaceImpulseKn = Math.max(latestSurfaceImpulseKn, dynamicForceN / 1000.0);

                BlockPos supportPos = le.getSteppingPos();
                handleJumpImpactOnStructureAndElevator(world, le, supportPos, massKg, dynamicForceN);
            }

            // Boussinesq vertical stress bulb onto shallow tunnel crown (y = 53, x = -18)
            double zDepth = le.getY() - 53.0;
            if (zDepth > 1.0 && zDepth < 32.0) {
                TunnelRingState ring = getRingForZ(le.getZ());
                if (ring != null) {
                    double rHoriz = Math.hypot(le.getX() - (-18.0), le.getZ() - ring.centerZ);
                    double boussinesqPa = (3.0 * dynamicForceN / (2.0 * Math.PI * zDepth * zDepth))
                            * Math.pow(1.0 + (rHoriz / zDepth) * (rHoriz / zDepth), -2.5);
                    ring.liveBoussinesqKpa += (boussinesqPa / 1000.0);
                }
            }
        }
    }

    private static void handleJumpImpactOnStructureAndElevator(
            ServerWorld world, LivingEntity jumper, BlockPos supportPos, double massKg, double peakForceN
    ) {
        if (!world.isChunkLoaded(supportPos.getX() >> 4, supportPos.getZ() >> 4)) return;

        // 1. Check EN 81-20 Elevator Cab Dynamic Overload (mtr:lift_track* within 3 blocks)
        boolean inElevatorShaft = false;
        BlockPos.Mutable mp = new BlockPos.Mutable();
        for (int dx = -2; dx <= 2 && !inElevatorShaft; dx++) {
            for (int dy = -1; dy <= 3 && !inElevatorShaft; dy++) {
                for (int dz = -2; dz <= 2 && !inElevatorShaft; dz++) {
                    if (!world.isChunkLoaded((supportPos.getX() + dx) >> 4, (supportPos.getZ() + dz) >> 4)) continue;
                    String bid = Registries.BLOCK.getId(world.getBlockState(mp.set(
                            supportPos.getX() + dx, supportPos.getY() + dy, supportPos.getZ() + dz
                    )).getBlock()).toString();
                    if (bid.contains("lift")) {
                        inElevatorShaft = true;
                    }
                }
            }
        }
        if (inElevatorShaft) {
            String shaftKey = (supportPos.getX() >> 2) + ":" + (supportPos.getZ() >> 2);
            int jumps = ELEVATOR_JUMP_COUNTS.getOrDefault(shaftKey, 0) + 1;
            ELEVATOR_JUMP_COUNTS.put(shaftKey, jumps);
            // EN 81-20 safety gear trip when peak dynamic load ratio > 1.25x or repeated resonance jumps
            double cabMassKg = 650.0;
            double ropeRatio = (cabMassKg * 9.81 + peakForceN) / ((cabMassKg + 320.0) * 9.81);
            if (ropeRatio > 1.25 || jumps >= 2) {
                elevatorBrakeTripped = true;
                elevatorFaultPos = supportPos.toImmutable();
                world.playSound(null, supportPos, SoundEvents.BLOCK_ANVIL_LAND, SoundCategory.BLOCKS, 0.65f, 0.6f);
                upsertAlert("elev_" + shaftKey, "ELEVATOR_BRAKE",
                        String.format(Locale.US, "Asansör Paraşüt Freni Devrede (Darbe %.1f kN)", peakForceN / 1000.0),
                        supportPos, 0.85);
            }
            return;
        }

        // 2. Check Uncolumned Clear Span Slab underneath supportPos!
        BlockState slabState = world.getBlockState(supportPos);
        if (slabState.isAir() || isProtectedTransitBlock(slabState)) return;

        // Must have a hollow room/cavity of at least 2 air blocks directly below the 1-2 block thick floor/roof slab!
        int slabThickness = 0;
        for (int dy = 0; dy <= 2; dy++) {
            BlockState below = world.getBlockState(supportPos.down(dy));
            if (!below.isAir()) slabThickness++;
            else break;
        }
        boolean hollowBelow = slabThickness >= 1 && slabThickness <= 2
                && world.getBlockState(supportPos.down(slabThickness)).isAir()
                && world.getBlockState(supportPos.down(slabThickness + 1)).isAir();
        if (!hollowBelow) return;

        // Measure horizontal distance L_span to nearest vertical support column/wall extending >= 2 blocks below slab!
        double nearestColDist = 9.0;
        for (int dx = -6; dx <= 6; dx++) {
            for (int dz = -6; dz <= 6; dz++) {
                int cx = supportPos.getX() + dx, cz = supportPos.getZ() + dz;
                if (!world.isChunkLoaded(cx >> 4, cz >> 4)) continue;
                BlockState s1 = world.getBlockState(mp.set(cx, supportPos.getY() - slabThickness, cz));
                BlockState s2 = world.getBlockState(mp.set(cx, supportPos.getY() - slabThickness - 1, cz));
                if (!s1.isAir() && !s2.isAir()) {
                    nearestColDist = Math.min(nearestColDist, Math.hypot(dx, dz));
                }
            }
        }

        // Clear span L = 2 * nearestColDist. If L >= 4.0m (no column underneath!), compute bending M / M_ult!
        double clearSpanM = nearestColDist * 2.0;
        if (clearSpanM >= 4.0) {
            boolean woodSlab = slabState.isIn(BlockTags.PLANKS) || slabState.isIn(BlockTags.WOODEN_SLABS) || slabState.isIn(BlockTags.WOODEN_STAIRS);
            double momentCapacityKnm = (woodSlab ? 11.5 : 22.0) * slabThickness;
            double deadLoadKnPerM = (estimateBlockMassKg(slabState) * 9.81 / 1000.0) * slabThickness;
            double appliedMomentKnm = (deadLoadKnPerM * clearSpanM * clearSpanM) / 8.0
                    + ((peakForceN / 1000.0) * clearSpanM) / 4.0;
            double overstress = appliedMomentKnm / Math.max(1.0, momentCapacityKnm);

            if (overstress > 0.72) {
                long key = supportPos.asLong();
                double dmg = SLAB_FATIGUE.getOrDefault(key, 0.0) + 0.36 * overstress * Math.max(0.7, massKg / 80.0);
                SLAB_FATIGUE.put(key, dmg);
                world.spawnParticles(new BlockStateParticleEffect(ParticleTypes.BLOCK, slabState),
                        supportPos.getX() + 0.5, supportPos.getY() - 0.1, supportPos.getZ() + 0.5,
                        14, 0.3, 0.1, 0.3, 0.05);
                world.playSound(null, supportPos,
                        woodSlab ? SoundEvents.BLOCK_WOOD_HIT : SoundEvents.BLOCK_STONE_HIT,
                        SoundCategory.BLOCKS, 0.8f, 0.65f);

                if (dmg >= 1.0) {
                    SLAB_FATIGUE.remove(key);
                    detachBlockAsLiveRigidBody(world, supportPos, 0.0, -0.8, 0.0);
                    upsertAlert("slab_" + supportPos.getX() + "_" + supportPos.getZ(), "SLAB_IMPACT",
                            String.format(Locale.US, "Kolonsuz Açıklık Çöktü (L=%.1fm, %.1f kN)", clearSpanM, peakForceN / 1000.0),
                            supportPos, 0.80);
                }
            }
        }
    }

    private static void updateTunnelGeotechnics(ServerWorld world) {
        boolean raining = world.isRaining();
        boolean thundering = world.isThundering();
        int rainLvl = raining ? Math.max(1, ArenaContent.rainIntensity) : 0;
        int thunderLvl = thundering ? Math.max(1, ArenaContent.thunderIntensity) : 0;

        double maxUw = 0.0;
        double minFos = 9.9;
        int critZ = 800;

        BlockPos.Mutable mp = new BlockPos.Mutable();
        for (TunnelRingState ring : TUNNEL_RINGS) {
            // Station caverns (North z=16..48, South z=1562..1598) have heavy reinforced box sections
            boolean isStationBox = (ring.centerZ >= 16 && ring.centerZ <= 48) || (ring.centerZ >= 1562 && ring.centerZ <= 1598);
            boolean chunkLoaded = world.isChunkLoaded(-2, ring.cz);

            if (chunkLoaded) {
                int topY = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, -18, ring.centerZ);
                ring.coverDepthM = Math.max(3.0, topY - 53.0);
            }

            // Green-Ampt infiltration -> Pore-water pressure u_w (kPa): shallower cover saturates faster!
            double depthAtten = Math.max(0.25, Math.min(1.35, 14.0 / ring.coverDepthM));
            if (raining || thundering) {
                double targetUw = (16.0 * rainLvl + 11.0 * thunderLvl) * depthAtten;
                ring.poreWaterKpa = ring.poreWaterKpa + (targetUw - ring.poreWaterKpa) * 0.035;
            } else {
                ring.poreWaterKpa *= 0.975; // gradual drainage
            }
            maxUw = Math.max(maxUw, ring.poreWaterKpa);

            if (isStationBox) {
                ring.factorOfSafety = 2.85;
                continue;
            }

            // Geological weak seam factor (deterministic natural heterogeneity along the 1.55km rock mass)
            double seamWave = 0.86 + 0.18 * Math.sin(ring.centerZ * 0.037) * Math.cos(ring.centerZ * 0.013);
            double verticalStressKpa = (18.5 * ring.coverDepthM) * 0.26 // Terzaghi loosening rock arch factor (~0.26)
                    + ring.liveBoussinesqKpa + ring.trainDynamicKpa + ring.seismicKpa;

            // Mohr-Coulomb effective shear + masonry arch ring capacity
            double cohesionKpa = (112.0 * seamWave) * (1.0 - 0.52 * ring.fatigueDamage);
            double normalConfiningKpa = Math.max(25.0, 95.0 - 0.85 * ring.poreWaterKpa);
            double phiRad = Math.toRadians(31.0);
            double shearCapacityKpa = cohesionKpa + normalConfiningKpa * Math.tan(phiRad);

            double fos = shearCapacityKpa / Math.max(18.0, verticalStressKpa);
            ring.factorOfSafety = Math.max(0.45, Math.min(3.50, fos));

            if (ring.factorOfSafety < minFos) {
                minFos = ring.factorOfSafety;
                critZ = ring.centerZ;
            }

            // Progressive fatigue & settlement under low FoS (< 1.32)
            if (ring.factorOfSafety < 1.32) {
                ring.fatigueDamage = Math.min(1.0, ring.fatigueDamage + (1.32 - ring.factorOfSafety) * 0.025);
                ring.settlementMm = Math.min(42.0, ring.fatigueDamage * 38.0);
            }

            int desiredStage = ring.crackStage;
            if (ring.factorOfSafety < 0.98 || ring.fatigueDamage > 0.88) {
                desiredStage = Math.max(desiredStage, 2);
            } else if (ring.factorOfSafety < 1.28 || ring.fatigueDamage > 0.35) {
                desiredStage = Math.max(desiredStage, 1);
            }

            if (desiredStage != ring.crackStage) {
                ring.crackStage = desiredStage;
                if (desiredStage >= 2) {
                    setRingEmergencyLights(world, ring.cz, true);
                    ring.emergencyLedActive = true;
                }
                if (desiredStage >= 1) {
                    upsertAlert("ring_" + ring.cz,
                            desiredStage >= 2 ? "TUNNEL_COLLAPSE" : "TUNNEL_CRACK",
                            String.format(Locale.US, "Tünel Z=%dm %s (FoS=%.2f, u=%.0fkPa)",
                                    ring.centerZ, desiredStage >= 2 ? "Kemer Çökmesi" : "Kemer Çatlağı (Sarı Uyarı)",
                                    ring.factorOfSafety, ring.poreWaterKpa),
                            new BlockPos(-18, 52, ring.centerZ),
                            desiredStage >= 2 ? 0.95 : 0.65);
                }
                if (desiredStage >= 2 && chunkLoaded) {
                    triggerTunnelCrownSpall(world, ring);
                }
            } else if (ring.crackStage >= 2 && !ring.emergencyLedActive && chunkLoaded) {
                setRingEmergencyLights(world, ring.cz, true);
                ring.emergencyLedActive = true;
            }

            // Seepage water drips & stone dust in cracked loaded rings
            if (ring.crackStage >= 1 && chunkLoaded && (tickCounter % 20 == 0)) {
                world.spawnParticles(ParticleTypes.DRIPPING_WATER,
                        -18.0 + (world.random.nextDouble() - 0.5) * 3.0, 52.8,
                        ring.centerZ + (world.random.nextDouble() - 0.5) * 10.0,
                        4, 0.8, 0.05, 2.0, 0.0);
            }
        }

        latestMaxPoreWaterKpa = maxUw;
        latestMinTunnelFos = minFos;
        latestCriticalRingZ = critZ;
    }

    /**
     * Switches tunnel_emergency_light[emergency=true/false] in ring cz +/- 1 chunk so red blinking lights
     * are 100% visible BOTH from afar on the station platform AND inside the damaged tunnel sector!
     */
    public static void setRingEmergencyLights(ServerWorld world, int centerCz, boolean emergency) {
        BlockPos.Mutable mp = new BlockPos.Mutable();
        for (int cz = centerCz - 1; cz <= centerCz + 1; cz++) {
            if (!world.isChunkLoaded(-2, cz)) continue;
            int z0 = cz << 4;
            for (int lz = 0; lz < 16; lz++) {
                BlockPos p = new BlockPos(-18, 52, z0 + lz);
                BlockState st = world.getBlockState(p);
                if (st.isOf(ArenaContent.TUNNEL_EMERGENCY_LIGHT) && st.get(ArenaContent.EMERGENCY) != emergency) {
                    world.setBlockState(p, st.with(ArenaContent.EMERGENCY, emergency), Block.NOTIFY_LISTENERS);
                }
            }
        }
    }

    /**
     * Detaches 2-4 shoulder/crown masonry blocks from a failed tunnel ring as LIVE 6-DoF rigid bodies!
     * Strictly preserves mtr:rail, mtr:platform, and tunnel_emergency_light fixtures so alarms keep blinking!
     */
    public static void triggerTunnelCrownSpall(ServerWorld world, TunnelRingState ring) {
        int[][] offsets = { {-20, 52, -2}, {-16, 52, 1}, {-19, 53, 0}, {-17, 53, 3} };
        for (int[] off : offsets) {
            BlockPos bp = new BlockPos(off[0], off[1], ring.centerZ + off[2]);
            if (!world.isChunkLoaded(bp.getX() >> 4, bp.getZ() >> 4)) continue;
            BlockState st = world.getBlockState(bp);
            if (st.isAir() || isProtectedTransitBlock(st)) continue;
            ring.missingBlocks.add(bp.toImmutable());
            detachBlockAsLiveRigidBody(world, bp,
                    (world.random.nextDouble() - 0.5) * 1.1,
                    -0.35,
                    (world.random.nextDouble() - 0.5) * 1.1);
        }
        world.playSound(null, new BlockPos(-18, 52, ring.centerZ),
                SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.BLOCKS, 0.55f, 0.55f);
    }

    public static PhysicsRigidBody detachBlockAsLiveRigidBody(
            ServerWorld world, BlockPos bp, double vx, double vy, double vz
    ) {
        if (!world.isChunkLoaded(bp.getX() >> 4, bp.getZ() >> 4)) return null;
        BlockState st = world.getBlockState(bp);
        if (st.isAir() || isProtectedTransitBlock(st) || st.hasBlockEntity()) return null;

        world.setBlockState(bp, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);
        while (RIGID_BODIES.size() >= MAX_RIGID_BODIES) {
            RIGID_BODIES.remove(0);
        }
        double wx = (world.random.nextDouble() - 0.5) * 5.2;
        double wy = (world.random.nextDouble() - 0.5) * 3.4;
        double wz = (world.random.nextDouble() - 0.5) * 5.2;
        PhysicsRigidBody rb = new PhysicsRigidBody(bp, st, vx, vy, vz, wx, wy, wz);
        RIGID_BODIES.add(rb);
        return rb;
    }

    private static boolean isProtectedTransitBlock(BlockState st) {
        String id = Registries.BLOCK.getId(st.getBlock()).toString();
        return id.startsWith("mtr:") || id.startsWith("arena_ai_bridge:") || st.isOf(Blocks.BEDROCK);
    }

    /**
     * 80 Hz (4 sub-steps per server tick) 6-DoF OBB rigid-body dynamics with corner torque, bounce & friction!
     */
    private static void tickRigidBodies(ServerWorld world) {
        if (RIGID_BODIES.isEmpty()) return;
        final double dtSub = 0.05 / 4.0; // 12.5 ms per sub-step
        final double[][] unitCorners = {
                {-0.46, -0.46, -0.46}, {0.46, -0.46, -0.46}, {-0.46, 0.46, -0.46}, {0.46, 0.46, -0.46},
                {-0.46, -0.46,  0.46}, {0.46, -0.46,  0.46}, {-0.46, 0.46,  0.46}, {0.46, 0.46,  0.46}
        };
        Vector3f tmp = new Vector3f();
        BlockPos.Mutable mp = new BlockPos.Mutable();

        for (PhysicsRigidBody rb : RIGID_BODIES) {
            rb.prevPx = rb.px;
            rb.prevPy = rb.py;
            rb.prevPz = rb.pz;
            rb.prevQuat.set(rb.quat);
            rb.ageTicks++;
            if (rb.sleeping) continue;
            if (!world.isChunkLoaded(((int) Math.floor(rb.px)) >> 4, ((int) Math.floor(rb.pz)) >> 4)) continue;

            boolean impactedHard = false;
            for (int step = 0; step < 4; step++) {
                // Gravity + light air drag
                rb.vy -= 9.81 * dtSub;
                rb.vx *= 0.996;
                rb.vy *= 0.998;
                rb.vz *= 0.996;
                rb.wx *= 0.988;
                rb.wy *= 0.988;
                rb.wz *= 0.988;

                rb.px += rb.vx * dtSub;
                rb.py += rb.vy * dtSub;
                rb.pz += rb.vz * dtSub;

                // Quaternion angular velocity integration: dq = 0.5 * omega * q * dt
                float hdt = (float) (0.5 * dtSub);
                float qx = rb.quat.x, qy = rb.quat.y, qz = rb.quat.z, qw = rb.quat.w;
                float owx = (float) rb.wx, owy = (float) rb.wy, owz = (float) rb.wz;
                rb.quat.set(
                        qx + hdt * (owx * qw + owy * qz - owz * qy),
                        qy + hdt * (owy * qw + owz * qx - owx * qz),
                        qz + hdt * (owz * qw + owx * qy - owy * qx),
                        qw + hdt * (-owx * qx - owy * qy - owz * qz)
                ).normalize();

                // 8-corner OBB vs World Voxel Collision with rotational lever-arm impulse!
                for (double[] c : unitCorners) {
                    tmp.set((float) c[0], (float) c[1], (float) c[2]);
                    rb.quat.transform(tmp);
                    double cx = rb.px + tmp.x;
                    double cy = rb.py + tmp.y;
                    double cz = rb.pz + tmp.z;
                    int bx = (int) Math.floor(cx);
                    int by = (int) Math.floor(cy);
                    int bz = (int) Math.floor(cz);
                    if (!world.isChunkLoaded(bx >> 4, bz >> 4)) continue;
                    BlockState hitState = world.getBlockState(mp.set(bx, by, bz));
                    if (hitState.isAir() || hitState.getCollisionShape(world, mp).isEmpty()) continue;

                    // Determine actual top height of block (e.g. MTR platform / slab / rail vs full cube)
                    double boxTop = by + hitState.getCollisionShape(world, mp).getMax(Direction.Axis.Y);
                    if (cy > boxTop) continue;

                    // Minimum penetration axis out of [bx..bx+1, by..boxTop, bz..bz+1]
                    double penYTop = boxTop - cy;
                    double penXMin = cx - bx, penXMax = (bx + 1.0) - cx;
                    double penZMin = cz - bz, penZMax = (bz + 1.0) - cz;
                    double nx = 0, ny = 1, nz = 0;
                    double minPen = penYTop;
                    if (penXMin < minPen) { minPen = penXMin; nx = -1; ny = 0; nz = 0; }
                    if (penXMax < minPen) { minPen = penXMax; nx = 1;  ny = 0; nz = 0; }
                    if (penZMin < minPen) { minPen = penZMin; nx = 0;  ny = 0; nz = -1; }
                    if (penZMax < minPen) { minPen = penZMax; nx = 0;  ny = 0; nz = 1; }

                    // Positional Baumgarte projection
                    rb.px += nx * minPen * 0.65;
                    rb.py += ny * minPen * 0.65;
                    rb.pz += nz * minPen * 0.65;

                    double rx = tmp.x, ry = tmp.y, rz = tmp.z;
                    double vpx = rb.vx + (rb.wy * rz - rb.wz * ry);
                    double vpy = rb.vy + (rb.wz * rx - rb.wx * rz);
                    double vpz = rb.vz + (rb.wx * ry - rb.wy * rx);
                    double vn = vpx * nx + vpy * ny + vpz * nz;
                    if (vn < 0.0) {
                        if (vn < -2.4) impactedHard = true;
                        double rCrossNx = ry * nz - rz * ny;
                        double rCrossNy = rz * nx - rx * nz;
                        double rCrossNz = rx * ny - ry * nx;
                        double angTerm = rb.invInertia * (rCrossNx * rCrossNx + rCrossNy * rCrossNy + rCrossNz * rCrossNz);
                        double rest = (-vn < 0.85) ? 0.0 : rb.restitution;
                        double jn = -(1.0 + rest) * vn / (rb.invMass + angTerm);

                        rb.vx += (jn * nx) * rb.invMass;
                        rb.vy += (jn * ny) * rb.invMass;
                        rb.vz += (jn * nz) * rb.invMass;
                        rb.wx += (rCrossNx * jn) * rb.invInertia;
                        rb.wy += (rCrossNy * jn) * rb.invInertia;
                        rb.wz += (rCrossNz * jn) * rb.invInertia;

                        // Coulomb tangential friction impulse -> converts skid into realistic rolling torque!
                        double tx = vpx - vn * nx, ty = vpy - vn * ny, tz = vpz - vn * nz;
                        double tLen = Math.sqrt(tx * tx + ty * ty + tz * tz);
                        if (tLen > 1e-4) {
                            tx /= tLen; ty /= tLen; tz /= tLen;
                            double jt = -tLen / (rb.invMass + angTerm);
                            double maxJt = rb.friction * jn;
                            jt = Math.max(-maxJt, Math.min(maxJt, jt));
                            rb.vx += (jt * tx) * rb.invMass;
                            rb.vy += (jt * ty) * rb.invMass;
                            rb.vz += (jt * tz) * rb.invMass;
                            rb.wx += ((ry * tz - rz * ty) * jt) * rb.invInertia;
                            rb.wy += ((rz * tx - rx * tz) * jt) * rb.invInertia;
                            rb.wz += ((rx * ty - ry * tx) * jt) * rb.invInertia;
                        }
                    }
                }

                // Body-to-Body spherical core repulsion so fallen blocks stack & clatter against each other!
                for (PhysicsRigidBody other : RIGID_BODIES) {
                    if (other == rb) continue;
                    double dx = rb.px - other.px;
                    double dy = rb.py - other.py;
                    double dz = rb.pz - other.pz;
                    double d2 = dx * dx + dy * dy + dz * dz;
                    if (d2 > 1e-5 && d2 < 0.84 * 0.84) {
                        double d = Math.sqrt(d2);
                        double pen = 0.84 - d;
                        double nx = dx / d, ny = dy / d, nz = dz / d;
                        rb.px += nx * pen * 0.5;
                        rb.py += ny * pen * 0.5;
                        rb.pz += nz * pen * 0.5;
                        other.sleeping = false;
                        double rvx = rb.vx - other.vx, rvy = rb.vy - other.vy, rvz = rb.vz - other.vz;
                        double vn = rvx * nx + rvy * ny + rvz * nz;
                        if (vn < 0) {
                            double j = -0.6 * vn;
                            rb.vx += nx * j; rb.vy += ny * j; rb.vz += nz * j;
                            other.vx -= nx * j; other.vy -= ny * j; other.vz -= nz * j;
                        }
                    }
                }
            }

            if (impactedHard) {
                world.playSound(null, BlockPos.ofFloored(rb.px, rb.py, rb.pz),
                        rb.state.getSoundGroup().getFallSound(), SoundCategory.BLOCKS, 0.55f, 0.85f);
            }

            double speedSq = rb.vx * rb.vx + rb.vy * rb.vy + rb.vz * rb.vz;
            double rotSq = rb.wx * rb.wx + rb.wy * rb.wy + rb.wz * rb.wz;
            if (speedSq < 0.0025 && rotSq < 0.008) {
                rb.lowEnergyTicks++;
                if (rb.lowEnergyTicks > 18) {
                    rb.vx = rb.vy = rb.vz = 0.0;
                    rb.wx = rb.wy = rb.wz = 0.0;
                    rb.sleeping = true;
                }
            } else {
                rb.lowEnergyTicks = 0;
            }
        }
    }

    /**
     * Rotational P-Delta foundation tilt solver for multi-block buildings ("binalar eğrilcek").
     */
    private static void tickTiltingStructures(ServerWorld world) {
        if (TILTING_STRUCTURES.isEmpty()) return;
        final double dt = 0.05;
        boolean storm = world.isThundering() || world.isRaining();
        double windMomentScale = storm ? (1.0 + ArenaContent.rainIntensity * 0.5) : 0.15;
        double timeSec = tickCounter * 0.05;

        Iterator<TiltingStructureBody> it = TILTING_STRUCTURES.iterator();
        while (it.hasNext()) {
            TiltingStructureBody b = it.next();
            b.prevTiltXRad = b.tiltXRad;
            b.prevTiltZRad = b.tiltZRad;

            if (b.repairing) {
                // Hydraulic foundation jacking smoothly restores building back to 0.0° and re-locks blocks!
                b.tiltXRad *= 0.86;
                b.tiltZRad *= 0.86;
                b.plasticTiltXRad *= 0.86;
                b.plasticTiltZRad *= 0.86;
                if (Math.hypot(b.tiltXRad, b.tiltZRad) < 0.003) {
                    for (RelBlock rb : b.blocks) {
                        BlockPos wp = b.hinge.add(rb.dx(), rb.dy(), rb.dz());
                        if (world.isChunkLoaded(wp.getX() >> 4, wp.getZ() >> 4)) {
                            world.setBlockState(wp, rb.state(), Block.NOTIFY_ALL);
                        }
                    }
                    TILTING_STRUCTURES.remove(b);
                }
                continue;
            }

            // Rotational subgrade spring stiffness k_theta & damping c_theta + P-Delta overturning M = M_total*g*H*sin(theta)
            double kBase = b.rotationalInertia * 6.8 * Math.max(0.18, b.soilStiffnessFactor);
            double cDamp = 2.0 * 0.32 * Math.sqrt(kBase * b.rotationalInertia);
            double pDeltaTorqueX = b.totalMassKg * 9.81 * b.cmHeightMeters * Math.sin(b.tiltXRad);
            double pDeltaTorqueZ = b.totalMassKg * 9.81 * b.cmHeightMeters * Math.sin(b.tiltZRad);
            double gustTorqueX = b.totalMassKg * 0.65 * windMomentScale * Math.sin(timeSec * 1.7 + b.id);
            double gustTorqueZ = b.totalMassKg * 0.55 * windMomentScale * Math.cos(timeSec * 1.3 + b.id);

            double accX = (gustTorqueX + pDeltaTorqueX - cDamp * b.omegaX - kBase * (b.tiltXRad - b.plasticTiltXRad)) / b.rotationalInertia;
            double accZ = (gustTorqueZ + pDeltaTorqueZ - cDamp * b.omegaZ - kBase * (b.tiltZRad - b.plasticTiltZRad)) / b.rotationalInertia;

            b.omegaX += accX * dt;
            b.omegaZ += accZ * dt;
            b.tiltXRad = Math.max(-0.28, Math.min(0.28, b.tiltXRad + b.omegaX * dt)); // cap ~16°
            b.tiltZRad = Math.max(-0.28, Math.min(0.28, b.tiltZRad + b.omegaZ * dt));

            // Progressive plastic soil creep under storm saturation
            if (storm && Math.hypot(b.plasticTiltXRad, b.plasticTiltZRad) < 0.16) {
                b.plasticTiltXRad += Math.signum(b.plasticTiltXRad == 0 ? 1 : b.plasticTiltXRad) * 0.00025;
            }

            // Shed outer eave blocks as tumbling 6-DoF rigid bodies if drift > 9.5°!
            double totalDeg = Math.toDegrees(Math.hypot(b.tiltXRad, b.tiltZRad));
            if (totalDeg > 9.5 && b.spalledCount < 6 && (tickCounter % 35 == 0) && b.blocks.size() > 12) {
                RelBlock topMost = b.blocks.get(b.blocks.size() - 1);
                b.blocks.remove(topMost);
                b.spalledCount++;
                BlockPos approxPos = b.hinge.add(topMost.dx(), topMost.dy(), topMost.dz());
                while (RIGID_BODIES.size() >= MAX_RIGID_BODIES) RIGID_BODIES.remove(0);
                RIGID_BODIES.add(new PhysicsRigidBody(approxPos, topMost.state(),
                        Math.sin(b.tiltZRad) * 1.8, -0.4, Math.sin(b.tiltXRad) * 1.8, 2.4, 0.8, 2.1));
            }
        }
    }

    /**
     * Captures a small crafted timber/masonry surface structure near targetPos into a live TiltingStructureBody!
     */
    public static TiltingStructureBody maybeInitiateBuildingTiltNear(
            ServerWorld world, BlockPos searchOrigin, double initialPlasticRad
    ) {
        if (TILTING_STRUCTURES.size() >= 4) return null;
        BlockPos.Mutable mp = new BlockPos.Mutable();
        BlockPos seed = null;

        for (int r = 0; r <= 18 && seed == null; r += 2) {
            for (int dx = -r; dx <= r && seed == null; dx += 2) {
                for (int dz = -r; dz <= r && seed == null; dz += 2) {
                    int x = searchOrigin.getX() + dx, z = searchOrigin.getZ() + dz;
                    // Never capture station platform caverns (y < 60) — only surface structures (y >= 62)!
                    if (!world.isChunkLoaded(x >> 4, z >> 4)) continue;
                    for (int y = 63; y <= 76; y++) {
                        BlockState st = world.getBlockState(mp.set(x, y, z));
                        if (st.isIn(BlockTags.PLANKS) || st.isOf(Blocks.SPRUCE_LOG) || st.isOf(Blocks.DARK_OAK_LOG)) {
                            // Verify it's part of a crafted cabin (has roof stairs nearby, not a wild tree!)
                            boolean hasStairs = false;
                            for (int sy = y; sy <= y + 5 && !hasStairs; sy++) {
                                if (world.getBlockState(mp.set(x, sy, z)).isIn(BlockTags.WOODEN_STAIRS)) hasStairs = true;
                            }
                            if (hasStairs) {
                                seed = new BlockPos(x, y, z);
                                break;
                            }
                        }
                    }
                }
            }
        }
        if (seed == null) return null;

        // Avoid capturing an already-tilting building
        for (TiltingStructureBody ex : TILTING_STRUCTURES) {
            if (ex.hinge.isWithinDistance(seed, 14.0)) {
                ex.plasticTiltXRad = Math.min(0.19, ex.plasticTiltXRad + initialPlasticRad);
                ex.soilStiffnessFactor = Math.max(0.25, ex.soilStiffnessFactor - 0.18);
                return ex;
            }
        }

        // Collect crafted building blocks within 9x8x9 box around seed (y >= 65)
        int minY = 999, sumX = 0, sumZ = 0, cnt = 0;
        List<BlockPos> found = new ArrayList<>();
        for (int x = seed.getX() - 5; x <= seed.getX() + 5; x++) {
            for (int z = seed.getZ() - 5; z <= seed.getZ() + 5; z++) {
                if (!world.isChunkLoaded(x >> 4, z >> 4)) continue;
                for (int y = 65; y <= 74; y++) {
                    BlockPos p = new BlockPos(x, y, z);
                    BlockState st = world.getBlockState(p);
                    if (st.isAir() || isProtectedTransitBlock(st) || st.hasBlockEntity()) continue;
                    if (st.isIn(BlockTags.PLANKS) || st.isIn(BlockTags.WOODEN_STAIRS) || st.isIn(BlockTags.WOODEN_SLABS)
                            || st.isOf(Blocks.SPRUCE_LOG) || st.isOf(Blocks.DARK_OAK_LOG)
                            || st.isOf(Blocks.GLASS) || st.isOf(Blocks.GLASS_PANE) || st.isIn(BlockTags.FENCES)) {
                        found.add(p);
                        minY = Math.min(minY, y);
                        sumX += x;
                        sumZ += z;
                        cnt++;
                    }
                }
            }
        }
        if (cnt < 16 || cnt > 360) return null;

        BlockPos hinge = new BlockPos(sumX / cnt, minY, sumZ / cnt);
        List<RelBlock> rels = new ArrayList<>(found.size());
        double totalMass = 0.0, weightedY = 0.0;
        for (BlockPos p : found) {
            BlockState st = world.getBlockState(p);
            double m = estimateBlockMassKg(st);
            totalMass += m;
            weightedY += m * (p.getY() - minY + 0.5);
            rels.add(new RelBlock(p.getX() - hinge.getX(), p.getY() - hinge.getY(), p.getZ() - hinge.getZ(), st));
            world.setBlockState(p, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);
        }

        TiltingStructureBody body = new TiltingStructureBody(
                "Yüzey Yapısı (" + hinge.getX() + "," + hinge.getZ() + ")",
                hinge, rels, totalMass, weightedY / Math.max(1.0, totalMass)
        );
        body.plasticTiltXRad = initialPlasticRad;
        body.plasticTiltZRad = initialPlasticRad * 0.55;
        body.soilStiffnessFactor = 0.42;
        TILTING_STRUCTURES.add(body);

        upsertAlert("tilt_" + hinge.getX() + "_" + hinge.getZ(), "BUILDING_TILT",
                String.format(Locale.US, "Zemin Sıvılaşması / Bina Eğrilmesi (%.1f°)",
                        Math.toDegrees(Math.hypot(body.plasticTiltXRad, body.plasticTiltZRad))),
                hinge, 0.82);
        return body;
    }

    /**
     * Scans vertical columns around players and computes exact Euler P_cr & P-Delta DCR!
     */
    private static void scanNearbyColumns(ServerWorld world) {
        if (world.getPlayers().isEmpty()) return;
        ServerPlayerEntity anchor = world.getPlayers().get(0);
        BlockPos center = anchor.getBlockPos();
        BlockPos.Mutable mp = new BlockPos.Mutable();
        List<ColumnHealth> cols = new ArrayList<>();
        ColumnHealth nearest = null;
        double bestDistSq = Double.MAX_VALUE;

        for (int dx = -14; dx <= 14; dx += 2) {
            for (int dz = -14; dz <= 14; dz += 2) {
                int x = center.getX() + dx, z = center.getZ() + dz;
                if (!world.isChunkLoaded(x >> 4, z >> 4)) continue;
                for (int y = Math.max(48, center.getY() - 4); y <= center.getY() + 3; y++) {
                    BlockState st = world.getBlockState(mp.set(x, y, z));
                    if (!isColumnMaterial(st)) continue;
                    if (isColumnMaterial(world.getBlockState(mp.set(x, y - 1, z)))) continue; // find column base
                    int h = 1;
                    while (h < 14 && isColumnMaterial(world.getBlockState(mp.set(x, y + h, z)))) h++;
                    if (h < 3) continue;

                    // Compute Young's modulus E (GPa -> kN/m^2) and section inertia I = b^4 / 12 (m^4)
                    boolean timber = st.isIn(BlockTags.LOGS) || st.isIn(BlockTags.PLANKS);
                    double eKpa = timber ? 11_000_000.0 : 26_500_000.0;
                    double widthM = timber ? 0.45 : 0.85; // effective structural core width
                    double areaM2 = widthM * widthM;
                    double inertiaM4 = Math.pow(widthM, 4) / 12.0;
                    double rg = Math.sqrt(inertiaM4 / areaM2);
                    double kEff = 0.80; // fixed-base, braced-top frame column
                    double le = kEff * h;
                    double eulerPcrKn = (Math.PI * Math.PI * eKpa * inertiaM4) / (le * le);

                    // Tributary roof + overburden + pore-water axial load (kN)
                    double tributaryAreaM2 = 16.0;
                    double deadKn = tributaryAreaM2 * (y < 58 ? 48.0 : 12.5);
                    double stormWaterKn = world.isRaining() ? tributaryAreaM2 * 3.2 * Math.max(1, ArenaContent.rainIntensity) : 0.0;
                    double axialKn = deadKn + stormWaterKn + latestSurfaceImpulseKn * 0.45;
                    double ratio = Math.min(0.94, axialKn / Math.max(50.0, eulerPcrKn));
                    double b2 = 1.0 / (1.0 - ratio); // AISC P-Delta amplification factor
                    double dcr = ratio * b2;

                    ColumnHealth ch = new ColumnHealth();
                    ch.basePos = new BlockPos(x, y, z);
                    ch.material = timber ? "Ahşap Dikme" : "Kuvars/Taş Kolon";
                    ch.heightM = h;
                    ch.slenderness = le / rg;
                    ch.axialLoadKn = axialKn;
                    ch.eulerCriticalKn = eulerPcrKn;
                    ch.pDeltaFactor = b2;
                    ch.dcr = dcr;
                    ch.fos = 1.0 / Math.max(0.05, dcr);
                    cols.add(ch);

                    double dSq = ch.basePos.getSquaredDistance(center);
                    if (dSq < bestDistSq) {
                        bestDistSq = dSq;
                        nearest = ch;
                    }
                    break;
                }
            }
        }

        SCANNED_COLUMNS.clear();
        SCANNED_COLUMNS.addAll(cols);
        if (nearest != null) {
            latestNearestColumnDcr = nearest.dcr;
            latestNearestColumnFos = nearest.fos;
            latestNearestColumnHeight = nearest.heightM;
        }
    }

    private static boolean isColumnMaterial(BlockState st) {
        return st.isOf(Blocks.QUARTZ_PILLAR) || st.isOf(Blocks.SPRUCE_LOG) || st.isOf(Blocks.DARK_OAK_LOG)
                || st.isOf(Blocks.POLISHED_DEEPSLATE);
    }

    private static void upsertAlert(String id, String kind, String summary, BlockPos pos, double severity) {
        ACTIVE_ALERTS.removeIf(a -> a.id.equals(id));
        ACTIVE_ALERTS.add(0, new StructuralAlert(id, kind, summary, pos, severity));
        while (ACTIVE_ALERTS.size() > 8) {
            ACTIVE_ALERTS.remove(ACTIVE_ALERTS.size() - 1);
        }
    }

    /**
     * Engineering Repair ("/onar" or Co-Op repair with ArenaAI):
     * - Grouts & rock-bolts damaged tunnel rings within radius, restores missing crown masonry, resets emergency LEDs,
     * - Hydraulically jacks tilted buildings back to 0.0°, clears fallen rubble, and resets elevator brake faults!
     */
    public static int repairStructuralDamageNear(ServerWorld world, BlockPos center, double radius) {
        int repairedItems = 0;
        for (TunnelRingState ring : TUNNEL_RINGS) {
            if (Math.abs(ring.centerZ - center.getZ()) <= radius || radius >= 2000.0) {
                if (ring.crackStage > 0 || ring.fatigueDamage > 0.05 || !ring.missingBlocks.isEmpty()) {
                    for (BlockPos mp : ring.missingBlocks) {
                        if (world.isChunkLoaded(mp.getX() >> 4, mp.getZ() >> 4) && world.getBlockState(mp).isAir()) {
                            world.setBlockState(mp, Blocks.STONE_BRICKS.getDefaultState(), Block.NOTIFY_ALL);
                        }
                    }
                    ring.missingBlocks.clear();
                    ring.crackStage = 0;
                    ring.fatigueDamage = 0.0;
                    ring.settlementMm = 0.0;
                    ring.poreWaterKpa *= 0.25;
                    ring.factorOfSafety = 2.40;
                    ring.emergencyLedActive = false;
                    setRingEmergencyLights(world, ring.cz, false);
                    ACTIVE_ALERTS.removeIf(a -> a.id.equals("ring_" + ring.cz));
                    repairedItems++;
                }
            }
        }

        RIGID_BODIES.removeIf(rb -> rb.originPos.isWithinDistance(center, radius) || radius >= 2000.0);

        for (TiltingStructureBody b : TILTING_STRUCTURES) {
            if (b.hinge.isWithinDistance(center, radius) || radius >= 2000.0) {
                b.repairing = true;
                ACTIVE_ALERTS.removeIf(a -> a.pos.isWithinDistance(b.hinge, 8.0));
                repairedItems++;
            }
        }

        if (elevatorBrakeTripped && (elevatorFaultPos == null || elevatorFaultPos.isWithinDistance(center, radius) || radius >= 2000.0)) {
            elevatorBrakeTripped = false;
            elevatorFaultPos = null;
            ELEVATOR_JUMP_COUNTS.clear();
            ACTIVE_ALERTS.removeIf(a -> "ELEVATOR_BRAKE".equals(a.kind));
            repairedItems++;
        }

        if (repairedItems > 0) {
            world.playSound(null, center, SoundEvents.BLOCK_ANVIL_USE, SoundCategory.BLOCKS, 0.65f, 1.15f);
        }
        return repairedItems;
    }

    /**
     * Triggers a realistic scientific stress scenario near the player for testing or extreme storm surge!
     */
    public static String simulateScenario(ServerWorld world, BlockPos nearPos, String mode) {
        if ("cokme".equalsIgnoreCase(mode) || "catlak".equalsIgnoreCase(mode)) {
            // Pick nearest bore tunnel ring outside station box
            int targetZ = nearPos.getZ();
            if (targetZ >= 1555) targetZ = 1548;
            else if (targetZ <= 55) targetZ = 62;
            TunnelRingState ring = getRingForZ(targetZ);
            if (ring == null) ring = TUNNEL_RINGS[98];
            boolean collapse = "cokme".equalsIgnoreCase(mode);
            ring.poreWaterKpa = collapse ? 74.0 : 44.0;
            ring.fatigueDamage = collapse ? 0.92 : 0.45;
            ring.settlementMm = collapse ? 34.0 : 14.0;
            ring.factorOfSafety = collapse ? 0.84 : 1.24;
            ring.crackStage = collapse ? 2 : 1;
            if (collapse) {
                ring.emergencyLedActive = true;
                setRingEmergencyLights(world, ring.cz, true);
            }
            upsertAlert("ring_" + ring.cz,
                    collapse ? "TUNNEL_COLLAPSE" : "TUNNEL_CRACK",
                    String.format(Locale.US, "Tünel Z=%dm %s (FoS=%.2f)",
                            ring.centerZ, collapse ? "Kemer Çökmesi" : "Kemer Çatlağı (Sarı Uyarı)", ring.factorOfSafety),
                    new BlockPos(-18, 52, ring.centerZ), collapse ? 0.95 : 0.68);
            if (collapse) {
                triggerTunnelCrownSpall(world, ring);
            }
            return "Tünel Z=" + ring.centerZ + "m halkasında " + (collapse ? "Mohr-Coulomb çökmesi, kırmızı alarm ve 6-DoF kaya düşmesi" : "kılcal çatlak ve sarı uyarı") + " oluştu!";
        } else if ("bina".equalsIgnoreCase(mode) || "bina_egrilme".equalsIgnoreCase(mode)) {
            TiltingStructureBody b = maybeInitiateBuildingTiltNear(world, nearPos, 0.13);
            if (b != null) {
                return b.label + " temelinde P-Delta zemin dönmesi başladı (" + String.format(Locale.US, "%.1f°", Math.toDegrees(0.13)) + ")!";
            }
            return "Yakında uygun yüzey ahşap/taş bina bulunamadı (yüzey kabinlerinin yanına çıkıp dene).";
        }
        return "Bilinmeyen senaryo: " + mode;
    }

    /**
     * Full ArenaAI + Player Radar JSON telemetry (/map_api {"physics": ...}).
     */
    public static JsonObject handleApi(String bodyStr, MinecraftServer server) {
        JsonObject out = new JsonObject();
        try {
            if (bodyStr != null && !bodyStr.isBlank()) {
                JsonObject req = JsonParser.parseString(bodyStr).getAsJsonObject();
                if (req.has("physics") && req.get("physics").isJsonObject()) {
                    req = req.getAsJsonObject("physics");
                }
                String op = req.has("op") ? req.get("op").getAsString() : "radar";
                ServerWorld world = server != null ? server.getOverworld() : null;
                if ("simulate".equalsIgnoreCase(op) && world != null) {
                    int x = req.has("x") ? req.get("x").getAsInt() : -18;
                    int y = req.has("y") ? req.get("y").getAsInt() : 52;
                    int z = req.has("z") ? req.get("z").getAsInt() : 1548;
                    String mode = req.has("mode") ? req.get("mode").getAsString() : "cokme";
                    CompletableFutureHolder.runSync(server, () -> simulateScenario(world, new BlockPos(x, y, z), mode));
                } else if ("repair".equalsIgnoreCase(op) && world != null) {
                    double rad = req.has("radius") ? req.get("radius").getAsDouble() : 2500.0;
                    int x = req.has("x") ? req.get("x").getAsInt() : -18;
                    int y = req.has("y") ? req.get("y").getAsInt() : 52;
                    int z = req.has("z") ? req.get("z").getAsInt() : 1548;
                    CompletableFutureHolder.runSync(server, () -> repairStructuralDamageNear(world, new BlockPos(x, y, z), rad));
                }
            }
        } catch (Throwable ignored) {}

        out.addProperty("ok", true);
        out.addProperty("minTunnelFos", Math.round(latestMinTunnelFos * 100.0) / 100.0);
        out.addProperty("criticalRingZ", latestCriticalRingZ);
        out.addProperty("maxPoreWaterKpa", Math.round(latestMaxPoreWaterKpa * 10.0) / 10.0);
        out.addProperty("nearestColumnDcr", Math.round(latestNearestColumnDcr * 1000.0) / 1000.0);
        out.addProperty("nearestColumnFos", Math.round(latestNearestColumnFos * 100.0) / 100.0);
        out.addProperty("surfaceImpulseKn", Math.round(latestSurfaceImpulseKn * 100.0) / 100.0);
        out.addProperty("trainRollDeg", Math.round(clientTrainRollDeg * 100.0) / 100.0);
        out.addProperty("sperlingWz", Math.round(clientSperlingWz * 100.0) / 100.0);
        out.addProperty("activeRigidBodies", RIGID_BODIES.size());
        out.addProperty("tiltingStructures", TILTING_STRUCTURES.size());
        out.addProperty("elevatorBrakeTripped", elevatorBrakeTripped);

        JsonArray alertsArr = new JsonArray();
        for (StructuralAlert a : ACTIVE_ALERTS) {
            JsonObject ao = new JsonObject();
            ao.addProperty("id", a.id);
            ao.addProperty("kind", a.kind);
            ao.addProperty("summary", a.summary);
            ao.addProperty("x", a.pos.getX());
            ao.addProperty("y", a.pos.getY());
            ao.addProperty("z", a.pos.getZ());
            ao.addProperty("severity", a.severity);
            alertsArr.add(ao);
        }
        out.add("alerts", alertsArr);
        return out;
    }

    private static final class CompletableFutureHolder {
        static void runSync(MinecraftServer srv, Runnable r) {
            if (srv == null) return;
            java.util.concurrent.CompletableFuture<Void> cf = new java.util.concurrent.CompletableFuture<>();
            srv.execute(() -> {
                try { r.run(); } finally { cf.complete(null); }
            });
            try { cf.get(3, java.util.concurrent.TimeUnit.SECONDS); } catch (Throwable ignored) {}
        }
    }
}

package ai.arena.bridge.board;

import ai.arena.bridge.ArenaContent;
import ai.arena.bridge.map.ArenaMapData;
import ai.arena.bridge.physics.GeoStructuralPhysicsEngine;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.entity.BlockEntityRenderer;
import net.minecraft.client.render.block.entity.BlockEntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Direction;
import org.joml.Matrix4f;

import java.util.List;
import java.util.Locale;

/**
 * Fixed SCADA Structural Integrity Map Renderer (v7.7.0):
 * - Replaces legacy rotating slides on transit_news_board with a permanent, real-time
 *   "YAPISAL BÜTÜNLÜK HARİTASI" driven directly by GeoStructuralPhysicsEngine.TUNNEL_RINGS.
 * - Automatically orients the M1 tunnel horizontally (facing EAST/WEST, parallel to tunnel)
 *   or vertically (facing NORTH/SOUTH, perpendicular to tunnel).
 * - Renders 24 engineered tunnel sectors:
 *     0 = Solid Emerald Green (Intact / Safe)
 *     1 = Blinking Amber-Yellow (Moderate Stress / Micro-Crack Warning)
 *     2 = Blinking Vivid Red (Critical Crack / Collapse Danger — "Yapısal Bütünlük Tehlikede!")
 */
public class TransitNewsBoardRenderer implements BlockEntityRenderer<ArenaContent.TransitNewsBoardBlockEntity> {

    private static final int SECTOR_COUNT = 24;
    private static final double TUNNEL_Z_NORTH = 32.0;
    private static final double TUNNEL_Z_SOUTH = 1580.0;

    public TransitNewsBoardRenderer(BlockEntityRendererFactory.Context ctx) {
    }

    @Override
    public int getRenderDistance() {
        return 96;
    }

    @Override
    public boolean rendersOutsideBoundingBox(ArenaContent.TransitNewsBoardBlockEntity blockEntity) {
        return true;
    }

    @Override
    public void render(
            ArenaContent.TransitNewsBoardBlockEntity entity,
            float tickDelta,
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            int light,
            int overlay
    ) {
        if (entity == null || entity.getWorld() == null) return;
        BlockState state = entity.getCachedState();
        if (!state.isOf(ArenaContent.TRANSIT_NEWS_BOARD)) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null) return;

        Direction facing = state.get(ArenaContent.FACING);
        boolean horizontal = (facing == Direction.EAST || facing == Direction.WEST);
        // When facing EAST, viewer looks West (-X): viewer's left is +Z (South/Güney) and right is -Z (North/Kuzey)
        boolean leftIsSouth = (facing == Direction.EAST);

        int fullBright = 0xF000F0;
        long nowMs = System.currentTimeMillis();
        long worldTick = entity.getWorld().getTime();
        // Red strobe synced with 20-tick (1.0s) emergency tunnel LED & .ogg alarm phase, plus crisp 2.5 Hz yellow blink
        boolean blinkRedOn = (worldTick % 20L) < 10L;
        boolean blinkYellowOn = ((nowMs / 260L) % 2L) == 0L;

        // Sample 24 sectors across Z = 32 .. 1580 from GeoStructuralPhysicsEngine.TUNNEL_RINGS
        int[] sectorSev = new int[SECTOR_COUNT]; // 0 = green, 1 = yellow blink, 2 = red blink
        double[] sectorMinFos = new double[SECTOR_COUNT];
        int worstSev = 0;
        double globalMinFos = 9.99;
        int worstSectorZ = 800;

        double spanZ = TUNNEL_Z_SOUTH - TUNNEL_Z_NORTH;
        for (int s = 0; s < SECTOR_COUNT; s++) {
            double z0 = TUNNEL_Z_NORTH + (spanZ * s) / SECTOR_COUNT;
            double z1 = TUNNEL_Z_NORTH + (spanZ * (s + 1)) / SECTOR_COUNT;
            int cz0 = Math.max(GeoStructuralPhysicsEngine.RING_MIN_CZ, ((int) Math.floor(z0)) >> 4);
            int cz1 = Math.min(GeoStructuralPhysicsEngine.RING_MAX_CZ, ((int) Math.floor(z1)) >> 4);

            int sev = 0;
            double sFos = 2.50;
            for (int cz = cz0; cz <= cz1; cz++) {
                int rIdx = cz - GeoStructuralPhysicsEngine.RING_MIN_CZ;
                if (rIdx < 0 || rIdx >= GeoStructuralPhysicsEngine.RING_COUNT) continue;
                GeoStructuralPhysicsEngine.TunnelRingState ring = GeoStructuralPhysicsEngine.TUNNEL_RINGS[rIdx];
                if (ring == null) continue;
                if (ring.factorOfSafety < sFos) {
                    sFos = ring.factorOfSafety;
                }
                int rSev = 0;
                if (ring.crackStage >= 2 || ring.factorOfSafety < 1.08
                        || (ring.crackStage >= 1 && ring.factorOfSafety < 1.16)) {
                    rSev = 2;
                } else if (ring.crackStage == 1 || ring.factorOfSafety < 1.55 || ring.fatigueDamage >= 0.22) {
                    rSev = 1;
                }
                if (rSev > sev) {
                    sev = rSev;
                }
            }
            sectorSev[s] = sev;
            sectorMinFos[s] = sFos;
            if (sFos < globalMinFos) {
                globalMinFos = sFos;
            }
            if (sev > worstSev || (sev == worstSev && sev > 0 && sFos <= globalMinFos + 0.02)) {
                worstSev = sev;
                worstSectorZ = (int) Math.round((z0 + z1) * 0.5);
            }
        }
        if (globalMinFos > 9.0) {
            globalMinFos = GeoStructuralPhysicsEngine.latestMinTunnelFos;
        }
        if (!GeoStructuralPhysicsEngine.ACTIVE_ALERTS.isEmpty() && worstSev == 0) {
            worstSev = 1;
        }

        List<ArenaMapData.LiveTrainInfo> trains = ArenaMapData.getLiveTrains();

        matrices.push();
        WorldMapBoardRenderer.orientToWallFace(matrices, facing, 0.398f);

        // =========================================================================
        // PASS 1: Emit ALL RenderLayer.getGui() quads BEFORE any drawWallText calls
        // =========================================================================
        VertexConsumer vc = vertexConsumers.getBuffer(RenderLayer.getGui());
        Matrix4f mat = matrices.peek().getPositionMatrix();

        // Dark SCADA background inside titanium bezel (x in [-0.465, +0.465], y in [-0.348, +0.348])
        WorldMapBoardRenderer.quad(vc, mat, -0.465f, -0.348f, 0.465f, 0.348f, 0.0f, 0xFF0E141B);
        // Subtle inner engineering border
        WorldMapBoardRenderer.quad(vc, mat, -0.458f, -0.341f, 0.458f, -0.338f, 0.0004f, 0xFF1E293B);
        WorldMapBoardRenderer.quad(vc, mat, -0.458f, 0.252f, 0.458f, 0.342f, 0.0005f, 0xFF17212E);

        int headerAccent = (worstSev == 2)
                ? (blinkRedOn ? 0xFFFF2E2E : 0xFF8A1C1C)
                : (worstSev == 1 ? (blinkYellowOn ? 0xFFFACC15 : 0xFF85680A) : 0xFF10B981);
        WorldMapBoardRenderer.quad(vc, mat, -0.458f, 0.248f, 0.458f, 0.253f, 0.0009f, headerAccent);

        if (horizontal) {
            // HORIZONTAL TUNNEL SCHEMATIC (x in [-0.365, +0.365], y in [0.025, 0.105])
            float barL = -0.365f;
            float barR = 0.365f;
            float barB = 0.025f;
            float barT = 0.105f;
            float midY = (barB + barT) * 0.5f;

            // Tunnel concrete liner rails (top & bottom walls)
            WorldMapBoardRenderer.quad(vc, mat, barL - 0.008f, barB - 0.012f, barR + 0.008f, barT + 0.012f, 0.0006f, 0xFF1E293B);
            WorldMapBoardRenderer.quad(vc, mat, barL - 0.004f, barT + 0.004f, barR + 0.004f, barT + 0.010f, 0.0010f, 0xFF475569);
            WorldMapBoardRenderer.quad(vc, mat, barL - 0.004f, barB - 0.010f, barR + 0.004f, barB - 0.004f, 0.0010f, 0xFF475569);

            float totalW = barR - barL;
            float stepW = totalW / SECTOR_COUNT;
            for (int i = 0; i < SECTOR_COUNT; i++) {
                // Map visual slot i (left->right) to physical sector s (0=North Z=32 .. 23=South Z=1580)
                int s = leftIsSouth ? (SECTOR_COUNT - 1 - i) : i;
                int sev = sectorSev[s];
                float sx0 = barL + i * stepW + 0.0025f;
                float sx1 = barL + (i + 1) * stepW - 0.0025f;

                int segCol = colorForSeverity(sev, blinkRedOn, blinkYellowOn);
                WorldMapBoardRenderer.quad(vc, mat, sx0, barB, sx1, barT, 0.0014f, segCol);

                // Blinking outer halo bracket on damaged sectors
                if (sev == 2 && blinkRedOn) {
                    WorldMapBoardRenderer.quad(vc, mat, sx0 - 0.003f, barB - 0.020f, sx1 + 0.003f, barT + 0.020f, 0.0008f, 0x88FF1E1E);
                } else if (sev == 1 && blinkYellowOn) {
                    WorldMapBoardRenderer.quad(vc, mat, sx0 - 0.002f, barB - 0.015f, sx1 + 0.002f, barT + 0.015f, 0.0008f, 0x77FACC15);
                }
            }

            // Station terminal nodes at Left & Right ends
            for (float nx : new float[]{barL - 0.026f, barR + 0.026f}) {
                WorldMapBoardRenderer.quad(vc, mat, nx - 0.020f, midY - 0.024f, nx + 0.020f, midY + 0.024f, 0.0018f, 0xFFE2E8F0);
                WorldMapBoardRenderer.quad(vc, mat, nx - 0.011f, midY - 0.014f, nx + 0.011f, midY + 0.014f, 0.0021f, 0xFF0F172A);
            }

            // Live train marker along horizontal tunnel
            if (!trains.isEmpty()) {
                ArenaMapData.LiveTrainInfo t = trains.get(0);
                double fracNorthToSouth = clamp01d((t.z - TUNNEL_Z_NORTH) / spanZ);
                double visFrac = leftIsSouth ? (1.0 - fracNorthToSouth) : fracNorthToSouth;
                float tx = (float) (barL + totalW * visFrac);
                WorldMapBoardRenderer.quad(vc, mat, tx - 0.014f, midY - 0.016f, tx + 0.014f, midY + 0.016f, 0.0025f, 0xFFFFFFFF);
                WorldMapBoardRenderer.quad(vc, mat, tx - 0.009f, midY - 0.011f, tx + 0.009f, midY + 0.011f, 0.0028f, 0xFF38BDF8);
            }

            // Bottom telemetry card background
            WorldMapBoardRenderer.quad(vc, mat, -0.442f, -0.320f, 0.442f, -0.072f, 0.0006f, 0xFF141D29);
            WorldMapBoardRenderer.quad(vc, mat, -0.442f, -0.076f, 0.442f, -0.072f, 0.0010f, headerAccent);
        } else {
            // VERTICAL TUNNEL SCHEMATIC (facing NORTH/SOUTH: tunnel runs top -> bottom)
            float colL = -0.365f;
            float colR = -0.275f;
            float colT = 0.195f;
            float colB = -0.275f;
            float midX = (colL + colR) * 0.5f;

            WorldMapBoardRenderer.quad(vc, mat, colL - 0.012f, colB - 0.008f, colR + 0.012f, colT + 0.008f, 0.0006f, 0xFF1E293B);
            WorldMapBoardRenderer.quad(vc, mat, colL - 0.010f, colB - 0.004f, colL - 0.004f, colT + 0.004f, 0.0010f, 0xFF475569);
            WorldMapBoardRenderer.quad(vc, mat, colR + 0.004f, colB - 0.004f, colR + 0.010f, colT + 0.004f, 0.0010f, 0xFF475569);

            float totalH = colT - colB;
            float stepH = totalH / SECTOR_COUNT;
            for (int s = 0; s < SECTOR_COUNT; s++) {
                // s = 0 at top (Kuzey Z=32), s = 23 at bottom (Güney Z=1580)
                int sev = sectorSev[s];
                float sy1 = colT - s * stepH - 0.0020f;
                float sy0 = colT - (s + 1) * stepH + 0.0020f;

                int segCol = colorForSeverity(sev, blinkRedOn, blinkYellowOn);
                WorldMapBoardRenderer.quad(vc, mat, colL, sy0, colR, sy1, 0.0014f, segCol);

                if (sev == 2 && blinkRedOn) {
                    WorldMapBoardRenderer.quad(vc, mat, colL - 0.020f, sy0 - 0.002f, colR + 0.020f, sy1 + 0.002f, 0.0008f, 0x88FF1E1E);
                } else if (sev == 1 && blinkYellowOn) {
                    WorldMapBoardRenderer.quad(vc, mat, colL - 0.015f, sy0 - 0.002f, colR + 0.015f, sy1 + 0.002f, 0.0008f, 0x77FACC15);
                }
            }

            // Top (Kuzey) & Bottom (Güney) station nodes
            for (float ny : new float[]{colT + 0.022f, colB - 0.022f}) {
                WorldMapBoardRenderer.quad(vc, mat, midX - 0.024f, ny - 0.016f, midX + 0.024f, ny + 0.016f, 0.0018f, 0xFFE2E8F0);
                WorldMapBoardRenderer.quad(vc, mat, midX - 0.013f, ny - 0.009f, midX + 0.013f, ny + 0.009f, 0.0021f, 0xFF0F172A);
            }

            if (!trains.isEmpty()) {
                ArenaMapData.LiveTrainInfo t = trains.get(0);
                double fracNorthToSouth = clamp01d((t.z - TUNNEL_Z_NORTH) / spanZ);
                float ty = (float) (colT - totalH * fracNorthToSouth);
                WorldMapBoardRenderer.quad(vc, mat, midX - 0.017f, ty - 0.012f, midX + 0.017f, ty + 0.012f, 0.0025f, 0xFFFFFFFF);
                WorldMapBoardRenderer.quad(vc, mat, midX - 0.011f, ty - 0.008f, midX + 0.011f, ty + 0.008f, 0.0028f, 0xFF38BDF8);
            }

            // Right-hand telemetry panel card
            WorldMapBoardRenderer.quad(vc, mat, -0.195f, -0.310f, 0.442f, 0.215f, 0.0006f, 0xFF141D29);
            WorldMapBoardRenderer.quad(vc, mat, -0.195f, 0.211f, 0.442f, 0.215f, 0.0010f, headerAccent);
        }

        // =========================================================================
        // PASS 2: Crisp Bezel-Safe Typography
        // =========================================================================
        TextRenderer tr = mc.textRenderer;
        if (tr != null) {
            String title = "YAPISAL BÜTÜNLÜK HARİTASI";
            String modeTag = horizontal ? "YATAY KESİT" : "DİKEY KESİT";
            WorldMapBoardRenderer.drawWallText(matrices, vertexConsumers, tr, title, -0.440f, 0.314f,
                    WorldMapBoardRenderer.fitScale(tr, title, 0.66f, 0.0031f), 0xFFF8FAFC, fullBright);
            WorldMapBoardRenderer.drawWallText(matrices, vertexConsumers, tr, modeTag, 0.245f, 0.312f,
                    WorldMapBoardRenderer.fitScale(tr, modeTag, 0.20f, 0.0025f), 0xFF94A3B8, fullBright);

            String statusText;
            int statusCol;
            if (worstSev == 2) {
                statusText = "YAPISAL BÜTÜNLÜK TEHLİKEDE!";
                statusCol = blinkRedOn ? 0xFFFF4444 : 0xFFFFB4B4;
            } else if (worstSev == 1) {
                statusText = "SARI UYARI: TÜNEL GERİLME / ÇATLAK RİSKİ";
                statusCol = blinkYellowOn ? 0xFFFACC15 : 0xFFFef08a;
            } else {
                statusText = "YAPISAL BÜTÜNLÜK: TÜM HAT GÜVENLİ";
                statusCol = 0xFF4ADE80;
            }

            String metrics = String.format(Locale.US, "Min FoS: %.2f  •  Boşluk Suyu: %.0f kPa  •  Kolon DCR: %.2f",
                    globalMinFos,
                    GeoStructuralPhysicsEngine.latestMaxPoreWaterKpa,
                    GeoStructuralPhysicsEngine.latestNearestColumnDcr);

            String detail = (worstSev >= 1)
                    ? String.format(Locale.US, "Hasar Bölgesi: Z=%d m (%s) • R Radar / /onar",
                            worstSectorZ, worstSev == 2 ? "Kırmızı Acil" : "Sarı Uyarı")
                    : "Yeşil: Sağlam  •  Sarı Yanıp Sönen: Çatlak  •  Kırmızı: Çökme";

            if (horizontal) {
                String leftLbl = leftIsSouth ? "GÜNEY ORMAN (Z=1580)" : "KUZEY ORMAN (Z=32)";
                String rightLbl = leftIsSouth ? "KUZEY ORMAN (Z=32)" : "GÜNEY ORMAN (Z=1580)";
                WorldMapBoardRenderer.drawWallText(matrices, vertexConsumers, tr, leftLbl, -0.438f, 0.175f,
                        WorldMapBoardRenderer.fitScale(tr, leftLbl, 0.36f, 0.0024f), 0xFFCBD5E1, fullBright);
                float rScale = WorldMapBoardRenderer.fitScale(tr, rightLbl, 0.36f, 0.0024f);
                float rW = tr.getWidth(rightLbl) * rScale;
                WorldMapBoardRenderer.drawWallText(matrices, vertexConsumers, tr, rightLbl, 0.438f - rW, 0.175f,
                        rScale, 0xFFCBD5E1, fullBright);
                WorldMapBoardRenderer.drawWallText(matrices, vertexConsumers, tr, "ORTA HAT (Z=806m)", -0.095f, -0.008f,
                        0.0021f, 0xFF64748B, fullBright);

                WorldMapBoardRenderer.drawWallText(matrices, vertexConsumers, tr, statusText, -0.422f, -0.105f,
                        WorldMapBoardRenderer.fitScale(tr, statusText, 0.84f, 0.0032f), statusCol, fullBright);
                WorldMapBoardRenderer.drawWallText(matrices, vertexConsumers, tr, metrics, -0.422f, -0.192f,
                        WorldMapBoardRenderer.fitScale(tr, metrics, 0.84f, 0.0025f), 0xFFE2E8F0, fullBright);
                WorldMapBoardRenderer.drawWallText(matrices, vertexConsumers, tr, detail, -0.422f, -0.268f,
                        WorldMapBoardRenderer.fitScale(tr, detail, 0.84f, 0.0023f), 0xFF94A3B8, fullBright);
            } else {
                // Vertical layout labels & right-side telemetry
                WorldMapBoardRenderer.drawWallText(matrices, vertexConsumers, tr, "KUZEY (Z=32)", -0.175f, 0.182f,
                        0.0024f, 0xFFCBD5E1, fullBright);
                WorldMapBoardRenderer.drawWallText(matrices, vertexConsumers, tr, statusText, -0.175f, 0.085f,
                        WorldMapBoardRenderer.fitScale(tr, statusText, 0.59f, 0.0028f), statusCol, fullBright);
                WorldMapBoardRenderer.drawWallText(matrices, vertexConsumers, tr,
                        String.format(Locale.US, "Min Güvenlik (FoS): %.2f", globalMinFos), -0.175f, -0.005f,
                        0.0024f, 0xFFE2E8F0, fullBright);
                WorldMapBoardRenderer.drawWallText(matrices, vertexConsumers, tr,
                        String.format(Locale.US, "Boşluk Suyu u_w: %.0f kPa", GeoStructuralPhysicsEngine.latestMaxPoreWaterKpa),
                        -0.175f, -0.075f, 0.0024f, 0xFFE2E8F0, fullBright);
                WorldMapBoardRenderer.drawWallText(matrices, vertexConsumers, tr, detail, -0.175f, -0.155f,
                        WorldMapBoardRenderer.fitScale(tr, detail, 0.59f, 0.0022f), 0xFF94A3B8, fullBright);
                WorldMapBoardRenderer.drawWallText(matrices, vertexConsumers, tr, "GÜNEY (Z=1580)", -0.175f, -0.255f,
                        0.0024f, 0xFFCBD5E1, fullBright);
            }
        }

        matrices.pop();
    }

    private static int colorForSeverity(int sev, boolean blinkRedOn, boolean blinkYellowOn) {
        if (sev >= 2) {
            return blinkRedOn ? 0xFFFF2424 : 0xFF4C0909;
        }
        if (sev == 1) {
            return blinkYellowOn ? 0xFFFACC15 : 0xFF4F3D08;
        }
        return 0xFF10B981;
    }

    private static double clamp01d(double v) {
        return v < 0.0 ? 0.0 : (v > 1.0 ? 1.0 : v);
    }
}

package ai.arena.bridge.board;

import ai.arena.bridge.ArenaContent;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.entity.BlockEntityRenderer;
import net.minecraft.client.render.block.entity.BlockEntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Direction;
import org.joml.Matrix4f;

import java.util.List;

/**
 * Scalable Multi-Block Display & Highway Gantry Sign Renderer (1x1 up to 8x4 meters!):
 * Renders seamless chassis + themed vector sign face + crisp auto-fitted Turkish typography.
 */
public class ProgrammableBoardRenderer implements BlockEntityRenderer<ArenaContent.ProgrammableBoardBlockEntity> {

    public ProgrammableBoardRenderer(BlockEntityRendererFactory.Context ctx) {}

    @Override
    public int getRenderDistance() {
        return 144; // Highway gantries & large plaza boards visible from 144 meters away!
    }

    @Override
    public boolean rendersOutsideBoundingBox(ArenaContent.ProgrammableBoardBlockEntity blockEntity) {
        return true;
    }

    @Override
    public void render(
            ArenaContent.ProgrammableBoardBlockEntity entity,
            float tickDelta,
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            int light,
            int overlay
    ) {
        if (entity.getWorld() == null) return;
        BlockState state = entity.getCachedState();
        if (!state.isOf(ArenaContent.PROGRAMMABLE_BOARD)) return;

        ProgrammableBoardManager.BoardSpec spec = ProgrammableBoardManager.resolve(entity.boardId);
        int wBlocks = entity.customWidth > 0 ? entity.customWidth : spec.widthBlocks;
        int hBlocks = entity.customHeight > 0 ? entity.customHeight : spec.heightBlocks;
        String theme = (entity.customTheme != null && !entity.customTheme.isBlank()) ? entity.customTheme : spec.theme;

        Direction facing = state.get(ArenaContent.FACING);
        ArenaContent.BoardMount mount = state.get(ArenaContent.BOARD_MOUNT);
        float depthFromCenter = switch (mount) {
            case WALL -> 0.395f;
            case STAND -> 0.095f;
            case POSTER -> 0.110f;
            case GANTRY -> -0.105f;
        };

        // Anchor block sits at bottom-center (for odd W) or bottom-left-center of the W x H span
        float totalW = Math.max(0.88f, wBlocks - 0.10f);
        float totalH = Math.max(0.84f, hBlocks - 0.12f);
        float xL = -totalW * 0.5f;
        float xR = totalW * 0.5f;
        float yB = (mount == ArenaContent.BoardMount.STAND) ? -0.14f : -0.44f;
        float yT = yB + totalH;

        int bgCol, headerCol, borderCol, badgeBgCol, titleCol, bodyCol, footerCol;
        switch (theme) {
            case "highway_green" -> {
                bgCol = 0xFF005C34;
                headerCol = 0xFF004828;
                borderCol = 0xFFF5F5F5;
                badgeBgCol = 0xFFE65100; // O-7 motorway orange shield!
                titleCol = 0xFFFFFFFF;
                bodyCol = 0xFFFFFFFF;
                footerCol = 0xFFC8E6C9;
            }
            case "highway_blue" -> {
                bgCol = 0xFF004684;
                headerCol = 0xFF003566;
                borderCol = 0xFFF5F5F5;
                badgeBgCol = 0xFF00796B;
                titleCol = 0xFFFFFFFF;
                bodyCol = 0xFFFFFFFF;
                footerCol = 0xFFBBDEFB;
            }
            case "warning_amber" -> {
                bgCol = 0xFF121212;
                headerCol = 0xFF1E1A10;
                borderCol = 0xFFFFB300;
                badgeBgCol = 0xFFD84315;
                titleCol = 0xFFFFCA28;
                bodyCol = 0xFFFFE082;
                footerCol = 0xFFFF8A65;
            }
            default -> {
                bgCol = 0xFF131920;
                headerCol = 0xFF1D2733;
                borderCol = 0xFF00ACC1;
                badgeBgCol = 0xFF00897B;
                titleCol = 0xFFF5F5F5;
                bodyCol = 0xFFE0F2F1;
                footerCol = 0xFF80DEEA;
            }
        }

        int fullBright = 0xF000F0;
        MinecraftClient mc = MinecraftClient.getInstance();
        TextRenderer tr = mc.textRenderer;

        matrices.push();
        WorldMapBoardRenderer.orientToWallFace(matrices, facing, depthFromCenter);

        // PASS 1: Emit ALL RenderLayer.getGui() quads FIRST (chassis backing, sign face, reflective border, header, badge)
        VertexConsumer vc = vertexConsumers.getBuffer(RenderLayer.getGui());
        Matrix4f mat = matrices.peek().getPositionMatrix();

        // Outer metallic housing
        WorldMapBoardRenderer.quad(vc, mat, xL - 0.03f, yB - 0.03f, xR + 0.03f, yT + 0.03f, -0.004f, 0xFF1E2229);
        // Reflective border & inner sign background
        WorldMapBoardRenderer.quad(vc, mat, xL, yB, xR, yT, 0.0f, borderCol);
        float bw = Math.min(0.025f, totalW * 0.015f);
        WorldMapBoardRenderer.quad(vc, mat, xL + bw, yB + bw, xR - bw, yT - bw, 0.0006f, bgCol);

        float headerH = Math.min(0.26f, totalH * 0.22f);
        float headerBottom = yT - bw - headerH;
        WorldMapBoardRenderer.quad(vc, mat, xL + bw, headerBottom, xR - bw, yT - bw, 0.0011f, headerCol);
        WorldMapBoardRenderer.quad(vc, mat, xL + bw, headerBottom - 0.008f, xR - bw, headerBottom, 0.0014f, borderCol);

        float badgeW = 0.0f;
        if (spec.badge != null && !spec.badge.isBlank()) {
            badgeW = Math.min(totalW * 0.22f, headerH * 1.85f);
            WorldMapBoardRenderer.quad(vc, mat, xL + bw + 0.02f, headerBottom + 0.02f,
                    xL + bw + 0.02f + badgeW, yT - bw - 0.02f, 0.0018f, badgeBgCol);
        }

        // PASS 2: Emit ALL text overlays AFTER all quads!
        if (tr != null) {
            float padX = xL + bw + 0.04f;
            float availW = (xR - bw - 0.04f) - padX;

            if (badgeW > 0.01f && spec.badge != null && !spec.badge.isBlank()) {
                float bScale = WorldMapBoardRenderer.fitScale(tr, spec.badge, badgeW - 0.03f, headerH * 0.048f);
                float bx = xL + bw + 0.02f + (badgeW - tr.getWidth(spec.badge) * bScale) * 0.5f;
                float by = yT - bw - (headerH - 8.0f * bScale) * 0.5f;
                WorldMapBoardRenderer.drawWallText(matrices, vertexConsumers, tr, spec.badge, bx, by, bScale, 0xFFFFFFFF, fullBright);
            }

            float titleLeft = padX + (badgeW > 0 ? badgeW + 0.04f : 0f);
            float titleAvailW = (xR - bw - 0.04f) - titleLeft;
            float tScale = WorldMapBoardRenderer.fitScale(tr, spec.title, titleAvailW, headerH * 0.052f);
            float titleTopY = yT - bw - (headerH - 8.0f * tScale) * 0.5f;
            WorldMapBoardRenderer.drawWallText(matrices, vertexConsumers, tr, spec.title, titleLeft, titleTopY, tScale, titleCol, fullBright);

            List<String> lines = spec.lines;
            float bodyTop = headerBottom - 0.035f;
            float footerSpace = (spec.footer != null && !spec.footer.isBlank()) ? Math.min(0.14f, totalH * 0.13f) : 0.02f;
            float bodyBottom = yB + bw + footerSpace;
            float bodyH = Math.max(0.10f, bodyTop - bodyBottom);
            int nLines = Math.max(1, lines.size());
            float rowStep = bodyH / nLines;
            float preferredLineScale = Math.min(rowStep * 0.072f, 0.0095f);

            for (int i = 0; i < lines.size(); i++) {
                String ln = lines.get(i);
                float lScale = WorldMapBoardRenderer.fitScale(tr, ln, availW, preferredLineScale);
                float ly = bodyTop - i * rowStep - (rowStep - 8.0f * lScale) * 0.35f;
                int lineCol = ln.startsWith("[✓]") ? 0xFFA5D6A7 : bodyCol;
                WorldMapBoardRenderer.drawWallText(matrices, vertexConsumers, tr, ln, padX, ly, lScale, lineCol, fullBright);
            }

            if (spec.footer != null && !spec.footer.isBlank()) {
                float fScale = WorldMapBoardRenderer.fitScale(tr, spec.footer, availW, Math.min(0.0048f, footerSpace * 0.048f));
                WorldMapBoardRenderer.drawWallText(matrices, vertexConsumers, tr, spec.footer,
                        padX, yB + bw + footerSpace * 0.72f, fScale, footerCol, fullBright);
            }
        }

        matrices.pop();
    }
}

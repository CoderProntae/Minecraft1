package ai.arena.bridge.transit;

import ai.arena.bridge.ArenaContent;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.minecraft.server.world.ServerWorld;
import org.mtr.core.data.Depot;
import org.mtr.core.data.PathData;
import org.mtr.core.data.Platform;
import org.mtr.core.data.Position;
import org.mtr.core.data.Rail;
import org.mtr.core.data.Route;
import org.mtr.core.data.RoutePlatformData;
import org.mtr.core.data.Siding;
import org.mtr.core.data.Station;
import org.mtr.core.data.TransportMode;
import org.mtr.core.data.VehicleExtraData;
import org.mtr.core.generated.data.RailSchema;
import org.mtr.core.operation.UpdateDataRequest;
import org.mtr.core.simulation.Simulator;
import org.mtr.core.tool.Angle;
import org.mtr.libraries.it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.mtr.libraries.it.unimi.dsi.fastutil.objects.ObjectImmutableList;
import org.mtr.mod.packet.PacketUpdateData;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Real-World Railway Kinematics, Traction & Braking Physics Engine (UIC / EN 13452 / IEEE 1474):
 *
 * 1. Replaces MTR's unrealistic flat 4.0 m/s² constant acceleration/braking with real-world rolling stock physics:
 *    - S-curve departure jerk ramp (0..8 km/h)
 *    - Adhesion-limited constant-torque regime (v <= v_base)
 *    - Constant-power electric motor hyperbola F(v) = P_max / v (v > v_base)
 *    - Davis rolling + quadratic aerodynamic & tunnel piston resistance: R(v) = A + B*v + C*k_tunnel*v^2
 *    - Track slope gravity force (-g * sin(theta)) and wet-rail storm adhesion reduction
 *    - EN 13452 comfort service braking envelope b(v)
 *
 * 2. Physics-Driven Station-to-Station Corridor Calculator:
 *    - Measures real MTR rail path length L (1 Minecraft block = 1.00 meter) & slope profile between stations.
 *    - Integrates the forward traction ODE and backward braking ODE (dt = 0.05 s) for every real train class
 *      (Tramvay 55, Metro 80, Banliyö 110, Bölgesel 150, YHT 250 km/h).
 *    - Determines line class & speed purely from whether the train can physically accelerate, hold steady cruise
 *      (>= 30% cruise time), and brake comfortably before the next station — NOT from arbitrary hard-coded rules!
 */
public final class RailPhysicsEngine {

    private static final double GRAVITY = 9.80665;
    private static final double MTR_ACCEL_UNIT = 1.0E-6; // 1 m/s² = 1.0E-6 m/ms² in MTR Simulator

    // Cached weather flag updated from server/client so Mixin runs in O(1) with zero world lookups
    public static volatile boolean wetOutdoorRails = false;
    // Maximum physical high-speed rail ceiling (250 km/h = Siemens Velaro TR HT80000 service speed)
    public static volatile long chunkSafeMaxSpeedKmh = 250L;

    public static final class RollingStockPhysics {
        public final UitpSystemType systemType;
        public final String referenceModel;
        public final double massTonnes;
        public final double rotaryInertiaFactor; // gamma (1.05..1.09)
        public final double maxPowerKw;          // Rated wheel-rim traction power (kW)
        public final double maxStartAccelMps2;   // Adhesion/comfort starting acceleration a0 (m/s²)
        public final double serviceBrakeMps2;    // EN 13452 normal service deceleration b_srv (m/s²)
        public final double designSpeedKmh;      // Real operational design speed (km/h)
        public final double davisA_N;            // Rolling resistance constant A (N)
        public final double davisB_NsPm;         // Flange/mechanical resistance B (N / (m/s))
        public final double davisC_Ns2Pm2;       // Aerodynamic drag C (N / (m/s)²)

        public RollingStockPhysics(
                UitpSystemType systemType,
                String referenceModel,
                double massTonnes,
                double rotaryInertiaFactor,
                double maxPowerKw,
                double maxStartAccelMps2,
                double serviceBrakeMps2,
                double designSpeedKmh,
                double davisA_N,
                double davisB_NsPm,
                double davisC_Ns2Pm2
        ) {
            this.systemType = systemType;
            this.referenceModel = referenceModel;
            this.massTonnes = massTonnes;
            this.rotaryInertiaFactor = rotaryInertiaFactor;
            this.maxPowerKw = maxPowerKw;
            this.maxStartAccelMps2 = maxStartAccelMps2;
            this.serviceBrakeMps2 = serviceBrakeMps2;
            this.designSpeedKmh = designSpeedKmh;
            this.davisA_N = davisA_N;
            this.davisB_NsPm = davisB_NsPm;
            this.davisC_Ns2Pm2 = davisC_Ns2Pm2;
        }

        public double effectiveMassKg() {
            return massTonnes * 1000.0 * rotaryInertiaFactor;
        }
    }

    // Authentic real-world UIC / Turkish transit rolling stock specifications:
    public static final RollingStockPhysics SPEC_TRAM = new RollingStockPhysics(
            UitpSystemType.TRAMVAY, "Bozankaya / Bombardier Flexity Tramvay",
            42.0, 1.08, 600.0, 1.22, 1.25, 50.0, 620.0, 11.5, 2.8
    );
    public static final RollingStockPhysics SPEC_HRS = new RollingStockPhysics(
            UitpSystemType.HRS, "ABB / Duewag Hafif Raylı Sistem (LRT)",
            86.0, 1.08, 1250.0, 1.18, 1.18, 65.0, 1320.0, 24.0, 4.1
    );
    public static final RollingStockPhysics SPEC_METRO = new RollingStockPhysics(
            UitpSystemType.METRO, "Alstom Metropolis / Rotem 4-Vagon Metro",
            148.0, 1.07, 2200.0, 1.15, 1.10, 80.0, 2150.0, 38.0, 5.6
    );
    public static final RollingStockPhysics SPEC_COMMUTER = new RollingStockPhysics(
            UitpSystemType.BANLIYO, "Hyundai Rotem E32000 (Marmaray / İZBAN)",
            212.0, 1.07, 3200.0, 0.92, 0.95, 110.0, 2950.0, 48.0, 6.4
    );
    public static final RollingStockPhysics SPEC_REGIONAL = new RollingStockPhysics(
            UitpSystemType.BOLGESEL, "Stadler FLIRT / TCDD Anahat Ekspres",
            248.0, 1.06, 4000.0, 0.74, 0.80, 150.0, 3200.0, 52.0, 6.9
    );
    public static final RollingStockPhysics SPEC_YHT = new RollingStockPhysics(
            UitpSystemType.YHT, "Siemens Velaro TR (TCDD HT80000 8-Vagon)",
            419.0, 1.05, 8000.0, 0.62, 0.58, 250.0, 4400.0, 68.0, 7.8
    );
    public static final RollingStockPhysics SPEC_MONORAIL = new RollingStockPhysics(
            UitpSystemType.MONORAY, "Hitachi / Alweg Şehir Monorayı",
            74.0, 1.08, 1050.0, 1.05, 1.10, 65.0, 1100.0, 22.0, 4.2
    );
    public static final RollingStockPhysics SPEC_FUNICULAR = new RollingStockPhysics(
            UitpSystemType.FUNIKULER, "Garaventa Kabataş-Taksim Füniküler",
            56.0, 1.06, 850.0, 1.00, 1.15, 50.0, 850.0, 18.0, 3.0
    );

    private static final RollingStockPhysics[] CANDIDATE_RAIL_LADDER = new RollingStockPhysics[]{
            SPEC_TRAM,
            SPEC_HRS,
            SPEC_METRO,
            SPEC_COMMUTER,
            SPEC_REGIONAL,
            SPEC_YHT
    };

    private RailPhysicsEngine() {}

    public static RollingStockPhysics getSpecForSystem(UitpSystemType type) {
        if (type == null) return SPEC_METRO;
        return switch (type) {
            case TRAMVAY -> SPEC_TRAM;
            case HRS -> SPEC_HRS;
            case METRO -> SPEC_METRO;
            case BANLIYO -> SPEC_COMMUTER;
            case BOLGESEL -> SPEC_REGIONAL;
            case YHT -> SPEC_YHT;
            case MONORAY -> SPEC_MONORAIL;
            case FUNIKULER, TELEFERIK -> SPEC_FUNICULAR;
        };
    }

    public static RollingStockPhysics getSpecForVehicle(VehicleExtraData ved) {
        if (ved == null) return SPEC_METRO;
        String rn = ved.getThisRouteNumber();
        if (rn == null || rn.isEmpty()) rn = ved.getNextRouteNumber();
        if (rn == null || rn.isEmpty()) rn = ved.getThisRouteName();
        return getSpecForSystem(UitpSystemType.fromRouteCodeOrType(rn));
    }

    /**
     * Speed-dependent physical net acceleration a(v, theta) in m/s²:
     * Incorporates departure jerk S-curve, constant-torque adhesion limit, constant-power motor hyperbola (P/v),
     * Davis aerodynamic + tunnel piston drag, grade gravity, and wet-rail storm adhesion.
     */
    public static double computeInstantAccelerationMps2(
            RollingStockPhysics spec,
            double speedMps,
            double sinGrade,
            boolean inTunnel,
            boolean wetRail
    ) {
        double v = Math.max(0.0, speedMps);
        double mEff = spec.effectiveMassKg();
        double adhesionWeather = (wetRail && !inTunnel) ? 0.85 : 1.00;

        // Smooth S-curve jerk limiter at departure (0 -> 8 km/h = 2.22 m/s)
        double jerkRamp = (v < 2.22) ? (0.52 + 0.48 * (v / 2.22)) : 1.0;

        double maxStartingForceN = mEff * spec.maxStartAccelMps2 * adhesionWeather;
        double powerLimitedForceN = (spec.maxPowerKw * 1000.0) / Math.max(1.2, v);
        double tractiveForceN = jerkRamp * Math.min(maxStartingForceN, powerLimitedForceN);

        // Davis equation R(v) = A + B*v + C * k_tunnel * v^2
        double tunnelAeroFactor = inTunnel ? 1.42 : 1.00;
        double dragForceN = spec.davisA_N
                + spec.davisB_NsPm * v
                + (spec.davisC_Ns2Pm2 * tunnelAeroFactor) * v * v;

        // Track gradient gravity component (capped to +-3.5% physical railway grade equivalent so steep MC ramps never stall)
        double clampedSin = Math.max(-0.035, Math.min(0.035, sinGrade));
        double gradeForceN = (spec.massTonnes * 1000.0) * GRAVITY * clampedSin;

        double netAccel = (tractiveForceN - dragForceN - gradeForceN) / mEff;
        return Math.max(0.14, Math.min(1.45, netAccel));
    }

    /**
     * Speed-dependent EN 13452 comfort service braking deceleration b(v, theta) in m/s²:
     * Incorporates thermal brake-power taper at high speeds (> 145 km/h), wet-rail adhesion, and grade.
     */
    public static double computeInstantDecelerationMps2(
            RollingStockPhysics spec,
            double speedMps,
            double sinGrade,
            boolean inTunnel,
            boolean wetRail
    ) {
        double v = Math.max(0.0, speedMps);
        double adhesionWeather = (wetRail && !inTunnel) ? 0.85 : 1.00;

        // High-speed regenerative/disc thermal power taper above 40 m/s (144 km/h)
        double highSpeedTaper = (v > 40.0) ? Math.pow(40.0 / v, 0.24) : 1.0;
        double baseBrake = spec.serviceBrakeMps2 * adhesionWeather * highSpeedTaper;

        double clampedSin = Math.max(-0.030, Math.min(0.030, sinGrade));
        double gradeAssist = 0.35 * GRAVITY * clampedSin;

        // Never drop below MTR Siding.MIN_ACCELERATION (0.40 m/s²)
        return Math.max(0.42, Math.min(1.45, baseBrake + gradeAssist));
    }

    /**
     * Called every tick from MtrVehiclePhysicsMixin inside Vehicle.simulateMoving (both server & client).
     */
    public static double computeVehicleAccelerationMtr(VehicleExtraData ved, double speedMetersPerMs, int pathIndex) {
        RollingStockPhysics spec = getSpecForVehicle(ved);
        double speedMps = Math.max(0.0, speedMetersPerMs * 1000.0);
        double sinGrade = 0.0;
        boolean inTunnel = false;

        if (ved != null && ved.immutablePath != null && pathIndex >= 0 && pathIndex < ved.immutablePath.size()) {
            PathData pd = ved.immutablePath.get(pathIndex);
            if (pd != null) {
                Position p1 = pd.getOrderedPosition1();
                Position p2 = pd.getOrderedPosition2();
                double len = Math.max(1.0, pd.getRailLength());
                if (p1 != null && p2 != null) {
                    sinGrade = (p2.getY() - p1.getY()) / len;
                    inTunnel = ((p1.getY() + p2.getY()) * 0.5) < 59.0;
                }
            }
        }
        double aMps2 = computeInstantAccelerationMps2(spec, speedMps, sinGrade, inTunnel, wetOutdoorRails);
        return aMps2 * MTR_ACCEL_UNIT;
    }

    /**
     * Called every tick from MtrVehiclePhysicsMixin inside Vehicle.simulateMoving (both server & client).
     */
    public static double computeVehicleDecelerationMtr(VehicleExtraData ved, double speedMetersPerMs, int pathIndex) {
        RollingStockPhysics spec = getSpecForVehicle(ved);
        double speedMps = Math.max(0.0, speedMetersPerMs * 1000.0);
        double sinGrade = 0.0;
        boolean inTunnel = false;

        if (ved != null && ved.immutablePath != null && pathIndex >= 0 && pathIndex < ved.immutablePath.size()) {
            PathData pd = ved.immutablePath.get(pathIndex);
            if (pd != null) {
                Position p1 = pd.getOrderedPosition1();
                Position p2 = pd.getOrderedPosition2();
                double len = Math.max(1.0, pd.getRailLength());
                if (p1 != null && p2 != null) {
                    sinGrade = (p2.getY() - p1.getY()) / len;
                    inTunnel = ((p1.getY() + p2.getY()) * 0.5) < 59.0;
                }
            }
        }
        double bMps2 = computeInstantDecelerationMtrScalar(spec, speedMps, sinGrade, inTunnel);
        return bMps2 * MTR_ACCEL_UNIT;
    }

    private static double computeInstantDecelerationMtrScalar(
            RollingStockPhysics spec,
            double speedMps,
            double sinGrade,
            boolean inTunnel
    ) {
        return computeInstantDecelerationMps2(spec, speedMps, sinGrade, inTunnel, wetOutdoorRails);
    }

    // ==================== CORRIDOR ODE KINEMATICS SOLVER & CLASSIFIER ====================

    public static final class KinematicRunResult {
        public final RollingStockPhysics spec;
        public final double corridorMeters;
        public final double peakSpeedKmh;
        public final double accelDistMeters;
        public final double cruiseDistMeters;
        public final double brakeDistMeters;
        public final double accelTimeSec;
        public final double cruiseTimeSec;
        public final double brakeTimeSec;
        public final double totalRunTimeSec;
        public final double cruiseTimeRatio;
        public final boolean reachesDesignSpeed;
        public final boolean physicallyViableForClass;

        public KinematicRunResult(
                RollingStockPhysics spec,
                double corridorMeters,
                double peakSpeedKmh,
                double accelDistMeters,
                double cruiseDistMeters,
                double brakeDistMeters,
                double accelTimeSec,
                double cruiseTimeSec,
                double brakeTimeSec
        ) {
            this.spec = spec;
            this.corridorMeters = corridorMeters;
            this.peakSpeedKmh = peakSpeedKmh;
            this.accelDistMeters = accelDistMeters;
            this.cruiseDistMeters = cruiseDistMeters;
            this.brakeDistMeters = brakeDistMeters;
            this.accelTimeSec = accelTimeSec;
            this.cruiseTimeSec = cruiseTimeSec;
            this.brakeTimeSec = brakeTimeSec;
            this.totalRunTimeSec = accelTimeSec + cruiseTimeSec + brakeTimeSec;
            this.cruiseTimeRatio = totalRunTimeSec > 0.01 ? (cruiseTimeSec / totalRunTimeSec) : 0.0;
            this.reachesDesignSpeed = peakSpeedKmh >= (spec.designSpeedKmh * 0.94);
            // A train class is physically meaningful ONLY if real acceleration + real braking leaves >= 28% steady cruise!
            this.physicallyViableForClass = this.reachesDesignSpeed && (this.cruiseTimeRatio >= 0.28);
        }
    }

    public static final class CorridorPhysicsDecision {
        public final double corridorMeters;
        public final boolean mostlyTunnel;
        public final RollingStockPhysics recommendedSpec;
        public final long recommendedLineSpeedKmh;
        public final KinematicRunResult optimalRun;
        public final List<KinematicRunResult> allEvaluations;

        public CorridorPhysicsDecision(
                double corridorMeters,
                boolean mostlyTunnel,
                RollingStockPhysics recommendedSpec,
                long recommendedLineSpeedKmh,
                KinematicRunResult optimalRun,
                List<KinematicRunResult> allEvaluations
        ) {
            this.corridorMeters = corridorMeters;
            this.mostlyTunnel = mostlyTunnel;
            this.recommendedSpec = recommendedSpec;
            this.recommendedLineSpeedKmh = recommendedLineSpeedKmh;
            this.optimalRun = optimalRun;
            this.allEvaluations = allEvaluations;
        }
    }

    /**
     * Numerically integrates forward traction ODE + backward EN 13452 braking ODE (dt = 0.05 s)
     * across exact corridor length L (meters) with ZERO arbitrary distance thresholds!
     */
    public static KinematicRunResult simulateTrainOnCorridor(
            RollingStockPhysics spec,
            double corridorMeters,
            boolean inTunnel
    ) {
        double L = Math.max(60.0, corridorMeters);
        double vMaxMps = spec.designSpeedKmh / 3.6;
        double dt = 0.05;

        // 1. Pre-integrate exact braking distance table s_brake(v) from 0 up to vMaxMps:
        int steps = 2400;
        double[] vTab = new double[steps + 1];
        double[] sBrakeTab = new double[steps + 1];
        double[] tBrakeTab = new double[steps + 1];
        double dv = vMaxMps / steps;
        for (int i = 1; i <= steps; i++) {
            double vMid = (i - 0.5) * dv;
            double b = computeInstantDecelerationMps2(spec, vMid, 0.0, inTunnel, false);
            double dtStep = dv / b;
            vTab[i] = i * dv;
            sBrakeTab[i] = sBrakeTab[i - 1] + vMid * dtStep;
            tBrakeTab[i] = tBrakeTab[i - 1] + dtStep;
        }

        // 2. Forward integrate acceleration from s = 0, v = 0 until s + s_brake(v) >= L or v reaches vMaxMps:
        double sAcc = 0.0;
        double tAcc = 0.0;
        double v = 0.0;

        while (v < vMaxMps - 1e-4) {
            int idx = Math.min(steps, (int) Math.round((v / vMaxMps) * steps));
            if (sAcc + sBrakeTab[idx] >= L) {
                break; // Hit physical braking curve before reaching design speed!
            }
            double a = computeInstantAccelerationMps2(spec, v, 0.0, inTunnel, false);
            double vNext = Math.min(vMaxMps, v + a * dt);
            double ds = 0.5 * (v + vNext) * dt;
            int idxNext = Math.min(steps, (int) Math.round((vNext / vMaxMps) * steps));
            if (sAcc + ds + sBrakeTab[idxNext] >= L) {
                // Exact intersection with braking envelope
                v = vNext;
                sAcc = Math.max(0.0, L - sBrakeTab[idxNext]);
                tAcc += dt;
                break;
            }
            sAcc += ds;
            tAcc += dt;
            v = vNext;
            if (tAcc > 600.0) break;
        }

        int peakIdx = Math.min(steps, (int) Math.round((v / vMaxMps) * steps));
        double sBrake = Math.min(L - sAcc, sBrakeTab[peakIdx]);
        double tBrake = tBrakeTab[peakIdx];
        double sCruise = Math.max(0.0, L - sAcc - sBrake);
        double tCruise = (v > 0.5) ? (sCruise / v) : 0.0;

        return new KinematicRunResult(
                spec, L, v * 3.6, sAcc, sCruise, sBrake, tAcc, tCruise, tBrake
        );
    }

    /**
     * Evaluates all real-world train physics models on a corridor of length corridorMeters
     * and selects the physically optimal system & operating speed.
     */
    public static CorridorPhysicsDecision evaluateCorridorPhysics(double corridorMeters, boolean mostlyTunnel) {
        List<KinematicRunResult> results = new ArrayList<>();
        KinematicRunResult bestViable = null;

        for (RollingStockPhysics candidate : CANDIDATE_RAIL_LADDER) {
            KinematicRunResult sim = simulateTrainOnCorridor(candidate, corridorMeters, mostlyTunnel);
            results.add(sim);
            if (sim.physicallyViableForClass) {
                bestViable = sim; // Highest speed tier that physically achieves design speed + >=28% steady cruise!
            }
        }

        if (bestViable == null) {
            // Very short hop (< 320m): Tram / Light Rail at its physically reachable safe plateau speed
            bestViable = results.get(0);
        }

        long physSpeedKmh = Math.max(40L, Math.round(Math.min(bestViable.spec.designSpeedKmh, bestViable.peakSpeedKmh) / 5.0) * 5L);
        return new CorridorPhysicsDecision(
                corridorMeters,
                mostlyTunnel,
                bestViable.spec,
                physSpeedKmh,
                bestViable,
                results
        );
    }

    /**
     * Measures exact station-to-station rail corridor distance in meters from MTR Simulator,
     * applies real-world acceleration/deceleration to Sidings, sets physics-derived rail speed limits,
     * and auto-classifies routes if needed.
     */
    @SuppressWarnings("unchecked")
    public static CorridorPhysicsDecision synchronizeSimulatorWithRealPhysics(
            ServerWorld overworld,
            boolean autoUpdateRouteClass
    ) {
        Simulator sim = MtrBridgeHelper.getOverworldSimulator();
        if (sim == null) return null;

        // 1. Measure real rail path length between consecutive platforms (fallback to Euclidean platform distance)
        double measuredCorridorM = 0.0;
        boolean mostlyTunnel = false;
        int tunnelSegs = 0;
        int totalSegs = 0;

        try {
            Field fPathMain = Siding.class.getDeclaredField("pathMainRoute");
            fPathMain.setAccessible(true);
            for (Siding s : sim.sidings) {
                ObjectArrayList<PathData> path = (ObjectArrayList<PathData>) fPathMain.get(s);
                if (path != null && !path.isEmpty()) {
                    double legSum = 0.0;
                    double bestLeg = 0.0;
                    boolean startedAfterFirstPlatform = false;
                    for (PathData pd : path) {
                        Position p1 = pd.getOrderedPosition1();
                        Position p2 = pd.getOrderedPosition2();
                        if (p1 != null && p2 != null) {
                            totalSegs++;
                            if (((p1.getY() + p2.getY()) * 0.5) < 59.0) tunnelSegs++;
                        }
                        if (pd.getDwellTime() > 0) {
                            if (startedAfterFirstPlatform && legSum > bestLeg) {
                                bestLeg = legSum;
                            }
                            startedAfterFirstPlatform = true;
                            legSum = 0.0;
                        } else if (startedAfterFirstPlatform) {
                            legSum += pd.getRailLength();
                        }
                    }
                    if (bestLeg > measuredCorridorM) measuredCorridorM = bestLeg;
                }
            }
        } catch (Throwable ignored) {}

        if (measuredCorridorM < 40.0 && sim.platforms.size() >= 2) {
            Platform first = null;
            for (Platform p : sim.platforms) {
                if (first == null) {
                    first = p;
                } else {
                    double dx = p.getMidPosition().getX() - first.getMidPosition().getX();
                    double dy = p.getMidPosition().getY() - first.getMidPosition().getY();
                    double dz = p.getMidPosition().getZ() - first.getMidPosition().getZ();
                    measuredCorridorM = Math.max(measuredCorridorM, Math.sqrt(dx * dx + dy * dy + dz * dz));
                }
            }
        }
        if (measuredCorridorM < 40.0) measuredCorridorM = 1548.0;
        mostlyTunnel = (totalSegs > 0) ? ((double) tunnelSegs / totalSegs >= 0.40) : true;

        CorridorPhysicsDecision decision = evaluateCorridorPhysics(measuredCorridorM, mostlyTunnel);
        RollingStockPhysics recSpec = decision.recommendedSpec;
        long targetSpeedKmh = Math.min(chunkSafeMaxSpeedKmh, decision.recommendedLineSpeedKmh);

        // 2. Apply physical Siding acceleration & deceleration (m/ms²) + disable MTR's unrealistic timetable speed-cheating!
        boolean sidingChanged = false;
        double targetAccMtr = Math.max(Siding.MIN_ACCELERATION, Math.min(Siding.MAX_ACCELERATION, recSpec.maxStartAccelMps2 * 0.88 * MTR_ACCEL_UNIT));
        double targetDecMtr = Math.max(Siding.MIN_ACCELERATION, Math.min(Siding.MAX_ACCELERATION, recSpec.serviceBrakeMps2 * MTR_ACCEL_UNIT));

        UpdateDataRequest updateReq = new UpdateDataRequest(sim);
        for (Siding s : sim.sidings) {
            boolean dirty = false;
            if (Math.abs(s.getAcceleration() - targetAccMtr) > 1.5E-7) {
                s.setAcceleration(targetAccMtr);
                dirty = true;
            }
            if (Math.abs(s.getDeceleration() - targetDecMtr) > 1.5E-7) {
                s.setDeceleration(targetDecMtr);
                dirty = true;
            }
            if (s.getDelayedVehicleSpeedIncreasePercentage() != 0) {
                s.setDelayedVehicleSpeedIncreasePercentage(0);
                dirty = true;
            }
            if (s.getDelayedVehicleReduceDwellTimePercentage() != 0) {
                s.setDelayedVehicleReduceDwellTimePercentage(0);
                dirty = true;
            }
            if (s.getEarlyVehicleIncreaseDwellTime()) {
                s.setEarlyVehicleIncreaseDwellTime(false);
                dirty = true;
            }
            if (dirty) {
                updateReq.addSiding(s);
                sidingChanged = true;
            }
        }

        // 3. Auto-align Route UITP prefix if current route claims a higher speed class than physics permits (e.g. YHT on 1.5 km)
        boolean routeChanged = false;
        if (autoUpdateRouteClass) {
            for (Route r : sim.routes) {
                UitpSystemType curType = UitpSystemType.fromRouteCodeOrType(r.getRouteNumber());
                RollingStockPhysics curSpec = getSpecForSystem(curType);
                if (curSpec.designSpeedKmh > recSpec.designSpeedKmh + 15.0) {
                    String newCode = recSpec.systemType.prefix + "1";
                    r.setRouteNumber(newCode);
                    r.setRouteType(recSpec.systemType.mtrRouteType);
                    r.setColor(recSpec.systemType.defaultColor);
                    if (r.getName() == null || r.getName().toUpperCase(Locale.ROOT).contains("YHT")) {
                        r.setName("Orman " + recSpec.systemType.spokenPrefixTr);
                    }
                    updateReq.addRoute(r);
                    routeChanged = true;
                }
            }
        }

        if (sidingChanged || routeChanged) {
            updateReq.update();
        }

        // 4. Synchronize running-line Rail speed limits to the physics-derived operating speed!
        int railsUpdated = 0;
        if (overworld != null && !sim.rails.isEmpty()) {
            railsUpdated = applyCorridorRailSpeedLimit(overworld, sim, targetSpeedKmh);
        }

        if ((sidingChanged || routeChanged || railsUpdated > 0) && !sim.depots.isEmpty()) {
            Depot.generateDepots(sim, new ObjectArrayList<>(sim.depots));
        }

        return decision;
    }

    @SuppressWarnings("unchecked")
    public static int applyCorridorRailSpeedLimit(ServerWorld overworld, Simulator sim, long targetKmh) {
        try {
            Field fPos1 = RailSchema.class.getDeclaredField("position1");
            Field fAng1 = RailSchema.class.getDeclaredField("angle1");
            Field fPos2 = RailSchema.class.getDeclaredField("position2");
            Field fAng2 = RailSchema.class.getDeclaredField("angle2");
            Field fShape = RailSchema.class.getDeclaredField("shape");
            Field fVertR = RailSchema.class.getDeclaredField("verticalRadius");
            Field fStyles = RailSchema.class.getDeclaredField("styles");
            Field fSpd1 = RailSchema.class.getDeclaredField("speedLimit1");
            Field fSpd2 = RailSchema.class.getDeclaredField("speedLimit2");
            Field fAcc = RailSchema.class.getDeclaredField("canAccelerate");
            Field fRem = RailSchema.class.getDeclaredField("canConnectRemotely");
            Field fSig = RailSchema.class.getDeclaredField("canHaveSignal");
            Field fMode = RailSchema.class.getDeclaredField("transportMode");

            fPos1.setAccessible(true); fAng1.setAccessible(true);
            fPos2.setAccessible(true); fAng2.setAccessible(true);
            fShape.setAccessible(true); fVertR.setAccessible(true);
            fStyles.setAccessible(true); fSpd1.setAccessible(true); fSpd2.setAccessible(true);
            fAcc.setAccessible(true); fRem.setAccessible(true);
            fSig.setAccessible(true); fMode.setAccessible(true);

            org.mtr.mapping.holder.ServerWorld mtrWorld =
                    (org.mtr.mapping.holder.ServerWorld) org.mtr.mapping.holder.ServerWorld.class
                            .getConstructors()[0].newInstance(overworld);

            ObjectArrayList<Rail> snapshot = new ObjectArrayList<>(sim.rails);
            int updated = 0;

            for (Rail r : snapshot) {
                if (r.isPlatform() || r.isSiding() || r.canTurnBack() || !r.canAccelerate()) continue;
                long s1 = fSpd1.getLong(r);
                long s2 = fSpd2.getLong(r);
                // Keep intentional one-way 0 limits intact while aligning active running direction to targetKmh
                long ns1 = (s1 == 0L) ? 0L : targetKmh;
                long ns2 = (s2 == 0L) ? 0L : targetKmh;
                if (s1 == ns1 && s2 == ns2) continue;

                ObjectArrayList<String> origStyles = (ObjectArrayList<String>) fStyles.get(r);
                ObjectArrayList<String> stylesCopy = origStyles != null ? new ObjectArrayList<>(origStyles) : new ObjectArrayList<>();

                Rail adjusted = Rail.newRail(
                        (Position) fPos1.get(r),
                        (Angle) fAng1.get(r),
                        (Position) fPos2.get(r),
                        (Angle) fAng2.get(r),
                        (Rail.Shape) fShape.get(r),
                        fVertR.getDouble(r),
                        stylesCopy,
                        ns1,
                        ns2,
                        false,
                        false,
                        fAcc.getBoolean(r),
                        fRem.getBoolean(r),
                        fSig.getBoolean(r),
                        (TransportMode) fMode.get(r)
                );
                adjusted.copySignalColors(r);
                PacketUpdateData.sendDirectlyToServerRail(mtrWorld, adjusted);
                updated++;
            }
            return updated;
        } catch (Throwable ignored) {
            return 0;
        }
    }

    public static List<String> formatTurkishReportLines(CorridorPhysicsDecision d) {
        List<String> lines = new ArrayList<>();
        lines.add(String.format(Locale.US,
                "=== Gerçek Dünya Raylı Sistem Fizik Analizi (Hat Uzunluğu: %.0f m %s) ===",
                d.corridorMeters, d.mostlyTunnel ? "[Tünel Aerodinamiği Aktif]" : "[Açık Hat]"));
        for (KinematicRunResult r : d.allEvaluations) {
            String status = r.physicallyViableForClass ? "UYGUN" :
                    (!r.reachesDesignSpeed ? "FREN EĞRİSİNE TAKILDI" : "SEYİR SÜRESİ KISA");
            lines.add(String.format(Locale.US,
                    "• [%s %.0f km/s] Zirve: %.0f km/s | İvme: %.0f m (%.0fs) | Seyir: %.0f m (%%%d) | Fren: %.0f m (%.0fs) -> %s",
                    r.spec.systemType.prefix,
                    r.spec.designSpeedKmh,
                    r.peakSpeedKmh,
                    r.accelDistMeters, r.accelTimeSec,
                    r.cruiseDistMeters, Math.round(r.cruiseTimeRatio * 100.0),
                    r.brakeDistMeters, r.brakeTimeSec,
                    status
            ));
        }
        lines.add(String.format(Locale.US,
                "=> Fizik Motoru Seçimi: %s (%s) — İşletme Hızı: %d km/s | Toplam Sefer: %.0f sn",
                d.recommendedSpec.systemType.displayNameTr,
                d.recommendedSpec.referenceModel,
                d.recommendedLineSpeedKmh,
                d.optimalRun.totalRunTimeSec
        ));
        return lines;
    }

    public static JsonObject toJson(CorridorPhysicsDecision d) {
        JsonObject out = new JsonObject();
        out.addProperty("ok", true);
        out.addProperty("corridorMeters", Math.round(d.corridorMeters));
        out.addProperty("mostlyTunnel", d.mostlyTunnel);
        out.addProperty("recommendedSystem", d.recommendedSpec.systemType.name());
        out.addProperty("recommendedCodePrefix", d.recommendedSpec.systemType.prefix);
        out.addProperty("referenceTrain", d.recommendedSpec.referenceModel);
        out.addProperty("recommendedSpeedKmh", d.recommendedLineSpeedKmh);
        out.addProperty("totalRunTimeSec", Math.round(d.optimalRun.totalRunTimeSec * 10.0) / 10.0);

        JsonArray evals = new JsonArray();
        for (KinematicRunResult r : d.allEvaluations) {
            JsonObject eo = new JsonObject();
            eo.addProperty("code", r.spec.systemType.prefix);
            eo.addProperty("designSpeedKmh", r.spec.designSpeedKmh);
            eo.addProperty("peakSpeedKmh", Math.round(r.peakSpeedKmh * 10.0) / 10.0);
            eo.addProperty("accelDistM", Math.round(r.accelDistMeters));
            eo.addProperty("cruiseDistM", Math.round(r.cruiseDistMeters));
            eo.addProperty("brakeDistM", Math.round(r.brakeDistMeters));
            eo.addProperty("cruisePct", Math.round(r.cruiseTimeRatio * 100.0));
            eo.addProperty("runTimeSec", Math.round(r.totalRunTimeSec * 10.0) / 10.0);
            eo.addProperty("viable", r.physicallyViableForClass);
            evals.add(eo);
        }
        out.add("evaluations", evals);
        return out;
    }
}

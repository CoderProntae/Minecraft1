package ai.arena.bridge.hotpatch;

import ai.arena.bridge.ArenaAiMod;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.server.MinecraftServer;
import org.joml.Matrix4f;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.jar.JarEntry;
import java.util.jar.JarInputStream;

/**
 * Live Code & Declarative Board Renderer Engine (v7.6.0):
 * 1. JVM Bytecode Hot-Injection ("op": "load_jar") — loads remapped .jar bytes in memory via KnotClassLoader parent,
 *    instantiates ArenaHotPatch, and swaps render/tick/RPC logic at 60 FPS with ZERO restarts.
 * 2. Declarative Board Override ("op": "board_override") — instant JSON text/color/canvas primitives for boards.
 */
public final class HotPatchManager {

    private static final AtomicReference<ArenaHotPatch> ACTIVE_PATCH = new AtomicReference<>(null);
    private static final AtomicReference<JsonObject> BOARD_OVERRIDE = new AtomicReference<>(null);
    private static volatile MinecraftServer lastServerRef = null;
    private static boolean persistedChecked = false;

    private HotPatchManager() {}

    private static java.io.File getPatchDir() {
        return new java.io.File(FabricLoader.getInstance().getGameDir().toFile(), "arena-hotpatches");
    }

    /**
     * Automatically reloads any persisted hot-patch JAR saved in .minecraft/arena-hotpatches/
     * so live-injected updates permanently survive game restarts!
     */
    public static synchronized void ensureLoaded() {
        if (persistedChecked) return;
        persistedChecked = true;
        try {
            java.io.File dir = getPatchDir();
            java.io.File jarF = new java.io.File(dir, "active-patch.jar");
            java.io.File metaF = new java.io.File(dir, "active-patch.json");
            if (jarF.exists() && metaF.exists()) {
                JsonObject meta = JsonParser.parseString(java.nio.file.Files.readString(metaF.toPath())).getAsJsonObject();
                String modVer = meta.has("modVersion") ? meta.get("modVersion").getAsString() : "";
                if ("7.7.0".equals(modVer)) {
                    String entryClass = meta.get("entryClass").getAsString();
                    byte[] jarBytes = java.nio.file.Files.readAllBytes(jarF.toPath());
                    loadPatchBytes(jarBytes, entryClass);
                }
            }
            java.io.File ovF = new java.io.File(dir, "board-override.json");
            if (ovF.exists()) {
                BOARD_OVERRIDE.set(JsonParser.parseString(java.nio.file.Files.readString(ovF.toPath())).getAsJsonObject());
            }
        } catch (Throwable ignored) {}
    }

    private static ArenaHotPatch loadPatchBytes(byte[] jarBytes, String entryClass) throws Exception {
        Map<String, byte[]> classes = new HashMap<>();
        try (JarInputStream jis = new JarInputStream(new ByteArrayInputStream(jarBytes))) {
            JarEntry je;
            while ((je = jis.getNextJarEntry()) != null) {
                if (!je.isDirectory() && je.getName().endsWith(".class")) {
                    String cname = je.getName().substring(0, je.getName().length() - 6).replace('/', '.');
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    byte[] buf = new byte[4096];
                    int r;
                    while ((r = jis.read(buf)) > 0) bos.write(buf, 0, r);
                    classes.put(cname, bos.toByteArray());
                }
            }
        }
        InMemoryPatchClassLoader loader = new InMemoryPatchClassLoader(
                ArenaAiMod.class.getClassLoader(), classes
        );
        Class<?> cls = Class.forName(entryClass, true, loader);
        Object inst = cls.getDeclaredConstructor().newInstance();
        if (!(inst instanceof ArenaHotPatch patch)) {
            throw new IllegalArgumentException(entryClass + " does not implement ArenaHotPatch");
        }
        ACTIVE_PATCH.set(patch);
        return patch;
    }

    public static MinecraftServer getLastServer() {
        return lastServerRef;
    }

    public static ArenaHotPatch getActivePatch() {
        return ACTIVE_PATCH.get();
    }

    public static JsonObject getBoardOverride() {
        return BOARD_OVERRIDE.get();
    }

    public static boolean renderWorldMapBoard(
            BlockEntity entity, float tickDelta, MatrixStack matrices,
            VertexConsumerProvider vcp, int light, int overlay
    ) {
        ArenaHotPatch p = ACTIVE_PATCH.get();
        if (p != null) {
            try {
                if (p.renderWorldMapBoard(entity, tickDelta, matrices, vcp, light, overlay)) {
                    return true;
                }
            } catch (Throwable ignored) {}
        }
        return false;
    }

    public static boolean renderNewsBoard(
            BlockEntity entity, float tickDelta, MatrixStack matrices,
            VertexConsumerProvider vcp, int light, int overlay
    ) {
        ArenaHotPatch p = ACTIVE_PATCH.get();
        if (p != null) {
            try {
                if (p.renderNewsBoard(entity, tickDelta, matrices, vcp, light, overlay)) {
                    return true;
                }
            } catch (Throwable ignored) {}
        }
        return false;
    }

    public static boolean renderVendingMachine(
            BlockEntity entity, float tickDelta, MatrixStack matrices,
            VertexConsumerProvider vcp, int light, int overlay
    ) {
        ArenaHotPatch p = ACTIVE_PATCH.get();
        if (p != null) {
            try {
                if (p.renderVendingMachine(entity, tickDelta, matrices, vcp, light, overlay)) {
                    return true;
                }
            } catch (Throwable ignored) {}
        }
        return false;
    }

    public static void onClientTick(MinecraftClient client) {
        ArenaHotPatch p = ACTIVE_PATCH.get();
        if (p != null) {
            try { p.onClientTick(client); } catch (Throwable ignored) {}
        }
    }

    public static void onServerTick(MinecraftServer server) {
        lastServerRef = server;
        ArenaHotPatch p = ACTIVE_PATCH.get();
        if (p != null) {
            try { p.onServerTick(server); } catch (Throwable ignored) {}
        }
    }

    /**
     * Renders optional declarative JSON overlay primitives ("primitives": [...]) onto an already-oriented board face.
     */
    public static boolean renderCustomPrimitivesIfFullReplace(
            String targetBoard, MatrixStack matrices, VertexConsumerProvider vcp, TextRenderer tr, int fullBright
    ) {
        JsonObject ov = BOARD_OVERRIDE.get();
        if (ov == null || !ov.has("primitives")) return false;
        String target = ov.has("target") ? ov.get("target").getAsString() : "world_map_board";
        if (!targetBoard.equals(target)) return false;
        boolean replace = ov.has("replace") && ov.get("replace").getAsBoolean();
        if (!replace) return false;
        drawPrimitives(ov.getAsJsonArray("primitives"), matrices, vcp, tr, fullBright);
        return true;
    }

    public static void renderCustomOverlayPrimitives(
            String targetBoard, MatrixStack matrices, VertexConsumerProvider vcp, TextRenderer tr, int fullBright
    ) {
        JsonObject ov = BOARD_OVERRIDE.get();
        if (ov == null || !ov.has("primitives")) return;
        String target = ov.has("target") ? ov.get("target").getAsString() : "world_map_board";
        if (!targetBoard.equals(target)) return;
        if (ov.has("replace") && ov.get("replace").getAsBoolean()) return;
        drawPrimitives(ov.getAsJsonArray("primitives"), matrices, vcp, tr, fullBright);
    }

    private static void drawPrimitives(
            JsonArray prims, MatrixStack matrices, VertexConsumerProvider vcp, TextRenderer tr, int fullBright
    ) {
        if (prims == null) return;
        // Pass 1: all quads first (preserves VertexConsumerProvider.Immediate buffer safety!)
        VertexConsumer vc = vcp.getBuffer(RenderLayer.getGui());
        Matrix4f mat = matrices.peek().getPositionMatrix();
        for (JsonElement el : prims) {
            if (!el.isJsonObject()) continue;
            JsonObject o = el.getAsJsonObject();
            String type = o.has("type") ? o.get("type").getAsString() : "";
            if ("quad".equals(type)) {
                float x0 = o.get("x0").getAsFloat();
                float y0 = o.get("y0").getAsFloat();
                float x1 = o.get("x1").getAsFloat();
                float y1 = o.get("y1").getAsFloat();
                float z  = o.has("z") ? o.get("z").getAsFloat() : 0.002f;
                int argb = parseHexArgb(o.has("color") ? o.get("color").getAsString() : "#FFFFFFFF");
                int a = (argb >>> 24) & 0xFF, r = (argb >>> 16) & 0xFF, g = (argb >>> 8) & 0xFF, b = argb & 0xFF;
                vc.vertex(mat, x0, y0, z).color(r, g, b, a).next();
                vc.vertex(mat, x1, y0, z).color(r, g, b, a).next();
                vc.vertex(mat, x1, y1, z).color(r, g, b, a).next();
                vc.vertex(mat, x0, y1, z).color(r, g, b, a).next();
            }
        }
        // Pass 2: all text elements
        if (tr == null) return;
        for (JsonElement el : prims) {
            if (!el.isJsonObject()) continue;
            JsonObject o = el.getAsJsonObject();
            String type = o.has("type") ? o.get("type").getAsString() : "";
            if ("text".equals(type) && o.has("text")) {
                String txt = o.get("text").getAsString();
                float leftX = o.get("x").getAsFloat();
                float topY  = o.get("y").getAsFloat();
                float scale = o.has("scale") ? o.get("scale").getAsFloat() : 0.0031f;
                int argb = parseHexArgb(o.has("color") ? o.get("color").getAsString() : "#FFFFFFFF");
                matrices.push();
                matrices.translate(leftX, topY, 0.0042f);
                matrices.scale(scale, -scale, scale);
                tr.draw(txt, 0f, 0f, argb, false, matrices.peek().getPositionMatrix(),
                        vcp, TextRenderer.TextLayerType.NORMAL, 0, fullBright);
                matrices.pop();
            }
        }
    }

    private static int parseHexArgb(String s) {
        if (s == null) return 0xFFFFFFFF;
        String h = s.startsWith("#") ? s.substring(1) : s;
        long v = Long.parseUnsignedLong(h, 16);
        return h.length() <= 6 ? (int) (0xFF000000L | v) : (int) v;
    }

    public static JsonObject handleHttp(String method, String bodyStr) {
        JsonObject res = new JsonObject();
        try {
            if ("GET".equalsIgnoreCase(method) || bodyStr == null || bodyStr.isBlank()) {
                ArenaHotPatch cur = ACTIVE_PATCH.get();
                res.addProperty("ok", true);
                res.addProperty("hasPatch", cur != null);
                res.addProperty("patchId", cur != null ? cur.getPatchId() : "none");
                res.add("boardOverride", BOARD_OVERRIDE.get());
                return res;
            }

            JsonObject req = JsonParser.parseString(bodyStr).getAsJsonObject();
            if (req.has("hotpatch") && req.get("hotpatch").isJsonObject()) {
                req = req.getAsJsonObject("hotpatch");
            }
            String op = req.has("op") ? req.get("op").getAsString() : "status";

            switch (op) {
                case "load_jar": {
                    String b64 = req.get("jarBase64").getAsString();
                    String entryClass = req.has("entryClass")
                            ? req.get("entryClass").getAsString()
                            : "ai.arena.bridge.hotpatch.LivePatchImpl";
                    byte[] jarBytes = Base64.getDecoder().decode(b64);
                    ArenaHotPatch patch = loadPatchBytes(jarBytes, entryClass);
                    // Persist to disk so the patch survives restarts automatically!
                    try {
                        java.io.File dir = getPatchDir();
                        dir.mkdirs();
                        java.nio.file.Files.write(new java.io.File(dir, "active-patch.jar").toPath(), jarBytes);
                        JsonObject meta = new JsonObject();
                        meta.addProperty("entryClass", entryClass);
                        meta.addProperty("modVersion", "7.7.0");
                        meta.addProperty("patchId", patch.getPatchId());
                        java.nio.file.Files.writeString(new java.io.File(dir, "active-patch.json").toPath(), meta.toString());
                    } catch (Throwable ignored) {}
                    res.addProperty("ok", true);
                    res.addProperty("persisted", true);
                    res.addProperty("patchId", patch.getPatchId());
                    return res;
                }
                case "invoke": {
                    ArenaHotPatch cur = ACTIVE_PATCH.get();
                    if (cur == null) {
                        res.addProperty("ok", false);
                        res.addProperty("error", "no_active_patch");
                        return res;
                    }
                    JsonObject payload = req.has("payload") && req.get("payload").isJsonObject()
                            ? req.getAsJsonObject("payload") : new JsonObject();
                    String thread = req.has("thread") ? req.get("thread").getAsString() : "client";
                    MinecraftClient mc = MinecraftClient.getInstance();
                    MinecraftServer srv = lastServerRef != null ? lastServerRef : (mc != null ? mc.getServer() : null);
                    if ("server".equalsIgnoreCase(thread) && srv != null) {
                        CompletableFuture<JsonObject> cf = new CompletableFuture<>();
                        srv.execute(() -> {
                            try { cf.complete(cur.invoke(mc, srv, payload)); }
                            catch (Throwable t) {
                                JsonObject e = new JsonObject();
                                e.addProperty("ok", false);
                                e.addProperty("error", t.toString());
                                cf.complete(e);
                            }
                        });
                        return cf.get(5, TimeUnit.SECONDS);
                    } else if ("client".equalsIgnoreCase(thread) && mc != null) {
                        CompletableFuture<JsonObject> cf = new CompletableFuture<>();
                        mc.execute(() -> {
                            try { cf.complete(cur.invoke(mc, srv, payload)); }
                            catch (Throwable t) {
                                JsonObject e = new JsonObject();
                                e.addProperty("ok", false);
                                e.addProperty("error", t.toString());
                                cf.complete(e);
                            }
                        });
                        return cf.get(5, TimeUnit.SECONDS);
                    }
                    return cur.invoke(mc, srv, payload);
                }
                case "board_override": {
                    JsonObject cfg = req.has("config") && req.get("config").isJsonObject()
                            ? req.getAsJsonObject("config") : null;
                    BOARD_OVERRIDE.set(cfg);
                    try {
                        java.io.File dir = getPatchDir();
                        dir.mkdirs();
                        java.io.File ovF = new java.io.File(dir, "board-override.json");
                        if (cfg != null) java.nio.file.Files.writeString(ovF.toPath(), cfg.toString());
                        else if (ovF.exists()) ovF.delete();
                    } catch (Throwable ignored) {}
                    res.addProperty("ok", true);
                    res.addProperty("hasOverride", cfg != null);
                    return res;
                }
                case "clear": {
                    ACTIVE_PATCH.set(null);
                    BOARD_OVERRIDE.set(null);
                    try {
                        java.io.File dir = getPatchDir();
                        new java.io.File(dir, "active-patch.jar").delete();
                        new java.io.File(dir, "active-patch.json").delete();
                        new java.io.File(dir, "board-override.json").delete();
                    } catch (Throwable ignored) {}
                    res.addProperty("ok", true);
                    res.addProperty("cleared", true);
                    return res;
                }
                default: {
                    ArenaHotPatch cur = ACTIVE_PATCH.get();
                    res.addProperty("ok", true);
                    res.addProperty("hasPatch", cur != null);
                    res.addProperty("patchId", cur != null ? cur.getPatchId() : "none");
                    return res;
                }
            }
        } catch (Throwable t) {
            res.addProperty("ok", false);
            res.addProperty("error", t.toString());
            return res;
        }
    }

    private static final class InMemoryPatchClassLoader extends ClassLoader {
        private final Map<String, byte[]> classDefs;

        InMemoryPatchClassLoader(ClassLoader parent, Map<String, byte[]> classDefs) {
            super(parent);
            this.classDefs = classDefs;
        }

        @Override
        protected Class<?> findClass(String name) throws ClassNotFoundException {
            byte[] bytes = classDefs.get(name);
            if (bytes != null) {
                return defineClass(name, bytes, 0, bytes.length);
            }
            throw new ClassNotFoundException(name);
        }
    }
}

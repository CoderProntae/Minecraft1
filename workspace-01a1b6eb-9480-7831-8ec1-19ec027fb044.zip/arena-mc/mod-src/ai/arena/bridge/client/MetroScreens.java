package ai.arena.bridge.client;

import ai.arena.bridge.ArenaContent;
import ai.arena.bridge.transit.RegionPolicyEngine;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;

/**
 * Custom Pixel-Art Textured Minecraft GUI Screens for Vending Machine & Info Kiosk (v7.5.0):
 * - Uses bespoke 256x256 beveled pixel-art GUI textures (vending_gui.png & kiosk_gui.png) via DrawContext.drawTexture.
 * - Authentic recessed 18x18 Minecraft item slot wells with hover highlights & real item tooltips.
 * - Custom sprite-sliced tactile buttons (normal / hovered / disabled).
 */
public final class MetroScreens {

    private static final Identifier VENDING_GUI_TEX = new Identifier(ArenaContent.MOD_ID, "textures/gui/vending_gui.png");
    private static final Identifier KIOSK_GUI_TEX   = new Identifier(ArenaContent.MOD_ID, "textures/gui/kiosk_gui.png");

    private MetroScreens() {}

    public static void openVendingScreen(BlockPos pos) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc != null) {
            mc.setScreen(new VendingScreen(pos));
        }
    }

    public static void openInfoKioskScreen(BlockPos pos) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc != null) {
            mc.setScreen(new InfoKioskScreen(pos));
        }
    }

    private record SpriteRect(int x, int y, int w, int h, Runnable action, boolean enabled, boolean secondary, String label) {
        boolean contains(double mx, double my) {
            return mx >= x && mx < x + w && my >= y && my < y + h;
        }
    }

    public static class VendingScreen extends Screen {
        private static final Item[] ITEMS = {
                Items.APPLE, Items.BREAD, Items.COOKIE, Items.SWEET_BERRIES, Items.GOLDEN_CARROT
        };
        private static final String[] NAMES = {
                "Taze Orman Elması", "Sıcak Sandviç Ekmeği", "Metro Kurabiyesi", "Böğürtlen Paketi", "Altın Havuç Enerji"
        };
        private static final int[] BASE_PRICES = { 4, 4, 4, 4, 6 };

        private static final int BG_W = 224;
        private static final int BG_H = 172;

        private final BlockPos machinePos;
        private final List<SpriteRect> buttons = new ArrayList<>();
        private int guiX;
        private int guiY;

        public VendingScreen(BlockPos pos) {
            super(Text.literal("Metro İkram Otomatı"));
            this.machinePos = pos;
        }

        @Override
        protected void init() {
            this.guiX = (this.width - BG_W) / 2;
            this.guiY = (this.height - BG_H) / 2;
            rebuildButtons();
        }

        private void rebuildButtons() {
            buttons.clear();
            MinecraftClient mc = MinecraftClient.getInstance();
            int bal = (mc != null && mc.world != null && mc.player != null)
                    ? ArenaContent.getPlayerMtrBalance(mc.world.getScoreboard(), mc.player) : 0;

            for (int i = 0; i < ITEMS.length; i++) {
                final int idx = i;
                int price = (mc != null && mc.world != null && mc.player != null)
                        ? RegionPolicyEngine.computeShopPrice(mc.world, machinePos, mc.player, BASE_PRICES[i])
                        : BASE_PRICES[i];
                int bx = guiX + 154;
                int by = guiY + 36 + i * 20;
                boolean canAfford = bal >= price;
                buttons.add(new SpriteRect(bx, by, 54, 16, () -> sendCmd("otomat al " + idx + " " + machinePos.getX() + " " + machinePos.getY() + " " + machinePos.getZ()), canAfford, false, price + " TL"));
            }

            // Bottom wallet top-up buttons (+10 TL Emerald, +5 TL Gold)
            buttons.add(new SpriteRect(guiX + 14, guiY + 145, 88, 16, () -> sendCmd("otomat yukle zumrut"), true, true, "+10 TL (Zümrüt)"));
            buttons.add(new SpriteRect(guiX + 122, guiY + 145, 88, 16, () -> sendCmd("otomat yukle altin"), true, true, "+5 TL (Altın)"));
        }

        private void sendCmd(String cmd) {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc != null && mc.player != null && mc.player.networkHandler != null) {
                mc.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, 1.0f));
                mc.player.networkHandler.sendCommand(cmd);
            }
        }

        @Override
        public void render(DrawContext context, int mouseX, int mouseY, float delta) {
            this.renderBackground(context, mouseX, mouseY, delta);
            rebuildButtons();

            MinecraftClient mc = MinecraftClient.getInstance();
            int bal = (mc != null && mc.world != null && mc.player != null)
                    ? ArenaContent.getPlayerMtrBalance(mc.world.getScoreboard(), mc.player) : 0;
            int disc = (mc != null && mc.world != null && mc.player != null)
                    ? RegionPolicyEngine.getBestShopDiscountPct(mc.world, machinePos, mc.player) : 0;

            // 1. Custom 224x172 Beveled Pixel-Art Container Window
            context.drawTexture(VENDING_GUI_TEX, guiX, guiY, 0, 0, BG_W, BG_H, 256, 256);

            // 2. Header text & live balance
            context.drawTextWithShadow(this.textRenderer, Text.literal("METRO OTOMAT").formatted(Formatting.AQUA, Formatting.BOLD), guiX + 14, guiY + 13, 0xFFFFFF);
            String balStr = "Bakiye: " + bal + " TL" + (disc > 0 ? " (-%" + disc + ")" : "");
            int balW = this.textRenderer.getWidth(balStr);
            context.drawTextWithShadow(this.textRenderer, balStr, guiX + BG_W - 14 - balW, guiY + 13, disc > 0 ? 0x55FFAA : 0xFFE066);

            // 3. 5 Recessed 18x18 Item Slots + Item Titles + Hover Highlights
            ItemStack hoveredStack = null;
            for (int i = 0; i < ITEMS.length; i++) {
                int slotX = guiX + 14;
                int slotY = guiY + 35 + i * 20;
                ItemStack stack = new ItemStack(ITEMS[i]);
                context.drawItem(stack, slotX + 1, slotY + 1);

                if (mouseX >= slotX && mouseX < slotX + 18 && mouseY >= slotY && mouseY < slotY + 18) {
                    context.fill(slotX + 1, slotY + 1, slotX + 17, slotY + 17, 0x55FFFFFF);
                    hoveredStack = stack;
                }
                context.drawTextWithShadow(this.textRenderer, NAMES[i], guiX + 37, slotY + 5, 0xE2E8F0);
            }

            // 4. Custom Sprite-Sliced Tactile Buttons
            for (SpriteRect b : buttons) {
                boolean hov = b.contains(mouseX, mouseY);
                if (b.secondary()) {
                    int u = hov ? 90 : 0;
                    context.drawTexture(VENDING_GUI_TEX, b.x(), b.y(), u, 194, 88, 16, 256, 256);
                } else {
                    int u = !b.enabled() ? 112 : (hov ? 56 : 0);
                    context.drawTexture(VENDING_GUI_TEX, b.x(), b.y(), u, 176, 54, 16, 256, 256);
                }
                int tw = this.textRenderer.getWidth(b.label());
                int col = !b.enabled() ? 0x888892 : (hov ? 0xFFFFCC : 0xF8FAFC);
                context.drawTextWithShadow(this.textRenderer, b.label(), b.x() + (b.w() - tw) / 2, b.y() + 4, col);
            }

            if (hoveredStack != null) {
                context.drawItemTooltip(this.textRenderer, hoveredStack, mouseX, mouseY);
            }
        }

        @Override
        public boolean mouseClicked(double mouseX, double mouseY, int button) {
            if (button == 0) {
                for (SpriteRect b : buttons) {
                    if (b.enabled() && b.contains(mouseX, mouseY)) {
                        b.action().run();
                        return true;
                    }
                }
            }
            return super.mouseClicked(mouseX, mouseY, button);
        }

        @Override
        public boolean shouldPause() {
            return false;
        }
    }

    public static class InfoKioskScreen extends Screen {
        private static final int BG_W = 228;
        private static final int BG_H = 164;

        private final BlockPos kioskPos;
        private int guiX;
        private int guiY;
        private SpriteRect closeBtn;

        public InfoKioskScreen(BlockPos pos) {
            super(Text.literal("Yolcu Bilgi Terminali"));
            this.kioskPos = pos;
        }

        @Override
        protected void init() {
            this.guiX = (this.width - BG_W) / 2;
            this.guiY = (this.height - BG_H) / 2;
            this.closeBtn = new SpriteRect(guiX + (BG_W - 80) / 2, guiY + 139, 80, 16, this::close, true, true, "Kapat");
        }

        @Override
        public void render(DrawContext context, int mouseX, int mouseY, float delta) {
            this.renderBackground(context, mouseX, mouseY, delta);
            MinecraftClient mc = MinecraftClient.getInstance();
            int bal = (mc != null && mc.world != null && mc.player != null)
                    ? ArenaContent.getPlayerMtrBalance(mc.world.getScoreboard(), mc.player) : 0;
            String reg = (mc != null && mc.world != null)
                    ? RegionPolicyEngine.getPrimaryRegionDisplay(mc.world, kioskPos) : "Standart Bölge";
            boolean freeTransit = (mc != null && mc.world != null && mc.player != null)
                    ? RegionPolicyEngine.hasFreeTransitInRegion(mc.world, kioskPos, mc.player) : false;
            int shopDisc = (mc != null && mc.world != null && mc.player != null)
                    ? RegionPolicyEngine.getBestShopDiscountPct(mc.world, kioskPos, mc.player) : 0;

            context.drawTexture(KIOSK_GUI_TEX, guiX, guiY, 0, 0, BG_W, BG_H, 256, 256);

            context.drawTextWithShadow(this.textRenderer, Text.literal("YOLCU BİLGİ TERMİNALİ").formatted(Formatting.AQUA, Formatting.BOLD), guiX + 15, guiY + 15, 0xFFFFFF);
            String balTxt = bal + " TL";
            context.drawTextWithShadow(this.textRenderer, balTxt, guiX + BG_W - 15 - this.textRenderer.getWidth(balTxt), guiY + 15, 0xFFE066);

            // Card 1: Active Region & Line
            context.drawTextWithShadow(this.textRenderer, "Konum / Bölge:", guiX + 20, guiY + 45, 0x94A3B8);
            context.drawTextWithShadow(this.textRenderer, reg, guiX + 100, guiY + 45, 0xF8FAFC);
            context.drawTextWithShadow(this.textRenderer, "Aktif Hat: M1 Orman Metrosu (80 km/s)", guiX + 20, guiY + 55, 0x7DD3FC);

            // Card 2: Transit Tariff
            context.drawTextWithShadow(this.textRenderer, "Turnike Geçiş:", guiX + 20, guiY + 75, 0x94A3B8);
            context.drawTextWithShadow(
                    this.textRenderer,
                    freeTransit ? "Bölge Kartı ile ÜCRETSİZ" : "Standart Tarife",
                    guiX + 100, guiY + 75,
                    freeTransit ? 0x4ADE80 : 0xFDE047
            );
            context.drawTextWithShadow(this.textRenderer, "Sefer Aralığı: Karşılıklı Otomatik", guiX + 20, guiY + 85, 0xCBD5E1);

            // Card 3: Shop & Vending Policy
            context.drawTextWithShadow(
                    this.textRenderer,
                    shopDisc > 0 ? ("Otomat & Mağaza İndirimi: %" + shopDisc + " Aktif") : "Otomat & Mağaza: Standart Fiyat",
                    guiX + 20, guiY + 105,
                    shopDisc > 0 ? 0x6EE7B7 : 0xE2E8F0
            );
            context.drawTextWithShadow(this.textRenderer, "Zümrüt (+10 TL) / Altın (+5 TL) yüklenir", guiX + 20, guiY + 115, 0x94A3B8);

            boolean hov = closeBtn.contains(mouseX, mouseY);
            context.drawTexture(KIOSK_GUI_TEX, closeBtn.x(), closeBtn.y(), hov ? 82 : 0, 170, 80, 16, 256, 256);
            int tw = this.textRenderer.getWidth(closeBtn.label());
            context.drawTextWithShadow(this.textRenderer, closeBtn.label(), closeBtn.x() + (80 - tw) / 2, closeBtn.y() + 4, hov ? 0xFFFFCC : 0xF8FAFC);
        }

        @Override
        public boolean mouseClicked(double mouseX, double mouseY, int button) {
            if (button == 0 && closeBtn != null && closeBtn.contains(mouseX, mouseY)) {
                MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, 1.0f));
                this.close();
                return true;
            }
            return super.mouseClicked(mouseX, mouseY, button);
        }

        @Override
        public boolean shouldPause() {
            return false;
        }
    }
}

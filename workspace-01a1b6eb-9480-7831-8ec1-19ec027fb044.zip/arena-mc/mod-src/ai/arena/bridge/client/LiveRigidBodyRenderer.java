package ai.arena.bridge.client;

import ai.arena.bridge.ArenaContent;
import ai.arena.bridge.map.ArenaMapData;
import ai.arena.bridge.physics.GeoStructuralPhysicsEngine;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.render.block.BlockRenderManager;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Quaternionf;

import java.util.List;
import java.util.Locale;

/**
 * Client-Side 60 FPS Physics-Mod Renderer, 3-DoF Railway Carbody Sway ODE,
 * Recorded 3D Emergency Alarm Sync, and Geotechnical/Structural Radar HUD (v7.7.0).
 */
public final class LiveRigidBodyRenderer {

    public static volatile boolean radarOpen = false;

    // 2nd-order bogie suspension state (roll phi, pitch theta, vertical heave z_c)
    private static double rollRad = 0.0, rollVel = 0.0;
    private static double pitchRad = 0.0, pitchVel = 0.0;
    private static double heaveM = 0.0, heaveVel = 0.0;
    private static double rmsVertAccelMps2 = 0.05;
    private static long lastSwayNs = 0L;
    private static long lastBeepWorldTick = -1L;

    private LiveRigidBodyRenderer() {}

    /**
     * Called in WorldRenderEvents.START: integrates 60 Hz railway secondary suspension ODE
     * and applies realistic carbody roll, pitch & vertical bounce when riding an MTR train!
     */
    public static void applyTrainCarbodySway(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.player == null || mc.world == null) return;

        long nowNs = System.nanoTime();
        double dt = (lastSwayNs == 0L) ? 0.016 : Math.min(0.05, Math.max(0.001, (nowNs - lastSwayNs) * 1e-9));
        lastSwayNs = nowNs;

        ArenaMapData.LiveTrainInfo aboard = null;
        double bestD2 = 16.0;
        for (ArenaMapData.LiveTrainInfo t : ArenaMapData.getLiveTrains()) {
            double dx = mc.player.getX() - t.x;
            double dy = mc.player.getY() - t.y;
            double dz = mc.player.getZ() - t.z;
            double horizD2 = dx * dx + dz * dz;
            if (horizD2 < 14.0 && Math.abs(dy) < 4.5 && horizD2 < bestD2) {
                bestD2 = horizD2;
                aboard = t;
            }
        }

        if (aboard == null || aboard.speedKmh < 0.8) {
            // Smoothly damp suspension back to rest when standing on platform
            rollRad *= Math.pow(0.08, dt);
            pitchRad *= Math.pow(0.08, dt);
            heaveM *= Math.pow(0.08, dt);
            rollVel *= 0.85;
            pitchVel *= 0.85;
            heaveVel *= 0.85;
            GeoStructuralPhysicsEngine.clientTrainRollDeg = (float) Math.toDegrees(rollRad);
            GeoStructuralPhysicsEngine.clientSperlingWz = 1.0f;
            return;
        }

        double vMps = aboard.speedKmh / 3.6;
        double sPos = aboard.z;
        GeoStructuralPhysicsEngine.TunnelRingState ring = GeoStructuralPhysicsEngine.getRingForZ(sPos);
        double settlementMm = (ring != null) ? ring.settlementMm : 0.0;
        int crackStage = (ring != null) ? ring.crackStage : 0;

        // Track PSD roughness + welded rail joint harmonic (Lambda1=12.5m, Lambda2=28m) + local tunnel settlement!
        double degradationAmp = 1.0 + (settlementMm / 9.0) + (crackStage * 1.15);
        double stormCrosswind = (mc.world.isThundering() && aboard.y > 58.0) ? 0.012 : 0.0;
        double speedScale = Math.min(1.35, vMps / 22.22);

        // Cross-level track irregularity excitation (radians) & vertical rail profile (meters)
        double klingelFreqHz = Math.max(0.6, (vMps / (2.0 * Math.PI)) * 0.17);
        double timeSec = nowNs * 1e-9;
        double crossLevelRad = speedScale * degradationAmp * (
                0.0042 * Math.sin(2.0 * Math.PI * sPos / 12.5)
                + 0.0028 * Math.sin(2.0 * Math.PI * sPos / 28.0 + 1.1)
                + 0.0022 * Math.sin(2.0 * Math.PI * klingelFreqHz * timeSec)
        ) + stormCrosswind * Math.sin(timeSec * 1.9);

        double vertTrackM = speedScale * degradationAmp * (
                0.0055 * Math.cos(2.0 * Math.PI * sPos / 12.5)
                + 0.0035 * Math.sin(2.0 * Math.PI * sPos / 6.25)
        );

        // 2nd-order secondary air-spring bogie suspension: wn_roll = 7.2 rad/s (1.15 Hz), zeta = 0.28
        double wnRoll = 7.2, zetaRoll = 0.28;
        double rollAcc = wnRoll * wnRoll * (crossLevelRad - rollRad) - 2.0 * zetaRoll * wnRoll * rollVel;
        rollVel += rollAcc * dt;
        rollRad = MathHelper.clamp(rollRad + rollVel * dt, -0.065, 0.065); // max ~3.7°

        double wnPitch = 8.4, zetaPitch = 0.32;
        double pitchTarget = speedScale * degradationAmp * 0.0026 * Math.sin(2.0 * Math.PI * sPos / 18.0);
        double pitchAcc = wnPitch * wnPitch * (pitchTarget - pitchRad) - 2.0 * zetaPitch * wnPitch * pitchVel;
        pitchVel += pitchAcc * dt;
        pitchRad = MathHelper.clamp(pitchRad + pitchVel * dt, -0.035, 0.035);

        double wnHeave = 8.8, zetaHeave = 0.30;
        double heaveAcc = wnHeave * wnHeave * (vertTrackM - heaveM) - 2.0 * zetaHeave * wnHeave * heaveVel;
        heaveVel += heaveAcc * dt;
        heaveM = MathHelper.clamp(heaveM + heaveVel * dt, -0.045, 0.045);

        // Filtered RMS vertical acceleration -> Sperling Ride Index Wz (GB/T 5599 / UIC 518)
        rmsVertAccelMps2 = rmsVertAccelMps2 * 0.94 + Math.abs(heaveAcc) * 0.06;
        double accCmS2 = Math.max(1.5, rmsVertAccelMps2 * 100.0);
        double fc = 1.40; // dominant carbody natural frequency (Hz)
        double wz = 0.896 * Math.pow((accCmS2 * accCmS2 * accCmS2) / fc, 0.10);

        GeoStructuralPhysicsEngine.clientTrainRollDeg = (float) Math.toDegrees(rollRad);
        GeoStructuralPhysicsEngine.clientTrainPitchDeg = (float) Math.toDegrees(pitchRad);
        GeoStructuralPhysicsEngine.clientTrainHeaveM = (float) heaveM;
        GeoStructuralPhysicsEngine.clientSperlingWz = (float) MathHelper.clamp(wz, 1.0, 5.2);

        MatrixStack ms = ctx.matrixStack();
        if (ms != null) {
            ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((float) Math.toDegrees(rollRad)));
            ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees((float) Math.toDegrees(pitchRad)));
            ms.translate(0.0, -heaveM, 0.0);
        }
    }

    /**
     * Called in WorldRenderEvents.AFTER_ENTITIES: renders all live 6-DoF tumbling blocks
     * and continuous rotational P-Delta tilting buildings!
     */
    public static void renderWorldBodies(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientWorld world = ctx.world();
        MatrixStack matrices = ctx.matrixStack();
        VertexConsumerProvider vcp = ctx.consumers();
        if (mc == null || world == null || matrices == null || vcp == null) return;

        Vec3d cam = ctx.camera().getPos();
        float tickDelta = ctx.tickDelta();
        BlockRenderManager brm = mc.getBlockRenderManager();

        Quaternionf interpQ = new Quaternionf();
        for (GeoStructuralPhysicsEngine.PhysicsRigidBody rb : GeoStructuralPhysicsEngine.RIGID_BODIES) {
            double lx = MathHelper.lerp(tickDelta, rb.prevPx, rb.px);
            double ly = MathHelper.lerp(tickDelta, rb.prevPy, rb.py);
            double lz = MathHelper.lerp(tickDelta, rb.prevPz, rb.pz);
            double dx = lx - cam.x, dy = ly - cam.y, dz = lz - cam.z;
            if (dx * dx + dy * dy + dz * dz > 76.0 * 76.0) continue;

            interpQ.set(rb.prevQuat).nlerp(rb.quat, tickDelta);
            int light = WorldRenderer.getLightmapCoordinates(world, BlockPos.ofFloored(lx, ly, lz));

            matrices.push();
            matrices.translate(dx, dy, dz);
            matrices.multiply(interpQ);
            matrices.translate(-0.5f, -0.5f, -0.5f);
            brm.renderBlockAsEntity(rb.state, matrices, vcp, light, OverlayTexture.DEFAULT_UV);
            matrices.pop();
        }

        Quaternionf tiltQ = new Quaternionf();
        for (GeoStructuralPhysicsEngine.TiltingStructureBody b : GeoStructuralPhysicsEngine.TILTING_STRUCTURES) {
            double hx = b.hinge.getX() + 0.5;
            double hy = b.hinge.getY();
            double hz = b.hinge.getZ() + 0.5;
            double dx = hx - cam.x, dy = hy - cam.y, dz = hz - cam.z;
            if (dx * dx + dy * dy + dz * dz > 96.0 * 96.0) continue;

            float tx = MathHelper.lerp(tickDelta, (float) b.prevTiltXRad, (float) b.tiltXRad);
            float tz = MathHelper.lerp(tickDelta, (float) b.prevTiltZRad, (float) b.tiltZRad);
            tiltQ.identity().rotationXYZ(tx, 0.0f, tz);
            int baseLight = WorldRenderer.getLightmapCoordinates(world, b.hinge.up(2));

            matrices.push();
            matrices.translate(dx, dy, dz);
            matrices.multiply(tiltQ);
            for (GeoStructuralPhysicsEngine.RelBlock rel : b.blocks) {
                matrices.push();
                matrices.translate(rel.dx() - 0.5f, rel.dy(), rel.dz() - 0.5f);
                brm.renderBlockAsEntity(rel.state(), matrices, vcp, baseLight, OverlayTexture.DEFAULT_UV);
                matrices.pop();
            }
            matrices.pop();
        }
    }

    /**
     * Plays the genuine recorded tunnel_alarm_beep.ogg in 3D space at the exact start of each red LED flash
     * whenever an emergency=true damaged tunnel sector is within 26m!
     */
    public static void tickEmergencyAlarmAudio(MinecraftClient mc) {
        if (mc == null || mc.world == null || mc.player == null || mc.isPaused()) return;
        long wt = mc.world.getTime();
        // Synchronize with led_red_emergency.png.mcmeta (frametime: 10 => 20-tick cycle, ON at wt % 20 == 0)
        if ((wt % 20L) != 0L || wt == lastBeepWorldTick) return;

        BlockPos pPos = mc.player.getBlockPos();
        BlockPos.Mutable mp = new BlockPos.Mutable();
        BlockPos nearestAlarm = null;
        double bestD2 = Double.MAX_VALUE;

        for (int dz = -24; dz <= 24; dz += 2) {
            for (int dx = -8; dx <= 8; dx += 2) {
                int x = pPos.getX() + dx;
                int z = pPos.getZ() + dz;
                if (!mc.world.isChunkLoaded(x >> 4, z >> 4)) continue;
                for (int dy = -2; dy <= 6; dy++) {
                    int y = pPos.getY() + dy;
                    BlockState st = mc.world.getBlockState(mp.set(x, y, z));
                    if (st.isOf(ArenaContent.TUNNEL_EMERGENCY_LIGHT) && st.get(ArenaContent.EMERGENCY)) {
                        double d2 = mc.player.squaredDistanceTo(x + 0.5, y + 0.5, z + 0.5);
                        if (d2 < bestD2) {
                            bestD2 = d2;
                            nearestAlarm = new BlockPos(x, y, z);
                        }
                    }
                }
            }
        }

        if (nearestAlarm != null && bestD2 <= 28.0 * 28.0) {
            lastBeepWorldTick = wt;
            mc.world.playSound(
                    nearestAlarm.getX() + 0.5,
                    nearestAlarm.getY() + 0.5,
                    nearestAlarm.getZ() + 0.5,
                    ArenaContent.TUNNEL_ALARM_BEEP_EVENT,
                    SoundCategory.BLOCKS,
                    0.82f,
                    1.0f,
                    false
            );
        }
    }

    /**
     * Renders the toggleable Geotechnical & Structural Engineering Radar (press 'R' or /radar).
     */
    public static void renderGeotechnicalRadarHud(DrawContext ctx) {
        if (!radarOpen) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.player == null || mc.options.hudHidden) return;
        TextRenderer tr = mc.textRenderer;

        int x0 = 8, y0 = 8, w = 244, h = 136;
        ctx.fill(x0 - 2, y0 - 2, x0 + w + 2, y0 + h + 2, 0xCC0D131A);
        ctx.fill(x0, y0, x0 + w, y0 + 15, 0xEE182633);
        ctx.fill(x0, y0 + 15, x0 + w, y0 + 16, 0xFF00BCD4);

        ctx.drawText(tr, "JEOTEKNİK VE YAPISAL RADAR [R]", x0 + 6, y0 + 4, 0xFF80DEEA, false);

        // 103-ring longitudinal tunnel FoS bar
        int barX = x0 + 6, barY = y0 + 21, barW = w - 12, barH = 12;
        ctx.fill(barX, barY, barX + barW, barY + barH, 0xFF121A22);
        int n = GeoStructuralPhysicsEngine.RING_COUNT;
        for (int i = 0; i < n; i++) {
            GeoStructuralPhysicsEngine.TunnelRingState r = GeoStructuralPhysicsEngine.TUNNEL_RINGS[i];
            int sx0 = barX + (i * barW) / n;
            int sx1 = Math.max(sx0 + 1, barX + ((i + 1) * barW) / n);
            int col;
            if (r.crackStage >= 2 || r.factorOfSafety < 1.0) col = 0xFFE53935;
            else if (r.crackStage == 1 || r.factorOfSafety < 1.35) col = 0xFFFFB300;
            else col = 0xFF2E7D32;
            ctx.fill(sx0, barY + 2, sx1, barY + barH - 2, col);
        }
        // Player Z cursor on tunnel bar
        double pFrac = MathHelper.clamp((mc.player.getZ() - (-32.0)) / 1648.0, 0.0, 1.0);
        int px = barX + (int) Math.round(pFrac * (barW - 2));
        ctx.fill(px, barY, px + 2, barY + barH, 0xFF40C4FF);

        int ty = y0 + 38;
        double minFos = GeoStructuralPhysicsEngine.latestMinTunnelFos;
        int fosCol = minFos < 1.05 ? 0xFFFF5252 : (minFos < 1.35 ? 0xFFFFD54F : 0xFF81C784);
        ctx.drawText(tr, String.format(Locale.US, "Tünel Min FoS: %.2f (Z=%dm) | u_w: %.1f kPa",
                minFos, GeoStructuralPhysicsEngine.latestCriticalRingZ, GeoStructuralPhysicsEngine.latestMaxPoreWaterKpa),
                x0 + 6, ty, fosCol, false);

        ty += 12;
        double dcr = GeoStructuralPhysicsEngine.latestNearestColumnDcr;
        ctx.drawText(tr, String.format(Locale.US, "Kolon P-Delta DCR: %%%.0f (Euler FoS: %.1f, H=%dm)",
                dcr * 100.0, GeoStructuralPhysicsEngine.latestNearestColumnFos, GeoStructuralPhysicsEngine.latestNearestColumnHeight),
                x0 + 6, ty, dcr > 0.75 ? 0xFFFF8A65 : 0xFFB0BEC5, false);

        ty += 12;
        ctx.drawText(tr, String.format(Locale.US, "Darbe Yükü: %.1f kN | 6-DoF Blok: %d | Eğik Bina: %d",
                GeoStructuralPhysicsEngine.latestSurfaceImpulseKn,
                GeoStructuralPhysicsEngine.RIGID_BODIES.size(),
                GeoStructuralPhysicsEngine.TILTING_STRUCTURES.size()),
                x0 + 6, ty, 0xFFB0BEC5, false);

        ty += 12;
        float wz = GeoStructuralPhysicsEngine.clientSperlingWz;
        ctx.drawText(tr, String.format(Locale.US, "Tren Sallantı: %.2f° | Sperling Wz: %.2f (%s)",
                GeoStructuralPhysicsEngine.clientTrainRollDeg, wz,
                wz < 2.0f ? "Çok İyi" : (wz < 3.1f ? "Orta" : "Sarsıntılı!")),
                x0 + 6, ty, wz > 3.1f ? 0xFFFFD54F : 0xFF80CBC4, false);

        ty += 14;
        ctx.fill(x0 + 4, ty - 2, x0 + w - 4, ty - 1, 0xFF263238);
        List<GeoStructuralPhysicsEngine.StructuralAlert> alerts = GeoStructuralPhysicsEngine.ACTIVE_ALERTS;
        if (alerts.isEmpty()) {
            ctx.drawText(tr, "✓ Aktif yapısal arıza veya çökme yok", x0 + 6, ty + 2, 0xFF81C784, false);
        } else {
            int shown = 0;
            for (GeoStructuralPhysicsEngine.StructuralAlert a : alerts) {
                if (shown >= 3) break;
                String s = "! " + a.summary;
                if (tr.getWidth(s) > w - 12) {
                    while (s.length() > 10 && tr.getWidth(s + "..") > w - 12) s = s.substring(0, s.length() - 1);
                    s += "..";
                }
                ctx.drawText(tr, s, x0 + 6, ty + 2 + shown * 11, a.severity > 0.8 ? 0xFFFF5252 : 0xFFFFD54F, false);
                shown++;
            }
        }
    }
}

const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const ASSET_ROOT = '/home/user/arena-mc/mod-src/assets/arena_ai_bridge';
const OUT_DIR = '/home/user/arena-mc/vision/previews';
fs.mkdirSync(OUT_DIR, { recursive: true });

// Minimal exact PNG RGBA decoder (supports filter types 0..4)
function loadPng(filepath) {
  const buf = fs.readFileSync(filepath);
  let pos = 8, w = 0, h = 0;
  const idats = [];
  while (pos < buf.length) {
    const len = buf.readUInt32BE(pos);
    const type = buf.toString('ascii', pos + 4, pos + 8);
    const data = buf.subarray(pos + 8, pos + 8 + len);
    if (type === 'IHDR') { w = data.readUInt32BE(0); h = data.readUInt32BE(4); }
    else if (type === 'IDAT') idats.push(data);
    pos += 12 + len;
  }
  const raw = zlib.inflateSync(Buffer.concat(idats));
  const rgba = new Uint8Array(w * h * 4);
  const stride = w * 4;
  for (let y = 0; y < h; y++) {
    const f = raw[y * (stride + 1)];
    const rowOff = y * (stride + 1) + 1;
    for (let x = 0; x < stride; x++) {
      const left = x >= 4 ? rgba[y * stride + x - 4] : 0;
      const up   = y > 0  ? rgba[(y - 1) * stride + x] : 0;
      const ul   = (x >= 4 && y > 0) ? rgba[(y - 1) * stride + x - 4] : 0;
      let val = raw[rowOff + x];
      if (f === 1) val = (val + left) & 255;
      else if (f === 2) val = (val + up) & 255;
      else if (f === 3) val = (val + ((left + up) >> 1)) & 255;
      else if (f === 4) {
        const p = left + up - ul;
        const pa = Math.abs(p - left), pb = Math.abs(p - up), pc = Math.abs(p - ul);
        const pr = (pa <= pb && pa <= pc) ? left : (pb <= pc ? up : ul);
        val = (val + pr) & 255;
      }
      rgba[y * stride + x] = val;
    }
  }
  return { w, h, rgba };
}

function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c ^= buf[i];
    for (let k = 0; k < 8; k++) c = (c >>> 1) ^ (c & 1 ? 0xedb88320 : 0);
  }
  return (c ^ 0xffffffff) >>> 0;
}
function savePng(filepath, w, h, rgba) {
  const chunk = (t, d) => {
    const l = Buffer.alloc(4); l.writeUInt32BE(d.length, 0);
    const tb = Buffer.from(t, 'ascii');
    const cr = Buffer.alloc(4); cr.writeUInt32BE(crc32(Buffer.concat([tb, d])), 0);
    return Buffer.concat([l, tb, d, cr]);
  };
  const raw = Buffer.alloc(h * (1 + w * 4));
  for (let y = 0; y < h; y++) {
    raw[y * (1 + w * 4)] = 0;
    Buffer.from(rgba.buffer, y * w * 4, w * 4).copy(raw, y * (1 + w * 4) + 1);
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 6;
  fs.writeFileSync(filepath, Buffer.concat([
    Buffer.from([137,80,78,71,13,10,26,10]),
    chunk('IHDR', ihdr),
    chunk('IDAT', zlib.deflateSync(raw)),
    chunk('IEND', Buffer.alloc(0))
  ]));
}

// 3D Math helpers
const sub = (a,b) => [a[0]-b[0], a[1]-b[1], a[2]-b[2]];
const cross = (a,b) => [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]];
const dot = (a,b) => a[0]*b[0] + a[1]*b[1] + a[2]*b[2];
const norm = (v) => { const l = Math.hypot(...v) || 1; return [v[0]/l, v[1]/l, v[2]/l]; };

function rotatePoint(p, rot) {
  if (!rot) return p;
  const rad = (rot.angle * Math.PI) / 180.0;
  const c = Math.cos(rad), s = Math.sin(rad);
  let [x, y, z] = sub(p, rot.origin);
  if (rot.axis === 'x') {
    // Minecraft BlockModel rotation around X!
    const ny = y * c - z * s, nz = y * s + z * c;
    y = ny; z = nz;
  } else if (rot.axis === 'y') {
    const nx = x * c + z * s, nz = -x * s + z * c;
    x = nx; z = nz;
  } else if (rot.axis === 'z') {
    const nx = x * c - y * s, ny = x * s + y * c;
    x = nx; y = ny;
  }
  return [x + rot.origin[0], y + rot.origin[1], z + rot.origin[2]];
}

// Build textured quads from a Minecraft block model JSON at world offset [ox, oy, oz] (in 0..16 units)
const texCache = new Map();
function getTex(ref, texMap) {
  let r = ref;
  while (r && r.startsWith('#')) r = texMap[r.slice(1)];
  if (!r) return null;
  const rel = r.split(':')[1];
  const p = path.join(ASSET_ROOT, 'textures', rel + '.png');
  if (!texCache.has(p)) texCache.set(p, loadPng(p));
  return texCache.get(p);
}

function collectModelQuads(modelName, offset = [0, 0, 0]) {
  const md = JSON.parse(fs.readFileSync(path.join(ASSET_ROOT, 'models/block', modelName), 'utf8'));
  const quads = [];
  for (const el of (md.elements || [])) {
    const [x1, y1, z1] = el.from;
    const [x2, y2, z2] = el.to;
    // Exact Minecraft face vertex order (top-left, bottom-left, bottom-right, top-right looking AT the face!)
    const faceDefs = {
      north: { verts: [[x2,y2,z1],[x2,y1,z1],[x1,y1,z1],[x1,y2,z1]], shade: 0.92, defUv: [16-x2, 16-y2, 16-x1, 16-y1] },
      south: { verts: [[x1,y2,z2],[x1,y1,z2],[x2,y1,z2],[x2,y2,z2]], shade: 0.82, defUv: [x1, 16-y2, x2, 16-y1] },
      west:  { verts: [[x1,y2,z1],[x1,y1,z1],[x1,y1,z2],[x1,y2,z2]], shade: 0.74, defUv: [z1, 16-y2, z2, 16-y1] },
      east:  { verts: [[x2,y2,z2],[x2,y1,z2],[x2,y1,z1],[x2,y2,z1]], shade: 0.78, defUv: [16-z2, 16-y2, 16-z1, 16-y1] },
      up:    { verts: [[x1,y2,z1],[x1,y2,z2],[x2,y2,z2],[x2,y2,z1]], shade: 1.00, defUv: [x1, z1, x2, z2] },
      down:  { verts: [[x1,y1,z2],[x1,y1,z1],[x2,y1,z1],[x2,y1,z2]], shade: 0.58, defUv: [x1, 16-z2, x2, 16-z1] }
    };
    for (const [fName, fSpec] of Object.entries(el.faces || {})) {
      const def = faceDefs[fName];
      if (!def) continue;
      const tex = getTex(fSpec.texture, md.textures || {});
      if (!tex) continue;
      const uv = fSpec.uv || def.defUv;
      let uvCorners = [[uv[0],uv[1]], [uv[0],uv[3]], [uv[2],uv[3]], [uv[2],uv[1]]];
      if (fSpec.rotation === 90) uvCorners = [uvCorners[1], uvCorners[2], uvCorners[3], uvCorners[0]];
      const pts = def.verts.map(v => {
        const rv = rotatePoint(v, el.rotation);
        return [rv[0] + offset[0], rv[1] + offset[1], rv[2] + offset[2]];
      });
      // Detect semi-transparent glass so we sort transparent faces AFTER opaque faces!
      const midU = Math.min(tex.w - 1, Math.max(0, Math.floor(((uv[0] + uv[2]) * 0.5 / 16) * tex.w)));
      const midV = Math.min(tex.h - 1, Math.max(0, Math.floor(((uv[1] + uv[3]) * 0.5 / 16) * tex.h)));
      const midA = tex.rgba[(midV * tex.w + midU) * 4 + 3];
      quads.push({ pts, uvCorners, tex, shade: def.shade, translucent: midA < 250 });
    }
  }
  return quads;
}

function renderScene(quads, camPos, lookAt, fovScale, W, H, outPath) {
  const rgba = new Uint8Array(W * H * 4);
  const zbuf = new Float32Array(W * H).fill(1e9);
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const i = (y * W + x) * 4;
      const g = 28 + Math.round((1 - y / H) * 18);
      rgba[i] = g; rgba[i+1] = g + 4; rgba[i+2] = g + 10; rgba[i+3] = 255;
    }
  }
  const fwd = norm(sub(lookAt, camPos));
  const right = norm(cross(fwd, [0, 1, 0]));
  const up = cross(right, fwd);

  const project = (p) => {
    const rel = sub(p, camPos);
    const cx = dot(rel, right), cy = dot(rel, up), cz = dot(rel, fwd);
    if (cz <= 0.5) return null;
    return [W * 0.5 + (cx / cz) * fovScale, H * 0.5 - (cy / cz) * fovScale, cz];
  };

  // Sort: opaque first, then translucent back-to-front!
  const sorted = [...quads].sort((a, b) => {
    if (a.translucent !== b.translucent) return a.translucent ? 1 : -1;
    const da = dot(sub(a.pts[0], camPos), fwd);
    const db = dot(sub(b.pts[0], camPos), fwd);
    return db - da;
  });

  const edge = (a, b, px, py) => (px - a[0]) * (b[1] - a[1]) - (py - a[1]) * (b[0] - a[0]);

  const drawTri = (p0, p1, p2, uv0, uv1, uv2, q) => {
    // Check both windings so rotated/double faces render cleanly from inspection angles
    let area = edge(p0, p1, p2[0], p2[1]);
    if (Math.abs(area) < 1e-4) return;
    if (area < 0) { [p1, p2] = [p2, p1]; [uv1, uv2] = [uv2, uv1]; area = -area; }
    const minX = Math.max(0, Math.floor(Math.min(p0[0], p1[0], p2[0])));
    const maxX = Math.min(W - 1, Math.ceil(Math.max(p0[0], p1[0], p2[0])));
    const minY = Math.max(0, Math.floor(Math.min(p0[1], p1[1], p2[1])));
    const maxY = Math.min(H - 1, Math.ceil(Math.max(p0[1], p1[1], p2[1])));

    for (let y = minY; y <= maxY; y++) {
      for (let x = minX; x <= maxX; x++) {
        const px = x + 0.5, py = y + 0.5;
        const w0 = edge(p1, p2, px, py);
        const w1 = edge(p2, p0, px, py);
        const w2 = edge(p0, p1, px, py);
        if (w0 < 0 || w1 < 0 || w2 < 0) continue;
        // Perspective-correct interpolation!
        const iz0 = 1 / p0[2], iz1 = 1 / p1[2], iz2 = 1 / p2[2];
        const b0 = w0 / area, b1 = w1 / area, b2 = w2 / area;
        const invZ = b0 * iz0 + b1 * iz1 + b2 * iz2;
        const z = 1 / invZ;
        const bi = y * W + x;
        if (z > zbuf[bi]) continue;

        const u = ((b0 * uv0[0] * iz0 + b1 * uv1[0] * iz1 + b2 * uv2[0] * iz2) * z) / 16.0;
        const v = ((b0 * uv0[1] * iz0 + b1 * uv1[1] * iz1 + b2 * uv2[1] * iz2) * z) / 16.0;
        const tx = Math.min(q.tex.w - 1, Math.max(0, Math.floor(u * q.tex.w)));
        const ty = Math.min(q.tex.h - 1, Math.max(0, Math.floor(v * q.tex.h)));
        const ti = (ty * q.tex.w + tx) * 4;
        const a = q.tex.rgba[ti + 3] / 255.0;
        if (a < 0.02) continue;

        const oi = bi * 4;
        const r = q.tex.rgba[ti] * q.shade;
        const g = q.tex.rgba[ti + 1] * q.shade;
        const b = q.tex.rgba[ti + 2] * q.shade;
        if (a >= 0.98) {
          zbuf[bi] = z;
          rgba[oi] = r; rgba[oi+1] = g; rgba[oi+2] = b; rgba[oi+3] = 255;
        } else {
          rgba[oi]   = rgba[oi]   * (1 - a) + r * a;
          rgba[oi+1] = rgba[oi+1] * (1 - a) + g * a;
          rgba[oi+2] = rgba[oi+2] * (1 - a) + b * a;
        }
      }
    }
  };

  for (const q of sorted) {
    const sp = q.pts.map(project);
    if (sp.some(x => !x)) continue;
    drawTri(sp[0], sp[1], sp[2], q.uvCorners[0], q.uvCorners[1], q.uvCorners[2], q);
    drawTri(sp[0], sp[2], sp[3], q.uvCorners[0], q.uvCorners[2], q.uvCorners[3], q);
  }
  savePng(outPath, W, H, rgba);
}

// Render Composite Showcase Sheet:
// 1. 2-Block Vending Machine + 2-Block Info Kiosk + Safety Cabinet side-by-side!
{
  const scene1 = [
    ...collectModelQuads('vending_machine_lower.json', [0, 0, 0]),
    ...collectModelQuads('vending_machine_upper.json', [0, 16, 0]),
    ...collectModelQuads('info_kiosk_lower.json', [22, 0, 0]),
    ...collectModelQuads('info_kiosk_upper.json', [22, 16, 0]),
    ...collectModelQuads('safety_cabinet.json', [42, 8, 0])
  ];
  renderScene(scene1, [20, 23, -46], [26, 15, 8], 560, 720, 480, path.join(OUT_DIR, 'machines_3d.png'));
}

// 2. 3-Block Connected Bench (left + middle + right) + 4 Ad Lightbox Posters!
{
  const scene2 = [
    ...collectModelQuads('metro_bench_left.json',   [4, 0, 0]),
    ...collectModelQuads('metro_bench_middle.json', [20, 0, 0]),
    ...collectModelQuads('metro_bench_right.json',  [36, 0, 0]),
    ...collectModelQuads('ad_lightbox.json',   [-4, 18, 12]),
    ...collectModelQuads('ad_lightbox_1.json', [14, 18, 12]),
    ...collectModelQuads('ad_lightbox_2.json', [32, 18, 12]),
    ...collectModelQuads('ad_lightbox_3.json', [50, 18, 12])
  ];
  renderScene(scene2, [24, 22, -48], [27, 15, 8], 540, 720, 480, path.join(OUT_DIR, 'bench_and_posters_3d.png'));
}

console.log('Rendered 3D software-rasterized previews to', OUT_DIR);

#!/usr/bin/env node
/**
 * Live JVM Bytecode Compiler, Remapper & Hot-Patch Injector (v7.6.0)
 * Usage:
 *   node tools/inject_patch.js <JavaFilePath> [fully.qualified.EntryClass]
 * Compiles against named MC 1.20.4 + MTR 4.0.5 + named-v760.jar, remaps to intermediary,
 * and injects directly into the running Minecraft JVM via POST /api/map {"hotpatch": {"op": "load_jar", ...}}!
 */
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

async function main() {
  const srcFile = path.resolve(process.argv[2]);
  const entryClass = process.argv[3] || 'ai.arena.bridge.hotpatch.LivePatchImpl';
  const workDir = '/tmp/mcbuild/hotpatch-work';
  fs.rmSync(workDir, { recursive: true, force: true });
  fs.mkdirSync(path.join(workDir, 'classes'), { recursive: true });

  const fapiJars = fs.readdirSync('/tmp/mcbuild/fapi-named').filter(f => f.endsWith('.jar')).map(f => `/tmp/mcbuild/fapi-named/${f}`);
  const libJars = fs.readdirSync('/tmp/mcbuild/libs').filter(f => f.endsWith('.jar')).map(f => `/tmp/mcbuild/libs/${f}`);
  const cp = [
    '/tmp/mcbuild/named-v770.jar',
    '/tmp/mcbuild/mc-1.20.4-named.jar',
    '/tmp/mcbuild/mtr-4.0.5.jar',
    ...fapiJars,
    ...libJars
  ].join(':');

  execSync(`/tmp/mcbuild/jdk17/bin/javac -proc:none --release 17 -encoding UTF-8 -cp "${cp}" -d "${workDir}/classes" "${srcFile}"`, { stdio: 'inherit' });
  execSync(`/tmp/mcbuild/jdk17/bin/jar cf "${workDir}/named-patch.jar" -C "${workDir}/classes" .`, { stdio: 'inherit' });

  execSync([
    '/tmp/mcbuild/jdk17/bin/java -jar /tmp/mcbuild/tiny-remapper.jar',
    `"${workDir}/named-patch.jar"`,
    `"${workDir}/remapped-patch.jar"`,
    '/tmp/mcbuild/yarn.tiny named intermediary',
    '/tmp/mcbuild/named-v770.jar',
    '/tmp/mcbuild/mc-1.20.4-named.jar',
    '/tmp/mcbuild/mtr-4.0.5.jar',
    ...fapiJars,
    ...libJars
  ].join(' '), { stdio: 'inherit' });

  const jarB64 = fs.readFileSync(`${workDir}/remapped-patch.jar`).toString('base64');
  const res = await fetch('http://127.0.0.1:8080/api/map', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      hotpatch: {
        op: 'load_jar',
        entryClass,
        jarBase64: jarB64
      }
    })
  }).then(r => r.json());
  console.log('HOTPATCH RESULT:', JSON.stringify(res, null, 2));
}

main().catch(e => {
  console.error(e);
  process.exit(1);
});

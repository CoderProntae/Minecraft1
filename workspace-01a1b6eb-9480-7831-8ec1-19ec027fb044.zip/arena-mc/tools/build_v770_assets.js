#!/usr/bin/env node
/**
 * Builds v7.7.0 assets:
 * 1. Real recorded mono 44.1kHz Ogg Vorbis alarm sound (tunnel_alarm_beep.ogg) + sounds.json
 * 2. Native GPU animated 16x32 red emergency LED texture (led_red_emergency.png + .mcmeta)
 *    + tunnel_emergency_light_ceiling_red.json / wall_red.json + blockstates/tunnel_emergency_light.json
 * 3. Custom UV-synced 3D models for programmable_board (wall, stand, poster, gantry) + blockstates + item + lang
 */
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const ASSET_ROOT = '/home/user/arena-mc/mod-src/assets/arena_ai_bridge';

function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c ^= buf[i];
    for (let k = 0; k < 8; k++) c = (c >>> 1) ^ (0xedb88320 & -(c & 1));
  }
  return (c ^ 0xffffffff) >>> 0;
}

function pngChunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const t = Buffer.from(type, 'ascii');
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(Buffer.concat([t, data])), 0);
  return Buffer.concat([len, t, data, crc]);
}

function writeRgbaPng(filePath, w, h, rgba) {
  const raw = Buffer.alloc(h * (1 + w * 4));
  for (let y = 0; y < h; y++) {
    raw[y * (1 + w * 4)] = 0;
    rgba.copy(raw, y * (1 + w * 4) + 1, y * w * 4, (y + 1) * w * 4);
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0);
  ihdr.writeUInt32BE(h, 4);
  ihdr[8] = 8;
  ihdr[9] = 6;
  const out = Buffer.concat([
    Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
    pngChunk('IHDR', ihdr),
    pngChunk('IDAT', zlib.deflateSync(raw, { level: 9 })),
    pngChunk('IEND', Buffer.alloc(0))
  ]);
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, out);
}

// 1. Copy real recorded mono 44.1 kHz Ogg Vorbis alarm beep + write sounds.json
const soundDir = path.join(ASSET_ROOT, 'sounds');
fs.mkdirSync(soundDir, { recursive: true });
fs.copyFileSync(
  '/tmp/mcbuild/mtr-sounds/assets/mtr/sounds/ticket_processor_fail.ogg',
  path.join(soundDir, 'tunnel_alarm_beep.ogg')
);
fs.writeFileSync(
  path.join(ASSET_ROOT, 'sounds.json'),
  JSON.stringify({
    tunnel_alarm_beep: {
      subtitle: 'Tünel yapısal acil durum alarmı',
      sounds: [
        {
          name: 'arena_ai_bridge:tunnel_alarm_beep',
          stream: false,
          volume: 0.9,
          pitch: 1.0,
          attenuation_distance: 28
        }
      ]
    }
  }, null, 2)
);

// 2. Build 16x32 native GPU-animated red emergency LED diffuser texture (2 frames of 16x16, POT!)
const W = 16, H = 32;
const ledBuf = Buffer.alloc(W * H * 4);
for (let frame = 0; frame < 2; frame++) {
  for (let y = 0; y < 16; y++) {
    for (let x = 0; x < 16; x++) {
      const yy = frame * 16 + y;
      const idx = (yy * W + x) * 4;
      const cx = Math.abs(x - 7.5) / 7.5;
      const rib = ((y % 2) === 0) ? 1.0 : 0.91;
      if (frame === 0) {
        // Frame 0 (ON): intense crimson-scarlet emergency diffuser with glowing diode core
        const glow = Math.max(0, 1.0 - cx * 0.58) * rib;
        ledBuf[idx]     = Math.min(255, Math.round(215 + 40 * glow));
        ledBuf[idx + 1] = Math.min(255, Math.round(14 + 52 * Math.pow(glow, 2.2)));
        ledBuf[idx + 2] = Math.min(255, Math.round(22 + 44 * Math.pow(glow, 2.2)));
        ledBuf[idx + 3] = 255;
      } else {
        // Frame 1 (OFF): dark unlit ruby polycarbonate housing lens
        const dim = (1.0 - cx * 0.35) * rib;
        ledBuf[idx]     = Math.round(42 * dim);
        ledBuf[idx + 1] = Math.round(7 * dim);
        ledBuf[idx + 2] = Math.round(10 * dim);
        ledBuf[idx + 3] = 255;
      }
    }
  }
}
const redPngPath = path.join(ASSET_ROOT, 'textures/block/led_red_emergency.png');
writeRgbaPng(redPngPath, W, H, ledBuf);
fs.writeFileSync(
  redPngPath + '.mcmeta',
  JSON.stringify({
    animation: {
      frametime: 10,
      interpolate: false,
      frames: [0, 1]
    }
  }, null, 2)
);

// Clone ceiling & wall tunnel light models to red emergency variants
for (const kind of ['ceiling', 'wall']) {
  const baseModel = JSON.parse(fs.readFileSync(
    path.join(ASSET_ROOT, `models/block/tunnel_emergency_light_${kind}.json`), 'utf8'
  ));
  baseModel.textures.led = 'arena_ai_bridge:block/led_red_emergency';
  baseModel.textures.particle = 'arena_ai_bridge:block/led_red_emergency';
  fs.writeFileSync(
    path.join(ASSET_ROOT, `models/block/tunnel_emergency_light_${kind}_red.json`),
    JSON.stringify(baseModel, null, 2)
  );
}

// Update blockstates/tunnel_emergency_light.json so emergency=true switches to _red GPU-animated models!
const telVariants = {};
const yMap = { north: 0, east: 90, south: 180, west: 270 };
for (const ceil of [true, false]) {
  for (const emg of [false, true]) {
    for (const [dir, yRot] of Object.entries(yMap)) {
      const key = `ceiling=${ceil},emergency=${emg},facing=${dir}`;
      const modelBase = ceil
        ? (emg ? 'arena_ai_bridge:block/tunnel_emergency_light_ceiling_red' : 'arena_ai_bridge:block/tunnel_emergency_light_ceiling')
        : (emg ? 'arena_ai_bridge:block/tunnel_emergency_light_wall_red' : 'arena_ai_bridge:block/tunnel_emergency_light_wall');
      telVariants[key] = yRot === 0 ? { model: modelBase } : { model: modelBase, y: yRot };
    }
  }
}
fs.writeFileSync(
  path.join(ASSET_ROOT, 'blockstates/tunnel_emergency_light.json'),
  JSON.stringify({ variants: telVariants }, null, 2)
);

// 3. Build custom 64x64 brushed_steel.png & led_cyan_accent.png + 4 custom 3D models for programmable_board!
const steelBuf = Buffer.alloc(64 * 64 * 4);
for (let y = 0; y < 64; y++) {
  for (let x = 0; x < 64; x++) {
    const idx = (y * 64 + x) * 4;
    const streak = Math.sin(x * 0.45 + y * 0.08) * 7 + (((x * 13 + y * 7) % 9) - 4);
    const bevel = (x < 2 || y < 2) ? 18 : ((x > 61 || y > 61) ? -18 : 0);
    const base = Math.max(48, Math.min(215, Math.round(118 + streak + bevel)));
    steelBuf[idx]     = base;
    steelBuf[idx + 1] = Math.min(255, base + 4);
    steelBuf[idx + 2] = Math.min(255, base + 10);
    steelBuf[idx + 3] = 255;
  }
}
writeRgbaPng(path.join(ASSET_ROOT, 'textures/block/brushed_steel.png'), 64, 64, steelBuf);

const cyanBuf = Buffer.alloc(16 * 16 * 4);
for (let y = 0; y < 16; y++) {
  for (let x = 0; x < 16; x++) {
    const idx = (y * 16 + x) * 4;
    const g = 1.0 - (Math.abs(y - 7.5) / 9.5) * 0.35;
    cyanBuf[idx]     = Math.round(24 * g);
    cyanBuf[idx + 1] = Math.min(255, Math.round(212 * g));
    cyanBuf[idx + 2] = Math.min(255, Math.round(238 * g));
    cyanBuf[idx + 3] = 255;
  }
}
writeRgbaPng(path.join(ASSET_ROOT, 'textures/block/led_cyan_accent.png'), 16, 16, cyanBuf);

function box(from, to, texMap) {
  const faces = {};
  for (const f of ['north', 'south', 'east', 'west', 'up', 'down']) {
    faces[f] = { texture: texMap[f] || texMap.all || '#frame' };
  }
  return { from, to, faces };
}

const commonTex = {
  particle: 'arena_ai_bridge:block/dark_titanium',
  frame: 'arena_ai_bridge:block/dark_titanium',
  steel: 'arena_ai_bridge:block/brushed_steel',
  accent: 'arena_ai_bridge:block/led_cyan_accent',
  screen: 'arena_ai_bridge:block/map_oled_screen'
};

const wallModel = {
  textures: commonTex,
  elements: [
    box([0.5, 1.0, 14.4], [15.5, 15.0, 16.0], { all: '#frame', north: '#screen' }),
    box([0.2, 14.5, 14.0], [15.8, 15.3, 16.0], { all: '#frame' }),
    box([0.2, 0.7, 14.0], [15.8, 1.5, 16.0], { all: '#frame' }),
    box([4.0, 15.3, 14.3], [12.0, 15.6, 15.4], { all: '#accent' })
  ]
};

const standModel = {
  textures: commonTex,
  elements: [
    // Heavy base plate + twin brushed steel pedestal legs + top display housing
    box([1.5, 0.0, 5.0], [14.5, 1.2, 11.0], { all: '#frame' }),
    box([2.5, 1.2, 7.2], [4.1, 6.0, 8.8], { all: '#steel' }),
    box([11.9, 1.2, 7.2], [13.5, 6.0, 8.8], { all: '#steel' }),
    box([0.6, 5.5, 6.6], [15.4, 15.6, 9.4], { all: '#frame', north: '#screen', south: '#frame' }),
    box([3.0, 15.6, 6.9], [13.0, 16.0, 9.1], { all: '#accent' })
  ]
};

const posterModel = {
  textures: commonTex,
  elements: [
    // Vertical backlit mupi / city-light poster totem
    box([2.0, 0.0, 5.5], [14.0, 1.4, 10.5], { all: '#steel' }),
    box([1.5, 1.4, 6.4], [14.5, 15.8, 9.6], { all: '#frame', north: '#screen', south: '#screen' }),
    box([2.5, 15.8, 6.8], [13.5, 16.0, 9.2], { all: '#accent' })
  ]
};

const gantryModel = {
  textures: commonTex,
  elements: [
    // Heavy highway / transit gantry steel space-frame truss + sign mount
    box([0.0, 11.5, 11.5], [16.0, 13.3, 15.5], { all: '#steel' }),
    box([0.0, 2.5, 11.5], [16.0, 4.3, 15.5], { all: '#steel' }),
    box([1.5, 4.3, 12.2], [3.3, 11.5, 14.8], { all: '#steel' }),
    box([12.7, 4.3, 12.2], [14.5, 11.5, 14.8], { all: '#steel' }),
    box([0.2, 1.0, 9.6], [15.8, 15.0, 11.5], { all: '#frame', north: '#screen' })
  ]
};

const modelsMap = {
  wall: wallModel,
  stand: standModel,
  poster: posterModel,
  gantry: gantryModel
};
for (const [style, mdl] of Object.entries(modelsMap)) {
  fs.writeFileSync(
    path.join(ASSET_ROOT, `models/block/programmable_board_${style}.json`),
    JSON.stringify(mdl, null, 2)
  );
}

const pbVariants = {};
for (const style of ['wall', 'stand', 'poster', 'gantry']) {
  for (const [dir, yRot] of Object.entries(yMap)) {
    const k = `facing=${dir},mount=${style}`;
    const m = `arena_ai_bridge:block/programmable_board_${style}`;
    pbVariants[k] = yRot === 0 ? { model: m } : { model: m, y: yRot };
  }
}
fs.writeFileSync(
  path.join(ASSET_ROOT, 'blockstates/programmable_board.json'),
  JSON.stringify({ variants: pbVariants }, null, 2)
);
fs.writeFileSync(
  path.join(ASSET_ROOT, 'models/item/programmable_board.json'),
  JSON.stringify({ parent: 'arena_ai_bridge:block/programmable_board_stand' }, null, 2)
);

// Update lang files
for (const [loc, label, integrityLabel, radarKey] of [
  ['tr_tr', 'Yüzey Hattı & Plan Panosu (Çok Boyutlu)', 'Yapısal Bütünlük Haritası', 'Jeoteknik ve Yapısal Radar'],
  ['en_us', 'Surface Line & Plans Board (Multi-Size)', 'Structural Integrity Map', 'Geotechnical & Structural Radar']
]) {
  const lp = path.join(ASSET_ROOT, `lang/${loc}.json`);
  const j = fs.existsSync(lp) ? JSON.parse(fs.readFileSync(lp, 'utf8')) : {};
  j['block.arena_ai_bridge.programmable_board'] = label;
  j['block.arena_ai_bridge.transit_news_board'] = integrityLabel;
  j['key.arena_ai_bridge.toggle_radar'] = radarKey;
  fs.writeFileSync(lp, JSON.stringify(j, null, 2));
}

console.log('v7.7.0 assets generated cleanly!');
